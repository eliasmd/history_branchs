package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;

public class LoginDTO {

	private String result;

	private AuthenticationDTO authentication;

	private CompanyDTO company;

	private List<String> messages;

	private String code;

	public LoginDTO() {

	}

	public LoginDTO(AuthenticationDTO authentication) {
		this.authentication = authentication;
	}

	public AuthenticationDTO getAuthentication() {
		return authentication;
	}

	public void setAuthentication(AuthenticationDTO authentication) {
		this.authentication = authentication;
	}

	public CompanyDTO getCompany() {
		return company;
	}

	public void setCompany(CompanyDTO company) {
		this.company = company;
	}

	public List<String> getMessages() {
		return messages;
	}

	public void setMessages(List<String> messages) {
		this.messages = messages;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
