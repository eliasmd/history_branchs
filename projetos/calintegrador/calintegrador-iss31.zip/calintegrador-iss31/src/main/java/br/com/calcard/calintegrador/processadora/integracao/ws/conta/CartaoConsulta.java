/**
 * CartaoConsulta.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public class CartaoConsulta  implements java.io.Serializable {
    private int IDConta;

    private int IDCartao;

    private java.lang.String numCartao;

    private java.lang.String CPFPortador;

    private java.lang.String CPFTitular;

    private int statusCartao;

    private java.lang.String dataCadastroCartao;

    private java.lang.String senhaCartao;

    private java.lang.String dataValidade;

    private java.lang.String nomePortador;

    private java.lang.String CVV2;

    private java.lang.String titularidade;

    public CartaoConsulta() {
    }

    public CartaoConsulta(
           int IDConta,
           int IDCartao,
           java.lang.String numCartao,
           java.lang.String CPFPortador,
           java.lang.String CPFTitular,
           int statusCartao,
           java.lang.String dataCadastroCartao,
           java.lang.String senhaCartao,
           java.lang.String dataValidade,
           java.lang.String nomePortador,
           java.lang.String CVV2,
           java.lang.String titularidade) {
           this.IDConta = IDConta;
           this.IDCartao = IDCartao;
           this.numCartao = numCartao;
           this.CPFPortador = CPFPortador;
           this.CPFTitular = CPFTitular;
           this.statusCartao = statusCartao;
           this.dataCadastroCartao = dataCadastroCartao;
           this.senhaCartao = senhaCartao;
           this.dataValidade = dataValidade;
           this.nomePortador = nomePortador;
           this.CVV2 = CVV2;
           this.titularidade = titularidade;
    }


    /**
     * Gets the IDConta value for this CartaoConsulta.
     * 
     * @return IDConta
     */
    public int getIDConta() {
        return IDConta;
    }


    /**
     * Sets the IDConta value for this CartaoConsulta.
     * 
     * @param IDConta
     */
    public void setIDConta(int IDConta) {
        this.IDConta = IDConta;
    }


    /**
     * Gets the IDCartao value for this CartaoConsulta.
     * 
     * @return IDCartao
     */
    public int getIDCartao() {
        return IDCartao;
    }


    /**
     * Sets the IDCartao value for this CartaoConsulta.
     * 
     * @param IDCartao
     */
    public void setIDCartao(int IDCartao) {
        this.IDCartao = IDCartao;
    }


    /**
     * Gets the numCartao value for this CartaoConsulta.
     * 
     * @return numCartao
     */
    public java.lang.String getNumCartao() {
        return numCartao;
    }


    /**
     * Sets the numCartao value for this CartaoConsulta.
     * 
     * @param numCartao
     */
    public void setNumCartao(java.lang.String numCartao) {
        this.numCartao = numCartao;
    }


    /**
     * Gets the CPFPortador value for this CartaoConsulta.
     * 
     * @return CPFPortador
     */
    public java.lang.String getCPFPortador() {
        return CPFPortador;
    }


    /**
     * Sets the CPFPortador value for this CartaoConsulta.
     * 
     * @param CPFPortador
     */
    public void setCPFPortador(java.lang.String CPFPortador) {
        this.CPFPortador = CPFPortador;
    }


    /**
     * Gets the CPFTitular value for this CartaoConsulta.
     * 
     * @return CPFTitular
     */
    public java.lang.String getCPFTitular() {
        return CPFTitular;
    }


    /**
     * Sets the CPFTitular value for this CartaoConsulta.
     * 
     * @param CPFTitular
     */
    public void setCPFTitular(java.lang.String CPFTitular) {
        this.CPFTitular = CPFTitular;
    }


    /**
     * Gets the statusCartao value for this CartaoConsulta.
     * 
     * @return statusCartao
     */
    public int getStatusCartao() {
        return statusCartao;
    }


    /**
     * Sets the statusCartao value for this CartaoConsulta.
     * 
     * @param statusCartao
     */
    public void setStatusCartao(int statusCartao) {
        this.statusCartao = statusCartao;
    }


    /**
     * Gets the dataCadastroCartao value for this CartaoConsulta.
     * 
     * @return dataCadastroCartao
     */
    public java.lang.String getDataCadastroCartao() {
        return dataCadastroCartao;
    }


    /**
     * Sets the dataCadastroCartao value for this CartaoConsulta.
     * 
     * @param dataCadastroCartao
     */
    public void setDataCadastroCartao(java.lang.String dataCadastroCartao) {
        this.dataCadastroCartao = dataCadastroCartao;
    }


    /**
     * Gets the senhaCartao value for this CartaoConsulta.
     * 
     * @return senhaCartao
     */
    public java.lang.String getSenhaCartao() {
        return senhaCartao;
    }


    /**
     * Sets the senhaCartao value for this CartaoConsulta.
     * 
     * @param senhaCartao
     */
    public void setSenhaCartao(java.lang.String senhaCartao) {
        this.senhaCartao = senhaCartao;
    }


    /**
     * Gets the dataValidade value for this CartaoConsulta.
     * 
     * @return dataValidade
     */
    public java.lang.String getDataValidade() {
        return dataValidade;
    }


    /**
     * Sets the dataValidade value for this CartaoConsulta.
     * 
     * @param dataValidade
     */
    public void setDataValidade(java.lang.String dataValidade) {
        this.dataValidade = dataValidade;
    }


    /**
     * Gets the nomePortador value for this CartaoConsulta.
     * 
     * @return nomePortador
     */
    public java.lang.String getNomePortador() {
        return nomePortador;
    }


    /**
     * Sets the nomePortador value for this CartaoConsulta.
     * 
     * @param nomePortador
     */
    public void setNomePortador(java.lang.String nomePortador) {
        this.nomePortador = nomePortador;
    }


    /**
     * Gets the CVV2 value for this CartaoConsulta.
     * 
     * @return CVV2
     */
    public java.lang.String getCVV2() {
        return CVV2;
    }


    /**
     * Sets the CVV2 value for this CartaoConsulta.
     * 
     * @param CVV2
     */
    public void setCVV2(java.lang.String CVV2) {
        this.CVV2 = CVV2;
    }


    /**
     * Gets the titularidade value for this CartaoConsulta.
     * 
     * @return titularidade
     */
    public java.lang.String getTitularidade() {
        return titularidade;
    }


    /**
     * Sets the titularidade value for this CartaoConsulta.
     * 
     * @param titularidade
     */
    public void setTitularidade(java.lang.String titularidade) {
        this.titularidade = titularidade;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CartaoConsulta)) return false;
        CartaoConsulta other = (CartaoConsulta) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.IDConta == other.getIDConta() &&
            this.IDCartao == other.getIDCartao() &&
            ((this.numCartao==null && other.getNumCartao()==null) || 
             (this.numCartao!=null &&
              this.numCartao.equals(other.getNumCartao()))) &&
            ((this.CPFPortador==null && other.getCPFPortador()==null) || 
             (this.CPFPortador!=null &&
              this.CPFPortador.equals(other.getCPFPortador()))) &&
            ((this.CPFTitular==null && other.getCPFTitular()==null) || 
             (this.CPFTitular!=null &&
              this.CPFTitular.equals(other.getCPFTitular()))) &&
            this.statusCartao == other.getStatusCartao() &&
            ((this.dataCadastroCartao==null && other.getDataCadastroCartao()==null) || 
             (this.dataCadastroCartao!=null &&
              this.dataCadastroCartao.equals(other.getDataCadastroCartao()))) &&
            ((this.senhaCartao==null && other.getSenhaCartao()==null) || 
             (this.senhaCartao!=null &&
              this.senhaCartao.equals(other.getSenhaCartao()))) &&
            ((this.dataValidade==null && other.getDataValidade()==null) || 
             (this.dataValidade!=null &&
              this.dataValidade.equals(other.getDataValidade()))) &&
            ((this.nomePortador==null && other.getNomePortador()==null) || 
             (this.nomePortador!=null &&
              this.nomePortador.equals(other.getNomePortador()))) &&
            ((this.CVV2==null && other.getCVV2()==null) || 
             (this.CVV2!=null &&
              this.CVV2.equals(other.getCVV2()))) &&
            ((this.titularidade==null && other.getTitularidade()==null) || 
             (this.titularidade!=null &&
              this.titularidade.equals(other.getTitularidade())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getIDConta();
        _hashCode += getIDCartao();
        if (getNumCartao() != null) {
            _hashCode += getNumCartao().hashCode();
        }
        if (getCPFPortador() != null) {
            _hashCode += getCPFPortador().hashCode();
        }
        if (getCPFTitular() != null) {
            _hashCode += getCPFTitular().hashCode();
        }
        _hashCode += getStatusCartao();
        if (getDataCadastroCartao() != null) {
            _hashCode += getDataCadastroCartao().hashCode();
        }
        if (getSenhaCartao() != null) {
            _hashCode += getSenhaCartao().hashCode();
        }
        if (getDataValidade() != null) {
            _hashCode += getDataValidade().hashCode();
        }
        if (getNomePortador() != null) {
            _hashCode += getNomePortador().hashCode();
        }
        if (getCVV2() != null) {
            _hashCode += getCVV2().hashCode();
        }
        if (getTitularidade() != null) {
            _hashCode += getTitularidade().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CartaoConsulta.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "CartaoConsulta"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IDConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IDCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CPFPortador");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CPFPortador"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CPFTitular");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CPFTitular"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "StatusCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataCadastroCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DataCadastroCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senhaCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "SenhaCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataValidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DataValidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePortador");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NomePortador"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CVV2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CVV2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("titularidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Titularidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
