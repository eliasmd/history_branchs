package br.com.calcard.calintegrador.motorFraude.service;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.springframework.stereotype.Service;

import br.com.calcard.calintegrador.dto.LogIntegracaoDTO;
import br.com.calcard.calintegrador.enums.NomeIntegracaoEnum;
import br.com.calcard.calintegrador.motorFraude.dto.ClearSaleDTO;
import br.com.calcard.calintegrador.motorFraude.dto.OrderDTO;
import br.com.calcard.calintegrador.motorFraude.dto.RespostaAnaliseDTO;
import br.com.calcard.calintegrador.motorFraude.exception.IntegracaoFraudeException;
import br.com.calcard.calintegrador.motorFraude.integracao.ServiceSoapProxy;

@Service
public class MotorFraudeIntegradorService {

	public List<RespostaAnaliseDTO> doTraduzirRespostaAnalise(
			String xmlRespostaAnalise) throws IntegracaoFraudeException {

		try {

			List<RespostaAnaliseDTO> resposta = new ArrayList<RespostaAnaliseDTO>();

			JAXBContext jaxbContext = JAXBContext
					.newInstance(ClearSaleDTO.class);

			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

			ClearSaleDTO clearSaleDTO = (ClearSaleDTO) unmarshaller
					.unmarshal(new StringReader(xmlRespostaAnalise));

			for (OrderDTO order : clearSaleDTO.getOrders())
				resposta.add(new RespostaAnaliseDTO(Integer.parseInt(order
						.getIdProposta()), order.getStatus(), Double
						.parseDouble(order.getScore()), null));

			return resposta;

		} catch (JAXBException e) {
			throw new IntegracaoFraudeException(
					"N�o foi poss�vel consultar a ClearSale", e);
		}

	}

	public LogIntegracaoDTO doConsultarRespostaAnalise(String entityCode)
			throws IntegracaoFraudeException {

		ServiceSoapProxy serviceProxy = new ServiceSoapProxy();

		try {

			final String NOME_SERVICO_EXECUTADO = "getReturnAnalysis";

			LogIntegracaoDTO logIntegracao = new LogIntegracaoDTO();

			logIntegracao.setDataRequisicao(new Date());

			logIntegracao.setNomeServico(NOME_SERVICO_EXECUTADO);

			logIntegracao
					.setNome(NomeIntegracaoEnum.CONSULTAR_RESPOTA_ANALISE_MOTOR_FRAUDE);

			logIntegracao.setRequisicao(entityCode);

			String xmlResposta = serviceProxy.getReturnAnalysis(entityCode);

			logIntegracao.setDataResposta(new Date());

			logIntegracao.setResposta(xmlResposta);

			return logIntegracao;

		} catch (IOException e) {
			throw new IntegracaoFraudeException(
					"N�o foi poss�vel consultar a ClearSale", e);
		}

	}

	public LogIntegracaoDTO doEnviarProposta(ClearSaleDTO dto, String entityCode)
			throws IntegracaoFraudeException {

		try {

			final String NOME_SERVICO_EXECUTADO = "sendOrders";

			StringWriter out = new StringWriter();

			JAXBContext jaxbContext = JAXBContext
					.newInstance(ClearSaleDTO.class);

			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			jaxbMarshaller.marshal(dto, out);

			String xmlRequisicao = this.doFormatarXmlRequisicao(out);

			ServiceSoapProxy serviceProxy = new ServiceSoapProxy();

			LogIntegracaoDTO logIntegracaoDTO = new LogIntegracaoDTO();

			logIntegracaoDTO.setNomeServico(NOME_SERVICO_EXECUTADO);

			logIntegracaoDTO
					.setNome(NomeIntegracaoEnum.ENVIAR_PROPOSTA_MOTOR_FRAUDE);

			logIntegracaoDTO.setRequisicao(xmlRequisicao);

			logIntegracaoDTO.setDataRequisicao(new Date());

			logIntegracaoDTO.setResposta(serviceProxy.sendOrders(entityCode,
					xmlRequisicao));

			logIntegracaoDTO.setDataResposta(new Date());

			return logIntegracaoDTO;

		} catch (RemoteException | JAXBException e) {
			throw new IntegracaoFraudeException(
					"N�o foi poss�vel consultar o motor de fraude!", e);
		}

	}

	private String doFormatarXmlRequisicao(StringWriter out) {

		return new StringBuilder()
				.append(out
						.toString()
						.replace(
								"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>",
								"")).toString().trim();

	}

	public LogIntegracaoDTO doFlegarPropostaRecebida(String entityCode,
			Integer idProposta) throws IntegracaoFraudeException {

		try {

			final String NOME_SERVICO_EXECUTADO = "setOrderAsReturned";

			LogIntegracaoDTO logIntegracao = new LogIntegracaoDTO();

			logIntegracao.setDataRequisicao(new Date());

			logIntegracao.setNomeServico(NOME_SERVICO_EXECUTADO);

			logIntegracao
					.setNome(NomeIntegracaoEnum.FLEGAR_PROPOSTA_RECEBIDA_MOTOR_FRAUDE);

			logIntegracao.setRequisicao(new StringBuilder()
					.append("{ entityCode : ").append(entityCode)
					.append(", orderID: ").append(idProposta).append(" }")
					.toString());

			ServiceSoapProxy serviceProxy = new ServiceSoapProxy();

			String resposta = serviceProxy.setOrderAsReturned(entityCode,
					String.valueOf(idProposta));

			logIntegracao.setResposta(resposta);

			logIntegracao.setDataResposta(new Date());

			return logIntegracao;

		} catch (RemoteException e) {
			throw new IntegracaoFraudeException(
					"N�o foi poss�vel comunicar com o motor de fraude!", e);
		}

	}

}
