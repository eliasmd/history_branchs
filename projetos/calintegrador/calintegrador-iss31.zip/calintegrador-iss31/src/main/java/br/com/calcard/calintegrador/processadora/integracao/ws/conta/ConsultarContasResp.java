/**
 * ConsultarContasResp.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public class ConsultarContasResp  implements java.io.Serializable {
    private ContaCartao[] contaCartao;

    private int codRetorno;

    private java.lang.String descricaoRetorno;

    public ConsultarContasResp() {
    }

    public ConsultarContasResp(
           ContaCartao[] contaCartao,
           int codRetorno,
           java.lang.String descricaoRetorno) {
           this.contaCartao = contaCartao;
           this.codRetorno = codRetorno;
           this.descricaoRetorno = descricaoRetorno;
    }


    /**
     * Gets the contaCartao value for this ConsultarContasResp.
     * 
     * @return contaCartao
     */
    public ContaCartao[] getContaCartao() {
        return contaCartao;
    }


    /**
     * Sets the contaCartao value for this ConsultarContasResp.
     * 
     * @param contaCartao
     */
    public void setContaCartao(ContaCartao[] contaCartao) {
        this.contaCartao = contaCartao;
    }

    public ContaCartao getContaCartao(int i) {
        return this.contaCartao[i];
    }

    public void setContaCartao(int i, ContaCartao _value) {
        this.contaCartao[i] = _value;
    }


    /**
     * Gets the codRetorno value for this ConsultarContasResp.
     * 
     * @return codRetorno
     */
    public int getCodRetorno() {
        return codRetorno;
    }


    /**
     * Sets the codRetorno value for this ConsultarContasResp.
     * 
     * @param codRetorno
     */
    public void setCodRetorno(int codRetorno) {
        this.codRetorno = codRetorno;
    }


    /**
     * Gets the descricaoRetorno value for this ConsultarContasResp.
     * 
     * @return descricaoRetorno
     */
    public java.lang.String getDescricaoRetorno() {
        return descricaoRetorno;
    }


    /**
     * Sets the descricaoRetorno value for this ConsultarContasResp.
     * 
     * @param descricaoRetorno
     */
    public void setDescricaoRetorno(java.lang.String descricaoRetorno) {
        this.descricaoRetorno = descricaoRetorno;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarContasResp)) return false;
        ConsultarContasResp other = (ConsultarContasResp) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.contaCartao==null && other.getContaCartao()==null) || 
             (this.contaCartao!=null &&
              java.util.Arrays.equals(this.contaCartao, other.getContaCartao()))) &&
            this.codRetorno == other.getCodRetorno() &&
            ((this.descricaoRetorno==null && other.getDescricaoRetorno()==null) || 
             (this.descricaoRetorno!=null &&
              this.descricaoRetorno.equals(other.getDescricaoRetorno())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getContaCartao() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getContaCartao());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getContaCartao(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getCodRetorno();
        if (getDescricaoRetorno() != null) {
            _hashCode += getDescricaoRetorno().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarContasResp.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "ConsultarContasResp"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contaCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "ContaCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "ContaCartao"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CodRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DescricaoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
