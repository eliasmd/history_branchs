package br.com.calcard.calintegrador.processadora.integracao.ws.cartao;

public class CartaoSoapProxy implements br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoap {
  private String _endpoint = null;
  private br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoap cartaoSoap = null;
  
  public CartaoSoapProxy() {
    _initCartaoSoapProxy();
  }
  
  public CartaoSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initCartaoSoapProxy();
  }
  
  private void _initCartaoSoapProxy() {
    try {
      cartaoSoap = (new br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoLocator()).getCartaoSoap();
      if (cartaoSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)cartaoSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)cartaoSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (cartaoSoap != null)
      ((javax.xml.rpc.Stub)cartaoSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoap getCartaoSoap() {
    if (cartaoSoap == null)
      _initCartaoSoapProxy();
    return cartaoSoap;
  }
  
  public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.DesbloquearCartaoResp desbloquearCartao(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.DesbloquearCartaoReq req) throws java.rmi.RemoteException{
    if (cartaoSoap == null)
      _initCartaoSoapProxy();
    return cartaoSoap.desbloquearCartao(req);
  }
  
  public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CancelarCartaoResp cancelarCartao(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CancelarCartaoReq req) throws java.rmi.RemoteException{
    if (cartaoSoap == null)
      _initCartaoSoapProxy();
    return cartaoSoap.cancelarCartao(req);
  }
  
  public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastraAlteraSenhaResp cadastraAlteraSenha(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastraAlteraSenhaReq req) throws java.rmi.RemoteException{
    if (cartaoSoap == null)
      _initCartaoSoapProxy();
    return cartaoSoap.cadastraAlteraSenha(req);
  }
  
  public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.RecuperarSenhaResp recuperarSenha(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.RecuperarSenhaReq req) throws java.rmi.RemoteException{
    if (cartaoSoap == null)
      _initCartaoSoapProxy();
    return cartaoSoap.recuperarSenha(req);
  }
  
  public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.EsqueciSenhaCartaoResp esqueciSenhaCartao(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.EsqueciSenhaCartaoReq esqueciSenhaReq) throws java.rmi.RemoteException{
    if (cartaoSoap == null)
      _initCartaoSoapProxy();
    return cartaoSoap.esqueciSenhaCartao(esqueciSenhaReq);
  }
  
  public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.ConsultarCartaoEmbossingResp consultarCartaoEmbossing(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.ConsultarCartaoEmbossingReq req) throws java.rmi.RemoteException{
    if (cartaoSoap == null)
      _initCartaoSoapProxy();
    return cartaoSoap.consultarCartaoEmbossing(req);
  }
  
  public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastrarAlterarSenhaCartaoResp cadastrarAlterarSenhaCartao(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastrarAlterarSenhaCartaoReq req) throws java.rmi.RemoteException{
    if (cartaoSoap == null)
      _initCartaoSoapProxy();
    return cartaoSoap.cadastrarAlterarSenhaCartao(req);
  }
  
  
}