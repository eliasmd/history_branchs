/**
 * DesbloquearCartaoReq.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.cartao;

public class DesbloquearCartaoReq  implements java.io.Serializable {
    private int idConta;

    private java.lang.String codigoSeguranca;

    private java.lang.String cartao;

    public DesbloquearCartaoReq() {
    }

    public DesbloquearCartaoReq(
           int idConta,
           java.lang.String codigoSeguranca,
           java.lang.String cartao) {
           this.idConta = idConta;
           this.codigoSeguranca = codigoSeguranca;
           this.cartao = cartao;
    }


    /**
     * Gets the idConta value for this DesbloquearCartaoReq.
     * 
     * @return idConta
     */
    public int getIdConta() {
        return idConta;
    }


    /**
     * Sets the idConta value for this DesbloquearCartaoReq.
     * 
     * @param idConta
     */
    public void setIdConta(int idConta) {
        this.idConta = idConta;
    }


    /**
     * Gets the codigoSeguranca value for this DesbloquearCartaoReq.
     * 
     * @return codigoSeguranca
     */
    public java.lang.String getCodigoSeguranca() {
        return codigoSeguranca;
    }


    /**
     * Sets the codigoSeguranca value for this DesbloquearCartaoReq.
     * 
     * @param codigoSeguranca
     */
    public void setCodigoSeguranca(java.lang.String codigoSeguranca) {
        this.codigoSeguranca = codigoSeguranca;
    }


    /**
     * Gets the cartao value for this DesbloquearCartaoReq.
     * 
     * @return cartao
     */
    public java.lang.String getCartao() {
        return cartao;
    }


    /**
     * Sets the cartao value for this DesbloquearCartaoReq.
     * 
     * @param cartao
     */
    public void setCartao(java.lang.String cartao) {
        this.cartao = cartao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DesbloquearCartaoReq)) return false;
        DesbloquearCartaoReq other = (DesbloquearCartaoReq) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.idConta == other.getIdConta() &&
            ((this.codigoSeguranca==null && other.getCodigoSeguranca()==null) || 
             (this.codigoSeguranca!=null &&
              this.codigoSeguranca.equals(other.getCodigoSeguranca()))) &&
            ((this.cartao==null && other.getCartao()==null) || 
             (this.cartao!=null &&
              this.cartao.equals(other.getCartao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getIdConta();
        if (getCodigoSeguranca() != null) {
            _hashCode += getCodigoSeguranca().hashCode();
        }
        if (getCartao() != null) {
            _hashCode += getCartao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DesbloquearCartaoReq.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "DesbloquearCartaoReq"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "idConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSeguranca");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CodigoSeguranca"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Cartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
