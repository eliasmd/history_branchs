package br.com.calcard.calintegrador.dto;

public class StatusPropostasDTO {

	private Integer idIntegracao;

	private Integer idProposta;

	private String status;

	private Double score;

	public StatusPropostasDTO() {

	}

	public StatusPropostasDTO(Integer idIntegracao, Integer idProposta,
			String status, Double score) {
		super();
		this.idIntegracao = idIntegracao;
		this.setIdProposta(idProposta);
		this.status = status;
		this.score = score;
	}

	public Integer getIdIntegracao() {
		return idIntegracao;
	}

	public void setIdIntegracao(Integer idIntegracao) {
		this.idIntegracao = idIntegracao;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getIdProposta() {
		return idProposta;
	}

	public void setIdProposta(Integer idProposta) {
		this.idProposta = idProposta;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

}
