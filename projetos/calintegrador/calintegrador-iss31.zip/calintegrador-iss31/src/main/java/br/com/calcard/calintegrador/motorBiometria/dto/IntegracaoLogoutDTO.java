package br.com.calcard.calintegrador.motorBiometria.dto;

public class IntegracaoLogoutDTO {

	private Integer idIntegracao;

	public IntegracaoLogoutDTO(Integer idIntegracao) {
		this.idIntegracao = idIntegracao;
	}

	public Integer getIdIntegracao() {
		return idIntegracao;
	}

	public void setIdIntegracao(Integer idIntegracao) {
		this.idIntegracao = idIntegracao;
	}

}
