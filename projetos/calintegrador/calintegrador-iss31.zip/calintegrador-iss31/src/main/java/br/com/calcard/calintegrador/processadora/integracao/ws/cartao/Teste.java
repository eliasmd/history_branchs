package br.com.calcard.calintegrador.processadora.integracao.ws.cartao;

import java.rmi.RemoteException;

public class Teste {

	public static void main(String[] args) {

	    CartaoSoapProxy serviceProxy = new CartaoSoapProxy();
		
		CadastrarAlterarSenhaCartaoReq requisicao = new CadastrarAlterarSenhaCartaoReq();
		
		requisicao.setId_Conta(1521268);
		requisicao.setNumCartao("2296");
		//requisicao.setSenhaAnterior("2346");
		requisicao.setNovaSenha("2347");
		requisicao.setCadastroSenha("1");
		requisicao.setSenhaCriptografada(0);
		requisicao.setLogSistema("CALSYSTEM TESTE");

		
		CadastrarAlterarSenhaCartaoResp resposta = new CadastrarAlterarSenhaCartaoResp();
		
		try {
			resposta = serviceProxy.cadastrarAlterarSenhaCartao(requisicao);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(resposta.getCodRetorno());
		System.out.println(resposta.getDescricaoRetorno());
	
	}
}
