/**
 * CadastrarAlterarSenhaCartaoReq.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.cartao;

public class CadastrarAlterarSenhaCartaoReq  implements java.io.Serializable {
    private int id_Conta;

    private java.lang.String numCartao;

    private java.lang.String senhaAnterior;

    private java.lang.String novaSenha;

    private java.lang.String cadastroSenha;

    private int senhaCriptografada;

    private java.lang.String logSistema;

    public CadastrarAlterarSenhaCartaoReq() {
    }

    public CadastrarAlterarSenhaCartaoReq(
           int id_Conta,
           java.lang.String numCartao,
           java.lang.String senhaAnterior,
           java.lang.String novaSenha,
           java.lang.String cadastroSenha,
           int senhaCriptografada,
           java.lang.String logSistema) {
           this.id_Conta = id_Conta;
           this.numCartao = numCartao;
           this.senhaAnterior = senhaAnterior;
           this.novaSenha = novaSenha;
           this.cadastroSenha = cadastroSenha;
           this.senhaCriptografada = senhaCriptografada;
           this.logSistema = logSistema;
    }


    /**
     * Gets the id_Conta value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @return id_Conta
     */
    public int getId_Conta() {
        return id_Conta;
    }


    /**
     * Sets the id_Conta value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @param id_Conta
     */
    public void setId_Conta(int id_Conta) {
        this.id_Conta = id_Conta;
    }


    /**
     * Gets the numCartao value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @return numCartao
     */
    public java.lang.String getNumCartao() {
        return numCartao;
    }


    /**
     * Sets the numCartao value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @param numCartao
     */
    public void setNumCartao(java.lang.String numCartao) {
        this.numCartao = numCartao;
    }


    /**
     * Gets the senhaAnterior value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @return senhaAnterior
     */
    public java.lang.String getSenhaAnterior() {
        return senhaAnterior;
    }


    /**
     * Sets the senhaAnterior value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @param senhaAnterior
     */
    public void setSenhaAnterior(java.lang.String senhaAnterior) {
        this.senhaAnterior = senhaAnterior;
    }


    /**
     * Gets the novaSenha value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @return novaSenha
     */
    public java.lang.String getNovaSenha() {
        return novaSenha;
    }


    /**
     * Sets the novaSenha value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @param novaSenha
     */
    public void setNovaSenha(java.lang.String novaSenha) {
        this.novaSenha = novaSenha;
    }


    /**
     * Gets the cadastroSenha value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @return cadastroSenha
     */
    public java.lang.String getCadastroSenha() {
        return cadastroSenha;
    }


    /**
     * Sets the cadastroSenha value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @param cadastroSenha
     */
    public void setCadastroSenha(java.lang.String cadastroSenha) {
        this.cadastroSenha = cadastroSenha;
    }


    /**
     * Gets the senhaCriptografada value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @return senhaCriptografada
     */
    public int getSenhaCriptografada() {
        return senhaCriptografada;
    }


    /**
     * Sets the senhaCriptografada value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @param senhaCriptografada
     */
    public void setSenhaCriptografada(int senhaCriptografada) {
        this.senhaCriptografada = senhaCriptografada;
    }


    /**
     * Gets the logSistema value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @return logSistema
     */
    public java.lang.String getLogSistema() {
        return logSistema;
    }


    /**
     * Sets the logSistema value for this CadastrarAlterarSenhaCartaoReq.
     * 
     * @param logSistema
     */
    public void setLogSistema(java.lang.String logSistema) {
        this.logSistema = logSistema;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CadastrarAlterarSenhaCartaoReq)) return false;
        CadastrarAlterarSenhaCartaoReq other = (CadastrarAlterarSenhaCartaoReq) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.id_Conta == other.getId_Conta() &&
            ((this.numCartao==null && other.getNumCartao()==null) || 
             (this.numCartao!=null &&
              this.numCartao.equals(other.getNumCartao()))) &&
            ((this.senhaAnterior==null && other.getSenhaAnterior()==null) || 
             (this.senhaAnterior!=null &&
              this.senhaAnterior.equals(other.getSenhaAnterior()))) &&
            ((this.novaSenha==null && other.getNovaSenha()==null) || 
             (this.novaSenha!=null &&
              this.novaSenha.equals(other.getNovaSenha()))) &&
            ((this.cadastroSenha==null && other.getCadastroSenha()==null) || 
             (this.cadastroSenha!=null &&
              this.cadastroSenha.equals(other.getCadastroSenha()))) &&
            this.senhaCriptografada == other.getSenhaCriptografada() &&
            ((this.logSistema==null && other.getLogSistema()==null) || 
             (this.logSistema!=null &&
              this.logSistema.equals(other.getLogSistema())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getId_Conta();
        if (getNumCartao() != null) {
            _hashCode += getNumCartao().hashCode();
        }
        if (getSenhaAnterior() != null) {
            _hashCode += getSenhaAnterior().hashCode();
        }
        if (getNovaSenha() != null) {
            _hashCode += getNovaSenha().hashCode();
        }
        if (getCadastroSenha() != null) {
            _hashCode += getCadastroSenha().hashCode();
        }
        _hashCode += getSenhaCriptografada();
        if (getLogSistema() != null) {
            _hashCode += getLogSistema().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CadastrarAlterarSenhaCartaoReq.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "CadastrarAlterarSenhaCartaoReq"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id_Conta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "id_Conta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senhaAnterior");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "SenhaAnterior"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("novaSenha");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NovaSenha"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cadastroSenha");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CadastroSenha"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senhaCriptografada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "SenhaCriptografada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logSistema");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "LogSistema"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
