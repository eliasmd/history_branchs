/**
 * CreditTalkStatelessSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.motorCredito.integracao.WS;

public interface CreditTalkStatelessSoap extends java.rmi.Remote {
    public java.lang.String report(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao, java.lang.String sDriver, java.lang.String sProduto) throws java.rmi.RemoteException;
    public java.lang.String explain(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException;
    public byte[] loadPDF(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException;
    public java.lang.String values(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException;
    public java.lang.String layout(java.lang.String sUser, java.lang.String sPassword) throws java.rmi.RemoteException;
    public br.com.calcard.calintegrador.motorCredito.integracao.WS.Parametro[] parameters(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException;
    public java.lang.String[] rawData(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao, java.lang.String sDriver, java.lang.String sProduto) throws java.rmi.RemoteException;
    public java.lang.String sources(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException;
    public java.lang.String loadLog(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException;
    public java.lang.String eval(java.lang.String sUser, java.lang.String sPassword, java.lang.String sParametros) throws java.rmi.RemoteException;
    public java.lang.String setPolicyEval(java.lang.String sUser, java.lang.String sPassword, java.lang.String sPolitica, java.lang.String sParametros) throws java.rmi.RemoteException;
    public java.lang.String setPolicyEvalValues(java.lang.String sUser, java.lang.String sPassword, java.lang.String sPolitica, java.lang.String sParametros) throws java.rmi.RemoteException;
    public java.lang.String setPolicyEvalValuesXml(java.lang.String sUser, java.lang.String sPassword, java.lang.String sPolitica, java.lang.String sParametros) throws java.rmi.RemoteException;
    public br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultEvalValuesXml setPolicyEvalValuesObjectXml(java.lang.String sUser, java.lang.String sPassword, java.lang.String sPolitica, java.lang.String sParametros) throws java.rmi.RemoteException;
}
