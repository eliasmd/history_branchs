/**
 * ConsultarCartoesReq.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public class ConsultarCartoesReq  implements java.io.Serializable {
    private java.lang.Integer idConta;

    private java.lang.String CPFConta;

    private java.lang.String CPFPortador;

    private java.lang.String numCartao;

    public ConsultarCartoesReq() {
    }

    public ConsultarCartoesReq(
           java.lang.Integer idConta,
           java.lang.String CPFConta,
           java.lang.String CPFPortador,
           java.lang.String numCartao) {
           this.idConta = idConta;
           this.CPFConta = CPFConta;
           this.CPFPortador = CPFPortador;
           this.numCartao = numCartao;
    }


    /**
     * Gets the idConta value for this ConsultarCartoesReq.
     * 
     * @return idConta
     */
    public java.lang.Integer getIdConta() {
        return idConta;
    }


    /**
     * Sets the idConta value for this ConsultarCartoesReq.
     * 
     * @param idConta
     */
    public void setIdConta(java.lang.Integer idConta) {
        this.idConta = idConta;
    }


    /**
     * Gets the CPFConta value for this ConsultarCartoesReq.
     * 
     * @return CPFConta
     */
    public java.lang.String getCPFConta() {
        return CPFConta;
    }


    /**
     * Sets the CPFConta value for this ConsultarCartoesReq.
     * 
     * @param CPFConta
     */
    public void setCPFConta(java.lang.String CPFConta) {
        this.CPFConta = CPFConta;
    }


    /**
     * Gets the CPFPortador value for this ConsultarCartoesReq.
     * 
     * @return CPFPortador
     */
    public java.lang.String getCPFPortador() {
        return CPFPortador;
    }


    /**
     * Sets the CPFPortador value for this ConsultarCartoesReq.
     * 
     * @param CPFPortador
     */
    public void setCPFPortador(java.lang.String CPFPortador) {
        this.CPFPortador = CPFPortador;
    }


    /**
     * Gets the numCartao value for this ConsultarCartoesReq.
     * 
     * @return numCartao
     */
    public java.lang.String getNumCartao() {
        return numCartao;
    }


    /**
     * Sets the numCartao value for this ConsultarCartoesReq.
     * 
     * @param numCartao
     */
    public void setNumCartao(java.lang.String numCartao) {
        this.numCartao = numCartao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarCartoesReq)) return false;
        ConsultarCartoesReq other = (ConsultarCartoesReq) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idConta==null && other.getIdConta()==null) || 
             (this.idConta!=null &&
              this.idConta.equals(other.getIdConta()))) &&
            ((this.CPFConta==null && other.getCPFConta()==null) || 
             (this.CPFConta!=null &&
              this.CPFConta.equals(other.getCPFConta()))) &&
            ((this.CPFPortador==null && other.getCPFPortador()==null) || 
             (this.CPFPortador!=null &&
              this.CPFPortador.equals(other.getCPFPortador()))) &&
            ((this.numCartao==null && other.getNumCartao()==null) || 
             (this.numCartao!=null &&
              this.numCartao.equals(other.getNumCartao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdConta() != null) {
            _hashCode += getIdConta().hashCode();
        }
        if (getCPFConta() != null) {
            _hashCode += getCPFConta().hashCode();
        }
        if (getCPFPortador() != null) {
            _hashCode += getCPFPortador().hashCode();
        }
        if (getNumCartao() != null) {
            _hashCode += getNumCartao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarCartoesReq.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "ConsultarCartoesReq"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IdConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CPFConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CPFConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CPFPortador");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CPFPortador"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
