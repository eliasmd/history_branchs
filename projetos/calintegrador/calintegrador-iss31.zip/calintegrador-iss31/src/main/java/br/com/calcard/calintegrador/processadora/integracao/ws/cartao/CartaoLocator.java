/**
 * CartaoLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.cartao;

public class CartaoLocator extends org.apache.axis.client.Service implements br.com.calcard.calintegrador.processadora.integracao.ws.cartao.Cartao {

    public CartaoLocator() {
    }


    public CartaoLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public CartaoLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for CartaoSoap
    private java.lang.String CartaoSoap_address = "http://10.19.252.136:2506/Cartao.asmx";

    public java.lang.String getCartaoSoapAddress() {
        return CartaoSoap_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CartaoSoapWSDDServiceName = "CartaoSoap";

    public java.lang.String getCartaoSoapWSDDServiceName() {
        return CartaoSoapWSDDServiceName;
    }

    public void setCartaoSoapWSDDServiceName(java.lang.String name) {
        CartaoSoapWSDDServiceName = name;
    }

    public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoap getCartaoSoap() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CartaoSoap_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCartaoSoap(endpoint);
    }

    public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoap getCartaoSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoapStub _stub = new br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoapStub(portAddress, this);
            _stub.setPortName(getCartaoSoapWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCartaoSoapEndpointAddress(java.lang.String address) {
        CartaoSoap_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoap.class.isAssignableFrom(serviceEndpointInterface)) {
                br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoapStub _stub = new br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoapStub(new java.net.URL(CartaoSoap_address), this);
                _stub.setPortName(getCartaoSoapWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("CartaoSoap".equals(inputPortName)) {
            return getCartaoSoap();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://conductor.com.br/", "Cartao");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://conductor.com.br/", "CartaoSoap"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("CartaoSoap".equals(portName)) {
            setCartaoSoapEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
