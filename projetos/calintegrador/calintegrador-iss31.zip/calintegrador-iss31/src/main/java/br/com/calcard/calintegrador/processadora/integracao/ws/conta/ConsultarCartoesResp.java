/**
 * ConsultarCartoesResp.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public class ConsultarCartoesResp  implements java.io.Serializable {
    private CartaoConsulta[] cartaoConsulta;

    private int codRetorno;

    private java.lang.String descricaoRetorno;

    public ConsultarCartoesResp() {
    }

    public ConsultarCartoesResp(
    		CartaoConsulta[] cartaoConsulta,
           int codRetorno,
           java.lang.String descricaoRetorno) {
           this.cartaoConsulta = cartaoConsulta;
           this.codRetorno = codRetorno;
           this.descricaoRetorno = descricaoRetorno;
    }


    /**
     * Gets the cartaoConsulta value for this ConsultarCartoesResp.
     * 
     * @return cartaoConsulta
     */
    public CartaoConsulta[] getCartaoConsulta() {
        return cartaoConsulta;
    }


    /**
     * Sets the cartaoConsulta value for this ConsultarCartoesResp.
     * 
     * @param cartaoConsulta
     */
    public void setCartaoConsulta(CartaoConsulta[] cartaoConsulta) {
        this.cartaoConsulta = cartaoConsulta;
    }

    public CartaoConsulta getCartaoConsulta(int i) {
        return this.cartaoConsulta[i];
    }

    public void setCartaoConsulta(int i, CartaoConsulta _value) {
        this.cartaoConsulta[i] = _value;
    }


    /**
     * Gets the codRetorno value for this ConsultarCartoesResp.
     * 
     * @return codRetorno
     */
    public int getCodRetorno() {
        return codRetorno;
    }


    /**
     * Sets the codRetorno value for this ConsultarCartoesResp.
     * 
     * @param codRetorno
     */
    public void setCodRetorno(int codRetorno) {
        this.codRetorno = codRetorno;
    }


    /**
     * Gets the descricaoRetorno value for this ConsultarCartoesResp.
     * 
     * @return descricaoRetorno
     */
    public java.lang.String getDescricaoRetorno() {
        return descricaoRetorno;
    }


    /**
     * Sets the descricaoRetorno value for this ConsultarCartoesResp.
     * 
     * @param descricaoRetorno
     */
    public void setDescricaoRetorno(java.lang.String descricaoRetorno) {
        this.descricaoRetorno = descricaoRetorno;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarCartoesResp)) return false;
        ConsultarCartoesResp other = (ConsultarCartoesResp) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cartaoConsulta==null && other.getCartaoConsulta()==null) || 
             (this.cartaoConsulta!=null &&
              java.util.Arrays.equals(this.cartaoConsulta, other.getCartaoConsulta()))) &&
            this.codRetorno == other.getCodRetorno() &&
            ((this.descricaoRetorno==null && other.getDescricaoRetorno()==null) || 
             (this.descricaoRetorno!=null &&
              this.descricaoRetorno.equals(other.getDescricaoRetorno())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCartaoConsulta() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCartaoConsulta());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCartaoConsulta(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getCodRetorno();
        if (getDescricaoRetorno() != null) {
            _hashCode += getDescricaoRetorno().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarCartoesResp.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "ConsultarCartoesResp"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cartaoConsulta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CartaoConsulta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "CartaoConsulta"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CodRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DescricaoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
