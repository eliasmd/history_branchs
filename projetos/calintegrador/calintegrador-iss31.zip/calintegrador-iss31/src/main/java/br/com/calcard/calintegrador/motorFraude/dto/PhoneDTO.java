package br.com.calcard.calintegrador.motorFraude.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

public class PhoneDTO {

	private String ddd;

	private String numero;

	private String ramal;

	private List<GenericDTO> generics;

	public PhoneDTO() {

	}

	public PhoneDTO(String ddd, String numero, String ramal,
			List<GenericDTO> generics) {
		super();

		this.ddd = ddd;
		this.numero = numero;
		this.ramal = ramal;
		this.generics = generics;

	}

	@XmlElement(name = "DDD")
	public String getDdd() {
		return ddd;
	}

	public void setDdd(String ddd) {
		this.ddd = ddd;
	}

	public void setDdd(Integer ddd) {
		this.ddd = ddd == null ? null : ddd.toString();
	}

	@XmlElement(name = "Number")
	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero == null ? null : numero.toString();
	}

	@XmlElement(name = "Extension")
	public String getRamal() {
		return ramal;
	}

	public void setRamal(String ramal) {
		this.ramal = ramal;
	}

	public void setRamal(Integer ramal) {
		this.ramal = ramal == null ? null : ramal.toString();
	}

	@XmlElementWrapper(name = "Generics")
	@XmlElement(name = "Generic")
	public List<GenericDTO> getGenerics() {
		return generics;
	}

	public void setGeneric(List<GenericDTO> generics) {
		this.generics = generics;
	}

}
