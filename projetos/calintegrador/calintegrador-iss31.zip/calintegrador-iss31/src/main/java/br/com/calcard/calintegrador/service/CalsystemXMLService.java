package br.com.calcard.calintegrador.service;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.springframework.stereotype.Service;

import br.com.calcard.calframework.service.ServiceException;

@Service
public class CalsystemXMLService implements ICalsystemXML {

	@Override
	public String doConverterDTOParaXML(Class<?> clazz, Object dto)
			throws ServiceException {

		try {

			StringWriter out = new StringWriter();

			JAXBContext jaxbContext = JAXBContext.newInstance(clazz);

			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			jaxbMarshaller.marshal(dto, out);

			String xml = this.doFormatarXmlRequisicao(out);

			return xml;

		} catch (Exception e) {
			throw new ServiceException(new StringBuilder(
					"Erro ao converter DTO em XML! CLASSE: ").append(clazz)
					.append(" DTO: ").append(dto).toString(), e);
		}

	}

	private String doFormatarXmlRequisicao(StringWriter out) {

		return new StringBuilder()
				.append(out
						.toString()
						.replace(
								"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>",
								"")).toString().trim();

	}

	@Override
	public Object doConverterXMLParaDTO(Class<?> clazz, String xml)
			throws ServiceException {

		try {

			JAXBContext jaxbContext = JAXBContext.newInstance(clazz);

			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

			return unmarshaller.unmarshal(new StringReader(xml));

		} catch (Exception e) {
			throw new ServiceException(new StringBuilder(
					"Erro ao converter XML em DTO! CLASSE: ").append(clazz)
					.append(" XML: ").append(xml).toString(), e);
		}

	}

}
