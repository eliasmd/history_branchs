package br.com.calcard.calintegrador.motorBiometria.dto;

public class IntegracaoAvaliacaoFotoDTO {

	private IntegracaoLoginDTO integracaoLogin;

	private Integer idIntegracao;

	private IntegracaoLogoutDTO integracaoLogout;
	
	private ResponsePoolingDTO responsePoolingDTO;

	public IntegracaoAvaliacaoFotoDTO(IntegracaoLoginDTO integracaoLogin,
			Integer idIntegracao, IntegracaoLogoutDTO integracaoLogout) {
		super();
		this.integracaoLogin = integracaoLogin;
		this.idIntegracao = idIntegracao;
		this.integracaoLogout = integracaoLogout;
	}
	
	public IntegracaoAvaliacaoFotoDTO(IntegracaoLoginDTO integracaoLogin,
			Integer idIntegracao, IntegracaoLogoutDTO integracaoLogout, 
			ResponsePoolingDTO responsePoolingDTO) {
		super();
		this.integracaoLogin = integracaoLogin;
		this.idIntegracao = idIntegracao;
		this.integracaoLogout = integracaoLogout;
		this.responsePoolingDTO = responsePoolingDTO;
	}

	public IntegracaoLoginDTO getIntegracaoLogin() {
		return integracaoLogin;
	}

	public void setIntegracaoLogin(IntegracaoLoginDTO integracaoLogin) {
		this.integracaoLogin = integracaoLogin;
	}

	public Integer getIdIntegracao() {
		return idIntegracao;
	}

	public void setIdIntegracao(Integer idIntegracao) {
		this.idIntegracao = idIntegracao;
	}

	public IntegracaoLogoutDTO getIntegracaoLogout() {
		return integracaoLogout;
	}

	public void setIntegracaoLogout(IntegracaoLogoutDTO integracaoLogout) {
		this.integracaoLogout = integracaoLogout;
	}

	public ResponsePoolingDTO getResponsePoolingDTO() {
		return responsePoolingDTO;
	}

	public void setResponsePoolingDTO(ResponsePoolingDTO responsePoolingDTO) {
		this.responsePoolingDTO = responsePoolingDTO;
	}

}
