package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;

public class UploadDocumentsInfoDTO {

	private Integer id;

	private List<DocumentDTO> document;

	public UploadDocumentsInfoDTO() {

	}

	public UploadDocumentsInfoDTO(Integer id, List<DocumentDTO> document) {
		super();
		this.id = id;
		this.document = document;
	}

	public List<DocumentDTO> getDocument() {
		return document;
	}

	public void setDocument(List<DocumentDTO> document) {
		this.document = document;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
