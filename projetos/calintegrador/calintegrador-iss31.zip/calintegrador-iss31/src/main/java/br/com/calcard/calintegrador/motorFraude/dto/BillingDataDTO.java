package br.com.calcard.calintegrador.motorFraude.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

public class BillingDataDTO {

	private String id;

	private String sexo;

	private String cpf;

	private String nome;

	private String dataNascimento;

	private String rg;

	private List<GenericDTO> dadosGenericos;

	private List<PersonalReferenceDTO> referenciasPessoais;

	private EmploymentDTO dadosProfissionais;

	private AddressDTO endereco;

	private List<PhoneDTO> telefones;

	private String email;

	private String origem;

	private String observacao;

	@XmlElement(name = "LegalDocument1")
	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	@XmlElement(name = "Name")
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@XmlElement(name = "BirthDate")
	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getRg() {
		return rg;
	}

	@XmlElement(name = "LegalDocument2")
	public void setRg(String rg) {
		this.rg = rg;
	}

	@XmlElementWrapper(name = "PersonalReferences")
	@XmlElement(name = "PersonalReference")
	public List<PersonalReferenceDTO> getReferenciasPessoais() {
		return referenciasPessoais;
	}

	public void setReferenciasPessoais(
			List<PersonalReferenceDTO> referenciasPessoais) {
		this.referenciasPessoais = referenciasPessoais;
	}

	@XmlElement(name = "Employment")
	public EmploymentDTO getDadosProfissionais() {
		return dadosProfissionais;
	}

	public void setDadosProfissionais(EmploymentDTO dadosProfissionais) {
		this.dadosProfissionais = dadosProfissionais;
	}

	@XmlElement(name = "Address")
	public AddressDTO getEndereco() {
		return endereco;
	}

	public void setEndereco(AddressDTO endereco) {
		this.endereco = endereco;
	}

	@XmlElementWrapper(name = "Generics")
	@XmlElement(name = "Generic")
	public List<GenericDTO> getDadosGenericos() {
		return dadosGenericos;
	}

	public void setDadosGenericos(List<GenericDTO> dadosGenericos) {
		this.dadosGenericos = dadosGenericos;
	}

	@XmlElementWrapper(name = "Phones")
	@XmlElement(name = "Phone")
	public List<PhoneDTO> getTelefones() {
		return telefones;
	}

	public void setTelefones(List<PhoneDTO> telefones) {
		this.telefones = telefones;
	}

	@XmlElement(name = "ID")
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@XmlElement(name = "Gender")
	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	@XmlElement(name = "Email")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@XmlElement(name = "Origin")
	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}

	@XmlElement(name = "Obs")
	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

}
