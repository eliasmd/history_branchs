package br.com.calcard.calintegrador.motorCredito.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class IntegracaoMotorCreditoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4684450315962296705L;

	public IntegracaoMotorCreditoException(String message, Throwable cause) {
		super(message, cause);
	}

	public IntegracaoMotorCreditoException(String message) {
		super(message);
	}

}
