package br.com.calcard.calintegrador.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calintegrador.enums.NomeIntegracaoEnum;

@Entity
@Table(name = "tbl_integracao")
public class Integracao extends CalsystemEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7807527539441767308L;

	private static final String COLUNA_NOME = "nome";

	private static final String COLUNA_NOME_SERVICO = "nome_servico";

	private static final String COLUNA_LOG_REQUISICAO = "log_requisicao";

	private static final String COLUNA_LOG_RESPOSTA = "log_resposta";

	private static final String COLUNA_DATA_REQUISICAO = "data_requisicao";

	private static final String COLUNA_DATA_RESPOSTA = "data_resposta";

	@Enumerated(EnumType.STRING)
	@Column(name = COLUNA_NOME, length = 50, nullable = false, unique = false)
	private NomeIntegracaoEnum nome;

	@Column(name = COLUNA_NOME_SERVICO, nullable = false, unique = false, length = 100)
	private String nomeServico;

	@Lob
	@Column(name = COLUNA_LOG_REQUISICAO, nullable = true, unique = false)
	private String logRequisicao;

	@Lob
	@Column(name = COLUNA_LOG_RESPOSTA, nullable = true, unique = false)
	private String logResposta;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = COLUNA_DATA_REQUISICAO, unique = false, nullable = false)
	private Date dataRequisicao;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = COLUNA_DATA_RESPOSTA, unique = false, nullable = true)
	private Date dataResposta;

	public Integracao() {
		super();
	}

	public Integracao(NomeIntegracaoEnum nome, String nomeServico,
			String logRequisicao, String logResposta, Date dataRequisicao,
			Date dataResposta) {
		super();
		this.nome = nome;
		this.nomeServico = nomeServico;
		this.logRequisicao = logRequisicao;
		this.logResposta = logResposta;
		this.dataRequisicao = dataRequisicao;
		this.dataResposta = dataResposta;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((logRequisicao == null) ? 0 : logRequisicao.hashCode());
		result = prime * result
				+ ((logResposta == null) ? 0 : logResposta.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result
				+ ((nomeServico == null) ? 0 : nomeServico.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Integracao other = (Integracao) obj;
		if (logRequisicao == null) {
			if (other.logRequisicao != null)
				return false;
		} else if (!logRequisicao.equals(other.logRequisicao))
			return false;
		if (logResposta == null) {
			if (other.logResposta != null)
				return false;
		} else if (!logResposta.equals(other.logResposta))
			return false;
		if (nome != other.nome)
			return false;
		if (nomeServico == null) {
			if (other.nomeServico != null)
				return false;
		} else if (!nomeServico.equals(other.nomeServico))
			return false;
		return true;
	}

	public NomeIntegracaoEnum getNome() {
		return nome;
	}

	public void setNome(NomeIntegracaoEnum nome) {
		this.nome = nome;
	}

	public String getNomeServico() {
		return nomeServico;
	}

	public void setNomeServico(String nomeServico) {
		this.nomeServico = nomeServico;
	}

	public String getLogRequisicao() {
		return logRequisicao;
	}

	public void setLogRequisicao(String logRequisicao) {
		this.logRequisicao = logRequisicao;
	}

	public String getLogResposta() {
		return logResposta;
	}

	public void setLogResposta(String logResposta) {
		this.logResposta = logResposta;
	}

	public Date getDataResposta() {
		return dataResposta;
	}

	public void setDataResposta(Date dataResposta) {
		this.dataResposta = dataResposta;
	}

	public Date getDataRequisicao() {
		return dataRequisicao;
	}

	public void setDataRequisicao(Date dataRequisicao) {
		this.dataRequisicao = dataRequisicao;
	}

}
