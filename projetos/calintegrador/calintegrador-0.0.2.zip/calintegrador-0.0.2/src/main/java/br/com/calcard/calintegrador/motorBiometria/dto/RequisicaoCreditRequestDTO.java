package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.ArrayList;
import java.util.List;

public class RequisicaoCreditRequestDTO {

	private AuthenticationDTO authentication;

	private List<CreditRequestDTO> creditrequest;

	public RequisicaoCreditRequestDTO() {
		this.authentication = new AuthenticationDTO();
		this.creditrequest = new ArrayList<CreditRequestDTO>();
	}

	public RequisicaoCreditRequestDTO(AuthenticationDTO authentication,
			List<CreditRequestDTO> creditrequest) {
		this.authentication = authentication;
		this.creditrequest = creditrequest;
	}

	public AuthenticationDTO getAuthentication() {
		return authentication;
	}

	public void setAuthentication(AuthenticationDTO authentication) {
		this.authentication = authentication;
	}

	public List<CreditRequestDTO> getCreditrequest() {
		return creditrequest;
	}

	public void setCreditrequest(List<CreditRequestDTO> creditrequest) {
		this.creditrequest = creditrequest;
	}

}
