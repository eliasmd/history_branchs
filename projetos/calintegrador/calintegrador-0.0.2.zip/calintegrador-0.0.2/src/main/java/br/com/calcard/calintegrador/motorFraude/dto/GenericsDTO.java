package br.com.calcard.calintegrador.motorFraude.dto;

import javax.xml.bind.annotation.XmlElement;

public class GenericsDTO {

	private GenericDTO sexo;

	private GenericDTO estadoCivil;

	private GenericsDTO dadosGenericos;

	private GenericDTO grauInstrucao;

	private GenericDTO dataEmissaoRg;

	private GenericDTO orgaoEmissorRg;

	private GenericDTO ufRg;

	private GenericDTO nomeMae;

	private GenericDTO naturalidade;

	private GenericDTO uf;

	private GenericDTO nacionalidade;

	private GenericDTO quantidadeDependentes;

	private GenericDTO nomePai;

	private GenericDTO outrasRendas;

	private GenericDTO tipoResidencia;

	private GenericDTO origemOutrasRendas;

	private GenericDTO tempoResidenciaAnos;

	private GenericDTO tempoResidenciaMeses;

	@XmlElement(name = "Generic")
	public GenericDTO getSexo() {
		return sexo;
	}

	public void setSexo(GenericDTO sexo) {
		this.sexo = sexo;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(GenericDTO estadoCivil) {
		this.estadoCivil = estadoCivil;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getGrauInstrucao() {
		return grauInstrucao;
	}

	public void setGrauInstrucao(GenericDTO grauInstrucao) {
		this.grauInstrucao = grauInstrucao;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getDataEmissaoRg() {
		return dataEmissaoRg;
	}

	public void setDataEmissaoRg(GenericDTO dataEmissaoRg) {
		this.dataEmissaoRg = dataEmissaoRg;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getOrgaoEmissorRg() {
		return orgaoEmissorRg;
	}

	public void setOrgaoEmissorRg(GenericDTO orgaoEmissorRg) {
		this.orgaoEmissorRg = orgaoEmissorRg;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getUfRg() {
		return ufRg;
	}

	public void setUfRg(GenericDTO ufRg) {
		this.ufRg = ufRg;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getNomeMae() {
		return nomeMae;
	}

	public void setNomeMae(GenericDTO nomeMae) {
		this.nomeMae = nomeMae;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getNaturalidade() {
		return naturalidade;
	}

	public void setNaturalidade(GenericDTO naturalidade) {
		this.naturalidade = naturalidade;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getUf() {
		return uf;
	}

	public void setUf(GenericDTO uf) {
		this.uf = uf;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(GenericDTO nacionalidade) {
		this.nacionalidade = nacionalidade;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getQuantidadeDependentes() {
		return quantidadeDependentes;
	}

	public void setQuantidadeDependentes(GenericDTO quantidadeDependentes) {
		this.quantidadeDependentes = quantidadeDependentes;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getNomePai() {
		return nomePai;
	}

	public void setNomePai(GenericDTO nomePai) {
		this.nomePai = nomePai;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getOutrasRendas() {
		return outrasRendas;
	}

	public void setOutrasRendas(GenericDTO outrasRendas) {
		this.outrasRendas = outrasRendas;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getTipoResidencia() {
		return tipoResidencia;
	}

	public void setTipoResidencia(GenericDTO tipoResidencia) {
		this.tipoResidencia = tipoResidencia;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getOrigemOutrasRendas() {
		return origemOutrasRendas;
	}

	public void setOrigemOutrasRendas(GenericDTO origemOutrasRendas) {
		this.origemOutrasRendas = origemOutrasRendas;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getTempoResidenciaAnos() {
		return tempoResidenciaAnos;
	}

	public void setTempoResidenciaAnos(GenericDTO tempoResidenciaAnos) {
		this.tempoResidenciaAnos = tempoResidenciaAnos;
	}

	@XmlElement(name = "Generic")
	public GenericDTO getTempoResidenciaMeses() {
		return tempoResidenciaMeses;
	}

	public void setTempoResidenciaMeses(GenericDTO tempoResidenciaMeses) {
		this.tempoResidenciaMeses = tempoResidenciaMeses;
	}

	@XmlElement(name = "Generics")
	public GenericsDTO getDadosGenericos() {
		return dadosGenericos;
	}

	public void setDadosGenericos(GenericsDTO dadosGenericos) {
		this.dadosGenericos = dadosGenericos;
	}
}
