package br.com.calcard.calintegrador.motorFraude.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;

public class EmploymentDTO {

	private String naturezaOcupacao;

	private String nomeEmpresa;

	private String cnpj;

	private Date dataAdmissao;

	private String profissao;

	private AddressDTO endereco;

	private Double salario;

	@XmlElement(name = "Occupation")
	public String getNaturezaOcupacao() {
		return naturezaOcupacao;
	}

	public void setNaturezaOcupacao(String naturezaOcupacao) {
		this.naturezaOcupacao = naturezaOcupacao;
	}

	@XmlElement(name = "Employer")
	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	@XmlElement(name = "CNPJ")
	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	@XmlElement(name = "AdmissionDate")
	public Date getDataAdmissao() {
		return dataAdmissao;
	}

	public void setDataAdmissao(Date dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}

	@XmlElement(name = "Role")
	public String getProfissao() {
		return profissao;
	}

	public void setProfissao(String profissao) {
		this.profissao = profissao;
	}

	@XmlElement(name = "Address")
	public AddressDTO getEndereco() {
		return endereco;
	}

	public void setEndereco(AddressDTO endereco) {
		this.endereco = endereco;
	}

	@XmlElement(name = "MontlyIncome")
	public Double getSalario() {
		return salario;
	}

	public void setSalario(Double salario) {
		this.salario = salario;
	}

}
