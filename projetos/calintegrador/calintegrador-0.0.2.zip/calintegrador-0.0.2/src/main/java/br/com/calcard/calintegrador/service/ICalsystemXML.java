package br.com.calcard.calintegrador.service;

import br.com.calcard.calframework.service.ServiceException;

public interface ICalsystemXML {

	public String doConverterDTOParaXML(Class<?> clazz, Object dto)
			throws ServiceException;

	public Object doConverterXMLParaDTO(Class<?> clazz, String xml)
			throws ServiceException;

}
