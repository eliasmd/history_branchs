package br.com.calcard.calintegrador.motorFraude.integracao;

public class ServiceSoapProxy implements br.com.calcard.calintegrador.motorFraude.integracao.ServiceSoap {
  private String _endpoint = null;
  private br.com.calcard.calintegrador.motorFraude.integracao.ServiceSoap serviceSoap = null;
  
  public ServiceSoapProxy() {
    _initServiceSoapProxy();
  }
  
  public ServiceSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initServiceSoapProxy();
  }
  
  private void _initServiceSoapProxy() {
    try {
      serviceSoap = (new br.com.calcard.calintegrador.motorFraude.integracao.ServiceLocator()).getServiceSoap();
      if (serviceSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)serviceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)serviceSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (serviceSoap != null)
      ((javax.xml.rpc.Stub)serviceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.calcard.calintegrador.motorFraude.integracao.ServiceSoap getServiceSoap() {
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap;
  }
  
  public java.lang.String sendOrders2(java.lang.String entityCode, java.lang.String pedidos) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.sendOrders2(entityCode, pedidos);
  }
  
  public java.lang.String sendOrders(java.lang.String entityCode, java.lang.String xml) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.sendOrders(entityCode, xml);
  }
  
  public java.lang.String getPackageStatus(java.lang.String entityCode, java.lang.String packageID) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.getPackageStatus(entityCode, packageID);
  }
  
  public java.lang.String getOrderStatus(java.lang.String entityCode, java.lang.String orderID) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.getOrderStatus(entityCode, orderID);
  }
  
  public java.lang.String getOrdersStatus(java.lang.String entityCode, java.lang.String xml) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.getOrdersStatus(entityCode, xml);
  }
  
  public java.lang.String getReturnAnalysis(java.lang.String entityCode) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.getReturnAnalysis(entityCode);
  }
  
  public java.lang.String setOrderAsReturned(java.lang.String entityCode, java.lang.String orderID) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.setOrderAsReturned(entityCode, orderID);
  }
  
  public java.lang.String getAnalystComments(java.lang.String entityCode, java.lang.String orderID, boolean getAll) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.getAnalystComments(entityCode, orderID, getAll);
  }
  
  public br.com.calcard.calintegrador.motorFraude.integracao.TransactionStatusCbk orderChargeBack(java.lang.String entityCode, java.lang.String xml, java.lang.String note) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.orderChargeBack(entityCode, xml, note);
  }
  
  public br.com.calcard.calintegrador.motorFraude.integracao.TransactionStatusCbk orderChargeBackByNsu(java.lang.String entityCode, int cartaoBandeira, java.lang.String nsu, java.lang.String conciliadorCode) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.orderChargeBackByNsu(entityCode, cartaoBandeira, nsu, conciliadorCode);
  }
  
  public java.lang.String submitInfo(java.lang.String entityCode, java.lang.String xmlDados) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.submitInfo(entityCode, xmlDados);
  }
  
  public java.lang.String checkOrderStatus(java.lang.String entityCode, java.lang.String pedidoIDCliente) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.checkOrderStatus(entityCode, pedidoIDCliente);
  }
  
  public java.lang.String getQuizURL(java.lang.String entityCode, java.lang.String orderID) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.getQuizURL(entityCode, orderID);
  }
  
  public java.lang.String getPackageStatusCustom(java.lang.String entityCode, java.lang.String transactionID) throws java.rmi.RemoteException{
    if (serviceSoap == null)
      _initServiceSoapProxy();
    return serviceSoap.getPackageStatusCustom(entityCode, transactionID);
  }
  
  
}