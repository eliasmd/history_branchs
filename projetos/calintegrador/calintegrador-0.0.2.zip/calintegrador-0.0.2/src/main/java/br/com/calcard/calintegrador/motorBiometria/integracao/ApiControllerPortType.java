/**
 * ApiControllerPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.motorBiometria.integracao;

public interface ApiControllerPortType extends java.rmi.Remote {
    public java.lang.Object[] welcome() throws java.rmi.RemoteException;
    public java.lang.Object[] login(java.lang.String username, java.lang.String password) throws java.rmi.RemoteException;
    public java.lang.Object[] logout(java.lang.String token) throws java.rmi.RemoteException;
    public java.lang.Object[] validate(java.lang.String token) throws java.rmi.RemoteException;
    public java.lang.Object[] places(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException;
    public java.lang.Object[] viewCustomerPhoto(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException;
    public java.lang.Object[] viewCRPhoto(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException;
    public java.lang.Object[] viewData(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException;
    public java.lang.Object[] viewDocuments(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException;
    public java.lang.Object[] pooling(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException;
    public java.lang.Object[] status(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException;
    public java.lang.Object[] changeStatus(java.lang.String token, java.math.BigInteger id, java.lang.String status, java.lang.String comment) throws java.rmi.RemoteException;
    public java.lang.Object[] survey(java.lang.String token, java.lang.String identifier_code, java.lang.String photo) throws java.rmi.RemoteException;
    public java.lang.Object[] listCreditRequests(java.lang.String token, java.math.BigInteger place_id, java.math.BigInteger limit, java.math.BigInteger offset) throws java.rmi.RemoteException;
    public java.lang.Object[] creditRequest(java.lang.String token, java.lang.String identifier_code, java.math.BigInteger document_type, java.math.BigInteger place_id, java.lang.String name, java.lang.String birth_date, java.lang.String photo) throws java.rmi.RemoteException;
    public java.lang.Object[] uploadDocuments(java.lang.String token, java.math.BigInteger id, java.math.BigInteger type, java.lang.String image) throws java.rmi.RemoteException;
    public java.lang.Object[] assessment(java.lang.String token, java.lang.String photo) throws java.rmi.RemoteException;
}
