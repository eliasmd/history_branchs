package br.com.calcard.calintegrador.motorBiometria.enums;

public enum CodeEnum {

	BAD_REQUEST(1, "bad_request"), //
	FAILED(2, "failed"), //
	NOT_FOUND(3, "not_found"), //
	LIMIT_EXCEEDED(4, "limit_exceeded");

	private Integer id;

	private String codigo;

	private CodeEnum(Integer id, String codigo) {

		this.id = id;

		this.codigo = codigo;
	}

	public Integer getId() {
		return id;
	}

	public String getCodigo() {
		return codigo;
	}

}
