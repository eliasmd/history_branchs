package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;

public class CreditRequestResponseDTO {

	private String result;

	private List<CreditRequestResponseInfoDTO> creditrequest;

	public List<CreditRequestResponseInfoDTO> getCreditrequest() {
		return creditrequest;
	}

	public void setCreditrequest(
			List<CreditRequestResponseInfoDTO> creditrequest) {
		this.creditrequest = creditrequest;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
