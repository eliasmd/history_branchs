package br.com.calcard.calintegrador.motorFraude.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Order")
public class OrderDTO {

	private String idProposta;

	private String dataProposta;

	private String email;

	private BillingDataDTO billingData;

	private IssuerDTO emissor;

	private String status;

	private String score;

	public OrderDTO() {

	}

	@XmlElement(name = "Email")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@XmlElement(name = "ID")
	public String getIdProposta() {
		return idProposta;
	}

	public void setIdProposta(String idProposta) {
		this.idProposta = idProposta;
	}

	public void setIdProposta(Integer idProposta) {
		this.idProposta = idProposta == null ? null : idProposta.toString();
	}

	@XmlElement(name = "Date")
	public String getDataProposta() {
		return dataProposta;
	}

	public void setDataProposta(String dataProposta) {
		this.dataProposta = dataProposta;
	}

	@XmlElement(name = "BillingData")
	public BillingDataDTO getBillingData() {
		return billingData;
	}

	public void setBillingData(BillingDataDTO billingData) {
		this.billingData = billingData;
	}

	@XmlElement(name = "Issuer")
	public IssuerDTO getEmissor() {
		return emissor;
	}

	public void setEmissor(IssuerDTO emissor) {
		this.emissor = emissor;
	}

	@XmlElement(name = "Status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@XmlElement(name = "Score")
	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

}
