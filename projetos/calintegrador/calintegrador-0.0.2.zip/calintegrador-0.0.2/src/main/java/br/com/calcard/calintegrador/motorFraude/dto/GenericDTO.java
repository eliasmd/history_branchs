package br.com.calcard.calintegrador.motorFraude.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Generic")
public class GenericDTO {

	private String nome;

	private String valor;

	public GenericDTO() {
	}

	public GenericDTO(String nome, String valor) {
		super();
		this.nome = nome;
		this.valor = valor;
	}

	public GenericDTO(String nome, Integer valor) {
		super();
		this.nome = nome;
		this.setValor(valor);
	}

	public GenericDTO(String nome, Double valor) {
		super();
		this.nome = nome;
		this.setValor(valor);
	}

	@XmlElement(name = "Name")
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@XmlElement(name = "Value")
	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public void setValor(Integer valor) {

		this.valor = valor == null ? null : valor.toString();

	}

	public void setValor(Double valor) {

		this.valor = valor == null ? null : valor.toString();

	}

}
