package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CreditRequestDTO {

	private Integer id;

	private String state;

	@JsonProperty("state_id")
	private String stateId;

	@JsonProperty("identifier_code")
	private String identifierCode;

	@JsonProperty("document_type")
	private String documentType = "2";

	@JsonProperty("place_id")
	private String placeId;

	private String name;

	@JsonProperty("birth_date")
	private String birthDate;

	private String photo;

	private List<DocumentDTO> document;
	
	private String identification;
	
	private String similarity;
	
	@JsonProperty("insert_date")
	private String insertDate;
	
	@JsonProperty("insert_time")
	private String insertTime;
	
	private String place;
	
	private String status;
	
	private String pending;

	public CreditRequestDTO() {
	}

	public CreditRequestDTO(Integer id) {
		this.setId(id);
	}

	public CreditRequestDTO(String identifierCode, String placeId, String name,
			String birthDate, String photo) {
		super();
		this.identifierCode = identifierCode;
		this.placeId = placeId;
		this.name = name;
		this.birthDate = birthDate;
		this.photo = photo;
	}

	public String getIdentifierCode() {
		return identifierCode;
	}

	public void setIdentifierCode(String identifierCode) {
		this.identifierCode = identifierCode;
	}

	public String getDocumentType() {
		return documentType;
	}

	public String getPlaceId() {
		return placeId;
	}

	public void setPlaceId(String placeId) {
		this.placeId = placeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public List<DocumentDTO> getDocument() {
		return document;
	}

	public void setDocument(List<DocumentDTO> document) {
		this.document = document;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStateId() {
		return stateId;
	}

	public void setStateId(String stateId) {
		this.stateId = stateId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getIdentification() {
		return identification;
	}

	public void setIdentification(String identification) {
		this.identification = identification;
	}

	public String getSimilarity() {
		return similarity;
	}

	public void setSimilarity(String similarity) {
		this.similarity = similarity;
	}

	public String getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(String insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(String insertTime) {
		this.insertTime = insertTime;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getPending() {
		return pending;
	}

	public void setPending(String pending) {
		this.pending = pending;
	}
	

}
