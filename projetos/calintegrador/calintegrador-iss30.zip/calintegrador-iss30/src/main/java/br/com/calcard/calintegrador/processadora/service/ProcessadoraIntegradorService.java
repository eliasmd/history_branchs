package br.com.calcard.calintegrador.processadora.service;

import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.interfaces.ICalsystemLog;
import br.com.calcard.calframework.service.CalsystemService;
import br.com.calcard.calintegrador.entity.Integracao;
import br.com.calcard.calintegrador.enums.NomeIntegracaoEnum;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorFraude.interfaces.ILogIntegracao;
import br.com.calcard.calintegrador.processadora.exception.IntegracaoProcessadoraException;
import br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastrarAlterarSenhaCartaoReq;
import br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastrarAlterarSenhaCartaoResp;
import br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoapProxy;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.CartaoConsulta;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.ConsultarCartoesReq;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.ConsultarCartoesResp;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.ConsultarContasReq;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.ConsultarContasResp;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.ContaCartao;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.ContaSoapProxy;
import br.com.calcard.calintegrador.processadora.interfaces.IProcessadoraIntegracao;

import com.google.gson.Gson;

@Service
public class ProcessadoraIntegradorService extends CalsystemService implements IProcessadoraIntegracao {
	
	public static final String LOG_SISTEMA = "CALSYSTEM";
	
	public static final String SENHA_ALTERAR_EXISTENTE = "0";
	
	public static final String SENHA_CADASTRAR_NOVA = "1";
	
	public static final Integer SENHA_SEM_CRIPTOGRAFIA = 0;
	
	public static final Integer SENHA_COM_CRIPTOGRAFIA = 1;

	private ICalsystemDAO daoService;

	private ILogIntegracao integracaoService;

	@Autowired
	public ProcessadoraIntegradorService(ICalsystemDAO 	daoService, 
										 ILogIntegracao integracaoService,
										 ICalsystemLog 	logService) {
		super(logService);
		this.daoService = daoService;
		this.integracaoService = integracaoService;
	}

	@Override
	@Transactional
	public CartaoConsulta[] doConsultarCartoesProcessadora(Integer idConta,
														   String cpfPortador, 
														   String numeroCartao, 
														   String cpfConta,
														   boolean validarRetornoNull, 
														   String mensagemRetornoNull) throws CalsystemInvalidArgumentException,
														   									  IntegracaoProcessadoraException, 
														   									  IntegracaoException,
														   									  CalsystemNoDataFoundException {

		ContaSoapProxy serviceProxy = new ContaSoapProxy();

		final String NOME_SERVICO_EXECUTADO = "ConsultarCartoes";

		Gson gson = new Gson();

		ConsultarCartoesReq requisicao = new ConsultarCartoesReq();

		ConsultarCartoesResp resposta = null;

		if (cpfPortador == null && idConta == null && numeroCartao == null
				&& cpfConta == null)
			throw new CalsystemInvalidArgumentException(
					"Nenhum parâmetro foi informado para a consulta!");

		if (cpfPortador != null)
			requisicao.setCPFPortador(cpfPortador);

		if (idConta != null)
			requisicao.setIdConta(idConta);

		if (numeroCartao != null)
			requisicao.setNumCartao(numeroCartao);

		if (cpfConta != null)
			requisicao.setCPFConta(cpfConta);
		
		Integracao integracao = new Integracao(NomeIntegracaoEnum.CONSULTAR_CARTOES_PROCESSADORA, 
											   NOME_SERVICO_EXECUTADO, 
											   gson.toJson(requisicao), 
											   new Date());
		
		integracao = integracaoService.doRegistrarIntegracao(integracao);

		try {
			resposta = serviceProxy.consultarCartoes(requisicao);
		} catch (RemoteException e) {
			throw new IntegracaoProcessadoraException(
					"Ocorreu erro de integracao ao consultar os cartoes do CPF:"
							+ cpfPortador + " erro encontrado: " + e);
		}
		
		integracao.setLogResposta(gson.toJson(resposta));
		integracao.setDataResposta(new Date());
		
		this.integracaoService.doRegistrarRespostaIntegracao(integracao);

		if (resposta.getCodRetorno() != 0)
			throw new IntegracaoProcessadoraException(new StringBuilder(
					"Erro ao consultar a processadora! CODIGO: ")
					.append(resposta.getCodRetorno()).append(" DESCRIÇÃO: ")
					.append(resposta.getDescricaoRetorno()).toString());

		if (validarRetornoNull
				&& (resposta.getCartaoConsulta() == null || resposta
						.getCartaoConsulta().length == 0))
			throw new CalsystemNoDataFoundException(
					mensagemRetornoNull != null ? mensagemRetornoNull
							: "Nenhum registro encontrado!");

		return resposta.getCartaoConsulta();

	}

	@Override
	@Transactional
	public List<CartaoConsulta> doConsultarCartoesProcessadoraAsList(
			Integer idConta, String cpfPortador, String numeroCartao,
			String cpfConta, boolean validarRetornoNull,
			String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			IntegracaoProcessadoraException, IntegracaoException,
			CalsystemNoDataFoundException {

		return Arrays.asList(this.doConsultarCartoesProcessadora(idConta,
				cpfPortador, numeroCartao, cpfConta, validarRetornoNull,
				mensagemRetornoNull));

	}
	
	
	@Transactional
	@Override
	public List<ContaCartao> doConsultarContasProcessadora(String cpf, Integer idConta) throws IntegracaoProcessadoraException, 
																							   IntegracaoException, 
																							   CalsystemInvalidArgumentException {
		
			/*		
			 if (cpf == null && idConta == null)
			throw new CalsystemInvalidArgumentException(
					"Nenhum parâmetro foi informado para a consulta!");
							*/
		
			ContaSoapProxy serviceProxy = new ContaSoapProxy();
			
			final String NOME_SERVICO_EXECUTADO = "ConsultarContas";
			
			Gson gson = new Gson();
			
			ConsultarContasReq requisicao = new ConsultarContasReq();
			ConsultarContasResp resposta = null;
			
			if (idConta != null)
				requisicao.setIdConta(idConta);
			
			if (cpf != null)
				requisicao.setCPF(cpf);
			
			Integracao integracao = new Integracao(NomeIntegracaoEnum.CONSULTAR_CONTAS_PROCESSADORA,
												   NOME_SERVICO_EXECUTADO, 
												   gson.toJson(requisicao), 
												   new Date());
			
			integracao = this.integracaoService.doRegistrarIntegracao(integracao);
			
			try {
				resposta = serviceProxy.consultarContas(requisicao);
			} catch (RemoteException e) {
				throw new IntegracaoProcessadoraException(new StringBuilder(
						"Ocorreu erro de integracao com a Processadora ao consultar Contas com CPF:").append(cpf).append(" ID Conta: ").append(idConta).append(" erro encontrado: ").append(e).toString());
			}
			
			integracao.setDataResposta(new Date());
			integracao.setLogResposta(gson.toJson(resposta));
			
			this.integracaoService.doRegistrarRespostaIntegracao(integracao);
			
			if (resposta.getCodRetorno() != 0)
				throw new IntegracaoProcessadoraException(new StringBuilder(
						"Ocorreu erro de integracao com a Processadora ao consultar Contas com CPF:").append(cpf).append(" ID Conta: ").append(idConta).append(" mensagem: ").append(resposta.getCodRetorno()).append(" - ").append(resposta.getDescricaoRetorno()).toString());
			
			if (resposta.getContaCartao() == null || resposta.getContaCartao().length == 0 ){
				throw new IntegracaoException(new StringBuilder("Consulta n�o retornou nenhuma Conta para o CPF: ").append(cpf).append(" ID Conta: ").append(idConta).toString());
			}
			
			//retorna a lista de contas encontrados
			return Arrays.asList(resposta.getContaCartao());

	}
	
	@Transactional
	@Override
	public void doAlterarSenhaCartao(Integer idConta, 
									  String numCartao,
									  String senhaAnterior, 
									  String novaSenha, 
									  String tipoCadastroSenha, 
									  Integer senhaCriptografada, 
									  String registroLogAlteracao) 
													  throws IntegracaoProcessadoraException, 
													  		 IntegracaoException, 
													  		 CalsystemInvalidArgumentException {
		
			validarParametrosAlteracaoSenhaCartao(idConta, 
													numCartao,
													senhaAnterior, 
													novaSenha, 
													tipoCadastroSenha, 
													senhaCriptografada, 
													registroLogAlteracao);
				
			CartaoSoapProxy serviceProxy = new CartaoSoapProxy();
			
			final String NOME_SERVICO_EXECUTADO = "CadastrarAlterarSenhaCartao";
			
			Gson gson = new Gson();
			
			CadastrarAlterarSenhaCartaoReq requisicao = new CadastrarAlterarSenhaCartaoReq();
			CadastrarAlterarSenhaCartaoResp resposta = null;
			
			//if (idConta != null)
			requisicao.setId_Conta(idConta);
			
			//if (numCartao != null)
			requisicao.setNumCartao(numCartao);
			
			//if (senhaAnterior != null)
			requisicao.setSenhaAnterior(senhaAnterior);
			
			//if (novaSenha != null)
			requisicao.setNovaSenha(novaSenha);
			
			//if (tipoCadastroSenha != null)
			requisicao.setCadastroSenha(tipoCadastroSenha);
			
			//if (senhaCriptografada != null)
			requisicao.setSenhaCriptografada(senhaCriptografada);
			
			//if (registroLogAlteracao != null)
			requisicao.setLogSistema(registroLogAlteracao);
			
			Date dataRequisicao = new Date();
			
			try {
				resposta = serviceProxy.cadastrarAlterarSenhaCartao(requisicao);
				
				if (resposta.getCodRetorno() != 0)
					throw new IntegracaoProcessadoraException(
							new StringBuilder("Ocorreu erro de integracao com a Processadora ao tentar alterar a senha do cartao final: ").append(numCartao).append( " ID Conta: ").append(idConta).append(" mensagem: ").append(resposta.getCodRetorno()).append(" - ").append(resposta.getDescricaoRetorno()).toString());
				
			} catch (RemoteException e) {
				throw new IntegracaoProcessadoraException(
						new StringBuilder("Ocorreu erro de integracao com a Processadora ao tentar alterar a senha do cartao final: ").append(numCartao).append( " ID Conta: ").append(idConta).append(" erro encontrado: ").append(e).toString());
			}
			
			Integracao integracao = new Integracao(
			NomeIntegracaoEnum.ALTERAR_SENHA_CARTAO_PROCESSADORA,
			NOME_SERVICO_EXECUTADO, gson.toJson(requisicao), gson.toJson(resposta),
			dataRequisicao, new Date());
			
			this.daoService.doCreate(integracao);
			
	}
	
	 
	
	private void validarParametrosAlteracaoSenhaCartao(Integer idConta, 
														  String numCartao,
														  String senhaAnterior, 
														  String novaSenha, 
														  String tipoCadastroSenha, 
														  Integer senhaCriptografada, 
														  String registroLogAlteracao) throws CalsystemInvalidArgumentException{
		try{
			
			if (idConta  == null)
				throw new CalsystemInvalidArgumentException(
						"ID da Conta deve ser informado!");
			
			if (numCartao == null)
				throw new CalsystemInvalidArgumentException(
						"N�mero do cart�o para atualiza��o n�o foi informado!");
			
			if (novaSenha == null)
				throw new CalsystemInvalidArgumentException(
						"Senha do cart�o para atualiza��o n�o foi informada!");
			
			if (tipoCadastroSenha == null)
				throw new CalsystemInvalidArgumentException(
						"Tipo de altera��o de senha do cart�o n�o foi informada!");
			
			if (senhaCriptografada  == null)
				throw new CalsystemInvalidArgumentException(
						"Parametro de Criptografia da senha do cart�o n�o foi informada!");
			
			if (tipoCadastroSenha != "0" && tipoCadastroSenha != "1" )
				throw new CalsystemInvalidArgumentException(
						"Tipo de altera��o de senha informado � inv�lido!");
			
			if (senhaCriptografada != 0 && senhaCriptografada != 1 )
				throw new CalsystemInvalidArgumentException(
						"Parametro de Criptografia de senha informado � inv�lido!");
			
			if (tipoCadastroSenha == "0" && senhaAnterior == null )
				throw new CalsystemInvalidArgumentException(
						"Para altera��o de senha existente � obrigat�rio informar a senha anterior!");
			
			if (numCartao.length() > 4)
				throw new CalsystemInvalidArgumentException(
						"Para altera��o de senha do cart�o, informar apenas os 4 �ltimos d�gitos do N�mero do cart�o!");
			
		}catch(Exception e){
			throw new CalsystemInvalidArgumentException(
					"Ocorreu erro na valida��o dos par�metros: " + e);
		}
		
	}
	

	public static void main(String[] args) throws RemoteException, IntegracaoProcessadoraException, 
	 												IntegracaoException, CalsystemInvalidArgumentException {
	//	ProcessadoraIntegradorService teste = new ProcessadoraIntegradorService();
		
	//	teste.doConsultarContas(null, 1521268);
		
	//	teste.doConsultarCartoes("77063481215");
		
	//	teste.doAlterarSenhaCartao(1521268, "2296", null, "2347", "1", 0, "CALSYSTEM TESTE");
		
	}

}
