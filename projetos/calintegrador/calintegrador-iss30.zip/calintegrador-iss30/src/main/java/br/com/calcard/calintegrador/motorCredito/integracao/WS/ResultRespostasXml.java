/**
 * ResultRespostasXml.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.motorCredito.integracao.WS;

public class ResultRespostasXml  implements java.io.Serializable {
    private java.lang.String sistema;

    private java.lang.String criterio;

    private java.lang.String resposta;

    private boolean _final;  // attribute

    public ResultRespostasXml() {
    }

    public ResultRespostasXml(
           java.lang.String sistema,
           java.lang.String criterio,
           java.lang.String resposta,
           boolean _final) {
           this.sistema = sistema;
           this.criterio = criterio;
           this.resposta = resposta;
           this._final = _final;
    }


    /**
     * Gets the sistema value for this ResultRespostasXml.
     * 
     * @return sistema
     */
    public java.lang.String getSistema() {
        return sistema;
    }


    /**
     * Sets the sistema value for this ResultRespostasXml.
     * 
     * @param sistema
     */
    public void setSistema(java.lang.String sistema) {
        this.sistema = sistema;
    }


    /**
     * Gets the criterio value for this ResultRespostasXml.
     * 
     * @return criterio
     */
    public java.lang.String getCriterio() {
        return criterio;
    }


    /**
     * Sets the criterio value for this ResultRespostasXml.
     * 
     * @param criterio
     */
    public void setCriterio(java.lang.String criterio) {
        this.criterio = criterio;
    }


    /**
     * Gets the resposta value for this ResultRespostasXml.
     * 
     * @return resposta
     */
    public java.lang.String getResposta() {
        return resposta;
    }


    /**
     * Sets the resposta value for this ResultRespostasXml.
     * 
     * @param resposta
     */
    public void setResposta(java.lang.String resposta) {
        this.resposta = resposta;
    }


    /**
     * Gets the _final value for this ResultRespostasXml.
     * 
     * @return _final
     */
    public boolean is_final() {
        return _final;
    }


    /**
     * Sets the _final value for this ResultRespostasXml.
     * 
     * @param _final
     */
    public void set_final(boolean _final) {
        this._final = _final;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ResultRespostasXml)) return false;
        ResultRespostasXml other = (ResultRespostasXml) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.sistema==null && other.getSistema()==null) || 
             (this.sistema!=null &&
              this.sistema.equals(other.getSistema()))) &&
            ((this.criterio==null && other.getCriterio()==null) || 
             (this.criterio!=null &&
              this.criterio.equals(other.getCriterio()))) &&
            ((this.resposta==null && other.getResposta()==null) || 
             (this.resposta!=null &&
              this.resposta.equals(other.getResposta()))) &&
            this._final == other.is_final();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSistema() != null) {
            _hashCode += getSistema().hashCode();
        }
        if (getCriterio() != null) {
            _hashCode += getCriterio().hashCode();
        }
        if (getResposta() != null) {
            _hashCode += getResposta().hashCode();
        }
        _hashCode += (is_final() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ResultRespostasXml.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("www.crivo.com.br", "ResultRespostasXml"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("_final");
        attrField.setXmlName(new javax.xml.namespace.QName("", "Final"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sistema");
        elemField.setXmlName(new javax.xml.namespace.QName("www.crivo.com.br", "Sistema"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("criterio");
        elemField.setXmlName(new javax.xml.namespace.QName("www.crivo.com.br", "Criterio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resposta");
        elemField.setXmlName(new javax.xml.namespace.QName("www.crivo.com.br", "Resposta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
