package br.com.calcard.calintegrador.motorFraude.interfaces;

import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.entity.Integracao;
import br.com.calcard.calintegrador.motorFraude.dto.ClearSaleDTO;
import br.com.calcard.calintegrador.motorFraude.dto.PropostaNegadaDTO;
import br.com.calcard.calintegrador.motorFraude.dto.RespostaAnaliseDTO;
import br.com.calcard.calintegrador.motorFraude.exception.IntegracaoFraudeException;

public interface IMotorFraude {

	public Integer doEnviarPropostaNegada(PropostaNegadaDTO propostaNegada);

	public List<RespostaAnaliseDTO> doTraduzirRespostaAnalise(
			String xmlRespostaAnalise) throws IntegracaoFraudeException;

	public List<RespostaAnaliseDTO> doConsultarRespostaAnalise()
			throws CalsystemInvalidArgumentException, ServiceException,
			IntegracaoFraudeException;

	public Integracao doEnviarProposta(ClearSaleDTO dto)
			throws ServiceException, CalsystemInvalidArgumentException;

	public Integracao doFlegarPropostaRecebida(Integer idProposta)
			throws CalsystemInvalidArgumentException, IntegracaoFraudeException;

}
