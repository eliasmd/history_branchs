package br.com.calcard.calintegrador.motorBiometria.dto;


public class RespostaAlteracaoStatusCreditRequestDTO {

	private String result;

	private CreditRequestDTO creditrequest;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public CreditRequestDTO getCreditrequest() {
		return creditrequest;
	}

	public void setCreditrequest(CreditRequestDTO creditrequest) {
		this.creditrequest = creditrequest;
	}


}
