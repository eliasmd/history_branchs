package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;

public class LogoutDTO {

	private String result;

	private AuthenticationDTO authentication;

	private List<String> messages;

	public LogoutDTO() {
		this.authentication = new AuthenticationDTO();
	}

	public LogoutDTO(String token) {
		this.authentication = new AuthenticationDTO(token);
	}

	public AuthenticationDTO getAuthentication() {
		return authentication;
	}

	public void setAuthentication(AuthenticationDTO authentication) {
		this.authentication = authentication;
	}

	public List<String> getMessages() {
		return messages;
	}

	public void setMessages(List<String> messages) {
		this.messages = messages;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
