/**
 * QuitacaoAnualDebito.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public class QuitacaoAnualDebito  implements java.io.Serializable {
    private java.lang.String dtDocumento;

    private java.lang.String tipoDeclaracao;

    private java.lang.String ano_referencia;

    private java.lang.Integer tipo_carteira;

    private java.lang.Integer id_conta;

    private java.lang.String cartao;

    private java.lang.String nome;

    private java.lang.String endereco;

    private java.lang.Integer numeroEnd;

    private java.lang.String complementoEnd;

    private java.lang.String cidadeEnd;

    private java.lang.String UFEnd;

    private java.lang.String CEPEnd;

    private java.lang.String bairroEnd;

    private java.lang.String numDocCliente;

    private java.lang.Integer flagDeficienteVisual;

    private java.lang.Short statusConta;

    private java.lang.String statusContaDescr;

    private java.lang.Short statusContabil;

    private java.lang.String descricaoStatusContabil;

    private java.lang.String cedente;

    private java.lang.Integer agencia;

    private java.lang.String CC;

    public QuitacaoAnualDebito() {
    }

    public QuitacaoAnualDebito(
           java.lang.String dtDocumento,
           java.lang.String tipoDeclaracao,
           java.lang.String ano_referencia,
           java.lang.Integer tipo_carteira,
           java.lang.Integer id_conta,
           java.lang.String cartao,
           java.lang.String nome,
           java.lang.String endereco,
           java.lang.Integer numeroEnd,
           java.lang.String complementoEnd,
           java.lang.String cidadeEnd,
           java.lang.String UFEnd,
           java.lang.String CEPEnd,
           java.lang.String bairroEnd,
           java.lang.String numDocCliente,
           java.lang.Integer flagDeficienteVisual,
           java.lang.Short statusConta,
           java.lang.String statusContaDescr,
           java.lang.Short statusContabil,
           java.lang.String descricaoStatusContabil,
           java.lang.String cedente,
           java.lang.Integer agencia,
           java.lang.String CC) {
           this.dtDocumento = dtDocumento;
           this.tipoDeclaracao = tipoDeclaracao;
           this.ano_referencia = ano_referencia;
           this.tipo_carteira = tipo_carteira;
           this.id_conta = id_conta;
           this.cartao = cartao;
           this.nome = nome;
           this.endereco = endereco;
           this.numeroEnd = numeroEnd;
           this.complementoEnd = complementoEnd;
           this.cidadeEnd = cidadeEnd;
           this.UFEnd = UFEnd;
           this.CEPEnd = CEPEnd;
           this.bairroEnd = bairroEnd;
           this.numDocCliente = numDocCliente;
           this.flagDeficienteVisual = flagDeficienteVisual;
           this.statusConta = statusConta;
           this.statusContaDescr = statusContaDescr;
           this.statusContabil = statusContabil;
           this.descricaoStatusContabil = descricaoStatusContabil;
           this.cedente = cedente;
           this.agencia = agencia;
           this.CC = CC;
    }


    /**
     * Gets the dtDocumento value for this QuitacaoAnualDebito.
     * 
     * @return dtDocumento
     */
    public java.lang.String getDtDocumento() {
        return dtDocumento;
    }


    /**
     * Sets the dtDocumento value for this QuitacaoAnualDebito.
     * 
     * @param dtDocumento
     */
    public void setDtDocumento(java.lang.String dtDocumento) {
        this.dtDocumento = dtDocumento;
    }


    /**
     * Gets the tipoDeclaracao value for this QuitacaoAnualDebito.
     * 
     * @return tipoDeclaracao
     */
    public java.lang.String getTipoDeclaracao() {
        return tipoDeclaracao;
    }


    /**
     * Sets the tipoDeclaracao value for this QuitacaoAnualDebito.
     * 
     * @param tipoDeclaracao
     */
    public void setTipoDeclaracao(java.lang.String tipoDeclaracao) {
        this.tipoDeclaracao = tipoDeclaracao;
    }


    /**
     * Gets the ano_referencia value for this QuitacaoAnualDebito.
     * 
     * @return ano_referencia
     */
    public java.lang.String getAno_referencia() {
        return ano_referencia;
    }


    /**
     * Sets the ano_referencia value for this QuitacaoAnualDebito.
     * 
     * @param ano_referencia
     */
    public void setAno_referencia(java.lang.String ano_referencia) {
        this.ano_referencia = ano_referencia;
    }


    /**
     * Gets the tipo_carteira value for this QuitacaoAnualDebito.
     * 
     * @return tipo_carteira
     */
    public java.lang.Integer getTipo_carteira() {
        return tipo_carteira;
    }


    /**
     * Sets the tipo_carteira value for this QuitacaoAnualDebito.
     * 
     * @param tipo_carteira
     */
    public void setTipo_carteira(java.lang.Integer tipo_carteira) {
        this.tipo_carteira = tipo_carteira;
    }


    /**
     * Gets the id_conta value for this QuitacaoAnualDebito.
     * 
     * @return id_conta
     */
    public java.lang.Integer getId_conta() {
        return id_conta;
    }


    /**
     * Sets the id_conta value for this QuitacaoAnualDebito.
     * 
     * @param id_conta
     */
    public void setId_conta(java.lang.Integer id_conta) {
        this.id_conta = id_conta;
    }


    /**
     * Gets the cartao value for this QuitacaoAnualDebito.
     * 
     * @return cartao
     */
    public java.lang.String getCartao() {
        return cartao;
    }


    /**
     * Sets the cartao value for this QuitacaoAnualDebito.
     * 
     * @param cartao
     */
    public void setCartao(java.lang.String cartao) {
        this.cartao = cartao;
    }


    /**
     * Gets the nome value for this QuitacaoAnualDebito.
     * 
     * @return nome
     */
    public java.lang.String getNome() {
        return nome;
    }


    /**
     * Sets the nome value for this QuitacaoAnualDebito.
     * 
     * @param nome
     */
    public void setNome(java.lang.String nome) {
        this.nome = nome;
    }


    /**
     * Gets the endereco value for this QuitacaoAnualDebito.
     * 
     * @return endereco
     */
    public java.lang.String getEndereco() {
        return endereco;
    }


    /**
     * Sets the endereco value for this QuitacaoAnualDebito.
     * 
     * @param endereco
     */
    public void setEndereco(java.lang.String endereco) {
        this.endereco = endereco;
    }


    /**
     * Gets the numeroEnd value for this QuitacaoAnualDebito.
     * 
     * @return numeroEnd
     */
    public java.lang.Integer getNumeroEnd() {
        return numeroEnd;
    }


    /**
     * Sets the numeroEnd value for this QuitacaoAnualDebito.
     * 
     * @param numeroEnd
     */
    public void setNumeroEnd(java.lang.Integer numeroEnd) {
        this.numeroEnd = numeroEnd;
    }


    /**
     * Gets the complementoEnd value for this QuitacaoAnualDebito.
     * 
     * @return complementoEnd
     */
    public java.lang.String getComplementoEnd() {
        return complementoEnd;
    }


    /**
     * Sets the complementoEnd value for this QuitacaoAnualDebito.
     * 
     * @param complementoEnd
     */
    public void setComplementoEnd(java.lang.String complementoEnd) {
        this.complementoEnd = complementoEnd;
    }


    /**
     * Gets the cidadeEnd value for this QuitacaoAnualDebito.
     * 
     * @return cidadeEnd
     */
    public java.lang.String getCidadeEnd() {
        return cidadeEnd;
    }


    /**
     * Sets the cidadeEnd value for this QuitacaoAnualDebito.
     * 
     * @param cidadeEnd
     */
    public void setCidadeEnd(java.lang.String cidadeEnd) {
        this.cidadeEnd = cidadeEnd;
    }


    /**
     * Gets the UFEnd value for this QuitacaoAnualDebito.
     * 
     * @return UFEnd
     */
    public java.lang.String getUFEnd() {
        return UFEnd;
    }


    /**
     * Sets the UFEnd value for this QuitacaoAnualDebito.
     * 
     * @param UFEnd
     */
    public void setUFEnd(java.lang.String UFEnd) {
        this.UFEnd = UFEnd;
    }


    /**
     * Gets the CEPEnd value for this QuitacaoAnualDebito.
     * 
     * @return CEPEnd
     */
    public java.lang.String getCEPEnd() {
        return CEPEnd;
    }


    /**
     * Sets the CEPEnd value for this QuitacaoAnualDebito.
     * 
     * @param CEPEnd
     */
    public void setCEPEnd(java.lang.String CEPEnd) {
        this.CEPEnd = CEPEnd;
    }


    /**
     * Gets the bairroEnd value for this QuitacaoAnualDebito.
     * 
     * @return bairroEnd
     */
    public java.lang.String getBairroEnd() {
        return bairroEnd;
    }


    /**
     * Sets the bairroEnd value for this QuitacaoAnualDebito.
     * 
     * @param bairroEnd
     */
    public void setBairroEnd(java.lang.String bairroEnd) {
        this.bairroEnd = bairroEnd;
    }


    /**
     * Gets the numDocCliente value for this QuitacaoAnualDebito.
     * 
     * @return numDocCliente
     */
    public java.lang.String getNumDocCliente() {
        return numDocCliente;
    }


    /**
     * Sets the numDocCliente value for this QuitacaoAnualDebito.
     * 
     * @param numDocCliente
     */
    public void setNumDocCliente(java.lang.String numDocCliente) {
        this.numDocCliente = numDocCliente;
    }


    /**
     * Gets the flagDeficienteVisual value for this QuitacaoAnualDebito.
     * 
     * @return flagDeficienteVisual
     */
    public java.lang.Integer getFlagDeficienteVisual() {
        return flagDeficienteVisual;
    }


    /**
     * Sets the flagDeficienteVisual value for this QuitacaoAnualDebito.
     * 
     * @param flagDeficienteVisual
     */
    public void setFlagDeficienteVisual(java.lang.Integer flagDeficienteVisual) {
        this.flagDeficienteVisual = flagDeficienteVisual;
    }


    /**
     * Gets the statusConta value for this QuitacaoAnualDebito.
     * 
     * @return statusConta
     */
    public java.lang.Short getStatusConta() {
        return statusConta;
    }


    /**
     * Sets the statusConta value for this QuitacaoAnualDebito.
     * 
     * @param statusConta
     */
    public void setStatusConta(java.lang.Short statusConta) {
        this.statusConta = statusConta;
    }


    /**
     * Gets the statusContaDescr value for this QuitacaoAnualDebito.
     * 
     * @return statusContaDescr
     */
    public java.lang.String getStatusContaDescr() {
        return statusContaDescr;
    }


    /**
     * Sets the statusContaDescr value for this QuitacaoAnualDebito.
     * 
     * @param statusContaDescr
     */
    public void setStatusContaDescr(java.lang.String statusContaDescr) {
        this.statusContaDescr = statusContaDescr;
    }


    /**
     * Gets the statusContabil value for this QuitacaoAnualDebito.
     * 
     * @return statusContabil
     */
    public java.lang.Short getStatusContabil() {
        return statusContabil;
    }


    /**
     * Sets the statusContabil value for this QuitacaoAnualDebito.
     * 
     * @param statusContabil
     */
    public void setStatusContabil(java.lang.Short statusContabil) {
        this.statusContabil = statusContabil;
    }


    /**
     * Gets the descricaoStatusContabil value for this QuitacaoAnualDebito.
     * 
     * @return descricaoStatusContabil
     */
    public java.lang.String getDescricaoStatusContabil() {
        return descricaoStatusContabil;
    }


    /**
     * Sets the descricaoStatusContabil value for this QuitacaoAnualDebito.
     * 
     * @param descricaoStatusContabil
     */
    public void setDescricaoStatusContabil(java.lang.String descricaoStatusContabil) {
        this.descricaoStatusContabil = descricaoStatusContabil;
    }


    /**
     * Gets the cedente value for this QuitacaoAnualDebito.
     * 
     * @return cedente
     */
    public java.lang.String getCedente() {
        return cedente;
    }


    /**
     * Sets the cedente value for this QuitacaoAnualDebito.
     * 
     * @param cedente
     */
    public void setCedente(java.lang.String cedente) {
        this.cedente = cedente;
    }


    /**
     * Gets the agencia value for this QuitacaoAnualDebito.
     * 
     * @return agencia
     */
    public java.lang.Integer getAgencia() {
        return agencia;
    }


    /**
     * Sets the agencia value for this QuitacaoAnualDebito.
     * 
     * @param agencia
     */
    public void setAgencia(java.lang.Integer agencia) {
        this.agencia = agencia;
    }


    /**
     * Gets the CC value for this QuitacaoAnualDebito.
     * 
     * @return CC
     */
    public java.lang.String getCC() {
        return CC;
    }


    /**
     * Sets the CC value for this QuitacaoAnualDebito.
     * 
     * @param CC
     */
    public void setCC(java.lang.String CC) {
        this.CC = CC;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QuitacaoAnualDebito)) return false;
        QuitacaoAnualDebito other = (QuitacaoAnualDebito) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.dtDocumento==null && other.getDtDocumento()==null) || 
             (this.dtDocumento!=null &&
              this.dtDocumento.equals(other.getDtDocumento()))) &&
            ((this.tipoDeclaracao==null && other.getTipoDeclaracao()==null) || 
             (this.tipoDeclaracao!=null &&
              this.tipoDeclaracao.equals(other.getTipoDeclaracao()))) &&
            ((this.ano_referencia==null && other.getAno_referencia()==null) || 
             (this.ano_referencia!=null &&
              this.ano_referencia.equals(other.getAno_referencia()))) &&
            ((this.tipo_carteira==null && other.getTipo_carteira()==null) || 
             (this.tipo_carteira!=null &&
              this.tipo_carteira.equals(other.getTipo_carteira()))) &&
            ((this.id_conta==null && other.getId_conta()==null) || 
             (this.id_conta!=null &&
              this.id_conta.equals(other.getId_conta()))) &&
            ((this.cartao==null && other.getCartao()==null) || 
             (this.cartao!=null &&
              this.cartao.equals(other.getCartao()))) &&
            ((this.nome==null && other.getNome()==null) || 
             (this.nome!=null &&
              this.nome.equals(other.getNome()))) &&
            ((this.endereco==null && other.getEndereco()==null) || 
             (this.endereco!=null &&
              this.endereco.equals(other.getEndereco()))) &&
            ((this.numeroEnd==null && other.getNumeroEnd()==null) || 
             (this.numeroEnd!=null &&
              this.numeroEnd.equals(other.getNumeroEnd()))) &&
            ((this.complementoEnd==null && other.getComplementoEnd()==null) || 
             (this.complementoEnd!=null &&
              this.complementoEnd.equals(other.getComplementoEnd()))) &&
            ((this.cidadeEnd==null && other.getCidadeEnd()==null) || 
             (this.cidadeEnd!=null &&
              this.cidadeEnd.equals(other.getCidadeEnd()))) &&
            ((this.UFEnd==null && other.getUFEnd()==null) || 
             (this.UFEnd!=null &&
              this.UFEnd.equals(other.getUFEnd()))) &&
            ((this.CEPEnd==null && other.getCEPEnd()==null) || 
             (this.CEPEnd!=null &&
              this.CEPEnd.equals(other.getCEPEnd()))) &&
            ((this.bairroEnd==null && other.getBairroEnd()==null) || 
             (this.bairroEnd!=null &&
              this.bairroEnd.equals(other.getBairroEnd()))) &&
            ((this.numDocCliente==null && other.getNumDocCliente()==null) || 
             (this.numDocCliente!=null &&
              this.numDocCliente.equals(other.getNumDocCliente()))) &&
            ((this.flagDeficienteVisual==null && other.getFlagDeficienteVisual()==null) || 
             (this.flagDeficienteVisual!=null &&
              this.flagDeficienteVisual.equals(other.getFlagDeficienteVisual()))) &&
            ((this.statusConta==null && other.getStatusConta()==null) || 
             (this.statusConta!=null &&
              this.statusConta.equals(other.getStatusConta()))) &&
            ((this.statusContaDescr==null && other.getStatusContaDescr()==null) || 
             (this.statusContaDescr!=null &&
              this.statusContaDescr.equals(other.getStatusContaDescr()))) &&
            ((this.statusContabil==null && other.getStatusContabil()==null) || 
             (this.statusContabil!=null &&
              this.statusContabil.equals(other.getStatusContabil()))) &&
            ((this.descricaoStatusContabil==null && other.getDescricaoStatusContabil()==null) || 
             (this.descricaoStatusContabil!=null &&
              this.descricaoStatusContabil.equals(other.getDescricaoStatusContabil()))) &&
            ((this.cedente==null && other.getCedente()==null) || 
             (this.cedente!=null &&
              this.cedente.equals(other.getCedente()))) &&
            ((this.agencia==null && other.getAgencia()==null) || 
             (this.agencia!=null &&
              this.agencia.equals(other.getAgencia()))) &&
            ((this.CC==null && other.getCC()==null) || 
             (this.CC!=null &&
              this.CC.equals(other.getCC())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDtDocumento() != null) {
            _hashCode += getDtDocumento().hashCode();
        }
        if (getTipoDeclaracao() != null) {
            _hashCode += getTipoDeclaracao().hashCode();
        }
        if (getAno_referencia() != null) {
            _hashCode += getAno_referencia().hashCode();
        }
        if (getTipo_carteira() != null) {
            _hashCode += getTipo_carteira().hashCode();
        }
        if (getId_conta() != null) {
            _hashCode += getId_conta().hashCode();
        }
        if (getCartao() != null) {
            _hashCode += getCartao().hashCode();
        }
        if (getNome() != null) {
            _hashCode += getNome().hashCode();
        }
        if (getEndereco() != null) {
            _hashCode += getEndereco().hashCode();
        }
        if (getNumeroEnd() != null) {
            _hashCode += getNumeroEnd().hashCode();
        }
        if (getComplementoEnd() != null) {
            _hashCode += getComplementoEnd().hashCode();
        }
        if (getCidadeEnd() != null) {
            _hashCode += getCidadeEnd().hashCode();
        }
        if (getUFEnd() != null) {
            _hashCode += getUFEnd().hashCode();
        }
        if (getCEPEnd() != null) {
            _hashCode += getCEPEnd().hashCode();
        }
        if (getBairroEnd() != null) {
            _hashCode += getBairroEnd().hashCode();
        }
        if (getNumDocCliente() != null) {
            _hashCode += getNumDocCliente().hashCode();
        }
        if (getFlagDeficienteVisual() != null) {
            _hashCode += getFlagDeficienteVisual().hashCode();
        }
        if (getStatusConta() != null) {
            _hashCode += getStatusConta().hashCode();
        }
        if (getStatusContaDescr() != null) {
            _hashCode += getStatusContaDescr().hashCode();
        }
        if (getStatusContabil() != null) {
            _hashCode += getStatusContabil().hashCode();
        }
        if (getDescricaoStatusContabil() != null) {
            _hashCode += getDescricaoStatusContabil().hashCode();
        }
        if (getCedente() != null) {
            _hashCode += getCedente().hashCode();
        }
        if (getAgencia() != null) {
            _hashCode += getAgencia().hashCode();
        }
        if (getCC() != null) {
            _hashCode += getCC().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QuitacaoAnualDebito.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "QuitacaoAnualDebito"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dtDocumento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DtDocumento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoDeclaracao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "TipoDeclaracao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ano_referencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Ano_referencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipo_carteira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Tipo_carteira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id_conta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Id_conta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Cartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nome");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Nome"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endereco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Endereco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumeroEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complementoEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "ComplementoEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cidadeEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CidadeEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UFEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "UFEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CEPEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CEPEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bairroEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "BairroEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numDocCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumDocCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flagDeficienteVisual");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "FlagDeficienteVisual"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "StatusConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "short"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusContaDescr");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "StatusContaDescr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusContabil");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "StatusContabil"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "short"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoStatusContabil");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DescricaoStatusContabil"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cedente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Cedente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("agencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Agencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
