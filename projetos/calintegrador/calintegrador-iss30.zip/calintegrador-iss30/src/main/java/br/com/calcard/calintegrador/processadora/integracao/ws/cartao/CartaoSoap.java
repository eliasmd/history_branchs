/**
 * CartaoSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.cartao;

public interface CartaoSoap extends java.rmi.Remote {

    /**
     * DesbloquearCartao
     */
    public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.DesbloquearCartaoResp desbloquearCartao(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.DesbloquearCartaoReq req) throws java.rmi.RemoteException;

    /**
     * CancelarCartao
     */
    public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CancelarCartaoResp cancelarCartao(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CancelarCartaoReq req) throws java.rmi.RemoteException;

    /**
     * CadastraAlteraSenha
     */
    public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastraAlteraSenhaResp cadastraAlteraSenha(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastraAlteraSenhaReq req) throws java.rmi.RemoteException;

    /**
     * RecuperarSenha
     */
    public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.RecuperarSenhaResp recuperarSenha(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.RecuperarSenhaReq req) throws java.rmi.RemoteException;

    /**
     * EsqueciSenhaCartao
     */
    public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.EsqueciSenhaCartaoResp esqueciSenhaCartao(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.EsqueciSenhaCartaoReq esqueciSenhaReq) throws java.rmi.RemoteException;

    /**
     * ConsultarCartãoEmbossing
     */
    public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.ConsultarCartaoEmbossingResp consultarCartaoEmbossing(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.ConsultarCartaoEmbossingReq req) throws java.rmi.RemoteException;

    /**
     * CadastrarAlterarSenhaCartao
     */
    public br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastrarAlterarSenhaCartaoResp cadastrarAlterarSenhaCartao(br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastrarAlterarSenhaCartaoReq req) throws java.rmi.RemoteException;
}
