package br.com.calcard.calintegrador.motorFraude.facade;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.entity.Integracao;
import br.com.calcard.calintegrador.motorFraude.dto.ClearSaleDTO;
import br.com.calcard.calintegrador.motorFraude.dto.PropostaNegadaDTO;
import br.com.calcard.calintegrador.motorFraude.dto.RespostaAnaliseDTO;
import br.com.calcard.calintegrador.motorFraude.exception.IntegracaoFraudeException;
import br.com.calcard.calintegrador.motorFraude.service.MotorFraudeService;
import br.com.calcard.calintegrador.service.ICalsystemXML;

@Component
public class MotorFraudeFacade {

	private ICalsystemDAO daoService;

	private ICalsystemXML xmlService;

	@Autowired
	public MotorFraudeFacade(ICalsystemDAO daoService, ICalsystemXML xmlService) {
		this.daoService = daoService;
		this.xmlService = xmlService;
	}

	public Integer doEnviarPropostaNegada(PropostaNegadaDTO propostaNegada) {

		return new MotorFraudeService(this.daoService, this.xmlService)
				.doEnviarPropostaNegada(propostaNegada);

	}

	public List<RespostaAnaliseDTO> doTraduzirRespostaAnalise(
			String xmlRespostaAnalise) throws IntegracaoFraudeException {

		return new MotorFraudeService(this.daoService, this.xmlService)
				.doTraduzirRespostaAnalise(xmlRespostaAnalise);

	}

	public List<RespostaAnaliseDTO> doConsultarRespostaAnalise()
			throws CalsystemInvalidArgumentException, ServiceException,
			IntegracaoFraudeException {

		return new MotorFraudeService(this.daoService, this.xmlService)
				.doConsultarRespostaAnalise();

	}

	public Integracao doEnviarProposta(ClearSaleDTO dto)
			throws ServiceException, CalsystemInvalidArgumentException {

		return new MotorFraudeService(this.daoService, this.xmlService)
				.doEnviarProposta(dto);

	}

	public Integracao doFlegarPropostaRecebida(Integer idProposta)
			throws CalsystemInvalidArgumentException, IntegracaoFraudeException {

		return new MotorFraudeService(this.daoService, this.xmlService)
				.doFlegarPropostaRecebida(idProposta);

	}

}
