package br.com.calcard.calintegrador.motorFraude.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ClearSale")
public class ClearSaleDTO {

	private List<OrderDTO> orders;

	public ClearSaleDTO() {

		this.orders = new ArrayList<OrderDTO>();

	}

	@XmlElementWrapper(name = "Orders")
	@XmlElement(name = "Order")
	public List<OrderDTO> getOrders() {
		return orders;
	}

	public void setOrders(List<OrderDTO> orders) {
		this.orders = orders;
	}

}
