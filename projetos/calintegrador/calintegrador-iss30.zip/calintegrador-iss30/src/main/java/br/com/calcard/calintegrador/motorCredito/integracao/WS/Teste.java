package br.com.calcard.calintegrador.motorCredito.integracao.WS;

import java.rmi.RemoteException;

import br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastrarAlterarSenhaCartaoReq;
import br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CadastrarAlterarSenhaCartaoResp;
import br.com.calcard.calintegrador.processadora.integracao.ws.cartao.CartaoSoapProxy;

public class Teste {

	public static void main(String[] args) throws RemoteException {

		CreditTalkStatelessSoapProxy serviceProxy = new CreditTalkStatelessSoapProxy();
			

			 String sUser = "calcard";
			 
			 String sPassword = "123calcard";
			 
			 String sPolitica = "1.00 - Origination Main p1";
			 
			 String sParametros = new StringBuilder("P\n").append("CPF;00366172964").toString();
			 
			 System.out.println(sParametros);
			
			
			 ResultEvalValuesXml retorno = serviceProxy.setPolicyEvalValuesObjectXml(sUser, sPassword, sPolitica, sParametros);
			 
			 System.out.println("retorno operacao:");
			 System.out.println(retorno.getCodigoOperacao());
			 System.out.println(retorno.getRespostas()[0].getCriterio());
			

	}

}
