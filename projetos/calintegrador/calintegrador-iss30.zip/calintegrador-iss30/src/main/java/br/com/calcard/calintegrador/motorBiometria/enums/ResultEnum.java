package br.com.calcard.calintegrador.motorBiometria.enums;

public enum ResultEnum {

	SUCESSO(1, "success"), ERRO(2, "error");

	private Integer id;

	private String codigo;

	private ResultEnum(Integer id, String codigo) {

		this.id = id;
		this.codigo = codigo;

	}

	public Integer getId() {
		return id;
	}

	public String getCodigo() {
		return codigo;
	}

}
