package br.com.calcard.calintegrador.motorFraude.enums;

public enum MotivoNegacaoEnum {

	BIOMETRIA, //
	RESTRITIVO, //
	SCORE;

}
