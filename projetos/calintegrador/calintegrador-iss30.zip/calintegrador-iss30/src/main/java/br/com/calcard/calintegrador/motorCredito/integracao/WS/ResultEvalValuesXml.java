/**
 * ResultEvalValuesXml.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.motorCredito.integracao.WS;

public class ResultEvalValuesXml  implements java.io.Serializable {
    private java.lang.String codigoOperacao;

    private java.lang.String[] operacoesObjetoAnalise;

    private br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultRespostasXml[] respostas;

    private br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultDriverXml[] drivers;

    public ResultEvalValuesXml() {
    }

    public ResultEvalValuesXml(
           java.lang.String codigoOperacao,
           java.lang.String[] operacoesObjetoAnalise,
           br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultRespostasXml[] respostas,
           br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultDriverXml[] drivers) {
           this.codigoOperacao = codigoOperacao;
           this.operacoesObjetoAnalise = operacoesObjetoAnalise;
           this.respostas = respostas;
           this.drivers = drivers;
    }


    /**
     * Gets the codigoOperacao value for this ResultEvalValuesXml.
     * 
     * @return codigoOperacao
     */
    public java.lang.String getCodigoOperacao() {
        return codigoOperacao;
    }


    /**
     * Sets the codigoOperacao value for this ResultEvalValuesXml.
     * 
     * @param codigoOperacao
     */
    public void setCodigoOperacao(java.lang.String codigoOperacao) {
        this.codigoOperacao = codigoOperacao;
    }


    /**
     * Gets the operacoesObjetoAnalise value for this ResultEvalValuesXml.
     * 
     * @return operacoesObjetoAnalise
     */
    public java.lang.String[] getOperacoesObjetoAnalise() {
        return operacoesObjetoAnalise;
    }


    /**
     * Sets the operacoesObjetoAnalise value for this ResultEvalValuesXml.
     * 
     * @param operacoesObjetoAnalise
     */
    public void setOperacoesObjetoAnalise(java.lang.String[] operacoesObjetoAnalise) {
        this.operacoesObjetoAnalise = operacoesObjetoAnalise;
    }


    /**
     * Gets the respostas value for this ResultEvalValuesXml.
     * 
     * @return respostas
     */
    public br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultRespostasXml[] getRespostas() {
        return respostas;
    }


    /**
     * Sets the respostas value for this ResultEvalValuesXml.
     * 
     * @param respostas
     */
    public void setRespostas(br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultRespostasXml[] respostas) {
        this.respostas = respostas;
    }


    /**
     * Gets the drivers value for this ResultEvalValuesXml.
     * 
     * @return drivers
     */
    public br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultDriverXml[] getDrivers() {
        return drivers;
    }


    /**
     * Sets the drivers value for this ResultEvalValuesXml.
     * 
     * @param drivers
     */
    public void setDrivers(br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultDriverXml[] drivers) {
        this.drivers = drivers;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ResultEvalValuesXml)) return false;
        ResultEvalValuesXml other = (ResultEvalValuesXml) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoOperacao==null && other.getCodigoOperacao()==null) || 
             (this.codigoOperacao!=null &&
              this.codigoOperacao.equals(other.getCodigoOperacao()))) &&
            ((this.operacoesObjetoAnalise==null && other.getOperacoesObjetoAnalise()==null) || 
             (this.operacoesObjetoAnalise!=null &&
              java.util.Arrays.equals(this.operacoesObjetoAnalise, other.getOperacoesObjetoAnalise()))) &&
            ((this.respostas==null && other.getRespostas()==null) || 
             (this.respostas!=null &&
              java.util.Arrays.equals(this.respostas, other.getRespostas()))) &&
            ((this.drivers==null && other.getDrivers()==null) || 
             (this.drivers!=null &&
              java.util.Arrays.equals(this.drivers, other.getDrivers())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoOperacao() != null) {
            _hashCode += getCodigoOperacao().hashCode();
        }
        if (getOperacoesObjetoAnalise() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOperacoesObjetoAnalise());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOperacoesObjetoAnalise(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRespostas() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRespostas());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRespostas(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDrivers() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDrivers());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDrivers(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ResultEvalValuesXml.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("www.crivo.com.br", "ResultEvalValuesXml"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoOperacao");
        elemField.setXmlName(new javax.xml.namespace.QName("www.crivo.com.br", "CodigoOperacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operacoesObjetoAnalise");
        elemField.setXmlName(new javax.xml.namespace.QName("www.crivo.com.br", "OperacoesObjetoAnalise"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("www.crivo.com.br", "CodigoOperacao"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("respostas");
        elemField.setXmlName(new javax.xml.namespace.QName("www.crivo.com.br", "Respostas"));
        elemField.setXmlType(new javax.xml.namespace.QName("www.crivo.com.br", "ResultRespostasXml"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("www.crivo.com.br", "Resposta"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("drivers");
        elemField.setXmlName(new javax.xml.namespace.QName("www.crivo.com.br", "Drivers"));
        elemField.setXmlType(new javax.xml.namespace.QName("www.crivo.com.br", "ResultDriverXml"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("www.crivo.com.br", "Driver"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
