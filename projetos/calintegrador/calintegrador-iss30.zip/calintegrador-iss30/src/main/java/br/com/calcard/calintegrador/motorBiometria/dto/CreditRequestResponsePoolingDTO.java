package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CreditRequestResponsePoolingDTO {

	private Integer id;
	
	private String fraud;

	private String state;

	@JsonProperty("state_id")
	private String stateId;
	
	@JsonProperty("biometry_result")
	private String biometryResult;

	private List<String> alert;

	private ContentCol1 col1;
	
	private ContentCol2 col2;
	
	private ContentCol3 col3;

	public CreditRequestResponsePoolingDTO() {
	}

	public CreditRequestResponsePoolingDTO(Integer id) {
		this.setId(id);
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFraud() {
		return fraud;
	}

	public void setFraud(String fraud) {
		this.fraud = fraud;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStateId() {
		return stateId;
	}

	public void setStateId(String stateId) {
		this.stateId = stateId;
	}

	public String getBiometryResult() {
		return biometryResult;
	}

	public void setBiometryResult(String biometryResult) {
		this.biometryResult = biometryResult;
	}

	public List<String> getAlert() {
		return alert;
	}

	public void setAlert(List<String> alert) {
		this.alert = alert;
	}

	public ContentCol1 getCol1() {
		return col1;
	}

	public void setCol1(ContentCol1 col1) {
		this.col1 = col1;
	}

	public ContentCol2 getCol2() {
		return col2;
	}

	public void setCol2(ContentCol2 col2) {
		this.col2 = col2;
	}

	public ContentCol3 getCol3() {
		return col3;
	}

	public void setCol3(ContentCol3 col3) {
		this.col3 = col3;
	}
	
	public class ContentCol1 {
		
		private CreditRequestDTO creditrequest;
		
		public ContentCol1() {
		}
		
		public void setCreditrequest(CreditRequestDTO creditrequest) {
			this.creditrequest = creditrequest;
		}

		public CreditRequestDTO getCreditrequest() {
			return creditrequest;
		}
		
    }
	
	@JsonIgnoreProperties(ignoreUnknown = true)
	public class ContentCol2 {
		
		private CreditRequestDTO customer;
		
		public ContentCol2() {
		}
		
		public void setCustomer(CreditRequestDTO customer) {
			this.customer = customer;
		}

		public CreditRequestDTO getCustomer() {
			return customer;
		}
		
    }
	
	public class ContentCol3 {
		
		private List<CreditRequestDTO> creditrequest_similars;
		
		private List<CreditRequestDTO> customer_similars;
		
		public ContentCol3() {
		}

		public List<CreditRequestDTO> getCreditrequest_similars() {
			return creditrequest_similars;
		}

		public void setCreditrequest_similars(
				List<CreditRequestDTO> creditrequest_similars) {
			this.creditrequest_similars = creditrequest_similars;
		}

		public List<CreditRequestDTO> getCustomer_similars() {
			return customer_similars;
		}

		public void setCustomer_similars(List<CreditRequestDTO> customer_similars) {
			this.customer_similars = customer_similars;
		}
		
		
    }
	
}
