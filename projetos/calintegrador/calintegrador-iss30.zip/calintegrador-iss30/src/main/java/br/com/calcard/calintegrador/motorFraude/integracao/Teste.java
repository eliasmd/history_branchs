package br.com.calcard.calintegrador.motorFraude.integracao;

import java.rmi.RemoteException;

public class Teste {

	public static void main(String[] args) throws RemoteException {
		// TODO Auto-generated method stub

		ServiceSoapProxy serviceProxy = new ServiceSoapProxy();

		System.out.println(serviceProxy.checkOrderStatus(
				"F414324C-8990-42E3-84DF-13882D675B58", "00000004"));

	}

}
