package br.com.calcard.calintegrador.motorBiometria.dto;

public class AssessmentDTO {

	private String result;

	private String messages;

	private String photo;

	public AssessmentDTO() {
		super();
	}

	public AssessmentDTO(String photo) {
		super();

		this.setPhoto(photo);

	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getMessages() {
		return messages;
	}

	public void setMessages(String messages) {
		this.messages = messages;
	}

}
