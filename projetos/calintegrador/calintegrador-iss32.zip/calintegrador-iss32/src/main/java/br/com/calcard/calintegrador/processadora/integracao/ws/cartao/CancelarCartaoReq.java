/**
 * CancelarCartaoReq.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.cartao;

public class CancelarCartaoReq  implements java.io.Serializable {
    private int id_Conta;

    private java.lang.String cartao;

    private int statusMotivo;

    private java.lang.String observacao;

    public CancelarCartaoReq() {
    }

    public CancelarCartaoReq(
           int id_Conta,
           java.lang.String cartao,
           int statusMotivo,
           java.lang.String observacao) {
           this.id_Conta = id_Conta;
           this.cartao = cartao;
           this.statusMotivo = statusMotivo;
           this.observacao = observacao;
    }


    /**
     * Gets the id_Conta value for this CancelarCartaoReq.
     * 
     * @return id_Conta
     */
    public int getId_Conta() {
        return id_Conta;
    }


    /**
     * Sets the id_Conta value for this CancelarCartaoReq.
     * 
     * @param id_Conta
     */
    public void setId_Conta(int id_Conta) {
        this.id_Conta = id_Conta;
    }


    /**
     * Gets the cartao value for this CancelarCartaoReq.
     * 
     * @return cartao
     */
    public java.lang.String getCartao() {
        return cartao;
    }


    /**
     * Sets the cartao value for this CancelarCartaoReq.
     * 
     * @param cartao
     */
    public void setCartao(java.lang.String cartao) {
        this.cartao = cartao;
    }


    /**
     * Gets the statusMotivo value for this CancelarCartaoReq.
     * 
     * @return statusMotivo
     */
    public int getStatusMotivo() {
        return statusMotivo;
    }


    /**
     * Sets the statusMotivo value for this CancelarCartaoReq.
     * 
     * @param statusMotivo
     */
    public void setStatusMotivo(int statusMotivo) {
        this.statusMotivo = statusMotivo;
    }


    /**
     * Gets the observacao value for this CancelarCartaoReq.
     * 
     * @return observacao
     */
    public java.lang.String getObservacao() {
        return observacao;
    }


    /**
     * Sets the observacao value for this CancelarCartaoReq.
     * 
     * @param observacao
     */
    public void setObservacao(java.lang.String observacao) {
        this.observacao = observacao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CancelarCartaoReq)) return false;
        CancelarCartaoReq other = (CancelarCartaoReq) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.id_Conta == other.getId_Conta() &&
            ((this.cartao==null && other.getCartao()==null) || 
             (this.cartao!=null &&
              this.cartao.equals(other.getCartao()))) &&
            this.statusMotivo == other.getStatusMotivo() &&
            ((this.observacao==null && other.getObservacao()==null) || 
             (this.observacao!=null &&
              this.observacao.equals(other.getObservacao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getId_Conta();
        if (getCartao() != null) {
            _hashCode += getCartao().hashCode();
        }
        _hashCode += getStatusMotivo();
        if (getObservacao() != null) {
            _hashCode += getObservacao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CancelarCartaoReq.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "CancelarCartaoReq"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id_Conta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Id_Conta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Cartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusMotivo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "StatusMotivo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("observacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Observacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
