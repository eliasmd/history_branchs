/**
 * RecuperarSenhaReq.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.cartao;

public class RecuperarSenhaReq  implements java.io.Serializable {
    private java.lang.Integer IDConta;

    private java.lang.String numCartao;

    private java.lang.String codigoSeguranca;

    private java.lang.String senha;

    public RecuperarSenhaReq() {
    }

    public RecuperarSenhaReq(
           java.lang.Integer IDConta,
           java.lang.String numCartao,
           java.lang.String codigoSeguranca,
           java.lang.String senha) {
           this.IDConta = IDConta;
           this.numCartao = numCartao;
           this.codigoSeguranca = codigoSeguranca;
           this.senha = senha;
    }


    /**
     * Gets the IDConta value for this RecuperarSenhaReq.
     * 
     * @return IDConta
     */
    public java.lang.Integer getIDConta() {
        return IDConta;
    }


    /**
     * Sets the IDConta value for this RecuperarSenhaReq.
     * 
     * @param IDConta
     */
    public void setIDConta(java.lang.Integer IDConta) {
        this.IDConta = IDConta;
    }


    /**
     * Gets the numCartao value for this RecuperarSenhaReq.
     * 
     * @return numCartao
     */
    public java.lang.String getNumCartao() {
        return numCartao;
    }


    /**
     * Sets the numCartao value for this RecuperarSenhaReq.
     * 
     * @param numCartao
     */
    public void setNumCartao(java.lang.String numCartao) {
        this.numCartao = numCartao;
    }


    /**
     * Gets the codigoSeguranca value for this RecuperarSenhaReq.
     * 
     * @return codigoSeguranca
     */
    public java.lang.String getCodigoSeguranca() {
        return codigoSeguranca;
    }


    /**
     * Sets the codigoSeguranca value for this RecuperarSenhaReq.
     * 
     * @param codigoSeguranca
     */
    public void setCodigoSeguranca(java.lang.String codigoSeguranca) {
        this.codigoSeguranca = codigoSeguranca;
    }


    /**
     * Gets the senha value for this RecuperarSenhaReq.
     * 
     * @return senha
     */
    public java.lang.String getSenha() {
        return senha;
    }


    /**
     * Sets the senha value for this RecuperarSenhaReq.
     * 
     * @param senha
     */
    public void setSenha(java.lang.String senha) {
        this.senha = senha;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RecuperarSenhaReq)) return false;
        RecuperarSenhaReq other = (RecuperarSenhaReq) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.IDConta==null && other.getIDConta()==null) || 
             (this.IDConta!=null &&
              this.IDConta.equals(other.getIDConta()))) &&
            ((this.numCartao==null && other.getNumCartao()==null) || 
             (this.numCartao!=null &&
              this.numCartao.equals(other.getNumCartao()))) &&
            ((this.codigoSeguranca==null && other.getCodigoSeguranca()==null) || 
             (this.codigoSeguranca!=null &&
              this.codigoSeguranca.equals(other.getCodigoSeguranca()))) &&
            ((this.senha==null && other.getSenha()==null) || 
             (this.senha!=null &&
              this.senha.equals(other.getSenha())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIDConta() != null) {
            _hashCode += getIDConta().hashCode();
        }
        if (getNumCartao() != null) {
            _hashCode += getNumCartao().hashCode();
        }
        if (getCodigoSeguranca() != null) {
            _hashCode += getCodigoSeguranca().hashCode();
        }
        if (getSenha() != null) {
            _hashCode += getSenha().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RecuperarSenhaReq.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "RecuperarSenhaReq"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IDConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSeguranca");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CodigoSeguranca"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senha");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Senha"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
