package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;

public class ViewDocumentsDTO {

	private AuthenticationDTO authentication;

	private CreditRequestDTO creditrequest;

	private String result;

	private List<String> messages;
	
	private String code;

	public ViewDocumentsDTO() {
		this.authentication = new AuthenticationDTO();
		this.creditrequest = new CreditRequestDTO();
	}

	public ViewDocumentsDTO(AuthenticationDTO authentication,
			CreditRequestDTO creditrequest) {
		super();
		this.authentication = authentication;
		this.creditrequest = creditrequest;
	}

	public AuthenticationDTO getAuthentication() {
		return authentication;
	}

	public void setAuthentication(AuthenticationDTO authentication) {
		this.authentication = authentication;
	}

	public CreditRequestDTO getCreditrequest() {
		return creditrequest;
	}

	public void setCreditrequest(CreditRequestDTO creditrequest) {
		this.creditrequest = creditrequest;
	}

	public List<String> getMessages() {
		return messages;
	}

	public void setMessages(List<String> messages) {
		this.messages = messages;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	

}
