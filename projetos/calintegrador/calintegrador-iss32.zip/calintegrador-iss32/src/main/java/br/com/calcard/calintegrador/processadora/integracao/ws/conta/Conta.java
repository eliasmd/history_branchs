/**
 * Conta.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public interface Conta extends javax.xml.rpc.Service {
    public java.lang.String getContaSoapAddress();

    public ContaSoap getContaSoap() throws javax.xml.rpc.ServiceException;

    public ContaSoap getContaSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
