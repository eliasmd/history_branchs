package br.com.calcard.calintegrador.motorBiometria.interfaces;

import java.util.Date;
import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.DocumentDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoAlteracaoStatusCreditRequest;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoAnexoDocumentosDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoAvaliacaoFotoDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoEnvioFotoDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoLoginDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoLogoutDTO;
import br.com.calcard.calintegrador.motorBiometria.enums.StatusSolicitacaoDeCredito;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;

public interface IMotorBiometria {

	public IntegracaoAnexoDocumentosDTO doAnexarDocumentos(
			List<DocumentDTO> documentos, Integer creditRequestId)
			throws IntegracaoException, CalsystemInvalidArgumentException,
			ServiceException, IntegracaoMotorBiometriaException;

	public IntegracaoEnvioFotoDTO doEnviarCreditRequest(String cpf,
			String idLoja, String nome, Date dataNascimento, String foto)
			throws IntegracaoException, CalsystemInvalidArgumentException,
			ServiceException, IntegracaoMotorBiometriaException;

	public IntegracaoAvaliacaoFotoDTO doAvaliarFoto(String fotoBase64)
			throws IntegracaoException, CalsystemInvalidArgumentException,
			ServiceException, IntegracaoMotorBiometriaException;

	public IntegracaoAvaliacaoFotoDTO doConsultarAnaliseComFoto(
			Integer creditRequestId) throws CalsystemInvalidArgumentException,
			ServiceException, IntegracaoException,
			IntegracaoMotorBiometriaException;

	IntegracaoEnvioFotoDTO doEnviarCreditRequest(String cpf, String idLoja,
			String nome, Date dataNascimento, String foto,
			List<DocumentDTO> documentDTO) throws IntegracaoException,
			CalsystemInvalidArgumentException, ServiceException,
			IntegracaoMotorBiometriaException;
	
	public IntegracaoLoginDTO doLogin() throws IntegracaoException,
			CalsystemInvalidArgumentException, ServiceException,
			IntegracaoMotorBiometriaException;
	
	public IntegracaoLogoutDTO doLogout(String token)
			throws IntegracaoException, CalsystemInvalidArgumentException,
			ServiceException;
	
	public IntegracaoAlteracaoStatusCreditRequest doAlterarStatusSolicitacaoCredito(Integer creditRequestId,
			StatusSolicitacaoDeCredito statusAlterado, String comentario)
			throws IntegracaoException, CalsystemInvalidArgumentException,
			ServiceException, IntegracaoMotorBiometriaException;
	
	public IntegracaoAnexoDocumentosDTO doConsultarDocumentos(Integer creditRequestId)
			throws IntegracaoException, CalsystemInvalidArgumentException,
			ServiceException, IntegracaoMotorBiometriaException;

}
