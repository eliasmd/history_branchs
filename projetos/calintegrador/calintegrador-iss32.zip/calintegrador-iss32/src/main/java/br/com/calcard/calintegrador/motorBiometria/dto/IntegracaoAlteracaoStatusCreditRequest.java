package br.com.calcard.calintegrador.motorBiometria.dto;

public class IntegracaoAlteracaoStatusCreditRequest {

	private IntegracaoLoginDTO integracaoLogin;

	private Integer idIntegracao;

	private IntegracaoLogoutDTO integracaoLogout;
	
	private RespostaAlteracaoStatusCreditRequestDTO responseDTO;

	public IntegracaoAlteracaoStatusCreditRequest(IntegracaoLoginDTO integracaoLogin,
			Integer idIntegracao, IntegracaoLogoutDTO integracaoLogout) {
		super();
		this.integracaoLogin = integracaoLogin;
		this.idIntegracao = idIntegracao;
		this.integracaoLogout = integracaoLogout;
	}
	
	public IntegracaoAlteracaoStatusCreditRequest(IntegracaoLoginDTO integracaoLogin,
			Integer idIntegracao, IntegracaoLogoutDTO integracaoLogout, 
			RespostaAlteracaoStatusCreditRequestDTO responseDTO) {
		super();
		this.integracaoLogin = integracaoLogin;
		this.idIntegracao = idIntegracao;
		this.integracaoLogout = integracaoLogout;
		this.responseDTO = responseDTO;
	}

	public IntegracaoLoginDTO getIntegracaoLogin() {
		return integracaoLogin;
	}

	public void setIntegracaoLogin(IntegracaoLoginDTO integracaoLogin) {
		this.integracaoLogin = integracaoLogin;
	}

	public Integer getIdIntegracao() {
		return idIntegracao;
	}

	public void setIdIntegracao(Integer idIntegracao) {
		this.idIntegracao = idIntegracao;
	}

	public IntegracaoLogoutDTO getIntegracaoLogout() {
		return integracaoLogout;
	}

	public void setIntegracaoLogout(IntegracaoLogoutDTO integracaoLogout) {
		this.integracaoLogout = integracaoLogout;
	}

	public RespostaAlteracaoStatusCreditRequestDTO getResponseDTO() {
		return responseDTO;
	}

	public void setResponseDTO(RespostaAlteracaoStatusCreditRequestDTO responseDTO) {
		this.responseDTO = responseDTO;
	}

}
