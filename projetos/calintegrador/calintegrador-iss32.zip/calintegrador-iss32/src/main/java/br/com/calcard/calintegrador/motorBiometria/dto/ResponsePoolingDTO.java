package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ResponsePoolingDTO {
	
		private String result;
		
		private CreditRequestResponsePoolingDTO creditrequest;
		
		
		private List<String> messages;

		public ResponsePoolingDTO() {
		}
		
		
		public String getResult() {
			return result;
		}

		public void setResult(String result) {
			this.result = result;
		}


		public CreditRequestResponsePoolingDTO getCreditrequest() {
			return creditrequest;
		}


		public void setCreditrequest(CreditRequestResponsePoolingDTO creditrequest) {
			this.creditrequest = creditrequest;
		}


		public List<String> getMessages() {
			return messages;
		}


		public void setMessages(List<String> messages) {
			this.messages = messages;
		}
		
		

		
}




