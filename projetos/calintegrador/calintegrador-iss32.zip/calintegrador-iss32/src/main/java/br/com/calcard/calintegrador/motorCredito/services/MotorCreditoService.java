package br.com.calcard.calintegrador.motorCredito.services;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calintegrador.entity.Integracao;
import br.com.calcard.calintegrador.enums.NomeIntegracaoEnum;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorCredito.exception.IntegracaoMotorCreditoException;
import br.com.calcard.calintegrador.motorCredito.integracao.WS.CreditTalkStatelessSoapProxy;
import br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultEvalValuesXml;
import br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultRespostasXml;
import br.com.calcard.calintegrador.motorCredito.interfaces.IMotorCredito;

import com.google.gson.Gson;

@Service
public class MotorCreditoService implements IMotorCredito {
	
	private ICalsystemDAO daoService;

	@Autowired
	public MotorCreditoService(ICalsystemDAO daoService) {
		this.daoService = daoService;
	}


	@Transactional
	@Override
	public ResultEvalValuesXml doConsultarPoliticaDeCredito(String usuario,
			String senha, String politica, Map<String, Object> parametros,
			boolean validarRetornoNull,String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException, IntegracaoException,
			CalsystemNoDataFoundException, IntegracaoMotorCreditoException{
		
		final String NOME_SERVICO_EXECUTADO = "SetPolicyEvalValuesObjectXml";
		
		
		doValidarParametrosConsultaPoliticaDeCredito(usuario, 
													senha, 
													politica, 
													parametros,
													NOME_SERVICO_EXECUTADO);

		CreditTalkStatelessSoapProxy serviceProxy = new CreditTalkStatelessSoapProxy();

		Gson gson = new Gson();
		
		ResultEvalValuesXml resposta = null;
		
		String parametrosFormatados = doComporParametros(parametros);

		String requisicaoLog = new StringBuilder(" Parametros informados: ")
										.append(" usuario: ").append(usuario)
										.append(" senha: ").append(senha)
										.append(" politica: ").append(politica)
										.append(" parametros: ").append(parametrosFormatados).toString();

		Date dataRequisicao = new Date();
		
		try {
			resposta = serviceProxy.setPolicyEvalValuesObjectXml(usuario, senha, politica, parametrosFormatados);
		} catch (RemoteException e) {
			throw new IntegracaoMotorCreditoException(
					new StringBuilder("Ocorreu erro de integracao com o Motor de Cr�dito na consulta do servi�o ")
					.append(NOME_SERVICO_EXECUTADO).append(" politica: ").append(politica).append(requisicaoLog).append(" Erro: ").append(e).toString());
		}

		Integracao integracao = new Integracao(
				NomeIntegracaoEnum.CONSULTAR_POLITICA_MOTOR_CREDITO,
				NOME_SERVICO_EXECUTADO, requisicaoLog,
				gson.toJson(resposta), dataRequisicao, new Date());

		this.daoService.doCreate(integracao);

		if (validarRetornoNull
				&& (resposta.getRespostas() == null || resposta
						.getRespostas().length == 0))
			throw new CalsystemNoDataFoundException(
					mensagemRetornoNull != null ? mensagemRetornoNull
							: "Nenhum registro encontrado!");

		return resposta;

	}
	
	private void doValidarParametrosConsultaPoliticaDeCredito(String usuario,
															  String senha, 
															  String politica, 
															  Map<String, Object> parametros,
															  String NOME_SERVICO_EXECUTADO) 
												throws CalsystemInvalidArgumentException{
		
		if (usuario == null || senha == null)
			throw new CalsystemInvalidArgumentException(
					new StringBuilder("Usu�rio ou Senha n�o informados na chamada do Motor de Cr�dito ").append(NOME_SERVICO_EXECUTADO).toString());
	
		if (politica == null)
			throw new CalsystemInvalidArgumentException(
				new StringBuilder("Pol�tica n�o informada na chamada do Motor de Cr�dito ").append(NOME_SERVICO_EXECUTADO).toString());
		
		if (parametros == null || parametros.isEmpty())
			throw new CalsystemInvalidArgumentException(
				new StringBuilder("Par�metros n�o informados na chamada do Motor de Cr�dito ").append(NOME_SERVICO_EXECUTADO).toString());
	
	}
	
	private String doComporParametros(Map<String, Object>  listaParametros){
		
		final String QUEBRA_DE_LINHA = "\n";
		final String DELIMITADOR_CRIVO_CHAVE_VALOR= ";";
		StringBuilder parametros = new StringBuilder("P\n");
		
		//for (String parametro : listaParametros) {
		for (Map.Entry<String, Object> parametro : listaParametros.entrySet())
		{
			parametros.append(parametro.getKey()).append(DELIMITADOR_CRIVO_CHAVE_VALOR).append(parametro.getValue()).append(QUEBRA_DE_LINHA);
			//parametros.append(parametro).append(QUEBRA_DE_LINHA);
		 }
		
		return parametros.toString();
		
	}
	
/*	public static void main(String[] args) throws CalsystemNoDataFoundException, CalsystemInvalidArgumentException, IntegracaoException, IntegracaoMotorCreditoException  {
		
		MotorCreditoService teste = new MotorCreditoService();
		
		 String usuario = "calcard";
		 
		 String senha = "123calcard";
		 
		 String politica = "1.00 - Origination Main p1";
		 
		 Map<String, String> parametros = new HashMap<String, String>();
		 parametros.put("P", "");
		 parametros.put("CPF", "00366172964");
		 
		 ///String parametros = new StringBuilder("P\n").append("CPF;00366172964").toString();
		
		teste.doConsultarPoliticaDeCredito(usuario, senha, politica, parametros, true, "Nenhuma resposta da consulta da pol�tica foi encontrada");
		
			
	}*/

}
