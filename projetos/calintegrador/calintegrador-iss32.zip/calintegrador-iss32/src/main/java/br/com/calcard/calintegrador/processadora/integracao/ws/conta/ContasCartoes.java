/**
 * ContasCartoes.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public class ContasCartoes  implements java.io.Serializable {
    private java.lang.Integer IDConta;

    private java.lang.Short idProduto;

    private java.lang.String descricaoProduto;

    private java.lang.Integer idCartao;

    private java.lang.String numCartao;

    private java.lang.String senhaCartao;

    public ContasCartoes() {
    }

    public ContasCartoes(
           java.lang.Integer IDConta,
           java.lang.Short idProduto,
           java.lang.String descricaoProduto,
           java.lang.Integer idCartao,
           java.lang.String numCartao,
           java.lang.String senhaCartao) {
           this.IDConta = IDConta;
           this.idProduto = idProduto;
           this.descricaoProduto = descricaoProduto;
           this.idCartao = idCartao;
           this.numCartao = numCartao;
           this.senhaCartao = senhaCartao;
    }


    /**
     * Gets the IDConta value for this ContasCartoes.
     * 
     * @return IDConta
     */
    public java.lang.Integer getIDConta() {
        return IDConta;
    }


    /**
     * Sets the IDConta value for this ContasCartoes.
     * 
     * @param IDConta
     */
    public void setIDConta(java.lang.Integer IDConta) {
        this.IDConta = IDConta;
    }


    /**
     * Gets the idProduto value for this ContasCartoes.
     * 
     * @return idProduto
     */
    public java.lang.Short getIdProduto() {
        return idProduto;
    }


    /**
     * Sets the idProduto value for this ContasCartoes.
     * 
     * @param idProduto
     */
    public void setIdProduto(java.lang.Short idProduto) {
        this.idProduto = idProduto;
    }


    /**
     * Gets the descricaoProduto value for this ContasCartoes.
     * 
     * @return descricaoProduto
     */
    public java.lang.String getDescricaoProduto() {
        return descricaoProduto;
    }


    /**
     * Sets the descricaoProduto value for this ContasCartoes.
     * 
     * @param descricaoProduto
     */
    public void setDescricaoProduto(java.lang.String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }


    /**
     * Gets the idCartao value for this ContasCartoes.
     * 
     * @return idCartao
     */
    public java.lang.Integer getIdCartao() {
        return idCartao;
    }


    /**
     * Sets the idCartao value for this ContasCartoes.
     * 
     * @param idCartao
     */
    public void setIdCartao(java.lang.Integer idCartao) {
        this.idCartao = idCartao;
    }


    /**
     * Gets the numCartao value for this ContasCartoes.
     * 
     * @return numCartao
     */
    public java.lang.String getNumCartao() {
        return numCartao;
    }


    /**
     * Sets the numCartao value for this ContasCartoes.
     * 
     * @param numCartao
     */
    public void setNumCartao(java.lang.String numCartao) {
        this.numCartao = numCartao;
    }


    /**
     * Gets the senhaCartao value for this ContasCartoes.
     * 
     * @return senhaCartao
     */
    public java.lang.String getSenhaCartao() {
        return senhaCartao;
    }


    /**
     * Sets the senhaCartao value for this ContasCartoes.
     * 
     * @param senhaCartao
     */
    public void setSenhaCartao(java.lang.String senhaCartao) {
        this.senhaCartao = senhaCartao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ContasCartoes)) return false;
        ContasCartoes other = (ContasCartoes) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.IDConta==null && other.getIDConta()==null) || 
             (this.IDConta!=null &&
              this.IDConta.equals(other.getIDConta()))) &&
            ((this.idProduto==null && other.getIdProduto()==null) || 
             (this.idProduto!=null &&
              this.idProduto.equals(other.getIdProduto()))) &&
            ((this.descricaoProduto==null && other.getDescricaoProduto()==null) || 
             (this.descricaoProduto!=null &&
              this.descricaoProduto.equals(other.getDescricaoProduto()))) &&
            ((this.idCartao==null && other.getIdCartao()==null) || 
             (this.idCartao!=null &&
              this.idCartao.equals(other.getIdCartao()))) &&
            ((this.numCartao==null && other.getNumCartao()==null) || 
             (this.numCartao!=null &&
              this.numCartao.equals(other.getNumCartao()))) &&
            ((this.senhaCartao==null && other.getSenhaCartao()==null) || 
             (this.senhaCartao!=null &&
              this.senhaCartao.equals(other.getSenhaCartao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIDConta() != null) {
            _hashCode += getIDConta().hashCode();
        }
        if (getIdProduto() != null) {
            _hashCode += getIdProduto().hashCode();
        }
        if (getDescricaoProduto() != null) {
            _hashCode += getDescricaoProduto().hashCode();
        }
        if (getIdCartao() != null) {
            _hashCode += getIdCartao().hashCode();
        }
        if (getNumCartao() != null) {
            _hashCode += getNumCartao().hashCode();
        }
        if (getSenhaCartao() != null) {
            _hashCode += getSenhaCartao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ContasCartoes.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "ContasCartoes"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IDConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IdProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "short"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DescricaoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IdCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senhaCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "SenhaCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
