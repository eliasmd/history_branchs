package br.com.calcard.calintegrador.dto;

import java.util.HashMap;
import java.util.Map;

public class RespostaIntegradorDTO {

	private Map<String, Object> respostaIntegracao;

	public RespostaIntegradorDTO() {
		this.respostaIntegracao = new HashMap<String, Object>();
	}

	public Map<String, Object> getRespostaIntegracao() {
		return respostaIntegracao;
	}

	public void setRespostaIntegracao(Map<String, Object> respostaIntegracao) {
		this.respostaIntegracao = respostaIntegracao;
	}

}
