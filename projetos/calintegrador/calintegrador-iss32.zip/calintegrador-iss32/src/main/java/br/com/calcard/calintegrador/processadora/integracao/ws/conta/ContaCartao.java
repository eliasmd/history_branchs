/**
 * ContaCartao.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public class ContaCartao  implements java.io.Serializable {
    private int IDConta;

    private java.lang.String CPF;

    private java.lang.String CNPJLoja;

    private java.lang.String nome;

    private java.lang.String dataCadastroConta;

    private java.lang.String possuiCompraAprovada;

    private java.lang.String dataNascimento;

    private java.lang.String numeroIdentidade;

    private java.lang.String orgaoIdentidade;

    private java.lang.String UFIdentidade;

    private java.lang.String dataEmissaoIdentidade;

    private java.lang.String DDDCelular;

    private java.lang.String numeroCelular;

    private int statusConta;

    public ContaCartao() {
    }

    public ContaCartao(
           int IDConta,
           java.lang.String CPF,
           java.lang.String CNPJLoja,
           java.lang.String nome,
           java.lang.String dataCadastroConta,
           java.lang.String possuiCompraAprovada,
           java.lang.String dataNascimento,
           java.lang.String numeroIdentidade,
           java.lang.String orgaoIdentidade,
           java.lang.String UFIdentidade,
           java.lang.String dataEmissaoIdentidade,
           java.lang.String DDDCelular,
           java.lang.String numeroCelular,
           int statusConta) {
           this.IDConta = IDConta;
           this.CPF = CPF;
           this.CNPJLoja = CNPJLoja;
           this.nome = nome;
           this.dataCadastroConta = dataCadastroConta;
           this.possuiCompraAprovada = possuiCompraAprovada;
           this.dataNascimento = dataNascimento;
           this.numeroIdentidade = numeroIdentidade;
           this.orgaoIdentidade = orgaoIdentidade;
           this.UFIdentidade = UFIdentidade;
           this.dataEmissaoIdentidade = dataEmissaoIdentidade;
           this.DDDCelular = DDDCelular;
           this.numeroCelular = numeroCelular;
           this.statusConta = statusConta;
    }


    /**
     * Gets the IDConta value for this ContaCartao.
     * 
     * @return IDConta
     */
    public int getIDConta() {
        return IDConta;
    }


    /**
     * Sets the IDConta value for this ContaCartao.
     * 
     * @param IDConta
     */
    public void setIDConta(int IDConta) {
        this.IDConta = IDConta;
    }


    /**
     * Gets the CPF value for this ContaCartao.
     * 
     * @return CPF
     */
    public java.lang.String getCPF() {
        return CPF;
    }


    /**
     * Sets the CPF value for this ContaCartao.
     * 
     * @param CPF
     */
    public void setCPF(java.lang.String CPF) {
        this.CPF = CPF;
    }


    /**
     * Gets the CNPJLoja value for this ContaCartao.
     * 
     * @return CNPJLoja
     */
    public java.lang.String getCNPJLoja() {
        return CNPJLoja;
    }


    /**
     * Sets the CNPJLoja value for this ContaCartao.
     * 
     * @param CNPJLoja
     */
    public void setCNPJLoja(java.lang.String CNPJLoja) {
        this.CNPJLoja = CNPJLoja;
    }


    /**
     * Gets the nome value for this ContaCartao.
     * 
     * @return nome
     */
    public java.lang.String getNome() {
        return nome;
    }


    /**
     * Sets the nome value for this ContaCartao.
     * 
     * @param nome
     */
    public void setNome(java.lang.String nome) {
        this.nome = nome;
    }


    /**
     * Gets the dataCadastroConta value for this ContaCartao.
     * 
     * @return dataCadastroConta
     */
    public java.lang.String getDataCadastroConta() {
        return dataCadastroConta;
    }


    /**
     * Sets the dataCadastroConta value for this ContaCartao.
     * 
     * @param dataCadastroConta
     */
    public void setDataCadastroConta(java.lang.String dataCadastroConta) {
        this.dataCadastroConta = dataCadastroConta;
    }


    /**
     * Gets the possuiCompraAprovada value for this ContaCartao.
     * 
     * @return possuiCompraAprovada
     */
    public java.lang.String getPossuiCompraAprovada() {
        return possuiCompraAprovada;
    }


    /**
     * Sets the possuiCompraAprovada value for this ContaCartao.
     * 
     * @param possuiCompraAprovada
     */
    public void setPossuiCompraAprovada(java.lang.String possuiCompraAprovada) {
        this.possuiCompraAprovada = possuiCompraAprovada;
    }


    /**
     * Gets the dataNascimento value for this ContaCartao.
     * 
     * @return dataNascimento
     */
    public java.lang.String getDataNascimento() {
        return dataNascimento;
    }


    /**
     * Sets the dataNascimento value for this ContaCartao.
     * 
     * @param dataNascimento
     */
    public void setDataNascimento(java.lang.String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }


    /**
     * Gets the numeroIdentidade value for this ContaCartao.
     * 
     * @return numeroIdentidade
     */
    public java.lang.String getNumeroIdentidade() {
        return numeroIdentidade;
    }


    /**
     * Sets the numeroIdentidade value for this ContaCartao.
     * 
     * @param numeroIdentidade
     */
    public void setNumeroIdentidade(java.lang.String numeroIdentidade) {
        this.numeroIdentidade = numeroIdentidade;
    }


    /**
     * Gets the orgaoIdentidade value for this ContaCartao.
     * 
     * @return orgaoIdentidade
     */
    public java.lang.String getOrgaoIdentidade() {
        return orgaoIdentidade;
    }


    /**
     * Sets the orgaoIdentidade value for this ContaCartao.
     * 
     * @param orgaoIdentidade
     */
    public void setOrgaoIdentidade(java.lang.String orgaoIdentidade) {
        this.orgaoIdentidade = orgaoIdentidade;
    }


    /**
     * Gets the UFIdentidade value for this ContaCartao.
     * 
     * @return UFIdentidade
     */
    public java.lang.String getUFIdentidade() {
        return UFIdentidade;
    }


    /**
     * Sets the UFIdentidade value for this ContaCartao.
     * 
     * @param UFIdentidade
     */
    public void setUFIdentidade(java.lang.String UFIdentidade) {
        this.UFIdentidade = UFIdentidade;
    }


    /**
     * Gets the dataEmissaoIdentidade value for this ContaCartao.
     * 
     * @return dataEmissaoIdentidade
     */
    public java.lang.String getDataEmissaoIdentidade() {
        return dataEmissaoIdentidade;
    }


    /**
     * Sets the dataEmissaoIdentidade value for this ContaCartao.
     * 
     * @param dataEmissaoIdentidade
     */
    public void setDataEmissaoIdentidade(java.lang.String dataEmissaoIdentidade) {
        this.dataEmissaoIdentidade = dataEmissaoIdentidade;
    }


    /**
     * Gets the DDDCelular value for this ContaCartao.
     * 
     * @return DDDCelular
     */
    public java.lang.String getDDDCelular() {
        return DDDCelular;
    }


    /**
     * Sets the DDDCelular value for this ContaCartao.
     * 
     * @param DDDCelular
     */
    public void setDDDCelular(java.lang.String DDDCelular) {
        this.DDDCelular = DDDCelular;
    }


    /**
     * Gets the numeroCelular value for this ContaCartao.
     * 
     * @return numeroCelular
     */
    public java.lang.String getNumeroCelular() {
        return numeroCelular;
    }


    /**
     * Sets the numeroCelular value for this ContaCartao.
     * 
     * @param numeroCelular
     */
    public void setNumeroCelular(java.lang.String numeroCelular) {
        this.numeroCelular = numeroCelular;
    }


    /**
     * Gets the statusConta value for this ContaCartao.
     * 
     * @return statusConta
     */
    public int getStatusConta() {
        return statusConta;
    }


    /**
     * Sets the statusConta value for this ContaCartao.
     * 
     * @param statusConta
     */
    public void setStatusConta(int statusConta) {
        this.statusConta = statusConta;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ContaCartao)) return false;
        ContaCartao other = (ContaCartao) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.IDConta == other.getIDConta() &&
            ((this.CPF==null && other.getCPF()==null) || 
             (this.CPF!=null &&
              this.CPF.equals(other.getCPF()))) &&
            ((this.CNPJLoja==null && other.getCNPJLoja()==null) || 
             (this.CNPJLoja!=null &&
              this.CNPJLoja.equals(other.getCNPJLoja()))) &&
            ((this.nome==null && other.getNome()==null) || 
             (this.nome!=null &&
              this.nome.equals(other.getNome()))) &&
            ((this.dataCadastroConta==null && other.getDataCadastroConta()==null) || 
             (this.dataCadastroConta!=null &&
              this.dataCadastroConta.equals(other.getDataCadastroConta()))) &&
            ((this.possuiCompraAprovada==null && other.getPossuiCompraAprovada()==null) || 
             (this.possuiCompraAprovada!=null &&
              this.possuiCompraAprovada.equals(other.getPossuiCompraAprovada()))) &&
            ((this.dataNascimento==null && other.getDataNascimento()==null) || 
             (this.dataNascimento!=null &&
              this.dataNascimento.equals(other.getDataNascimento()))) &&
            ((this.numeroIdentidade==null && other.getNumeroIdentidade()==null) || 
             (this.numeroIdentidade!=null &&
              this.numeroIdentidade.equals(other.getNumeroIdentidade()))) &&
            ((this.orgaoIdentidade==null && other.getOrgaoIdentidade()==null) || 
             (this.orgaoIdentidade!=null &&
              this.orgaoIdentidade.equals(other.getOrgaoIdentidade()))) &&
            ((this.UFIdentidade==null && other.getUFIdentidade()==null) || 
             (this.UFIdentidade!=null &&
              this.UFIdentidade.equals(other.getUFIdentidade()))) &&
            ((this.dataEmissaoIdentidade==null && other.getDataEmissaoIdentidade()==null) || 
             (this.dataEmissaoIdentidade!=null &&
              this.dataEmissaoIdentidade.equals(other.getDataEmissaoIdentidade()))) &&
            ((this.DDDCelular==null && other.getDDDCelular()==null) || 
             (this.DDDCelular!=null &&
              this.DDDCelular.equals(other.getDDDCelular()))) &&
            ((this.numeroCelular==null && other.getNumeroCelular()==null) || 
             (this.numeroCelular!=null &&
              this.numeroCelular.equals(other.getNumeroCelular()))) &&
            this.statusConta == other.getStatusConta();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getIDConta();
        if (getCPF() != null) {
            _hashCode += getCPF().hashCode();
        }
        if (getCNPJLoja() != null) {
            _hashCode += getCNPJLoja().hashCode();
        }
        if (getNome() != null) {
            _hashCode += getNome().hashCode();
        }
        if (getDataCadastroConta() != null) {
            _hashCode += getDataCadastroConta().hashCode();
        }
        if (getPossuiCompraAprovada() != null) {
            _hashCode += getPossuiCompraAprovada().hashCode();
        }
        if (getDataNascimento() != null) {
            _hashCode += getDataNascimento().hashCode();
        }
        if (getNumeroIdentidade() != null) {
            _hashCode += getNumeroIdentidade().hashCode();
        }
        if (getOrgaoIdentidade() != null) {
            _hashCode += getOrgaoIdentidade().hashCode();
        }
        if (getUFIdentidade() != null) {
            _hashCode += getUFIdentidade().hashCode();
        }
        if (getDataEmissaoIdentidade() != null) {
            _hashCode += getDataEmissaoIdentidade().hashCode();
        }
        if (getDDDCelular() != null) {
            _hashCode += getDDDCelular().hashCode();
        }
        if (getNumeroCelular() != null) {
            _hashCode += getNumeroCelular().hashCode();
        }
        _hashCode += getStatusConta();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ContaCartao.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "ContaCartao"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IDConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CPF");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CPF"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CNPJLoja");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CNPJLoja"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nome");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Nome"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataCadastroConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DataCadastroConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("possuiCompraAprovada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "PossuiCompraAprovada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataNascimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DataNascimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroIdentidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumeroIdentidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orgaoIdentidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "OrgaoIdentidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UFIdentidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "UFIdentidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataEmissaoIdentidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DataEmissaoIdentidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DDDCelular");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DDDCelular"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCelular");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumeroCelular"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "StatusConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
