package br.com.calcard.calintegrador.motorFraude.interfaces;

import java.util.Date;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calintegrador.entity.Integracao;
import br.com.calcard.calintegrador.enums.NomeIntegracaoEnum;

public interface ILogIntegracao {

	public Integracao doRegistrarLogIntegracao(Date dataRequisicao,
			Date dataResposta, String requisicao, String resposta,
			NomeIntegracaoEnum nomeIntegracao, String nomeServico)
			throws CalsystemInvalidArgumentException;

	public Integracao doRegistrarIntegracao(Integracao integracao)
			throws CalsystemInvalidArgumentException;

	public Integracao doRegistrarRespostaIntegracao(Integracao integracao)
			throws CalsystemInvalidArgumentException;

}
