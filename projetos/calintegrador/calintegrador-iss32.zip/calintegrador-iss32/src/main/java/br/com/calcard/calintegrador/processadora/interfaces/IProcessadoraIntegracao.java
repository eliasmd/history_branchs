package br.com.calcard.calintegrador.processadora.interfaces;

import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.processadora.exception.IntegracaoProcessadoraException;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.CartaoConsulta;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.ContaCartao;

public interface IProcessadoraIntegracao {


	public CartaoConsulta[] doConsultarCartoesProcessadora(Integer idConta,
			String cpfPortador, String numeroCartao, String cpfConta,
			boolean validarRetornoNull, String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			IntegracaoProcessadoraException, IntegracaoException,
			CalsystemNoDataFoundException;

	public List<CartaoConsulta> doConsultarCartoesProcessadoraAsList(
			Integer idConta, String cpfPortador, String numeroCartao,
			String cpfConta, boolean validarRetornoNull,
			String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			IntegracaoProcessadoraException, IntegracaoException,
			CalsystemNoDataFoundException;


	public List<ContaCartao> doConsultarContasProcessadora(String cpf, Integer idConta) 
															throws  IntegracaoProcessadoraException, 
																	IntegracaoException, 
																	CalsystemInvalidArgumentException;
	
	public void doAlterarSenhaCartao( Integer idConta, 
									  String numCartao,
									  String senhaAnterior, 
									  String novaSenha, 
									  String tipoCadastroSenha, 
									  Integer senhaCriptografada, 
									  String registroLogAlteracao) 
													  throws IntegracaoProcessadoraException, 
													  		 IntegracaoException, 
													  		 CalsystemInvalidArgumentException;
}
