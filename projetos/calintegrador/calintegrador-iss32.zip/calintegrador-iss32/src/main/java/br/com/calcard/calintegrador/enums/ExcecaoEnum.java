package br.com.calcard.calintegrador.enums;

public enum ExcecaoEnum {

	// Integracao
	EXCECAO_INTEGRACAO(300000, "300000"), //
	EXCECAO_INTEGRACAO_MOTOR_FRAUDE(300001, "300001"), //
	EXCECAO_INTEGRACAO_MOTOR_BIOMETRIA(300002, "300002");

	private Integer id;

	private String codigo;

	private ExcecaoEnum(Integer id, String codigo) {

		this.id = id;

		this.codigo = codigo;
	}

	public Integer getId() {
		return id;
	}

	public String getCodigo() {
		return codigo;
	}

}
