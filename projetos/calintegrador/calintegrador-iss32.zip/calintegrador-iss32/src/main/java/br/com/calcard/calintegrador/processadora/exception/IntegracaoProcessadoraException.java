package br.com.calcard.calintegrador.processadora.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class IntegracaoProcessadoraException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4684450315962296705L;

	public IntegracaoProcessadoraException(String message, Throwable cause) {
		super(message, cause);
	}

	public IntegracaoProcessadoraException(String message) {
		super(message);
	}

}
