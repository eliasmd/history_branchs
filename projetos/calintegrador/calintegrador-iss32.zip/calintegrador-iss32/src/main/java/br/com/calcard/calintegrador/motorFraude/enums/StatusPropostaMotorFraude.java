package br.com.calcard.calintegrador.motorFraude.enums;

public enum StatusPropostaMotorFraude {

	APROVACAO_AUTOMATICA("APA"), //

	APROVACAO_MANUAL("APM"), //

	REPROVADO_SEM_SUSPEITA("RPM"), //

	ANALISE_MANUAL("AMA"), //

	ERRO("ERR"), //

	NOVO("NVO"), //

	SUSPENSAO_MANUAL("SUS"), //

	CANCELADO_PELO_CLIENTE("CAN"), //

	FRAUDE_CONFIRMADA("FRD"), //

	REPROVACAO_AUTOMATICA("RPA"), //

	REPROVACAO_POR_POLITICA("RPP");//

	private String codigo;

	private StatusPropostaMotorFraude(String codigo) {
		this.codigo = codigo;
	}

	public String getCodigo() {
		return codigo;
	}

}
