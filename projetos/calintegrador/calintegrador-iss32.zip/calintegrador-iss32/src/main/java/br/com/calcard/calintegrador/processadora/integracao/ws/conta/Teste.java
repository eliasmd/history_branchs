package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

import java.rmi.RemoteException;


public class Teste {

	public static void main(String[] args) throws RemoteException {
		// TODO Auto-generated method stub

		ContaSoapProxy serviceProxy = new ContaSoapProxy();
		
		ConsultarContasReq requisicao = new ConsultarContasReq();
		
		requisicao.setIdConta(1521268);
		//requisicao.setCPF("77063481215");
		
		ConsultarContasResp resposta = new ConsultarContasResp();
		
		resposta = serviceProxy.consultarContas(requisicao);

		System.out.println(resposta.getCodRetorno());
		
		
		/* Teste consulta Conta		
		 * ContaSoapProxy serviceProxy = new ContaSoapProxy();
		
		ConsultarContasReq requisicao = new ConsultarContasReq();
		
		requisicao.setIdConta(1521268);
		//requisicao.setCPF("77063481215");
		
		ConsultarContasResp resposta = new ConsultarContasResp();
		
		resposta = serviceProxy.consultarContas(requisicao);

		System.out.println(resposta.getCodRetorno());*/
		

		/*Teste consulta Cartoes
		 * 
		ContaSoapProxy serviceProxy = new ContaSoapProxy();
		
		ConsultarCartoesReq requisicao = new ConsultarCartoesReq();
		
		requisicao.setIdConta(1521268);
		
		ConsultarCartoesResp resposta = new ConsultarCartoesResp();
		
		resposta = serviceProxy.consultarCartoes(requisicao);

		System.out.println(resposta.getCartaoConsulta(0));*/
	}

}
