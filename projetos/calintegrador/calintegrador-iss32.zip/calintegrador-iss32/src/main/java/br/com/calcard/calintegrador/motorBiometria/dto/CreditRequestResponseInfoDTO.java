package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CreditRequestResponseInfoDTO {

	private String id;

	private String result;

	private String state;

	@JsonProperty("state_id")
	private String stateId;

	private List<String> messages;

	private String code;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStateId() {
		return stateId;
	}

	public void setStateId(String stateId) {
		this.stateId = stateId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {

		this.state = state;

	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public List<String> getMessages() {
		return messages;
	}

	public void setMessages(List<String> messages) {
		this.messages = messages;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
