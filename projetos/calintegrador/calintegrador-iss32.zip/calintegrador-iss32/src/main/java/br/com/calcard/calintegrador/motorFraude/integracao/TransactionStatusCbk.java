/**
 * TransactionStatusCbk.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.motorFraude.integracao;

public class TransactionStatusCbk  extends br.com.calcard.calintegrador.motorFraude.integracao.TransactionStatus  implements java.io.Serializable {
    private br.com.calcard.calintegrador.motorFraude.integracao.Order[] orders;

    public TransactionStatusCbk() {
    }

    public TransactionStatusCbk(
           br.com.calcard.calintegrador.motorFraude.integracao.StatusCode statusCode,
           java.lang.String message,
           br.com.calcard.calintegrador.motorFraude.integracao.Order[] orders) {
        super(
            statusCode,
            message);
        this.orders = orders;
    }


    /**
     * Gets the orders value for this TransactionStatusCbk.
     * 
     * @return orders
     */
    public br.com.calcard.calintegrador.motorFraude.integracao.Order[] getOrders() {
        return orders;
    }


    /**
     * Sets the orders value for this TransactionStatusCbk.
     * 
     * @param orders
     */
    public void setOrders(br.com.calcard.calintegrador.motorFraude.integracao.Order[] orders) {
        this.orders = orders;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TransactionStatusCbk)) return false;
        TransactionStatusCbk other = (TransactionStatusCbk) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.orders==null && other.getOrders()==null) || 
             (this.orders!=null &&
              java.util.Arrays.equals(this.orders, other.getOrders())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getOrders() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrders());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrders(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TransactionStatusCbk.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.clearsale.com.br/integration", "TransactionStatusCbk"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orders");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.clearsale.com.br/integration", "Orders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.clearsale.com.br/integration", "Order"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.clearsale.com.br/integration", "Order"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
