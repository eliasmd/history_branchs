package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;

public class RespostaCreditRequestDTO {

	private String result;

	private List<CreditRequestDTO> creditrequest;

	private List<String> messages;

	private String code;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public List<CreditRequestDTO> getCreditrequest() {
		return creditrequest;
	}

	public void setCreditrequest(List<CreditRequestDTO> creditrequest) {
		this.creditrequest = creditrequest;
	}

	public List<String> getMessages() {
		return messages;
	}

	public void setMessages(List<String> messages) {
		this.messages = messages;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
