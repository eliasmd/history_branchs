package br.com.calcard.calintegrador.motorFraude.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calintegrador.entity.Integracao;
import br.com.calcard.calintegrador.enums.NomeIntegracaoEnum;
import br.com.calcard.calintegrador.motorFraude.interfaces.ILogIntegracao;

@Service
public class IntegracaoService implements ILogIntegracao {

	private ICalsystemDAO daoService;

	@Autowired
	public IntegracaoService(ICalsystemDAO daoService) {
		this.daoService = daoService;
	}

	public Integracao doRegistrarLogIntegracao(Date dataRequisicao,
			Date dataResposta, String requisicao, String resposta,
			NomeIntegracaoEnum nomeIntegracao, String nomeServico)
			throws CalsystemInvalidArgumentException {

		Integracao integracao = new Integracao();

		integracao.setDataRequisicao(dataRequisicao);
		integracao.setDataResposta(dataResposta);
		integracao.setLogRequisicao(requisicao);
		integracao.setLogResposta(resposta);
		integracao.setNome(nomeIntegracao);
		integracao.setNomeServico(nomeServico);

		return this.daoService.doCreate(integracao);

	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Integracao doRegistrarIntegracao(Integracao integracao)
			throws CalsystemInvalidArgumentException {

		return this.daoService
				.doCreate(integracao, "Integração não informada!");

	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Integracao doRegistrarRespostaIntegracao(Integracao integracao)
			throws CalsystemInvalidArgumentException {

		return this.daoService.doUpdate(integracao, "Integração não informada!");

	}


}
