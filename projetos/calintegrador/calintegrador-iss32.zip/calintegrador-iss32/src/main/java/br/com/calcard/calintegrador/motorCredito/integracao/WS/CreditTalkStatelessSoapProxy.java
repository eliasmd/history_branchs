package br.com.calcard.calintegrador.motorCredito.integracao.WS;

public class CreditTalkStatelessSoapProxy implements br.com.calcard.calintegrador.motorCredito.integracao.WS.CreditTalkStatelessSoap {
  private String _endpoint = null;
  private br.com.calcard.calintegrador.motorCredito.integracao.WS.CreditTalkStatelessSoap creditTalkStatelessSoap = null;
  
  public CreditTalkStatelessSoapProxy() {
    _initCreditTalkStatelessSoapProxy();
  }
  
  public CreditTalkStatelessSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initCreditTalkStatelessSoapProxy();
  }
  
  private void _initCreditTalkStatelessSoapProxy() {
    try {
      creditTalkStatelessSoap = (new br.com.calcard.calintegrador.motorCredito.integracao.WS.CreditTalkStatelessLocator()).getCreditTalkStatelessSoap();
      if (creditTalkStatelessSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)creditTalkStatelessSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)creditTalkStatelessSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (creditTalkStatelessSoap != null)
      ((javax.xml.rpc.Stub)creditTalkStatelessSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.calcard.calintegrador.motorCredito.integracao.WS.CreditTalkStatelessSoap getCreditTalkStatelessSoap() {
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap;
  }
  
  public java.lang.String report(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao, java.lang.String sDriver, java.lang.String sProduto) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.report(sUser, sPassword, sOperacao, sDriver, sProduto);
  }
  
  public java.lang.String explain(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.explain(sUser, sPassword, sOperacao);
  }
  
  public byte[] loadPDF(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.loadPDF(sUser, sPassword, sOperacao);
  }
  
  public java.lang.String values(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.values(sUser, sPassword, sOperacao);
  }
  
  public java.lang.String layout(java.lang.String sUser, java.lang.String sPassword) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.layout(sUser, sPassword);
  }
  
  public br.com.calcard.calintegrador.motorCredito.integracao.WS.Parametro[] parameters(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.parameters(sUser, sPassword, sOperacao);
  }
  
  public java.lang.String[] rawData(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao, java.lang.String sDriver, java.lang.String sProduto) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.rawData(sUser, sPassword, sOperacao, sDriver, sProduto);
  }
  
  public java.lang.String sources(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.sources(sUser, sPassword, sOperacao);
  }
  
  public java.lang.String loadLog(java.lang.String sUser, java.lang.String sPassword, java.lang.String sOperacao) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.loadLog(sUser, sPassword, sOperacao);
  }
  
  public java.lang.String eval(java.lang.String sUser, java.lang.String sPassword, java.lang.String sParametros) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.eval(sUser, sPassword, sParametros);
  }
  
  public java.lang.String setPolicyEval(java.lang.String sUser, java.lang.String sPassword, java.lang.String sPolitica, java.lang.String sParametros) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.setPolicyEval(sUser, sPassword, sPolitica, sParametros);
  }
  
  public java.lang.String setPolicyEvalValues(java.lang.String sUser, java.lang.String sPassword, java.lang.String sPolitica, java.lang.String sParametros) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.setPolicyEvalValues(sUser, sPassword, sPolitica, sParametros);
  }
  
  public java.lang.String setPolicyEvalValuesXml(java.lang.String sUser, java.lang.String sPassword, java.lang.String sPolitica, java.lang.String sParametros) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.setPolicyEvalValuesXml(sUser, sPassword, sPolitica, sParametros);
  }
  
  public br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultEvalValuesXml setPolicyEvalValuesObjectXml(java.lang.String sUser, java.lang.String sPassword, java.lang.String sPolitica, java.lang.String sParametros) throws java.rmi.RemoteException{
    if (creditTalkStatelessSoap == null)
      _initCreditTalkStatelessSoapProxy();
    return creditTalkStatelessSoap.setPolicyEvalValuesObjectXml(sUser, sPassword, sPolitica, sParametros);
  }
  
  
}