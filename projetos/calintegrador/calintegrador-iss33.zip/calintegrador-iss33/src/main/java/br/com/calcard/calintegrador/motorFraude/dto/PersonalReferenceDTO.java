package br.com.calcard.calintegrador.motorFraude.dto;

import javax.xml.bind.annotation.XmlElement;

public class PersonalReferenceDTO {

	private String nome;

	private String grauParentesco;

	private String ddd;

	private String telefone;

	private String ramal;

	public PersonalReferenceDTO() {
		// TODO Auto-generated constructor stub
	}

	public PersonalReferenceDTO(String nome, String grauParentesco, String ddd,
			String telefone, String ramal) {
		super();
		this.nome = nome;
		this.grauParentesco = grauParentesco;
		this.ddd = ddd;
		this.telefone = telefone;
		this.ramal = ramal;
	}

	@XmlElement(name = "Name")
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@XmlElement(name = "Relationship")
	public String getGrauParentesco() {
		return grauParentesco;
	}

	public void setGrauParentesco(String grauParentesco) {
		this.grauParentesco = grauParentesco;
	}

	@XmlElement(name = "PhoneExtension")
	public String getRamal() {
		return ramal;
	}

	public void setRamal(String ramal) {
		this.ramal = ramal;
	}

	public void setRamal(Integer ramal) {
		this.ramal = ramal == null ? null : ramal.toString();
	}

	@XmlElement(name = "PhoneNumber")
	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public void setTelefone(Integer telefone) {
		this.telefone = telefone == null ? null : telefone.toString();
	}

	@XmlElement(name = "PhoneAreaCode")
	public String getDdd() {
		return ddd;
	}

	public void setDdd(String ddd) {
		this.ddd = ddd;
	}

	public void setDdd(Integer ddd) {
		this.ddd = ddd == null ? null : ddd.toString();
	}

}
