package br.com.calcard.calintegrador.motorBiometria.integracao;

import java.util.List;

public class TesteDTO {

	private String result;

	private List<String> messages;

	private String version;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public List<String> getMessages() {
		return messages;
	}

	public void setMessages(List<String> messages) {
		this.messages = messages;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}
