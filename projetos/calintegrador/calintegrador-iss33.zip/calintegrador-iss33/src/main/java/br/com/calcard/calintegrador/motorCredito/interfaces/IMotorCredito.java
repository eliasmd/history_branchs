package br.com.calcard.calintegrador.motorCredito.interfaces;

import java.util.Map;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorCredito.exception.IntegracaoMotorCreditoException;
import br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultEvalValuesXml;
import br.com.calcard.calintegrador.processadora.exception.IntegracaoProcessadoraException;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.CartaoConsulta;

public interface IMotorCredito {

	public ResultEvalValuesXml doConsultarPoliticaDeCredito(String usuario,
			String senha, String politica, Map<String, Object> parametros,
			boolean validarRetornoNull,String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException, IntegracaoException,
			CalsystemNoDataFoundException, IntegracaoMotorCreditoException;

}
