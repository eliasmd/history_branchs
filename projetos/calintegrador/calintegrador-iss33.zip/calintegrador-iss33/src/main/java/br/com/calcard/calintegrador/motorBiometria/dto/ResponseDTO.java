package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;


public class ResponseDTO {
	
		private String result;
		
		private String code;
		
		private CreditRequestDTO creditrequest;
		
		private List<String> messages;

		public ResponseDTO() {
		}
		
		
		public String getResult() {
			return result;
		}

		public void setResult(String result) {
			this.result = result;
		}


		public CreditRequestDTO getCreditrequest() {
			return creditrequest;
		}


		public void setCreditrequest(CreditRequestDTO creditrequest) {
			this.creditrequest = creditrequest;
		}


		public List<String> getMessages() {
			return messages;
		}


		public void setMessages(List<String> messages) {
			this.messages = messages;
		}

		public String getCode() {
			return code;
		}


		public void setCode(String code) {
			this.code = code;
		}


		
}




