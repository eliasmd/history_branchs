package br.com.calcard.calintegrador.motorBiometria.dto;

public class IntegracaoConsultaStatusCreditRequest {

	private IntegracaoLoginDTO integracaoLogin;

	private Integer idIntegracao;

	private IntegracaoLogoutDTO integracaoLogout;
	
	private ResponseDTO responseDTO;

	public IntegracaoConsultaStatusCreditRequest(IntegracaoLoginDTO integracaoLogin,
												 Integer idIntegracao, 
												 IntegracaoLogoutDTO integracaoLogout) {
		super();
		this.integracaoLogin = integracaoLogin;
		this.idIntegracao = idIntegracao;
		this.integracaoLogout = integracaoLogout;
		
	}
	
	public IntegracaoConsultaStatusCreditRequest(IntegracaoLoginDTO integracaoLogin,
												 Integer idIntegracao, 
												 IntegracaoLogoutDTO integracaoLogout, 
												 ResponseDTO responseDTO) {
		super();
		this.integracaoLogin = integracaoLogin;
		this.idIntegracao = idIntegracao;
		this.integracaoLogout = integracaoLogout;
		this.responseDTO = responseDTO;
	}

	public IntegracaoLoginDTO getIntegracaoLogin() {
		return integracaoLogin;
	}

	public void setIntegracaoLogin(IntegracaoLoginDTO integracaoLogin) {
		this.integracaoLogin = integracaoLogin;
	}

	public Integer getIdIntegracao() {
		return idIntegracao;
	}

	public void setIdIntegracao(Integer idIntegracao) {
		this.idIntegracao = idIntegracao;
	}

	public IntegracaoLogoutDTO getIntegracaoLogout() {
		return integracaoLogout;
	}

	public void setIntegracaoLogout(IntegracaoLogoutDTO integracaoLogout) {
		this.integracaoLogout = integracaoLogout;
	}

	public ResponseDTO getResponseDTO() {
		return responseDTO;
	}

	public void setResponseDTO(ResponseDTO responseDTO) {
		this.responseDTO = responseDTO;
	}

}

