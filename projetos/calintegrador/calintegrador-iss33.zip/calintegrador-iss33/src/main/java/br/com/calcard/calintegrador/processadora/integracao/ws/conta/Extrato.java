/**
 * Extrato.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public class Extrato  implements java.io.Serializable {
    private int id_Conta;

    private java.lang.String nomePlastico;

    private java.lang.String dataOrigem;

    private java.lang.String nomeEstabelecimento;

    private java.lang.String conteudoTransacao;

    private java.lang.String creditoValor;

    private java.lang.String debitoValor;

    private java.lang.String limiteDisponivel;

    private java.lang.String status;

    private int codigoRetorno;

    private java.lang.String descricaoRetorno;

    public Extrato() {
    }

    public Extrato(
           int id_Conta,
           java.lang.String nomePlastico,
           java.lang.String dataOrigem,
           java.lang.String nomeEstabelecimento,
           java.lang.String conteudoTransacao,
           java.lang.String creditoValor,
           java.lang.String debitoValor,
           java.lang.String limiteDisponivel,
           java.lang.String status,
           int codigoRetorno,
           java.lang.String descricaoRetorno) {
           this.id_Conta = id_Conta;
           this.nomePlastico = nomePlastico;
           this.dataOrigem = dataOrigem;
           this.nomeEstabelecimento = nomeEstabelecimento;
           this.conteudoTransacao = conteudoTransacao;
           this.creditoValor = creditoValor;
           this.debitoValor = debitoValor;
           this.limiteDisponivel = limiteDisponivel;
           this.status = status;
           this.codigoRetorno = codigoRetorno;
           this.descricaoRetorno = descricaoRetorno;
    }


    /**
     * Gets the id_Conta value for this Extrato.
     * 
     * @return id_Conta
     */
    public int getId_Conta() {
        return id_Conta;
    }


    /**
     * Sets the id_Conta value for this Extrato.
     * 
     * @param id_Conta
     */
    public void setId_Conta(int id_Conta) {
        this.id_Conta = id_Conta;
    }


    /**
     * Gets the nomePlastico value for this Extrato.
     * 
     * @return nomePlastico
     */
    public java.lang.String getNomePlastico() {
        return nomePlastico;
    }


    /**
     * Sets the nomePlastico value for this Extrato.
     * 
     * @param nomePlastico
     */
    public void setNomePlastico(java.lang.String nomePlastico) {
        this.nomePlastico = nomePlastico;
    }


    /**
     * Gets the dataOrigem value for this Extrato.
     * 
     * @return dataOrigem
     */
    public java.lang.String getDataOrigem() {
        return dataOrigem;
    }


    /**
     * Sets the dataOrigem value for this Extrato.
     * 
     * @param dataOrigem
     */
    public void setDataOrigem(java.lang.String dataOrigem) {
        this.dataOrigem = dataOrigem;
    }


    /**
     * Gets the nomeEstabelecimento value for this Extrato.
     * 
     * @return nomeEstabelecimento
     */
    public java.lang.String getNomeEstabelecimento() {
        return nomeEstabelecimento;
    }


    /**
     * Sets the nomeEstabelecimento value for this Extrato.
     * 
     * @param nomeEstabelecimento
     */
    public void setNomeEstabelecimento(java.lang.String nomeEstabelecimento) {
        this.nomeEstabelecimento = nomeEstabelecimento;
    }


    /**
     * Gets the conteudoTransacao value for this Extrato.
     * 
     * @return conteudoTransacao
     */
    public java.lang.String getConteudoTransacao() {
        return conteudoTransacao;
    }


    /**
     * Sets the conteudoTransacao value for this Extrato.
     * 
     * @param conteudoTransacao
     */
    public void setConteudoTransacao(java.lang.String conteudoTransacao) {
        this.conteudoTransacao = conteudoTransacao;
    }


    /**
     * Gets the creditoValor value for this Extrato.
     * 
     * @return creditoValor
     */
    public java.lang.String getCreditoValor() {
        return creditoValor;
    }


    /**
     * Sets the creditoValor value for this Extrato.
     * 
     * @param creditoValor
     */
    public void setCreditoValor(java.lang.String creditoValor) {
        this.creditoValor = creditoValor;
    }


    /**
     * Gets the debitoValor value for this Extrato.
     * 
     * @return debitoValor
     */
    public java.lang.String getDebitoValor() {
        return debitoValor;
    }


    /**
     * Sets the debitoValor value for this Extrato.
     * 
     * @param debitoValor
     */
    public void setDebitoValor(java.lang.String debitoValor) {
        this.debitoValor = debitoValor;
    }


    /**
     * Gets the limiteDisponivel value for this Extrato.
     * 
     * @return limiteDisponivel
     */
    public java.lang.String getLimiteDisponivel() {
        return limiteDisponivel;
    }


    /**
     * Sets the limiteDisponivel value for this Extrato.
     * 
     * @param limiteDisponivel
     */
    public void setLimiteDisponivel(java.lang.String limiteDisponivel) {
        this.limiteDisponivel = limiteDisponivel;
    }


    /**
     * Gets the status value for this Extrato.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this Extrato.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the codigoRetorno value for this Extrato.
     * 
     * @return codigoRetorno
     */
    public int getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this Extrato.
     * 
     * @param codigoRetorno
     */
    public void setCodigoRetorno(int codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the descricaoRetorno value for this Extrato.
     * 
     * @return descricaoRetorno
     */
    public java.lang.String getDescricaoRetorno() {
        return descricaoRetorno;
    }


    /**
     * Sets the descricaoRetorno value for this Extrato.
     * 
     * @param descricaoRetorno
     */
    public void setDescricaoRetorno(java.lang.String descricaoRetorno) {
        this.descricaoRetorno = descricaoRetorno;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Extrato)) return false;
        Extrato other = (Extrato) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.id_Conta == other.getId_Conta() &&
            ((this.nomePlastico==null && other.getNomePlastico()==null) || 
             (this.nomePlastico!=null &&
              this.nomePlastico.equals(other.getNomePlastico()))) &&
            ((this.dataOrigem==null && other.getDataOrigem()==null) || 
             (this.dataOrigem!=null &&
              this.dataOrigem.equals(other.getDataOrigem()))) &&
            ((this.nomeEstabelecimento==null && other.getNomeEstabelecimento()==null) || 
             (this.nomeEstabelecimento!=null &&
              this.nomeEstabelecimento.equals(other.getNomeEstabelecimento()))) &&
            ((this.conteudoTransacao==null && other.getConteudoTransacao()==null) || 
             (this.conteudoTransacao!=null &&
              this.conteudoTransacao.equals(other.getConteudoTransacao()))) &&
            ((this.creditoValor==null && other.getCreditoValor()==null) || 
             (this.creditoValor!=null &&
              this.creditoValor.equals(other.getCreditoValor()))) &&
            ((this.debitoValor==null && other.getDebitoValor()==null) || 
             (this.debitoValor!=null &&
              this.debitoValor.equals(other.getDebitoValor()))) &&
            ((this.limiteDisponivel==null && other.getLimiteDisponivel()==null) || 
             (this.limiteDisponivel!=null &&
              this.limiteDisponivel.equals(other.getLimiteDisponivel()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            this.codigoRetorno == other.getCodigoRetorno() &&
            ((this.descricaoRetorno==null && other.getDescricaoRetorno()==null) || 
             (this.descricaoRetorno!=null &&
              this.descricaoRetorno.equals(other.getDescricaoRetorno())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getId_Conta();
        if (getNomePlastico() != null) {
            _hashCode += getNomePlastico().hashCode();
        }
        if (getDataOrigem() != null) {
            _hashCode += getDataOrigem().hashCode();
        }
        if (getNomeEstabelecimento() != null) {
            _hashCode += getNomeEstabelecimento().hashCode();
        }
        if (getConteudoTransacao() != null) {
            _hashCode += getConteudoTransacao().hashCode();
        }
        if (getCreditoValor() != null) {
            _hashCode += getCreditoValor().hashCode();
        }
        if (getDebitoValor() != null) {
            _hashCode += getDebitoValor().hashCode();
        }
        if (getLimiteDisponivel() != null) {
            _hashCode += getLimiteDisponivel().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        _hashCode += getCodigoRetorno();
        if (getDescricaoRetorno() != null) {
            _hashCode += getDescricaoRetorno().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Extrato.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "Extrato"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id_Conta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Id_Conta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePlastico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NomePlastico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataOrigem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DataOrigem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeEstabelecimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NomeEstabelecimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conteudoTransacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "ConteudoTransacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditoValor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CreditoValor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("debitoValor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DebitoValor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("limiteDisponivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "LimiteDisponivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CodigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DescricaoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
