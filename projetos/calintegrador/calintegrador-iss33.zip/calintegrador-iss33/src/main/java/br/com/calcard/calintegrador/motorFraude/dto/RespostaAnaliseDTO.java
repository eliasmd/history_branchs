package br.com.calcard.calintegrador.motorFraude.dto;

public class RespostaAnaliseDTO {

	private Integer idProposta;

	private String status;

	private Double score;

	private Integer idIntegracao;

	public RespostaAnaliseDTO() {
	}

	public RespostaAnaliseDTO(Integer idProposta, String status, Double score,
			Integer idIntegracao) {
		super();
		this.setIdProposta(idProposta);
		this.status = status;
		this.score = score;
		this.idIntegracao = idIntegracao;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

	public Integer getIdProposta() {
		return idProposta;
	}

	public void setIdProposta(Integer idProposta) {
		this.idProposta = idProposta;
	}

	public Integer getIdIntegracao() {
		return idIntegracao;
	}

	public void setIdIntegracao(Integer idIntegracao) {
		this.idIntegracao = idIntegracao;
	}

}
