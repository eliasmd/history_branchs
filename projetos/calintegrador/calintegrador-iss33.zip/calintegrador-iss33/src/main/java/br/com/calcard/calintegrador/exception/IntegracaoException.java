package br.com.calcard.calintegrador.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class IntegracaoException extends CalsystemException {

	private static final long serialVersionUID = -2964229609922196645L;

	public IntegracaoException(String message) {
		super(message);
	}

	public IntegracaoException(String message, Throwable e) {
		super(message, e);
	}

}
