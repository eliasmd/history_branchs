package br.com.calcard.calintegrador.dto;

import java.util.Date;

import br.com.calcard.calintegrador.enums.NomeIntegracaoEnum;

public class LogIntegracaoDTO {

	private Integer id;

	private NomeIntegracaoEnum nome;

	private String nomeServico;

	private String requisicao;

	private Object resposta;

	private Date dataRequisicao;

	private Date dataResposta;

	public LogIntegracaoDTO(String nomeServico, String requisicao,
			String resposta, Date dataRequisicao, Date dataResposta,
			NomeIntegracaoEnum nome) {
		super();
		this.nomeServico = nomeServico;
		this.requisicao = requisicao;
		this.resposta = resposta;
		this.dataRequisicao = dataRequisicao;
		this.dataResposta = dataResposta;
		this.nome = nome;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((dataRequisicao == null) ? 0 : dataRequisicao.hashCode());
		result = prime * result
				+ ((dataResposta == null) ? 0 : dataResposta.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result
				+ ((nomeServico == null) ? 0 : nomeServico.hashCode());
		result = prime * result
				+ ((requisicao == null) ? 0 : requisicao.hashCode());
		result = prime * result
				+ ((resposta == null) ? 0 : resposta.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LogIntegracaoDTO other = (LogIntegracaoDTO) obj;
		if (dataRequisicao == null) {
			if (other.dataRequisicao != null)
				return false;
		} else if (!dataRequisicao.equals(other.dataRequisicao))
			return false;
		if (dataResposta == null) {
			if (other.dataResposta != null)
				return false;
		} else if (!dataResposta.equals(other.dataResposta))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (nome != other.nome)
			return false;
		if (nomeServico == null) {
			if (other.nomeServico != null)
				return false;
		} else if (!nomeServico.equals(other.nomeServico))
			return false;
		if (requisicao == null) {
			if (other.requisicao != null)
				return false;
		} else if (!requisicao.equals(other.requisicao))
			return false;
		if (resposta == null) {
			if (other.resposta != null)
				return false;
		} else if (!resposta.equals(other.resposta))
			return false;
		return true;
	}

	public LogIntegracaoDTO() {
	}

	public String getNomeServico() {
		return nomeServico;
	}

	public void setNomeServico(String nomeServico) {
		this.nomeServico = nomeServico;
	}

	public String getRequisicao() {
		return requisicao;
	}

	public void setRequisicao(String requisicao) {
		this.requisicao = requisicao;
	}

	public Date getDataRequisicao() {
		return dataRequisicao;
	}

	public void setDataRequisicao(Date dataRequisicao) {
		this.dataRequisicao = dataRequisicao;
	}

	public Date getDataResposta() {
		return dataResposta;
	}

	public void setDataResposta(Date dataResposta) {
		this.dataResposta = dataResposta;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public NomeIntegracaoEnum getNome() {
		return nome;
	}

	public void setNome(NomeIntegracaoEnum nome) {
		this.nome = nome;
	}

	public Object getResposta() {
		return resposta;
	}

	public void setResposta(Object resposta) {
		this.resposta = resposta;
	}

}
