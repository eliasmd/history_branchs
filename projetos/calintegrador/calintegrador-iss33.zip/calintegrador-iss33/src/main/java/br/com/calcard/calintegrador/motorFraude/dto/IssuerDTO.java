package br.com.calcard.calintegrador.motorFraude.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

public class IssuerDTO {

	private String estabelecimento;

	private String promotor;

	private List<GenericDTO> generics;

	@XmlElement(name = "Promoter")
	public String getPromotor() {
		return promotor;
	}

	public void setPromotor(String promotor) {
		this.promotor = promotor;
	}

	@XmlElement(name = "Establishment")
	public String getEstabelecimento() {
		return estabelecimento;
	}

	public void setEstabelecimento(String estabelecimento) {
		this.estabelecimento = estabelecimento;
	}

	public void setEstabelecimento(Integer estabelecimento) {
		this.estabelecimento = estabelecimento == null ? null : estabelecimento
				.toString();
	}

	@XmlElementWrapper(name = "Generics")
	@XmlElement(name = "Generic")
	public List<GenericDTO> getGenerics() {
		return generics;
	}

	public void setGenerics(List<GenericDTO> generics) {
		this.generics = generics;
	}

}
