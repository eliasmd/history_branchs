package br.com.calcard.calintegrador.motorFraude.dto;

import java.util.Date;

import br.com.calcard.calintegrador.motorFraude.enums.MotivoNegacaoEnum;

public class PropostaNegadaDTO {

	private Integer id;

	private Date dataCadastro;

	private String nome;

	private Date dataNascimento;

	private String sexo;

	private String cpf;

	private MotivoNegacaoEnum motivoNegacao;

	public PropostaNegadaDTO() {
		super();
	}

	public PropostaNegadaDTO(Integer id, Date dataCadastro, String nome,
			Date dataNascimento, String sexo, String cpf,
			MotivoNegacaoEnum motivoNegacao) {
		super();
		this.id = id;
		this.dataCadastro = dataCadastro;
		this.nome = nome;
		this.dataNascimento = dataNascimento;
		this.sexo = sexo;
		this.cpf = cpf;
		this.motivoNegacao = motivoNegacao;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public MotivoNegacaoEnum getMotivoNegacao() {
		return motivoNegacao;
	}

	public void setMotivoNegacao(MotivoNegacaoEnum motivoNegacao) {
		this.motivoNegacao = motivoNegacao;
	}

}
