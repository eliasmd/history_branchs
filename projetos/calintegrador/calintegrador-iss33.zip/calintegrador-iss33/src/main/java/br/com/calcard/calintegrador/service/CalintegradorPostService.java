package br.com.calcard.calintegrador.service;

import java.util.Date;

import org.springframework.web.client.RestTemplate;

import br.com.calcard.calintegrador.dto.LogIntegracaoDTO;
import br.com.calcard.calintegrador.enums.NomeIntegracaoEnum;
import br.com.calcard.calintegrador.exception.IntegracaoException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class CalintegradorPostService {

	private RestTemplate restTemplate;

	private ObjectMapper conversorJson;

	public CalintegradorPostService() {

		this.restTemplate = new RestTemplate();

		this.conversorJson = new ObjectMapper();

	}

	public LogIntegracaoDTO doPost(String urlServico,
			NomeIntegracaoEnum nomeIntegracao, Object bodyRequisicao,
			Class<?> classeResposta) throws IntegracaoException {

		try {

			LogIntegracaoDTO logIntegracaoDTO = new LogIntegracaoDTO();

			logIntegracaoDTO.setNome(nomeIntegracao);

			logIntegracaoDTO.setNomeServico(urlServico);

			logIntegracaoDTO.setRequisicao(this.conversorJson
					.writeValueAsString(bodyRequisicao));

			logIntegracaoDTO.setDataRequisicao(new Date());
			
			// iniciou a solicitacao
			
			Object resposta = this.restTemplate.postForObject(urlServico,
					bodyRequisicao, classeResposta);
			
			// finalizou a solicitacao
			//tempo total da requisicao
			

			logIntegracaoDTO.setDataResposta(new Date());

			logIntegracaoDTO.setResposta(resposta);

			return logIntegracaoDTO;

		} catch (Exception e) {

			throw new IntegracaoException(
					"N�o foi poss�vel se comunicar com o motor de biometria!",
					e);
		}

	}

}
