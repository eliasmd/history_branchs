/**
 * CreditTalkStateless.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.motorCredito.integracao.WS;

public interface CreditTalkStateless extends javax.xml.rpc.Service {
    public java.lang.String getCreditTalkStatelessSoapAddress();

    public br.com.calcard.calintegrador.motorCredito.integracao.WS.CreditTalkStatelessSoap getCreditTalkStatelessSoap() throws javax.xml.rpc.ServiceException;

    public br.com.calcard.calintegrador.motorCredito.integracao.WS.CreditTalkStatelessSoap getCreditTalkStatelessSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
