package br.com.calcard.calintegrador.motorBiometria.enums;

public enum StatusSolicitacaoDeCredito {
	
	ATIVO(1, "A", "Solicita��o de Cr�dito Aprovada."),
	INATIVO(2, "I", "Solicita��o de Cr�dito Desconsiderada."),
	RESTRITO(3, "R", "Solicita��o de Cr�dito Reprovada.");
	
	private Integer id;
	
	private String codigo;
	
	private String descricao;
	
	private StatusSolicitacaoDeCredito(Integer id, String codigo, String descricao) {		
		this.id 		= id;
		this.codigo 	= codigo;
		this.descricao 	= descricao;
	}

	public Integer getId() {
		return id;
	}

	public String getDescricao() {
		return descricao;
	}

	public String getCodigo() {
		return codigo;
	}	
	
}
