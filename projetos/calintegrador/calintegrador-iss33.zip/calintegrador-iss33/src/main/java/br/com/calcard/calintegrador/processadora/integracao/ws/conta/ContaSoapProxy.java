package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public class ContaSoapProxy implements ContaSoap {
  private String _endpoint = null;
  private ContaSoap contaSoap = null;
  
  public ContaSoapProxy() {
    _initContaSoapProxy();
  }
  
  public ContaSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initContaSoapProxy();
  }
  
  private void _initContaSoapProxy() {
    try {
      contaSoap = (new ContaLocator()).getContaSoap();
      if (contaSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)contaSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)contaSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (contaSoap != null)
      ((javax.xml.rpc.Stub)contaSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public ContaSoap getContaSoap() {
    if (contaSoap == null)
      _initContaSoapProxy();
    return contaSoap;
  }
  
  public Extrato[] consultarExtratoSaldo(ConsultarExtratoSaldoReq req) throws java.rmi.RemoteException{
    if (contaSoap == null)
      _initContaSoapProxy();
    return contaSoap.consultarExtratoSaldo(req);
  }
  
  public ConsultarSaldoResp consultarSaldo(ConsultarSaldoReq req) throws java.rmi.RemoteException{
    if (contaSoap == null)
      _initContaSoapProxy();
    return contaSoap.consultarSaldo(req);
  }
  
  public TransferirCreditoResp transferirCredito(TransferirCreditoReq req) throws java.rmi.RemoteException{
    if (contaSoap == null)
      _initContaSoapProxy();
    return contaSoap.transferirCredito(req);
  }
  
  public RetornarContasCartoesResp retornarContasCartoes(RetornarContasCartoesReq req) throws java.rmi.RemoteException{
    if (contaSoap == null)
      _initContaSoapProxy();
    return contaSoap.retornarContasCartoes(req);
  }
  
  public VerificarPrimeiraCompraResp verificarPrimeiraCompra(VerificarPrimeiraCompraReq req) throws java.rmi.RemoteException{
    if (contaSoap == null)
      _initContaSoapProxy();
    return contaSoap.verificarPrimeiraCompra(req);
  }
  
  public TermoQuitacaoAnualDeDebitosResp consultaQuitacaoAnualDeDebitos(TermoQuitacaoAnualDeDebitosReq req) throws java.rmi.RemoteException{
    if (contaSoap == null)
      _initContaSoapProxy();
    return contaSoap.consultaQuitacaoAnualDeDebitos(req);
  }
  
  public ConsultarContasResp consultarContas(ConsultarContasReq req) throws java.rmi.RemoteException{
    if (contaSoap == null)
      _initContaSoapProxy();
    return contaSoap.consultarContas(req);
  }
  
  public ConsultarCartoesResp consultarCartoes(ConsultarCartoesReq req) throws java.rmi.RemoteException{
    if (contaSoap == null)
      _initContaSoapProxy();
    return contaSoap.consultarCartoes(req);
  }
  
  
}