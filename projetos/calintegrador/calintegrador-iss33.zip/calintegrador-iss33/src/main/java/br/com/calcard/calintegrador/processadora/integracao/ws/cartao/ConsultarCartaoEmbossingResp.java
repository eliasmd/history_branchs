/**
 * ConsultarCartaoEmbossingResp.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.cartao;

public class ConsultarCartaoEmbossingResp  implements java.io.Serializable {
    private int codigoRetorno;

    private java.lang.String descricaoRetorno;

    private int IDConta;

    private int statusConta;

    private int statusCartao;

    private java.lang.String dataExpiracao;

    private java.lang.String nomePortador;

    private java.lang.String dadosTrilhaMagnetica;

    private java.lang.String CVV;

    private java.lang.String numeroCartao;

    public ConsultarCartaoEmbossingResp() {
    }

    public ConsultarCartaoEmbossingResp(
           int codigoRetorno,
           java.lang.String descricaoRetorno,
           int IDConta,
           int statusConta,
           int statusCartao,
           java.lang.String dataExpiracao,
           java.lang.String nomePortador,
           java.lang.String dadosTrilhaMagnetica,
           java.lang.String CVV,
           java.lang.String numeroCartao) {
           this.codigoRetorno = codigoRetorno;
           this.descricaoRetorno = descricaoRetorno;
           this.IDConta = IDConta;
           this.statusConta = statusConta;
           this.statusCartao = statusCartao;
           this.dataExpiracao = dataExpiracao;
           this.nomePortador = nomePortador;
           this.dadosTrilhaMagnetica = dadosTrilhaMagnetica;
           this.CVV = CVV;
           this.numeroCartao = numeroCartao;
    }


    /**
     * Gets the codigoRetorno value for this ConsultarCartaoEmbossingResp.
     * 
     * @return codigoRetorno
     */
    public int getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this ConsultarCartaoEmbossingResp.
     * 
     * @param codigoRetorno
     */
    public void setCodigoRetorno(int codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the descricaoRetorno value for this ConsultarCartaoEmbossingResp.
     * 
     * @return descricaoRetorno
     */
    public java.lang.String getDescricaoRetorno() {
        return descricaoRetorno;
    }


    /**
     * Sets the descricaoRetorno value for this ConsultarCartaoEmbossingResp.
     * 
     * @param descricaoRetorno
     */
    public void setDescricaoRetorno(java.lang.String descricaoRetorno) {
        this.descricaoRetorno = descricaoRetorno;
    }


    /**
     * Gets the IDConta value for this ConsultarCartaoEmbossingResp.
     * 
     * @return IDConta
     */
    public int getIDConta() {
        return IDConta;
    }


    /**
     * Sets the IDConta value for this ConsultarCartaoEmbossingResp.
     * 
     * @param IDConta
     */
    public void setIDConta(int IDConta) {
        this.IDConta = IDConta;
    }


    /**
     * Gets the statusConta value for this ConsultarCartaoEmbossingResp.
     * 
     * @return statusConta
     */
    public int getStatusConta() {
        return statusConta;
    }


    /**
     * Sets the statusConta value for this ConsultarCartaoEmbossingResp.
     * 
     * @param statusConta
     */
    public void setStatusConta(int statusConta) {
        this.statusConta = statusConta;
    }


    /**
     * Gets the statusCartao value for this ConsultarCartaoEmbossingResp.
     * 
     * @return statusCartao
     */
    public int getStatusCartao() {
        return statusCartao;
    }


    /**
     * Sets the statusCartao value for this ConsultarCartaoEmbossingResp.
     * 
     * @param statusCartao
     */
    public void setStatusCartao(int statusCartao) {
        this.statusCartao = statusCartao;
    }


    /**
     * Gets the dataExpiracao value for this ConsultarCartaoEmbossingResp.
     * 
     * @return dataExpiracao
     */
    public java.lang.String getDataExpiracao() {
        return dataExpiracao;
    }


    /**
     * Sets the dataExpiracao value for this ConsultarCartaoEmbossingResp.
     * 
     * @param dataExpiracao
     */
    public void setDataExpiracao(java.lang.String dataExpiracao) {
        this.dataExpiracao = dataExpiracao;
    }


    /**
     * Gets the nomePortador value for this ConsultarCartaoEmbossingResp.
     * 
     * @return nomePortador
     */
    public java.lang.String getNomePortador() {
        return nomePortador;
    }


    /**
     * Sets the nomePortador value for this ConsultarCartaoEmbossingResp.
     * 
     * @param nomePortador
     */
    public void setNomePortador(java.lang.String nomePortador) {
        this.nomePortador = nomePortador;
    }


    /**
     * Gets the dadosTrilhaMagnetica value for this ConsultarCartaoEmbossingResp.
     * 
     * @return dadosTrilhaMagnetica
     */
    public java.lang.String getDadosTrilhaMagnetica() {
        return dadosTrilhaMagnetica;
    }


    /**
     * Sets the dadosTrilhaMagnetica value for this ConsultarCartaoEmbossingResp.
     * 
     * @param dadosTrilhaMagnetica
     */
    public void setDadosTrilhaMagnetica(java.lang.String dadosTrilhaMagnetica) {
        this.dadosTrilhaMagnetica = dadosTrilhaMagnetica;
    }


    /**
     * Gets the CVV value for this ConsultarCartaoEmbossingResp.
     * 
     * @return CVV
     */
    public java.lang.String getCVV() {
        return CVV;
    }


    /**
     * Sets the CVV value for this ConsultarCartaoEmbossingResp.
     * 
     * @param CVV
     */
    public void setCVV(java.lang.String CVV) {
        this.CVV = CVV;
    }


    /**
     * Gets the numeroCartao value for this ConsultarCartaoEmbossingResp.
     * 
     * @return numeroCartao
     */
    public java.lang.String getNumeroCartao() {
        return numeroCartao;
    }


    /**
     * Sets the numeroCartao value for this ConsultarCartaoEmbossingResp.
     * 
     * @param numeroCartao
     */
    public void setNumeroCartao(java.lang.String numeroCartao) {
        this.numeroCartao = numeroCartao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarCartaoEmbossingResp)) return false;
        ConsultarCartaoEmbossingResp other = (ConsultarCartaoEmbossingResp) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.codigoRetorno == other.getCodigoRetorno() &&
            ((this.descricaoRetorno==null && other.getDescricaoRetorno()==null) || 
             (this.descricaoRetorno!=null &&
              this.descricaoRetorno.equals(other.getDescricaoRetorno()))) &&
            this.IDConta == other.getIDConta() &&
            this.statusConta == other.getStatusConta() &&
            this.statusCartao == other.getStatusCartao() &&
            ((this.dataExpiracao==null && other.getDataExpiracao()==null) || 
             (this.dataExpiracao!=null &&
              this.dataExpiracao.equals(other.getDataExpiracao()))) &&
            ((this.nomePortador==null && other.getNomePortador()==null) || 
             (this.nomePortador!=null &&
              this.nomePortador.equals(other.getNomePortador()))) &&
            ((this.dadosTrilhaMagnetica==null && other.getDadosTrilhaMagnetica()==null) || 
             (this.dadosTrilhaMagnetica!=null &&
              this.dadosTrilhaMagnetica.equals(other.getDadosTrilhaMagnetica()))) &&
            ((this.CVV==null && other.getCVV()==null) || 
             (this.CVV!=null &&
              this.CVV.equals(other.getCVV()))) &&
            ((this.numeroCartao==null && other.getNumeroCartao()==null) || 
             (this.numeroCartao!=null &&
              this.numeroCartao.equals(other.getNumeroCartao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getCodigoRetorno();
        if (getDescricaoRetorno() != null) {
            _hashCode += getDescricaoRetorno().hashCode();
        }
        _hashCode += getIDConta();
        _hashCode += getStatusConta();
        _hashCode += getStatusCartao();
        if (getDataExpiracao() != null) {
            _hashCode += getDataExpiracao().hashCode();
        }
        if (getNomePortador() != null) {
            _hashCode += getNomePortador().hashCode();
        }
        if (getDadosTrilhaMagnetica() != null) {
            _hashCode += getDadosTrilhaMagnetica().hashCode();
        }
        if (getCVV() != null) {
            _hashCode += getCVV().hashCode();
        }
        if (getNumeroCartao() != null) {
            _hashCode += getNumeroCartao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarCartaoEmbossingResp.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "ConsultarCartaoEmbossingResp"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CodigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DescricaoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IDConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "StatusConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "StatusCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataExpiracao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DataExpiracao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePortador");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NomePortador"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosTrilhaMagnetica");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "DadosTrilhaMagnetica"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CVV");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CVV"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumeroCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
