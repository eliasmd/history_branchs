package br.com.calcard.calintegrador.motorFraude.service;

import java.io.IOException;
import java.io.StringReader;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.entity.Integracao;
import br.com.calcard.calintegrador.enums.NomeIntegracaoEnum;
import br.com.calcard.calintegrador.motorFraude.dto.ClearSaleDTO;
import br.com.calcard.calintegrador.motorFraude.dto.OrderDTO;
import br.com.calcard.calintegrador.motorFraude.dto.PropostaNegadaDTO;
import br.com.calcard.calintegrador.motorFraude.dto.RespostaAnaliseDTO;
import br.com.calcard.calintegrador.motorFraude.exception.IntegracaoFraudeException;
import br.com.calcard.calintegrador.motorFraude.integracao.ServiceSoapProxy;
import br.com.calcard.calintegrador.motorFraude.interfaces.IMotorFraude;
import br.com.calcard.calintegrador.service.ICalsystemXML;

@Service
public class MotorFraudeService implements IMotorFraude {

	private static final String CODIGO_ACESSO = "F414324C-8990-42E3-84DF-13882D675B58";

	private ICalsystemDAO daoService;

	private ICalsystemXML xmlService;

	@Autowired
	public MotorFraudeService(ICalsystemDAO daoService, ICalsystemXML xmlService) {
		this.daoService = daoService;
		this.xmlService = xmlService;
	}

	@Override
	public Integer doEnviarPropostaNegada(PropostaNegadaDTO propostaNegada) {

		return 1;

	}

	@Override
	public List<RespostaAnaliseDTO> doTraduzirRespostaAnalise(
			String xmlRespostaAnalise) throws IntegracaoFraudeException {

		try {

			List<RespostaAnaliseDTO> resposta = new ArrayList<RespostaAnaliseDTO>();

			JAXBContext jaxbContext = JAXBContext
					.newInstance(ClearSaleDTO.class);

			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

			ClearSaleDTO clearSaleDTO = (ClearSaleDTO) unmarshaller
					.unmarshal(new StringReader(xmlRespostaAnalise));

			for (OrderDTO order : clearSaleDTO.getOrders())
				resposta.add(new RespostaAnaliseDTO(Integer.parseInt(order
						.getIdProposta()), order.getStatus(), Double
						.parseDouble(order.getScore()), null));

			return resposta;

		} catch (JAXBException e) {
			throw new IntegracaoFraudeException(
					"N�o foi poss�vel consultar a ClearSale", e);
		}

	}

	@Override
	public List<RespostaAnaliseDTO> doConsultarRespostaAnalise()
			throws CalsystemInvalidArgumentException, ServiceException,
			IntegracaoFraudeException {

		ServiceSoapProxy serviceProxy = new ServiceSoapProxy();

		try {

			Date dataRequisicao = new Date();

			String xmlResposta = serviceProxy.getReturnAnalysis(CODIGO_ACESSO);

			Date dataResposta = new Date();

			Integracao integracao = new Integracao(
					NomeIntegracaoEnum.CONSULTAR_RESPOTA_ANALISE_MOTOR_FRAUDE,
					"getReturnAnalysis", CODIGO_ACESSO, xmlResposta,
					dataRequisicao, dataResposta);

			this.daoService.doCreate(integracao);

			ClearSaleDTO clearSaleDTO = (ClearSaleDTO) this.xmlService
					.doConverterXMLParaDTO(ClearSaleDTO.class, xmlResposta);

			List<RespostaAnaliseDTO> resposta = new ArrayList<RespostaAnaliseDTO>();

			for (OrderDTO order : clearSaleDTO.getOrders())
				resposta.add(new RespostaAnaliseDTO(Integer.parseInt(order
						.getIdProposta()), order.getStatus(), Double
						.parseDouble(order.getScore()), null));

			for (RespostaAnaliseDTO respostaAnalise : resposta)
				respostaAnalise.setIdIntegracao(integracao.getId());

			return resposta;

		} catch (IOException e) {
			throw new IntegracaoFraudeException(
					"N�o foi poss�vel consultar a ClearSale", e);
		}

	}

	@Override
	public Integracao doEnviarProposta(ClearSaleDTO dto)
			throws ServiceException, CalsystemInvalidArgumentException {

		try {

			final String NOME_SERVICO_EXECUTADO = "sendOrders";

			String xmlRequisicao = xmlService.doConverterDTOParaXML(
					ClearSaleDTO.class, dto);

			Date dataRequisicao = new Date();

			String xmlResposta = new ServiceSoapProxy().sendOrders(
					CODIGO_ACESSO, xmlRequisicao);

			Date dataResposta = new Date();

			Integracao integracao = new Integracao(
					NomeIntegracaoEnum.ENVIAR_PROPOSTA_MOTOR_FRAUDE,
					NOME_SERVICO_EXECUTADO, xmlRequisicao, xmlResposta,
					dataRequisicao, dataResposta);

			return this.daoService.doCreate(integracao);

		} catch (RemoteException e) {
			throw new ServiceException(
					new StringBuilder(
							"Erro ao enviar proposta para o motor de fraude!")
							.toString(),
					e);
		}

	}

	@Override
	public Integracao doFlegarPropostaRecebida(Integer idProposta)
			throws CalsystemInvalidArgumentException, IntegracaoFraudeException {

		try {

			final String NOME_SERVICO_EXECUTADO = "setOrderAsReturned";

			String requisicao = new StringBuilder().append("{ entityCode : ")
					.append(CODIGO_ACESSO).append(", orderID: ")
					.append(idProposta).append(" }").toString();

			ServiceSoapProxy serviceProxy = new ServiceSoapProxy();

			Date dataRequisicao = new Date();

			String resposta = serviceProxy.setOrderAsReturned(CODIGO_ACESSO,
					String.valueOf(idProposta));

			Date dataResposta = new Date();

			Integracao integracao = new Integracao(
					NomeIntegracaoEnum.FLEGAR_PROPOSTA_RECEBIDA_MOTOR_FRAUDE,
					NOME_SERVICO_EXECUTADO, requisicao, resposta,
					dataRequisicao, dataResposta);

			return this.daoService.doCreate(integracao);

		} catch (RemoteException e) {
			throw new IntegracaoFraudeException(
					"N�o foi poss�vel comunicar com o motor de fraude!", e);
		}

	}
}
