package br.com.calcard.calintegrador.motorBiometria.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class IntegracaoMotorBiometriaException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4684450315962296705L;

	public IntegracaoMotorBiometriaException(String message, Throwable cause) {
		super(message, cause);
	}

	public IntegracaoMotorBiometriaException(String message) {
		super(message);
	}

}
