package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.List;

public class UploadDocumentsDTO {

	private AuthenticationDTO authentication;

	private UploadDocumentsInfoDTO creditrequest;

	private String result;

	private List<String> messages;

	public UploadDocumentsDTO() {
		this.authentication = new AuthenticationDTO();
		this.creditrequest = new UploadDocumentsInfoDTO();
	}

	public UploadDocumentsDTO(AuthenticationDTO authentication,
			UploadDocumentsInfoDTO creditrequest) {
		super();
		this.authentication = authentication;
		this.creditrequest = creditrequest;
	}

	public AuthenticationDTO getAuthentication() {
		return authentication;
	}

	public void setAuthentication(AuthenticationDTO authentication) {
		this.authentication = authentication;
	}

	public UploadDocumentsInfoDTO getCreditrequest() {
		return creditrequest;
	}

	public void setCreditrequest(UploadDocumentsInfoDTO creditrequest) {
		this.creditrequest = creditrequest;
	}

	public List<String> getMessages() {
		return messages;
	}

	public void setMessages(List<String> messages) {
		this.messages = messages;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
