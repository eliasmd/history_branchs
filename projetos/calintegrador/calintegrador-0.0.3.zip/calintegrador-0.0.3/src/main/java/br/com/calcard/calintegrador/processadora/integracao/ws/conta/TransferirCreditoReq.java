/**
 * TransferirCreditoReq.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public class TransferirCreditoReq  implements java.io.Serializable {
    private int IDContaOrigem;

    private int IDContaDestino;

    private java.math.BigDecimal valor;

    public TransferirCreditoReq() {
    }

    public TransferirCreditoReq(
           int IDContaOrigem,
           int IDContaDestino,
           java.math.BigDecimal valor) {
           this.IDContaOrigem = IDContaOrigem;
           this.IDContaDestino = IDContaDestino;
           this.valor = valor;
    }


    /**
     * Gets the IDContaOrigem value for this TransferirCreditoReq.
     * 
     * @return IDContaOrigem
     */
    public int getIDContaOrigem() {
        return IDContaOrigem;
    }


    /**
     * Sets the IDContaOrigem value for this TransferirCreditoReq.
     * 
     * @param IDContaOrigem
     */
    public void setIDContaOrigem(int IDContaOrigem) {
        this.IDContaOrigem = IDContaOrigem;
    }


    /**
     * Gets the IDContaDestino value for this TransferirCreditoReq.
     * 
     * @return IDContaDestino
     */
    public int getIDContaDestino() {
        return IDContaDestino;
    }


    /**
     * Sets the IDContaDestino value for this TransferirCreditoReq.
     * 
     * @param IDContaDestino
     */
    public void setIDContaDestino(int IDContaDestino) {
        this.IDContaDestino = IDContaDestino;
    }


    /**
     * Gets the valor value for this TransferirCreditoReq.
     * 
     * @return valor
     */
    public java.math.BigDecimal getValor() {
        return valor;
    }


    /**
     * Sets the valor value for this TransferirCreditoReq.
     * 
     * @param valor
     */
    public void setValor(java.math.BigDecimal valor) {
        this.valor = valor;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TransferirCreditoReq)) return false;
        TransferirCreditoReq other = (TransferirCreditoReq) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.IDContaOrigem == other.getIDContaOrigem() &&
            this.IDContaDestino == other.getIDContaDestino() &&
            ((this.valor==null && other.getValor()==null) || 
             (this.valor!=null &&
              this.valor.equals(other.getValor())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getIDContaOrigem();
        _hashCode += getIDContaDestino();
        if (getValor() != null) {
            _hashCode += getValor().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TransferirCreditoReq.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "TransferirCreditoReq"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDContaOrigem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IDContaOrigem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDContaDestino");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IDContaDestino"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "Valor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
