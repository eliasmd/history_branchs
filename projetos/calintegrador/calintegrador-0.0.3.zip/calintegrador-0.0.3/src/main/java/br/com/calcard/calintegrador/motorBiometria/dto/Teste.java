package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Teste {

	public static void main(String[] args) throws JsonProcessingException {

		List<CreditRequestInfoDTO> creditRequestInfo = new ArrayList<CreditRequestInfoDTO>();

		CreditRequestInfoDTO c = new CreditRequestInfoDTO();
		c.setIdentifierCode("123");

		creditRequestInfo.add(c);

		CreditRequestDTO2 cr = new CreditRequestDTO2(
				new AuthenticationDTO("123"), creditRequestInfo);

		ObjectMapper mapper = new ObjectMapper();
		System.out.println("Serialization: " + mapper.writeValueAsString(c));

		System.out.println("Serialization: " + mapper.writeValueAsString(cr));

	}

}
