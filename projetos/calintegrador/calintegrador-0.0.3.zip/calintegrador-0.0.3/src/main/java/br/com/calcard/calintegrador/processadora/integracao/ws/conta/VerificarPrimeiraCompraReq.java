/**
 * VerificarPrimeiraCompraReq.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public class VerificarPrimeiraCompraReq  implements java.io.Serializable {
    private java.lang.Integer idConta;

    private java.lang.String CPF;

    private java.lang.String numCartao;

    private java.lang.Boolean flagOnOffUs;

    public VerificarPrimeiraCompraReq() {
    }

    public VerificarPrimeiraCompraReq(
           java.lang.Integer idConta,
           java.lang.String CPF,
           java.lang.String numCartao,
           java.lang.Boolean flagOnOffUs) {
           this.idConta = idConta;
           this.CPF = CPF;
           this.numCartao = numCartao;
           this.flagOnOffUs = flagOnOffUs;
    }


    /**
     * Gets the idConta value for this VerificarPrimeiraCompraReq.
     * 
     * @return idConta
     */
    public java.lang.Integer getIdConta() {
        return idConta;
    }


    /**
     * Sets the idConta value for this VerificarPrimeiraCompraReq.
     * 
     * @param idConta
     */
    public void setIdConta(java.lang.Integer idConta) {
        this.idConta = idConta;
    }


    /**
     * Gets the CPF value for this VerificarPrimeiraCompraReq.
     * 
     * @return CPF
     */
    public java.lang.String getCPF() {
        return CPF;
    }


    /**
     * Sets the CPF value for this VerificarPrimeiraCompraReq.
     * 
     * @param CPF
     */
    public void setCPF(java.lang.String CPF) {
        this.CPF = CPF;
    }


    /**
     * Gets the numCartao value for this VerificarPrimeiraCompraReq.
     * 
     * @return numCartao
     */
    public java.lang.String getNumCartao() {
        return numCartao;
    }


    /**
     * Sets the numCartao value for this VerificarPrimeiraCompraReq.
     * 
     * @param numCartao
     */
    public void setNumCartao(java.lang.String numCartao) {
        this.numCartao = numCartao;
    }


    /**
     * Gets the flagOnOffUs value for this VerificarPrimeiraCompraReq.
     * 
     * @return flagOnOffUs
     */
    public java.lang.Boolean getFlagOnOffUs() {
        return flagOnOffUs;
    }


    /**
     * Sets the flagOnOffUs value for this VerificarPrimeiraCompraReq.
     * 
     * @param flagOnOffUs
     */
    public void setFlagOnOffUs(java.lang.Boolean flagOnOffUs) {
        this.flagOnOffUs = flagOnOffUs;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof VerificarPrimeiraCompraReq)) return false;
        VerificarPrimeiraCompraReq other = (VerificarPrimeiraCompraReq) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idConta==null && other.getIdConta()==null) || 
             (this.idConta!=null &&
              this.idConta.equals(other.getIdConta()))) &&
            ((this.CPF==null && other.getCPF()==null) || 
             (this.CPF!=null &&
              this.CPF.equals(other.getCPF()))) &&
            ((this.numCartao==null && other.getNumCartao()==null) || 
             (this.numCartao!=null &&
              this.numCartao.equals(other.getNumCartao()))) &&
            ((this.flagOnOffUs==null && other.getFlagOnOffUs()==null) || 
             (this.flagOnOffUs!=null &&
              this.flagOnOffUs.equals(other.getFlagOnOffUs())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdConta() != null) {
            _hashCode += getIdConta().hashCode();
        }
        if (getCPF() != null) {
            _hashCode += getCPF().hashCode();
        }
        if (getNumCartao() != null) {
            _hashCode += getNumCartao().hashCode();
        }
        if (getFlagOnOffUs() != null) {
            _hashCode += getFlagOnOffUs().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VerificarPrimeiraCompraReq.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "VerificarPrimeiraCompraReq"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "IdConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CPF");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CPF"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flagOnOffUs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "FlagOnOffUs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
