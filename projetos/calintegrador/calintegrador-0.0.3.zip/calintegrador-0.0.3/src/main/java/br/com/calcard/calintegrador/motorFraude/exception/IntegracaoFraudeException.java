package br.com.calcard.calintegrador.motorFraude.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class IntegracaoFraudeException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3660595421726307504L;

	public IntegracaoFraudeException(String mensagem) {
		super(mensagem);

	}

	public IntegracaoFraudeException(String message, Throwable cause) {
		super(message, cause);
	}

}
