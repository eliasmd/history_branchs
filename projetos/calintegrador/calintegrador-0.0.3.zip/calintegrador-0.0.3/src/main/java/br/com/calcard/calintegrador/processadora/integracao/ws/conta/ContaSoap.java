/**
 * ContaSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.conta;

public interface ContaSoap extends java.rmi.Remote {

    /**
     * ConsultarExtratoSaldo
     */
    public Extrato[] consultarExtratoSaldo(ConsultarExtratoSaldoReq req) throws java.rmi.RemoteException;

    /**
     * ConsultarSaldo
     */
    public ConsultarSaldoResp consultarSaldo(ConsultarSaldoReq req) throws java.rmi.RemoteException;

    /**
     * TransferirCredito
     */
    public TransferirCreditoResp transferirCredito(TransferirCreditoReq req) throws java.rmi.RemoteException;

    /**
     * RetornarContasCartoes
     */
    public RetornarContasCartoesResp retornarContasCartoes(RetornarContasCartoesReq req) throws java.rmi.RemoteException;

    /**
     * VerificarPrimeiraCompra
     */
    public VerificarPrimeiraCompraResp verificarPrimeiraCompra(VerificarPrimeiraCompraReq req) throws java.rmi.RemoteException;

    /**
     * ConsultaQuitacaoAnualDeDebitos
     */
    public TermoQuitacaoAnualDeDebitosResp consultaQuitacaoAnualDeDebitos(TermoQuitacaoAnualDeDebitosReq req) throws java.rmi.RemoteException;

    /**
     * ConsultarContas
     */
    public ConsultarContasResp consultarContas(ConsultarContasReq req) throws java.rmi.RemoteException;

    /**
     * ConsultarCartoes
     */
    public ConsultarCartoesResp consultarCartoes(ConsultarCartoesReq req) throws java.rmi.RemoteException;
}
