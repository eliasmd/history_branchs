package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.ArrayList;
import java.util.List;

public class CreditRequestDTO2 {

	private String result;

	private AuthenticationDTO authentication;

	private List<CreditRequestInfoDTO> creditrequest;

	public CreditRequestDTO2() {
		this.authentication = new AuthenticationDTO();
		this.setCreditrequest(new ArrayList<CreditRequestInfoDTO>());
	}

	public CreditRequestDTO2(AuthenticationDTO authentication,
			List<CreditRequestInfoDTO> creditrequest) {
		this.authentication = authentication;
		this.setCreditrequest(creditrequest);
	}

	public AuthenticationDTO getAuthentication() {
		return authentication;
	}

	public void setAuthentication(AuthenticationDTO authentication) {
		this.authentication = authentication;
	}

	public List<CreditRequestInfoDTO> getCreditrequest() {
		return creditrequest;
	}

	public void setCreditrequest(List<CreditRequestInfoDTO> creditrequest) {
		this.creditrequest = creditrequest;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
