package br.com.calcard.calintegrador.motorBiometria.dto;

public class DocumentDTO {

	private Integer type;

	private String image;

	public DocumentDTO() {

	}

	public DocumentDTO(Integer type, String image) {
		super();
		this.type = type;
		this.image = image;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}
