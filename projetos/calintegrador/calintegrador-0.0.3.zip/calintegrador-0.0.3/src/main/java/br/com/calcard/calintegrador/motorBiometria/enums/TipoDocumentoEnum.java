package br.com.calcard.calintegrador.motorBiometria.enums;

public enum TipoDocumentoEnum {

	DOCUMENTO_IDENTIFICACAO(1), //
	COMPROVANTE_ENDERECO(200), //
	COMPROVANTE_RENDA(2020);

	private Integer id;

	private TipoDocumentoEnum(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

}
