package br.com.calcard.calintegrador.motorBiometria.dto;

import java.util.ArrayList;
import java.util.List;

public class JsonAssessmentDTO {

	private String result;

	private String code;

	private List<String> messages;

	private AuthenticationDTO authentication;

	private List<AssessmentDTO> assessment;

	public JsonAssessmentDTO() {

	}

	public JsonAssessmentDTO(AuthenticationDTO authentication,
			AssessmentDTO assessment) {
		super();
		this.authentication = authentication;

		this.setAssessment(new ArrayList<AssessmentDTO>());
		this.getAssessment().add(assessment);

	}

	public AuthenticationDTO getAuthentication() {
		return authentication;
	}

	public void setAuthentication(AuthenticationDTO authentication) {
		this.authentication = authentication;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public List<String> getMessages() {
		return messages;
	}

	public void setMessages(List<String> messages) {
		this.messages = messages;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public List<AssessmentDTO> getAssessment() {
		return assessment;
	}

	public void setAssessment(List<AssessmentDTO> assessment) {
		this.assessment = assessment;
	}

}
