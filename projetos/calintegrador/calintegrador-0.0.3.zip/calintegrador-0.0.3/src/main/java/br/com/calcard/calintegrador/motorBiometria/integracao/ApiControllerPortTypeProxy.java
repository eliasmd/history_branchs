package br.com.calcard.calintegrador.motorBiometria.integracao;

public class ApiControllerPortTypeProxy implements br.com.calcard.calintegrador.motorBiometria.integracao.ApiControllerPortType {
  private String _endpoint = null;
  private br.com.calcard.calintegrador.motorBiometria.integracao.ApiControllerPortType apiControllerPortType = null;
  
  public ApiControllerPortTypeProxy() {
    _initApiControllerPortTypeProxy();
  }
  
  public ApiControllerPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initApiControllerPortTypeProxy();
  }
  
  private void _initApiControllerPortTypeProxy() {
    try {
      apiControllerPortType = (new br.com.calcard.calintegrador.motorBiometria.integracao.ApiControllerServiceLocator()).getApiControllerPort();
      if (apiControllerPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)apiControllerPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)apiControllerPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (apiControllerPortType != null)
      ((javax.xml.rpc.Stub)apiControllerPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.calcard.calintegrador.motorBiometria.integracao.ApiControllerPortType getApiControllerPortType() {
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType;
  }
  
  public java.lang.Object[] welcome() throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.welcome();
  }
  
  public java.lang.Object[] login(java.lang.String username, java.lang.String password) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.login(username, password);
  }
  
  public java.lang.Object[] logout(java.lang.String token) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.logout(token);
  }
  
  public java.lang.Object[] validate(java.lang.String token) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.validate(token);
  }
  
  public java.lang.Object[] places(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.places(token, id);
  }
  
  public java.lang.Object[] viewCustomerPhoto(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.viewCustomerPhoto(token, id);
  }
  
  public java.lang.Object[] viewCRPhoto(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.viewCRPhoto(token, id);
  }
  
  public java.lang.Object[] viewData(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.viewData(token, id);
  }
  
  public java.lang.Object[] viewDocuments(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.viewDocuments(token, id);
  }
  
  public java.lang.Object[] pooling(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.pooling(token, id);
  }
  
  public java.lang.Object[] status(java.lang.String token, java.math.BigInteger id) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.status(token, id);
  }
  
  public java.lang.Object[] changeStatus(java.lang.String token, java.math.BigInteger id, java.lang.String status, java.lang.String comment) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.changeStatus(token, id, status, comment);
  }
  
  public java.lang.Object[] survey(java.lang.String token, java.lang.String identifier_code, java.lang.String photo) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.survey(token, identifier_code, photo);
  }
  
  public java.lang.Object[] listCreditRequests(java.lang.String token, java.math.BigInteger place_id, java.math.BigInteger limit, java.math.BigInteger offset) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.listCreditRequests(token, place_id, limit, offset);
  }
  
  public java.lang.Object[] creditRequest(java.lang.String token, java.lang.String identifier_code, java.math.BigInteger document_type, java.math.BigInteger place_id, java.lang.String name, java.lang.String birth_date, java.lang.String photo) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.creditRequest(token, identifier_code, document_type, place_id, name, birth_date, photo);
  }
  
  public java.lang.Object[] uploadDocuments(java.lang.String token, java.math.BigInteger id, java.math.BigInteger type, java.lang.String image) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.uploadDocuments(token, id, type, image);
  }
  
  public java.lang.Object[] assessment(java.lang.String token, java.lang.String photo) throws java.rmi.RemoteException{
    if (apiControllerPortType == null)
      _initApiControllerPortTypeProxy();
    return apiControllerPortType.assessment(token, photo);
  }
  
  
}