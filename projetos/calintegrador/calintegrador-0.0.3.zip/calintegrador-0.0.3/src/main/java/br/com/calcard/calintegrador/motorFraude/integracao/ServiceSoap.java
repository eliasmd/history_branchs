/**
 * ServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.motorFraude.integracao;

public interface ServiceSoap extends java.rmi.Remote {

    /**
     * Método para envio de pedidos (Igual ao SendOrders porém com
     * o nome parametro (XML) diferente (PEDIDOS))
     */
    public java.lang.String sendOrders2(java.lang.String entityCode, java.lang.String pedidos) throws java.rmi.RemoteException;

    /**
     * Método para envio de pedidos
     */
    public java.lang.String sendOrders(java.lang.String entityCode, java.lang.String xml) throws java.rmi.RemoteException;

    /**
     * Retorna o status de todos os pedidos em um pacote
     */
    public java.lang.String getPackageStatus(java.lang.String entityCode, java.lang.String packageID) throws java.rmi.RemoteException;

    /**
     * Retorna o status de um pedido
     */
    public java.lang.String getOrderStatus(java.lang.String entityCode, java.lang.String orderID) throws java.rmi.RemoteException;

    /**
     * Retorna o status de vários pedidos
     */
    public java.lang.String getOrdersStatus(java.lang.String entityCode, java.lang.String xml) throws java.rmi.RemoteException;

    /**
     * Retorna o status de pedidos que estão no clearsale em fila
     * ou finalisados e que não foram setados como retornados
     */
    public java.lang.String getReturnAnalysis(java.lang.String entityCode) throws java.rmi.RemoteException;

    /**
     * Avisa ao ClearSale para que não retorne mais o pedido na chamada
     * do Método GetReturnAnalysis
     */
    public java.lang.String setOrderAsReturned(java.lang.String entityCode, java.lang.String orderID) throws java.rmi.RemoteException;

    /**
     * Recupera os comentários do analistas
     */
    public java.lang.String getAnalystComments(java.lang.String entityCode, java.lang.String orderID, boolean getAll) throws java.rmi.RemoteException;

    /**
     * Marca o pedido como ChargeBack
     */
    public br.com.calcard.calintegrador.motorFraude.integracao.TransactionStatusCbk orderChargeBack(java.lang.String entityCode, java.lang.String xml, java.lang.String note) throws java.rmi.RemoteException;

    /**
     * Marca o pedido como ChargeBack através do NSU
     */
    public br.com.calcard.calintegrador.motorFraude.integracao.TransactionStatusCbk orderChargeBackByNsu(java.lang.String entityCode, int cartaoBandeira, java.lang.String nsu, java.lang.String conciliadorCode) throws java.rmi.RemoteException;

    /**
     * Método para envio de pedidos
     */
    public java.lang.String submitInfo(java.lang.String entityCode, java.lang.String xmlDados) throws java.rmi.RemoteException;

    /**
     * Retorna o status de um pedido
     */
    public java.lang.String checkOrderStatus(java.lang.String entityCode, java.lang.String pedidoIDCliente) throws java.rmi.RemoteException;

    /**
     * Retorna a URL do Quetionário para auto validação
     */
    public java.lang.String getQuizURL(java.lang.String entityCode, java.lang.String orderID) throws java.rmi.RemoteException;

    /**
     * Retorna o status do pacote
     */
    public java.lang.String getPackageStatusCustom(java.lang.String entityCode, java.lang.String transactionID) throws java.rmi.RemoteException;
}
