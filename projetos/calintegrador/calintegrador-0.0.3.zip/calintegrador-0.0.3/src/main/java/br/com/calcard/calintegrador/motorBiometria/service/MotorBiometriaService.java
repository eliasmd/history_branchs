package br.com.calcard.calintegrador.motorBiometria.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.helper.CalsystemJsonHelper;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calintegrador.dto.LogIntegracaoDTO;
import br.com.calcard.calintegrador.enums.NomeIntegracaoEnum;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.AssessmentDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.AuthenticationDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.CreditRequestDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.DocumentDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoAnexoDocumentosDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoAvaliacaoFotoDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoEnvioFotoDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoLoginDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoLogoutDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.JsonAssessmentDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.LoginDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.LogoutDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.RequestPoolingDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.RequisicaoCreditRequestDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.ResponsePoolingDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.RespostaCreditRequestDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.UploadDocumentsDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.UploadDocumentsInfoDTO;
import br.com.calcard.calintegrador.motorBiometria.enums.ResultEnum;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calintegrador.motorFraude.interfaces.ILogIntegracao;
import br.com.calcard.calintegrador.service.CalintegradorPostService;

@Service
public class MotorBiometriaService implements IMotorBiometria {

	private ILogIntegracao logIntegracaoService;

	private final String username = "calcardapi";

	private final String password = "Calcard_Test2015";

	private final String api = "https://test.creddefense.com/index.php/api/";

	private final String versao = "v2/";

	private final String urlBasica = api + versao;

	private final String urlLogin = urlBasica + "login/";

	private final String urlCreditRequest = urlBasica + "creditRequest/";

	private final String urlPooling = urlBasica + "pooling/";

	private final String urlLogout = urlBasica + "logout/";

	private final String urlUploadDocuments = urlBasica + "uploaddocuments/";

	private final String urlAssessment = urlBasica + "assessment/";

	CalintegradorPostService calintegradorPostService;

	@Autowired
	public MotorBiometriaService(ILogIntegracao logIntegracaoService) {

		this.logIntegracaoService = logIntegracaoService;

		this.calintegradorPostService = new CalintegradorPostService();

	}

	@Override
	public IntegracaoAnexoDocumentosDTO doAnexarDocumentos(
			List<DocumentDTO> documentos, Integer creditRequestId)
			throws IntegracaoException, CalsystemInvalidArgumentException,
			ServiceException, IntegracaoMotorBiometriaException {

		IntegracaoLoginDTO integracaoLogin = this.doLogin();

		UploadDocumentsDTO uploadDocumentsDTO = new UploadDocumentsDTO(
				new AuthenticationDTO(integracaoLogin.getToken()),
				new UploadDocumentsInfoDTO(creditRequestId, documentos));

		LogIntegracaoDTO logIntegracaoAnexoFotoDTO = this.calintegradorPostService
				.doPost(this.urlUploadDocuments,
						NomeIntegracaoEnum.ANEXAR_DOCUMENTOS_MOTOR_BIOMETRIA,
						uploadDocumentsDTO, UploadDocumentsDTO.class);

		Integer idIntegracaoAnexoFoto = this.logIntegracaoService
				.doRegistrarLogIntegracao(
						logIntegracaoAnexoFotoDTO.getDataRequisicao(),
						logIntegracaoAnexoFotoDTO.getDataResposta(),
						logIntegracaoAnexoFotoDTO.getRequisicao(),
						CalsystemJsonHelper
								.doConverterParaJson(logIntegracaoAnexoFotoDTO
										.getResposta()),
						logIntegracaoAnexoFotoDTO.getNome(),
						logIntegracaoAnexoFotoDTO.getNomeServico()).getId();

		IntegracaoLogoutDTO integracaoLogout = this.doLogout(integracaoLogin
				.getToken());

		UploadDocumentsDTO uploadDocumentosDTO = (UploadDocumentsDTO) logIntegracaoAnexoFotoDTO
				.getResposta();

		if (!uploadDocumentosDTO.getResult().equals(
				ResultEnum.SUCESSO.getCodigo()))
			throw new IntegracaoMotorBiometriaException(new StringBuilder(
					"Erro ao anexar documentos no motor de biometria! ERRO: ")
					.append(uploadDocumentosDTO.getMessages().get(0))
					.toString());

		return new IntegracaoAnexoDocumentosDTO(integracaoLogin,
				idIntegracaoAnexoFoto, integracaoLogout);

	}

	@Override
	public IntegracaoLogoutDTO doLogout(String token)
			throws IntegracaoException, CalsystemInvalidArgumentException,
			ServiceException {

		LogoutDTO logout = new LogoutDTO(token);

		LogIntegracaoDTO logIntegracaoLogout = this.calintegradorPostService
				.doPost(this.urlLogout,
						NomeIntegracaoEnum.LOGOUT_MOTOR_BIOMETRIA, logout,
						LogoutDTO.class);

		Integer idIntegracaoLogout = this.logIntegracaoService
				.doRegistrarLogIntegracao(
						logIntegracaoLogout.getDataRequisicao(),
						logIntegracaoLogout.getDataResposta(),
						logIntegracaoLogout.getRequisicao(),
						CalsystemJsonHelper
								.doConverterParaJson(logIntegracaoLogout
										.getResposta()),
						logIntegracaoLogout.getNome(),
						logIntegracaoLogout.getNomeServico()).getId();

		// Descomentar esse trexo quando a a CredDefence passar a retornar o

		// LogoutDTO logoutDTO = (LogoutDTO) logIntegracaoLogout.getResposta();

		// campo result no servi�o de logout.
		// if (!logoutDTO.getResult().equals(ResultEnum.SUCESSO))
		// throw new IntegracaoMotorBiometriaException(
		// new StringBuilder()
		// .append("Erro ao realizaro logout no motor de biometria! ERRO: ")
		// .append(logoutDTO.getMessages() == null ? null
		// : logoutDTO.getMessages().get(0))
		// .toString());

		return new IntegracaoLogoutDTO(idIntegracaoLogout);

	}

	@Override
	public IntegracaoLoginDTO doLogin() throws IntegracaoException,
			CalsystemInvalidArgumentException, ServiceException,
			IntegracaoMotorBiometriaException {

		LoginDTO request = new LoginDTO(new AuthenticationDTO(this.username,
				this.password));

		LogIntegracaoDTO logIntegracao = this.calintegradorPostService.doPost(
				this.urlLogin, NomeIntegracaoEnum.LOGIN_MOTOR_BIOMETRIA,
				request, LoginDTO.class);

		LoginDTO respostaLogin = (LoginDTO) logIntegracao.getResposta();

		Integer idIntegracaoLogin = this.logIntegracaoService
				.doRegistrarLogIntegracao(
						logIntegracao.getDataRequisicao(),
						logIntegracao.getDataResposta(),
						logIntegracao.getRequisicao(),
						CalsystemJsonHelper.doConverterParaJson(logIntegracao
								.getResposta()), logIntegracao.getNome(),
						logIntegracao.getNomeServico()).getId();

		if (!respostaLogin.getResult().equals(ResultEnum.SUCESSO.getCodigo()))
			throw new IntegracaoMotorBiometriaException(
					new StringBuilder()
							.append("Erro ao realizaro login no motor de biometria! ERRO: ")
							.append(respostaLogin.getMessages() == null ? null
									: respostaLogin.getMessages().get(0))
							.toString());

		return new IntegracaoLoginDTO(respostaLogin.getAuthentication()
				.getToken(), idIntegracaoLogin);

	}

	@Override
	public IntegracaoEnvioFotoDTO doEnviarCreditRequest(String cpf,
			String idLoja, String nome, Date dataNascimento, String foto)
			throws IntegracaoException, CalsystemInvalidArgumentException,
			ServiceException, IntegracaoMotorBiometriaException {

		return this.doEnviarCreditRequest(cpf, idLoja, nome, dataNascimento,
				foto, null);

	}

	@Override
	public IntegracaoEnvioFotoDTO doEnviarCreditRequest(String cpf,
			String idLoja, String nome, Date dataNascimento, String foto,
			List<DocumentDTO> documentDTO) throws IntegracaoException,
			CalsystemInvalidArgumentException, ServiceException,
			IntegracaoMotorBiometriaException {

		IntegracaoLoginDTO respostaLogin = this.doLogin();

		List<CreditRequestDTO> creditRequest = new ArrayList<CreditRequestDTO>();

		if (CalsystemUtil.isNull(cpf))
			throw new CalsystemInvalidArgumentException("CPF não informado!");

		if (CalsystemUtil.isNull(idLoja))
			throw new CalsystemInvalidArgumentException(
					"ID Loja não informado!");

		if (CalsystemUtil.isNull(nome))
			throw new CalsystemInvalidArgumentException("Nome não informado!");

		if (CalsystemUtil.isNull(foto))
			throw new CalsystemInvalidArgumentException("Foto não informada!");

		if (documentDTO != null)
			this.doValidarDocumentDTO(documentDTO);

		creditRequest.add(new CreditRequestDTO(cpf, idLoja, nome, CalsystemUtil
				.doConverterDateToString(dataNascimento, "dd/MM/yyyy"), foto,
				documentDTO));

		RequisicaoCreditRequestDTO requisicaoCreditRequestDTO = new RequisicaoCreditRequestDTO(
				new AuthenticationDTO(respostaLogin.getToken()), creditRequest);

		LogIntegracaoDTO logIntegracaoCreditRequest = this.calintegradorPostService
				.doPost(this.urlCreditRequest,
						NomeIntegracaoEnum.ENVIAR_CREDIT_REQUEST_MOTOR_BIOMETRIA,
						requisicaoCreditRequestDTO,
						RespostaCreditRequestDTO.class);

		Integer idIntegracaoCreditRequest = this.logIntegracaoService
				.doRegistrarLogIntegracao(
						logIntegracaoCreditRequest.getDataRequisicao(),
						logIntegracaoCreditRequest.getDataResposta(),
						logIntegracaoCreditRequest.getRequisicao(),
						CalsystemJsonHelper
								.doConverterParaJson(logIntegracaoCreditRequest
										.getResposta()),
						logIntegracaoCreditRequest.getNome(),
						logIntegracaoCreditRequest.getNomeServico()).getId();

		IntegracaoLogoutDTO respostaLogout = this.doLogout(respostaLogin
				.getToken());

		RespostaCreditRequestDTO creditRequestDTO = (RespostaCreditRequestDTO) logIntegracaoCreditRequest
				.getResposta();

		if (!creditRequestDTO.getResult()
				.equals(ResultEnum.SUCESSO.getCodigo()))
			throw new IntegracaoMotorBiometriaException(
					new StringBuilder()
							.append("Erro eo enviar a foto para o motor de biometria! ERRO: ")
							.append(creditRequestDTO.getMessages() == null ? creditRequestDTO
									.getCreditrequest().get(0).getState()
									: creditRequestDTO.getMessages().get(0))
							.toString());

		return new IntegracaoEnvioFotoDTO(respostaLogin,
				idIntegracaoCreditRequest, respostaLogout,
				Integer.valueOf(creditRequestDTO.getCreditrequest().get(0)
						.getId()));

	}

	private void doValidarDocumentDTO(List<DocumentDTO> documentDTO)
			throws CalsystemInvalidArgumentException {

		if (documentDTO == null)
			throw new CalsystemInvalidArgumentException(
					"Documentos não informados!");

		for (DocumentDTO document : documentDTO) {

			if (document.getType() == null)
				throw new CalsystemInvalidArgumentException(
						"Type do documento não informado!");

			if (document.getImage() == null)
				throw new CalsystemInvalidArgumentException(
						"Imagem do documento não informada!");

		}

	}

	@Transactional
	@Override
	public IntegracaoAvaliacaoFotoDTO doAvaliarFoto(String fotoBase64)
			throws IntegracaoException, CalsystemInvalidArgumentException,
			ServiceException, IntegracaoMotorBiometriaException {

		IntegracaoLoginDTO integracaoLogin = this.doLogin();

		JsonAssessmentDTO jsonAssessmentDTO = new JsonAssessmentDTO(
				new AuthenticationDTO(integracaoLogin.getToken()),
				new AssessmentDTO(fotoBase64));

		LogIntegracaoDTO logIntegracaoAvaliacaoFoto = this.calintegradorPostService
				.doPost(this.urlAssessment, NomeIntegracaoEnum.AVALIAR_FOTO,
						jsonAssessmentDTO, JsonAssessmentDTO.class);

		Integer idIntegracaoAvaliacaoFoto = this.logIntegracaoService
				.doRegistrarLogIntegracao(
						logIntegracaoAvaliacaoFoto.getDataRequisicao(),
						logIntegracaoAvaliacaoFoto.getDataResposta(),
						logIntegracaoAvaliacaoFoto.getRequisicao(),
						CalsystemJsonHelper
								.doConverterParaJson(logIntegracaoAvaliacaoFoto
										.getResposta()),
						logIntegracaoAvaliacaoFoto.getNome(),
						logIntegracaoAvaliacaoFoto.getNomeServico()).getId();

		IntegracaoLogoutDTO respostaLogout = this.doLogout(integracaoLogin
				.getToken());

		JsonAssessmentDTO avaliacaoFotoDTO = (JsonAssessmentDTO) logIntegracaoAvaliacaoFoto
				.getResposta();

		if (!avaliacaoFotoDTO.getResult()
				.equals(ResultEnum.SUCESSO.getCodigo()))
			throw new IntegracaoMotorBiometriaException(
					new StringBuilder(
							"Erro ao realizar avalia��o da foto no motor de biometria! ERRO: ")
							.append(avaliacaoFotoDTO.getMessages() == null ? null
									: avaliacaoFotoDTO.getMessages().get(0))
							.toString());

		if (!avaliacaoFotoDTO.getAssessment().get(0).getResult()
				.equals(ResultEnum.SUCESSO.getCodigo()))
			throw new IntegracaoMotorBiometriaException(new StringBuilder(
					"Foto reprovada! MOTIVO: ").append(
					avaliacaoFotoDTO.getAssessment().get(0).getMessages())
					.toString());

		return new IntegracaoAvaliacaoFotoDTO(integracaoLogin,
				idIntegracaoAvaliacaoFoto, respostaLogout);

	}

	@Override
	public IntegracaoAvaliacaoFotoDTO doConsultarAnaliseComFoto(
			Integer creditRequestId) throws CalsystemInvalidArgumentException,
			ServiceException, IntegracaoException,
			IntegracaoMotorBiometriaException {

		if (creditRequestId == null)
			throw new CalsystemInvalidArgumentException(
					"ID do CreditRequest não informado!");

		IntegracaoLoginDTO respostaLogin = this.doLogin();

		RequestPoolingDTO requestPooling = new RequestPoolingDTO(
				new AuthenticationDTO(respostaLogin.getToken()),
				new CreditRequestDTO(creditRequestId));

		LogIntegracaoDTO logIntegracaoCreditRequest = this.calintegradorPostService
				.doPost(this.urlPooling,
						NomeIntegracaoEnum.CONSULTAR_ANALISE_COM_FOTO,
						requestPooling, ResponsePoolingDTO.class);

		Integer idIntegracaoCreditRequest = this.logIntegracaoService
				.doRegistrarLogIntegracao(
						logIntegracaoCreditRequest.getDataRequisicao(),
						logIntegracaoCreditRequest.getDataResposta(),
						logIntegracaoCreditRequest.getRequisicao(),
						CalsystemJsonHelper
								.doConverterParaJson(logIntegracaoCreditRequest
										.getResposta()),
						logIntegracaoCreditRequest.getNome(),
						logIntegracaoCreditRequest.getNomeServico()).getId();

		IntegracaoLogoutDTO respostaLogout = this.doLogout(respostaLogin
				.getToken());

		ResponsePoolingDTO responsePooling = (ResponsePoolingDTO) logIntegracaoCreditRequest
				.getResposta();

		if (!responsePooling.getResult().equals(ResultEnum.SUCESSO.getCodigo()))
			throw new IntegracaoMotorBiometriaException(
					new StringBuilder()
							.append("Erro eo enviar a foto para o motor de biometria! ERRO: ")
							.append("Erro ao consultar o CreditRequest ID:"
									+ creditRequestId).toString());

		/*
		 * return new IntegracaoEnvioFotoDTO(respostaLogin,
		 * idIntegracaoCreditRequest, respostaLogout,
		 * responsePooling.getCreditrequest().getId());
		 */

		return new IntegracaoAvaliacaoFotoDTO(respostaLogin,
				idIntegracaoCreditRequest, respostaLogout, responsePooling);

	}
}
