/**
 * StatusCode.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.motorFraude.integracao;

public class StatusCode implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected StatusCode(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _Invalido = "Invalido";
    public static final java.lang.String _OK = "OK";
    public static final java.lang.String _UserNotFound = "UserNotFound";
    public static final java.lang.String _XMLValidation = "XMLValidation";
    public static final java.lang.String _XMLTransform = "XMLTransform";
    public static final java.lang.String _UnexpectedError = "UnexpectedError";
    public static final java.lang.String _OrderExist = "OrderExist";
    public static final java.lang.String _InputPlugin = "InputPlugin";
    public static final java.lang.String _OutputPlugin = "OutputPlugin";
    public static final java.lang.String _PaymentTypeNotFound = "PaymentTypeNotFound";
    public static final java.lang.String _CardTypeNotFound = "CardTypeNotFound";
    public static final java.lang.String _StatusNotPermited = "StatusNotPermited";
    public static final java.lang.String _OrderNotFound = "OrderNotFound";
    public static final java.lang.String _OKComErros = "OKComErros";
    public static final java.lang.String _FilaNaoEncontrada = "FilaNaoEncontrada";
    public static final java.lang.String _InvalidRequest = "InvalidRequest";
    public static final java.lang.String _PaymentNotFound = "PaymentNotFound";
    public static final java.lang.String _NsuExists = "NsuExists";
    public static final java.lang.String _NsuNotFound = "NsuNotFound";
    public static final java.lang.String _NsuDuplicate = "NsuDuplicate";
    public static final java.lang.String _QuizInactive = "QuizInactive";
    public static final java.lang.String _GenericFieldNotFound = "GenericFieldNotFound";
    public static final java.lang.String _QuizNotFound = "QuizNotFound";
    public static final java.lang.String _UserNotAuthorized = "UserNotAuthorized";
    public static final java.lang.String _OrderWithoutDiagnostics = "OrderWithoutDiagnostics";
    public static final java.lang.String _ProductUnavailable = "ProductUnavailable";
    public static final StatusCode Invalido = new StatusCode(_Invalido);
    public static final StatusCode OK = new StatusCode(_OK);
    public static final StatusCode UserNotFound = new StatusCode(_UserNotFound);
    public static final StatusCode XMLValidation = new StatusCode(_XMLValidation);
    public static final StatusCode XMLTransform = new StatusCode(_XMLTransform);
    public static final StatusCode UnexpectedError = new StatusCode(_UnexpectedError);
    public static final StatusCode OrderExist = new StatusCode(_OrderExist);
    public static final StatusCode InputPlugin = new StatusCode(_InputPlugin);
    public static final StatusCode OutputPlugin = new StatusCode(_OutputPlugin);
    public static final StatusCode PaymentTypeNotFound = new StatusCode(_PaymentTypeNotFound);
    public static final StatusCode CardTypeNotFound = new StatusCode(_CardTypeNotFound);
    public static final StatusCode StatusNotPermited = new StatusCode(_StatusNotPermited);
    public static final StatusCode OrderNotFound = new StatusCode(_OrderNotFound);
    public static final StatusCode OKComErros = new StatusCode(_OKComErros);
    public static final StatusCode FilaNaoEncontrada = new StatusCode(_FilaNaoEncontrada);
    public static final StatusCode InvalidRequest = new StatusCode(_InvalidRequest);
    public static final StatusCode PaymentNotFound = new StatusCode(_PaymentNotFound);
    public static final StatusCode NsuExists = new StatusCode(_NsuExists);
    public static final StatusCode NsuNotFound = new StatusCode(_NsuNotFound);
    public static final StatusCode NsuDuplicate = new StatusCode(_NsuDuplicate);
    public static final StatusCode QuizInactive = new StatusCode(_QuizInactive);
    public static final StatusCode GenericFieldNotFound = new StatusCode(_GenericFieldNotFound);
    public static final StatusCode QuizNotFound = new StatusCode(_QuizNotFound);
    public static final StatusCode UserNotAuthorized = new StatusCode(_UserNotAuthorized);
    public static final StatusCode OrderWithoutDiagnostics = new StatusCode(_OrderWithoutDiagnostics);
    public static final StatusCode ProductUnavailable = new StatusCode(_ProductUnavailable);
    public java.lang.String getValue() { return _value_;}
    public static StatusCode fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        StatusCode enumeration = (StatusCode)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static StatusCode fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(StatusCode.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.clearsale.com.br/integration", "StatusCode"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
