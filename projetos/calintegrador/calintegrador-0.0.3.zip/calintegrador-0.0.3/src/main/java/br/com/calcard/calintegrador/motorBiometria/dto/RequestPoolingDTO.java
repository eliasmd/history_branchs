package br.com.calcard.calintegrador.motorBiometria.dto;

public class RequestPoolingDTO {

	private AuthenticationDTO authentication;

	private CreditRequestDTO creditrequest;

	public RequestPoolingDTO(AuthenticationDTO authentication,
			CreditRequestDTO creditrequest) {
		this.authentication = authentication;
		this.creditrequest = creditrequest;
	}

	public AuthenticationDTO getAuthentication() {
		return authentication;
	}

	public void setAuthentication(AuthenticationDTO authentication) {
		this.authentication = authentication;
	}

	public CreditRequestDTO getCreditrequest() {
		return creditrequest;
	}

	public void setCreditrequest(CreditRequestDTO creditrequest) {
		this.creditrequest = creditrequest;
	}

}
