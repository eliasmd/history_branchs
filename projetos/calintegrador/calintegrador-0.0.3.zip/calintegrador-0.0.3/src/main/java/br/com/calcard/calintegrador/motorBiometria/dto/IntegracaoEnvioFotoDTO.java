package br.com.calcard.calintegrador.motorBiometria.dto;

public class IntegracaoEnvioFotoDTO {

	private IntegracaoLoginDTO integracaoLogin;

	private Integer idIntegracao;

	private Integer idMotorBiometria;

	private IntegracaoLogoutDTO integracaoLogout;

	public IntegracaoEnvioFotoDTO(IntegracaoLoginDTO integracaoLogin,
			Integer idIntegracao, IntegracaoLogoutDTO integracaoLogout,
			Integer idMotorBiometria) {
		super();
		this.integracaoLogin = integracaoLogin;
		this.idIntegracao = idIntegracao;
		this.integracaoLogout = integracaoLogout;
		this.idMotorBiometria = idMotorBiometria;
	}

	public IntegracaoLoginDTO getIntegracaoLogin() {
		return integracaoLogin;
	}

	public void setIntegracaoLogin(IntegracaoLoginDTO integracaoLogin) {
		this.integracaoLogin = integracaoLogin;
	}

	public Integer getIdIntegracao() {
		return idIntegracao;
	}

	public void setIdIntegracao(Integer idIntegracao) {
		this.idIntegracao = idIntegracao;
	}

	public IntegracaoLogoutDTO getIntegracaoLogout() {
		return integracaoLogout;
	}

	public void setIntegracaoLogout(IntegracaoLogoutDTO integracaoLogout) {
		this.integracaoLogout = integracaoLogout;
	}

	public Integer getIdMotorBiometria() {
		return idMotorBiometria;
	}

	public void setIdMotorBiometria(Integer idMotorBiometria) {
		this.idMotorBiometria = idMotorBiometria;
	}

}
