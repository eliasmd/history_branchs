package br.com.calcard.calintegrador.motorBiometria.dto;

public class IntegracaoLoginDTO {

	private String token;

	private Integer idIntegracao;

	public IntegracaoLoginDTO() {

	}

	public IntegracaoLoginDTO(String token, Integer idIntegracao) {
		super();
		this.token = token;
		this.idIntegracao = idIntegracao;
	}

	public Integer getIdIntegracao() {
		return idIntegracao;
	}

	public void setIdIntegracao(Integer idIntegracao) {
		this.idIntegracao = idIntegracao;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}
