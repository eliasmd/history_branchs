/**
 * CadastraAlteraSenhaReq.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.calcard.calintegrador.processadora.integracao.ws.cartao;

public class CadastraAlteraSenhaReq  implements java.io.Serializable {
    private int id_Conta;

    private java.lang.String codigoSeguranca;

    private java.lang.String numeroCartao;

    private int usaCriptografia;

    private java.lang.String senhaAnterior;

    private java.lang.String senhaDigitada;

    private java.lang.String senhaRedigitada;

    public CadastraAlteraSenhaReq() {
    }

    public CadastraAlteraSenhaReq(
           int id_Conta,
           java.lang.String codigoSeguranca,
           java.lang.String numeroCartao,
           int usaCriptografia,
           java.lang.String senhaAnterior,
           java.lang.String senhaDigitada,
           java.lang.String senhaRedigitada) {
           this.id_Conta = id_Conta;
           this.codigoSeguranca = codigoSeguranca;
           this.numeroCartao = numeroCartao;
           this.usaCriptografia = usaCriptografia;
           this.senhaAnterior = senhaAnterior;
           this.senhaDigitada = senhaDigitada;
           this.senhaRedigitada = senhaRedigitada;
    }


    /**
     * Gets the id_Conta value for this CadastraAlteraSenhaReq.
     * 
     * @return id_Conta
     */
    public int getId_Conta() {
        return id_Conta;
    }


    /**
     * Sets the id_Conta value for this CadastraAlteraSenhaReq.
     * 
     * @param id_Conta
     */
    public void setId_Conta(int id_Conta) {
        this.id_Conta = id_Conta;
    }


    /**
     * Gets the codigoSeguranca value for this CadastraAlteraSenhaReq.
     * 
     * @return codigoSeguranca
     */
    public java.lang.String getCodigoSeguranca() {
        return codigoSeguranca;
    }


    /**
     * Sets the codigoSeguranca value for this CadastraAlteraSenhaReq.
     * 
     * @param codigoSeguranca
     */
    public void setCodigoSeguranca(java.lang.String codigoSeguranca) {
        this.codigoSeguranca = codigoSeguranca;
    }


    /**
     * Gets the numeroCartao value for this CadastraAlteraSenhaReq.
     * 
     * @return numeroCartao
     */
    public java.lang.String getNumeroCartao() {
        return numeroCartao;
    }


    /**
     * Sets the numeroCartao value for this CadastraAlteraSenhaReq.
     * 
     * @param numeroCartao
     */
    public void setNumeroCartao(java.lang.String numeroCartao) {
        this.numeroCartao = numeroCartao;
    }


    /**
     * Gets the usaCriptografia value for this CadastraAlteraSenhaReq.
     * 
     * @return usaCriptografia
     */
    public int getUsaCriptografia() {
        return usaCriptografia;
    }


    /**
     * Sets the usaCriptografia value for this CadastraAlteraSenhaReq.
     * 
     * @param usaCriptografia
     */
    public void setUsaCriptografia(int usaCriptografia) {
        this.usaCriptografia = usaCriptografia;
    }


    /**
     * Gets the senhaAnterior value for this CadastraAlteraSenhaReq.
     * 
     * @return senhaAnterior
     */
    public java.lang.String getSenhaAnterior() {
        return senhaAnterior;
    }


    /**
     * Sets the senhaAnterior value for this CadastraAlteraSenhaReq.
     * 
     * @param senhaAnterior
     */
    public void setSenhaAnterior(java.lang.String senhaAnterior) {
        this.senhaAnterior = senhaAnterior;
    }


    /**
     * Gets the senhaDigitada value for this CadastraAlteraSenhaReq.
     * 
     * @return senhaDigitada
     */
    public java.lang.String getSenhaDigitada() {
        return senhaDigitada;
    }


    /**
     * Sets the senhaDigitada value for this CadastraAlteraSenhaReq.
     * 
     * @param senhaDigitada
     */
    public void setSenhaDigitada(java.lang.String senhaDigitada) {
        this.senhaDigitada = senhaDigitada;
    }


    /**
     * Gets the senhaRedigitada value for this CadastraAlteraSenhaReq.
     * 
     * @return senhaRedigitada
     */
    public java.lang.String getSenhaRedigitada() {
        return senhaRedigitada;
    }


    /**
     * Sets the senhaRedigitada value for this CadastraAlteraSenhaReq.
     * 
     * @param senhaRedigitada
     */
    public void setSenhaRedigitada(java.lang.String senhaRedigitada) {
        this.senhaRedigitada = senhaRedigitada;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CadastraAlteraSenhaReq)) return false;
        CadastraAlteraSenhaReq other = (CadastraAlteraSenhaReq) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.id_Conta == other.getId_Conta() &&
            ((this.codigoSeguranca==null && other.getCodigoSeguranca()==null) || 
             (this.codigoSeguranca!=null &&
              this.codigoSeguranca.equals(other.getCodigoSeguranca()))) &&
            ((this.numeroCartao==null && other.getNumeroCartao()==null) || 
             (this.numeroCartao!=null &&
              this.numeroCartao.equals(other.getNumeroCartao()))) &&
            this.usaCriptografia == other.getUsaCriptografia() &&
            ((this.senhaAnterior==null && other.getSenhaAnterior()==null) || 
             (this.senhaAnterior!=null &&
              this.senhaAnterior.equals(other.getSenhaAnterior()))) &&
            ((this.senhaDigitada==null && other.getSenhaDigitada()==null) || 
             (this.senhaDigitada!=null &&
              this.senhaDigitada.equals(other.getSenhaDigitada()))) &&
            ((this.senhaRedigitada==null && other.getSenhaRedigitada()==null) || 
             (this.senhaRedigitada!=null &&
              this.senhaRedigitada.equals(other.getSenhaRedigitada())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getId_Conta();
        if (getCodigoSeguranca() != null) {
            _hashCode += getCodigoSeguranca().hashCode();
        }
        if (getNumeroCartao() != null) {
            _hashCode += getNumeroCartao().hashCode();
        }
        _hashCode += getUsaCriptografia();
        if (getSenhaAnterior() != null) {
            _hashCode += getSenhaAnterior().hashCode();
        }
        if (getSenhaDigitada() != null) {
            _hashCode += getSenhaDigitada().hashCode();
        }
        if (getSenhaRedigitada() != null) {
            _hashCode += getSenhaRedigitada().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CadastraAlteraSenhaReq.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://conductor.com.br/", "CadastraAlteraSenhaReq"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id_Conta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "id_Conta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSeguranca");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "CodigoSeguranca"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "NumeroCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usaCriptografia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "UsaCriptografia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senhaAnterior");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "SenhaAnterior"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senhaDigitada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "SenhaDigitada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senhaRedigitada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://conductor.com.br/", "SenhaRedigitada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
