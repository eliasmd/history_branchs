package br.com.calcard.calsystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.calcard.calframework.entity.CalsystemEntity;

@Entity
@Table(name = "tbl_processo_digitalizacao")
public class ProcessoDigitalizacao extends CalsystemEntity {

	private static final long serialVersionUID = 1353028575163867718L;

	private static final String COLUNA_NOME = "nome";

	private static final String COLUNA_DESCRICAO = "descricao";

	private static final String COLUNA_SIGLA = "sigla";
	
	public static final String SIGLA_ALTERACAO_SENHA = "AS";

	@Column(name = COLUNA_NOME, length = 30, nullable = false, unique = true)
	private String nome;

	@Column(name = COLUNA_DESCRICAO, length = 200, nullable = false, unique = false)
	private String descricao;

	@Column(name = COLUNA_SIGLA, length = 10, nullable = true, unique = false)
	private String sigla;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((descricao == null) ? 0 : descricao.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((sigla == null) ? 0 : sigla.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProcessoDigitalizacao other = (ProcessoDigitalizacao) obj;
		if (descricao == null) {
			if (other.descricao != null)
				return false;
		} else if (!descricao.equals(other.descricao))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (sigla == null) {
			if (other.sigla != null)
				return false;
		} else if (!sigla.equals(other.sigla))
			return false;
		return true;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

}
