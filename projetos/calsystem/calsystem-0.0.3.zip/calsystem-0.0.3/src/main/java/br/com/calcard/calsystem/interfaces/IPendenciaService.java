package br.com.calcard.calsystem.interfaces;

import br.com.calcard.calsystem.entity.PendenciaAlteracaoSenha;

public interface IPendenciaService {

	public PendenciaAlteracaoSenha doCadastrarPendenciaAlteracaoSenha(
			PendenciaAlteracaoSenha pendenciaAlteracaoSenha);

}
