package br.com.calcard.calsystem.interfaces;

import java.util.List;

import org.springframework.http.ResponseEntity;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorCredito.exception.IntegracaoMotorCreditoException;
import br.com.calcard.calintegrador.processadora.exception.IntegracaoProcessadoraException;
import br.com.calcard.calsystem.dto.AlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.CartaoDTO;
import br.com.calcard.calsystem.dto.DocumentoDTO;

public interface ICartao {

	public List<CartaoDTO> doListarCartoes(String cpf, String numeroCartao)
			throws CalsystemInvalidArgumentException;

	public List<CartaoDTO> doListarCartoesCadastroSenhaEDesbloqueio(String cpf,
			String numeroCartao) throws IntegracaoProcessadoraException, IntegracaoException, CalsystemInvalidArgumentException, CalsystemNoDataFoundException;

	public ResponseEntity<Object> doAlterarSenhaPortador(
			AlteracaoSenhaDTO alteracaoSenhaDTO);

	public void doAlterarSenhaPortador(Integer idConta, String cpfPortador,
			String senha, Integer idUsuario, String foto,
			Integer idEstabelecimento, List<DocumentoDTO> documentoDTO)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, IntegracaoException,
			ServiceException, IntegracaoMotorBiometriaException,
			IntegracaoProcessadoraException, IntegracaoMotorCreditoException;

}
