package br.com.calcard.calsystem.exception.proposta;

public class PropostaEnderecoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3950569999134812135L;

	public PropostaEnderecoException(String mensagem) {
		super(mensagem);
	}

}
