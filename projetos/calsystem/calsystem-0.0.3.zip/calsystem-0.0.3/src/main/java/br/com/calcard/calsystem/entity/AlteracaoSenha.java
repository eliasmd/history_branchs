package br.com.calcard.calsystem.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;
import br.com.calcard.calsystem.entity.proposta.Foto;

@Entity
@NamedQueries({ @NamedQuery(name = AlteracaoSenha.NQ_SELECT_ALTERACAO_SENHA_BY_STATUS, query = "select c from AlteracaoSenha c where c.status = :status") })
@Table(name = "tbl_alteracao_senha")
public class AlteracaoSenha extends CalsystemEntity {

	private static final long serialVersionUID = 826758298441371443L;

	public static final String NQ_SELECT_ALTERACAO_SENHA_BY_STATUS = "NQAlteracaoSenhaByStatus";

	public static final String COLUNA_ID_CONTA = "id_conta";
	public static final String COLUNA_SENHA = "senha";
	public static final String COLUNA_CPF = "cpf";
	private static final String COLUNA_FOTO = "id_foto";
	private static final String COLUNA_NOME = "nome";
	private static final String COLUNA_ESTABELECIMENTO = "id_estabelecimento";

	@Column(name = COLUNA_STATUS, length = 50, nullable = false, unique = false)
	protected String status; 

	@Column(name = COLUNA_ID_CONTA, nullable = false, unique = false)
	private Integer conta;

	@Column(name = COLUNA_SENHA, length = 4, nullable = true, unique = false)
	private String senha;

	@Column(name = COLUNA_CPF, length = 11, nullable = false, unique = false)
	private String cpf;

	@OneToOne
	@JoinColumn(name = COLUNA_FOTO, unique = false, nullable = true)
	private Foto foto;

	@OneToOne
	@JoinColumn(name = COLUNA_ESTABELECIMENTO, nullable = false, unique = false)
	private Estabelecimento estabelecimento;

	@Column(name = COLUNA_NOME, length = 50, nullable = false, unique = false)
	private String nome;

	@Type(type = "yes_no")
	@Column(name = "titular", unique = false, nullable = false)
	private Boolean titular;

	/*@OneToMany(mappedBy = "alteracaoSenha", cascade = CascadeType.ALL)
	private List<DocumentoDigitalizadoAlteracaoSenha> documentosDigitalizados;*/
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER) 
	@JoinTable(name="tbl_documento_digitalizado_alteracao_senha", joinColumns={@JoinColumn(name="id_alteracao_senha", referencedColumnName="id")}, inverseJoinColumns={@JoinColumn(name="id_documento_digitalizado", referencedColumnName="id")})
	private List<DocumentoDigitalizado> documentosDigitalizados;


	public AlteracaoSenha() {
		super();
	}

	public AlteracaoSenha(String status, Conta conta, String cpf,
			String numero, Date dataCadastro, Date dataValidade,
			String nomePortador, boolean titular) {
		super();
		// this.conta = conta;
		this.cpf = cpf;
		// this.titular = titular;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Boolean getTitular() {
		return titular;
	}

	public void setTitular(Boolean titular) {
		this.titular = titular;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<DocumentoDigitalizado> getDocumentosDigitalizados() {
		return documentosDigitalizados;
	}

	public void setDocumentosDigitalizados(
			List<DocumentoDigitalizado> documentosDigitalizados) {
		this.documentosDigitalizados = documentosDigitalizados;
	}

	public Integer getConta() {
		return conta;
	}

	public void setConta(Integer conta) {
		this.conta = conta;
	}

	public Foto getFoto() {
		return foto;
	}

	public void setFoto(Foto foto) {
		this.foto = foto;
	}

	public Estabelecimento getEstabelecimento() {
		return estabelecimento;
	}

	public void setEstabelecimento(Estabelecimento estabelecimento) {
		this.estabelecimento = estabelecimento;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
