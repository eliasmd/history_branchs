package br.com.calcard.calsystem.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class TipoDocumentoDigitalizadoInvalido extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3769248074768883882L;

	public TipoDocumentoDigitalizadoInvalido(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
