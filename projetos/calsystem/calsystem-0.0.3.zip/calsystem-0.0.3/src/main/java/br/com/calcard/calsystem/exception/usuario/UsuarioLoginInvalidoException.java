package br.com.calcard.calsystem.exception.usuario;

public class UsuarioLoginInvalidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2256688526818940917L;

}
