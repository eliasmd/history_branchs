package br.com.calcard.calsystem.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class PerifericoNaoEncontradoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3046434619886703426L;

	public PerifericoNaoEncontradoException(String mensagem) {
		super(mensagem);
	}

}
