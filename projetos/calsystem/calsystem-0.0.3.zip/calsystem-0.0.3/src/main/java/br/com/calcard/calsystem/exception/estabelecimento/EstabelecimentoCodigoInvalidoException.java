package br.com.calcard.calsystem.exception.estabelecimento;

import br.com.calcard.calframework.exception.CalsystemException;

public class EstabelecimentoCodigoInvalidoException extends CalsystemException {

	private static final long serialVersionUID = 7662360622532394253L;

	public EstabelecimentoCodigoInvalidoException(String mensagem) {
		super(mensagem);
	}

}
