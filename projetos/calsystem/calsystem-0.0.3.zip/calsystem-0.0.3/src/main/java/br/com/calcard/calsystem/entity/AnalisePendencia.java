package br.com.calcard.calsystem.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;
import br.com.calcard.calsystem.entity.proposta.Foto;

@Entity
@NamedQueries({
	@NamedQuery(name = AnalisePendencia.NQ_SELECT_PENDENCIA_ALTERACAO_SENHA, query = "select a from AnalisePendencia a where a.alteracaoSenha = :alteracaoSenha") })
@Table(name = "tbl_analise_pendencia", uniqueConstraints = @UniqueConstraint(columnNames = {
		AnalisePendencia.COLUNA_ALTERACAO_SENHA }, name = "UK_LOCK_PENDENCIA"))
public class AnalisePendencia extends CalsystemEntity {

	private static final long serialVersionUID = 826758298441371443L;
	
	public static final String NQ_SELECT_PENDENCIA_ALTERACAO_SENHA = "NQPendenciaAlteracaoSenha";
	
	public static final String COLUNA_DATA_INICIO = "data_inicio";
	public static final String COLUNA_DATA_FIM = "data_fim";
	public static final String COLUNA_STATUS = "status";
	public static final String COLUNA_ETAPA_STATUS = "etapa_status";
	private static final String COLUNA_PARECER = "parecer";
	private static final String COLUNA_ANALISTA = "id_analista";
	public static final String COLUNA_ALTERACAO_SENHA = "id_alteracao_senha";

	@Column(name = COLUNA_STATUS, length = 50, nullable = false, unique = false)
	protected String status;
	
	@Column(name = COLUNA_ETAPA_STATUS, length = 50, nullable = true, unique = false)
	protected String etapa_status;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = COLUNA_DATA_INICIO, unique = false, nullable = false)
	protected Date dataInicio;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = COLUNA_DATA_FIM, unique = false, nullable = true)
	protected Date dataFim;
	
	@ManyToOne
	@JoinColumn(name = COLUNA_ANALISTA,  nullable = false, unique = false)
	private Usuario analista;
	
	@Column(name = COLUNA_PARECER, length = 50, nullable = true, unique = false)
	private String parecer;
	
	@OneToOne
	@JoinColumn(name = COLUNA_ALTERACAO_SENHA, nullable = false, unique = true)
	private AlteracaoSenha alteracaoSenha;
	
	public AnalisePendencia() {
		super();
	}

	public AnalisePendencia(String status, 
							String etapa_status,
							Date dataInicio,
							Date dataFim,
							Usuario analista,
							String parecer,
							AlteracaoSenha alteracaoSenha) {
		super();
		this.status = status;
		this.etapa_status = etapa_status;
		this.dataInicio = dataInicio;
		this.dataFim = dataFim;
		this.analista = analista;
		this.parecer = parecer;
		this.alteracaoSenha = alteracaoSenha;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEtapa_status() {
		return etapa_status;
	}

	public void setEtapa_status(String etapa_status) {
		this.etapa_status = etapa_status;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	public Usuario getAnalista() {
		return analista;
	}

	public void setAnalista(Usuario analista) {
		this.analista = analista;
	}

	public String getParecer() {
		return parecer;
	}

	public void setParecer(String parecer) {
		this.parecer = parecer;
	}

	public AlteracaoSenha getAlteracaoSenha() {
		return alteracaoSenha;
	}

	public void setAlteracaoSenha(AlteracaoSenha alteracaoSenha) {
		this.alteracaoSenha = alteracaoSenha;
	}
	
}
