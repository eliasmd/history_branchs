package br.com.calcard.calsystem.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class TokenInvalidoException extends CalsystemException {

	private static final long serialVersionUID = 4000798862240318733L;

	public TokenInvalidoException(String message) {
		super(message);
	}

}
