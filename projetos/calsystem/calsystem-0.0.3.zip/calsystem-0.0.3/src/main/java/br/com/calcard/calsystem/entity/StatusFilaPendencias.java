package br.com.calcard.calsystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import br.com.calcard.calframework.entity.CalsystemEntity;

@Entity
@Table(name = "tbl_status_fila_pendencia")
@NamedQueries({ @NamedQuery(name = StatusFilaPendencias.NQ_SELECT_STATUS_PENDENCIA_BY_STATUS, query = "select s from StatusFilaPendencias s where s.status = :status") })
public class StatusFilaPendencias extends CalsystemEntity {

	private static final long serialVersionUID = 4636712282306612663L;

	public static final String NQ_SELECT_STATUS_PENDENCIA_BY_STATUS = "NQStatusPendenciaByStatus";

	public static final String STATUS_PENDENTE = "PENDENTE";

	public static final String STATUS_NEGADO = "NEGADO";

	public static final String STATUS_EM_ANALISE = "EM_ANALISE";

	public static final String STATUS_APROVADO = "APROVADO";

	@Column(name = COLUNA_STATUS, length = 50, nullable = false, unique = false)
	protected String status;

	public StatusFilaPendencias() {
		super();
	}

	public StatusFilaPendencias(String status) {
		super();
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
