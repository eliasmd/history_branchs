package br.com.calcard.calsystem.exception.proposta;

public class TelefoneInvalidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4994680402990958158L;

	public TelefoneInvalidoException(String mensagem) {
		super(mensagem);
	}

}
