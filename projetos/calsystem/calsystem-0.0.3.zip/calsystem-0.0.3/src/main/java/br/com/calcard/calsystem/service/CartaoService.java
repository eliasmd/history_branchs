package br.com.calcard.calsystem.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calframework.ws.CalsystemServiceWS;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.DocumentDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoEnvioFotoDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoLoginDTO;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calintegrador.motorCredito.exception.IntegracaoMotorCreditoException;
import br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultEvalValuesXml;
import br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultRespostasXml;
import br.com.calcard.calintegrador.motorCredito.interfaces.IMotorCredito;
import br.com.calcard.calintegrador.processadora.exception.IntegracaoProcessadoraException;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.CartaoConsulta;
import br.com.calcard.calintegrador.processadora.interfaces.IProcessadoraIntegracao;
import br.com.calcard.calintegrador.processadora.service.ProcessadoraIntegradorService;
import br.com.calcard.calsystem.dto.AlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.CartaoDTO;
import br.com.calcard.calsystem.dto.ContaDTO;
import br.com.calcard.calsystem.dto.DocumentoDTO;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.ParametroGlobal;
import br.com.calcard.calsystem.entity.PendenciaAlteracaoSenha;
import br.com.calcard.calsystem.entity.StatusFilaPendencias;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;
import br.com.calcard.calsystem.entity.proposta.Foto;
import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;
import br.com.calcard.calsystem.enums.Enum.StatusPadraoEnum;
import br.com.calcard.calsystem.exception.proposta.PropostaDocumentosDigitalizadosException;
import br.com.calcard.calsystem.helper.CartaoServiceHelper;
import br.com.calcard.calsystem.interfaces.ICartao;
import br.com.calcard.calsystem.interfaces.IDocumentoDigitalizado;
import br.com.calcard.calsystem.interfaces.IEstabelecimento;
import br.com.calcard.calsystem.interfaces.IParametroGlobal;
import br.com.calcard.calsystem.interfaces.IUsuario;
import br.com.calcard.calsystem.util.Parametro;

@Component
@Service
public class CartaoService extends CalsystemServiceWS implements ICartao {

	private ICalsystemDAO daoService;

	private IProcessadoraIntegracao integracaoProcessadoraService;

	private IMotorBiometria motorBiometriaService;

	private IProcessadoraIntegracao processadoraService;

	private IUsuario usuarioService;

	private IEstabelecimento estabelecimentoService;

	private IDocumentoDigitalizado documentoDigitalizadoService;
	
	private IMotorCredito motorCreditoService;
	
	private IParametroGlobal parametroGlobalService;

	@Autowired
	public CartaoService(ICalsystemDAO daoService,
			IMotorBiometria motorBiometriaService,
			IProcessadoraIntegracao processadoraService,
			IUsuario usuarioService, IEstabelecimento estabelecimentoService,
			IDocumentoDigitalizado documentoDigitalizadoService,
			IProcessadoraIntegracao integracaoProcessadoraService,
			IMotorCredito motorCreditoService,
			IParametroGlobal parametroGlobalService) {
		this.daoService = daoService;
		this.motorBiometriaService = motorBiometriaService;
		this.processadoraService = processadoraService;
		this.usuarioService = usuarioService;
		this.estabelecimentoService = estabelecimentoService;
		this.documentoDigitalizadoService = documentoDigitalizadoService;
		this.integracaoProcessadoraService = integracaoProcessadoraService;
		this.motorCreditoService = motorCreditoService;
		this.parametroGlobalService = parametroGlobalService;
	}

	@Override
	public List<CartaoDTO> doListarCartoes(String cpf, String numeroCartao)
			throws CalsystemInvalidArgumentException {

		if (cpf == null && numeroCartao == null)
			throw new CalsystemInvalidArgumentException(
					"CPF ou N�mero do Cart�o precis�o ser informados!");

		List<CartaoDTO> cartoes = new ArrayList<CartaoDTO>();
		ContaDTO conta = null;
		CartaoDTO cartao = null;

		if (cpf == null || numeroCartao != null) {

			cpf = "13644256373";

			conta = new ContaDTO(1229, "Maria da Silva",
					CalsystemUtil.doMascararCPF(cpf), "NORMAL");

			cartao = new CartaoDTO(numeroCartao, "Maria da Silva", cpf, true,
					"NORMAL", conta);

			cartoes.add(cartao);
		}

		if (numeroCartao == null) {

			for (int i = 0; i < 2; i++) {

				// Titular da conta
				if (i == 0) {

					conta = new ContaDTO(8988, "Maria da Silva",
							CalsystemUtil.doMascararCPF(cpf), "NORMAL");

					cartao = new CartaoDTO("6364********0808",
							"Maria da Silva", CalsystemUtil.doMascararCPF(cpf),
							true, "NORMAL", conta);

					cartoes.add(cartao);

					// Depend�nte da conta
				} else if (i == 1) {

					conta = new ContaDTO(7655, "Jo�o Paulo",
							CalsystemUtil.doMascararCPF(cpf), "NORMAL");

					cartao = new CartaoDTO("6364********5632",
							"Maria da Silva", "897******76", false, "NORMAL",
							conta);

					cartoes.add(cartao);

				}

			}

		}

		return cartoes;

	}

	@Override
	public List<CartaoDTO> doListarCartoesCadastroSenhaEDesbloqueio(String cpf,
			String numeroCartao) throws IntegracaoProcessadoraException,
			IntegracaoException, CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		// try {

		if (cpf == null && numeroCartao == null)
			throw new CalsystemInvalidArgumentException(
					"CPF ou N�mero do Cart�o n�o foram informados!");

		List<CartaoDTO> cartoesDTO = doComporCartoesDTO(this.integracaoProcessadoraService
				.doConsultarCartoesProcessadoraAsList(null, cpf, null, null,
						false, null));

		return cartoesDTO;

		/*
		 * return super.doRetornarSucessoWS(new Parametro().doAddParametro(
		 * "cartoes", cartoesDTO).getParametros());
		 * 
		 * } catch (CalsystemInvalidArgumentException |
		 * IntegracaoProcessadoraException | IntegracaoException e) { return
		 * super.doRetornarErroWS(e); }
		 */

	}

	private List<CartaoDTO> doComporCartoesDTO(
			List<CartaoConsulta> cartaoConsulta) {

		List<CartaoDTO> cartoesDTO = new ArrayList<CartaoDTO>();
		// ContaDTO conta = null;
		CartaoDTO cartao = null;

		for (int i = 0; i < cartaoConsulta.size(); i++) {

			// tem que buscar os dados da conta
			/*
			 * conta = new ContaDTO(cartaoConsulta.get(i).getIDConta(),
			 * cartaoConsulta.get(i).getNomePortador(),
			 * CalsystemUtil.doMascararCPF
			 * (cartaoConsulta.get(i).getCPFTitular()), "NORMAL");
			 */

			cartao = new CartaoDTO(cartaoConsulta.get(i).getNumCartao(),
					cartaoConsulta.get(i).getNomePortador(),
					CalsystemUtil.doMascararCPF(cartaoConsulta.get(i)
							.getCPFTitular()), cartaoConsulta.get(i)
							.getTitularidade() == "S" ? true : false, // titular
																		// true
					Integer.toString(cartaoConsulta.get(i).getStatusCartao()), // Status
																				// 1
																				// necess�rio
																				// converter
																				// para
																				// normal
					null);

			cartoesDTO.add(cartao);

		}

		return cartoesDTO;

	}

	private AlteracaoSenha doRegistrarAlteracaoSenha(
			AlteracaoSenhaDTO alteracaoSenhaDTO)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException,
			PropostaDocumentosDigitalizadosException {

		CartaoServiceHelper cartaoServiceHelper = new CartaoServiceHelper();

		AlteracaoSenha alteracaoSenha = cartaoServiceHelper
				.doCarregarDadosAlteracaoDeSenha(alteracaoSenhaDTO);

		alteracaoSenha
				.setDocumentosDigitalizados(doCarregarDocumentosDigitalizados(
						alteracaoSenhaDTO.getDocumentosDigitalizados(),
						alteracaoSenha));

		Foto foto = this.daoService
				.doRead(alteracaoSenhaDTO.getFotoNSU(),
						Foto.class,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhuma biometria facial com o NSU informado! NSU: ")
								.append(alteracaoSenhaDTO.getFotoNSU())
								.toString(), "NSU da foto n�o foi informado!");

		alteracaoSenha.setFoto(foto);

		Estabelecimento estab = this.daoService
				.doRead(alteracaoSenhaDTO.getIdEstabelecimento(),
						Estabelecimento.class,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhum Estabelecimento com o ID informado: ")
								.append(alteracaoSenhaDTO
										.getIdEstabelecimento()).toString(),
						"ID do Estabelecimento n�o foi informado!");

		alteracaoSenha.setEstabelecimento(estab);

		// salva a solicitacao de senha
		this.daoService.doCreate(alteracaoSenha);

		// salva a lista de documentos digitalizados
		for (DocumentoDigitalizado documentoDigitalizadoSenha : alteracaoSenha
				.getDocumentosDigitalizados()) {
			this.daoService.doUpdate(documentoDigitalizadoSenha);
			// this.daoService.doCreate(documentoDigitalizadoSenha);
		}

		return alteracaoSenha;
	}

	@Override
	@Transactional
	public ResponseEntity<Object> doAlterarSenhaPortador(
			AlteracaoSenhaDTO alteracaoSenhaDTO) {

		try {

			AlteracaoSenha alteracaoSenha = this
					.doRegistrarAlteracaoSenha(alteracaoSenhaDTO);

			IntegracaoEnvioFotoDTO integracao = this.motorBiometriaService
					.doEnviarCreditRequest(alteracaoSenha.getCpf(), "81",
							// proposta.getPropostaP1().getEstabelecimento().getId().toString(),
							alteracaoSenha.getNome(), new Date("01/01/1900"),
							alteracaoSenha.getFoto().getFotoBase64());

			alteracaoSenha.getFoto().setIdMotorBiometria(
					integracao.getIdMotorBiometria());
			this.daoService.doUpdate(alteracaoSenha.getFoto());

			return super.doRetornarSucessoWS(null);

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public List<DocumentoDigitalizado> doCarregarDocumentosDigitalizados(
			List<DocumentoDigitalizadoDTO> listaDocumentoDigitalizadoDTO,
			AlteracaoSenha alteracaoSenha)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		// List<DocumentoDigitalizadoAlteracaoSenha>
		// documentosDigitalizadosSenha = new
		// ArrayList<DocumentoDigitalizadoAlteracaoSenha>();
		List<DocumentoDigitalizado> documentosDigitalizadosSenha = new ArrayList<DocumentoDigitalizado>();

		for (DocumentoDigitalizadoDTO documentoDigitalizadoDTO : listaDocumentoDigitalizadoDTO) {

			TipoDocumentoDigitalizado tipoDocumentoDigitalizado = this.daoService
					.doRead(documentoDigitalizadoDTO.getIdTipoDocumento(),
							TipoDocumentoDigitalizado.class,
							true,
							new StringBuilder(
									"N�o foi encontrado nenhum tipo de documento digitalizado com o ID informado! ID: ")
									.append(documentoDigitalizadoDTO
											.getIdTipoDocumento()).toString(),
							"ID do tipo de documento digitalizado n�o foi informado!");

			DocumentoDigitalizado documentoDigitalizado = this.daoService
					.doRead(documentoDigitalizadoDTO.getId(),
							DocumentoDigitalizado.class,
							true,
							new StringBuilder(
									"N�o foi encontrado nenhum documento digitalizado com o ID informado! ID: ")
									.append(documentoDigitalizadoDTO.getId())
									.toString(),
							"ID do documento digitalizado n�o foi informado!");

			// marca o documento para inativo para que n�o seja utilizado em
			// outra solicitacao
			documentoDigitalizado.setStatus(StatusPadraoEnum.INATIVO);
			documentoDigitalizado.setTipo(tipoDocumentoDigitalizado);

			// adiciona na lista da tabela temporaria
			/*
			 * documentosDigitalizadosSenha .add(new
			 * DocumentoDigitalizadoAlteracaoSenha( documentoDigitalizado,
			 * alteracaoSenha));
			 */
			documentosDigitalizadosSenha.add(documentoDigitalizado);

		}

		return documentosDigitalizadosSenha;
	}

	@Override
	@Transactional
	public void doAlterarSenhaPortador(Integer idConta, String cpfPortador,
			String senha, Integer idUsuario, String foto,
			Integer idEstabelecimento, List<DocumentoDTO> documentoDTO)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, IntegracaoException,
			ServiceException, IntegracaoMotorBiometriaException,
			IntegracaoProcessadoraException, IntegracaoMotorCreditoException {

		Usuario usuario = this.usuarioService
				.doConsultarUsuarioPorId(
						idUsuario,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhum usu�rio com o id informado! ID: ")
								.append(idUsuario).toString(),
						"ID do usu�rio n�o informado!");

		Estabelecimento estabelecimento = this.estabelecimentoService
				.doConsultarEstabelecimentoPorId(
						idEstabelecimento,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhum estabelecimento com o id informado! ID: ")
								.append(idEstabelecimento).toString(),
						"Id do estabelecimento n�o informado!");

		if (documentoDTO == null)
			throw new CalsystemInvalidArgumentException(
					"Documentos n�o informados!");

		List<DocumentDTO> documentDTO = new ArrayList<DocumentDTO>();

		for (DocumentoDTO documento : documentoDTO) {

			if (documento.getImagem() == null)
				throw new CalsystemInvalidArgumentException(
						"Imagem do documento n�o informada!");

			TipoDocumentoDigitalizado tipoDocumentoDigitalizado = this.documentoDigitalizadoService
					.doConsultarTipoDocumentoDigitalizado(
							documento.getIdTipoDocumento(),
							true,
							new StringBuilder(
									"Tipo de documento inv�lido! ID: ").append(
									documento.getIdTipoDocumento()).toString(),
							"Id do tipo de documento n�o informado!");

			documentDTO.add(new DocumentDTO(tipoDocumentoDigitalizado
					.getDocumentType(), documento.getImagem()));

		}

		CartaoConsulta[] cartoes = this.processadoraService
				.doConsultarCartoesProcessadora(idConta, cpfPortador, null,
						null, true,
						"Nenhum cart�o foi encontrado na processadora para os par�metros informados!");

		/*StatusFilaPendencias status = this.daoService.doGetSingleResult(
				StatusFilaPendencias.NQ_SELECT_STATUS_PENDENCIA_BY_STATUS,
				new Parametro().doAddParametro("status",
						StatusFilaPendencias.STATUS_PENDENTE).getParametros(),
				StatusFilaPendencias.class, true,
				"Status da pend�ncia n�o encontrado!");*/

		IntegracaoEnvioFotoDTO integracao = this.motorBiometriaService
				.doEnviarCreditRequest(cpfPortador,
						String.valueOf(estabelecimento.getCodigo()),
						cartoes[0].getNomePortador(), null, foto, documentDTO);
		
		
		String politica = parametroGlobalService.doConsultar(
				ParametroGlobal.PARAMETRO_CREDDEFENSE_POLITICA_BIOMETRIA).getValorTexto();
		
		String usuarioCredDefense = parametroGlobalService.doConsultar(
				ParametroGlobal.PARAMETRO_CREDDEFENSE_USUARIO).getValorTexto();
		
		String senhaCredDefense = parametroGlobalService.doConsultar(
				ParametroGlobal.PARAMETRO_CREDDEFENSE_SENHA).getValorTexto();
		
		//faz login na CredDefense
		IntegracaoLoginDTO tokenLogin = this.motorBiometriaService.doLogin();
		
		Parametro parametros = new Parametro();
		//parametros.doAddParametro("CPF", "00366172964");
		
		parametros.doAddParametro("token", tokenLogin.getToken());
		parametros.doAddParametro("ID", integracao.getIdMotorBiometria());
		
		//BUSCA O RESULTADO DA BIOMETRIA NO CRIVO
		ResultEvalValuesXml retorno =  motorCreditoService.doConsultarPoliticaDeCredito(usuarioCredDefense,
																						senhaCredDefense, 
																						politica,
																						parametros.getParametros(),
																						true, 
																						"Nenhuma resposta da consulta da pol�tica foi encontrada");

		 String resultadoBiometria = null;
		 for (ResultRespostasXml resultRespostasXml : retorno.getRespostas()) {
			if(resultRespostasXml.getCriterio().equalsIgnoreCase(politica)){
				resultadoBiometria = resultRespostasXml.getSistema();
			}
		}
		
		super.getLogger().info(new StringBuilder("retorno do Crivo foi: ")
							.append(resultadoBiometria).append(" Para o ID biometria: ")
							.append(integracao.getIdMotorBiometria()));

		StatusFilaPendencias status = this.daoService.doGetSingleResult(
				StatusFilaPendencias.NQ_SELECT_STATUS_PENDENCIA_BY_STATUS,
				new Parametro().doAddParametro("status",
						doDeparaStatusBiometriaMotorCredito(resultadoBiometria)).getParametros(),
				StatusFilaPendencias.class, true,
				"Status da pend�ncia n�o encontrado!");
		

		PendenciaAlteracaoSenha pendencia = new PendenciaAlteracaoSenha(
				cartoes[0].getIDConta(), cartoes[0].getCPFPortador(), senha,
				status, integracao.getIdMotorBiometria(), estabelecimento,
				null, null, null, null, usuario);

		this.daoService.doCreate(pendencia);

		//faz logout na CredDefense
		this.motorBiometriaService.doLogout(tokenLogin.getToken());
		
		
		//altera a senha dos cartoes na conductor caso tenha sido aprovado no motor Biometria
		if(doDeparaStatusBiometriaMotorCredito(resultadoBiometria).equals(StatusFilaPendencias.STATUS_APROVADO) ){
			for (CartaoConsulta cartao : cartoes) {
				this.integracaoProcessadoraService.doAlterarSenhaCartao(cartao.getIDConta(), 
																		cartao.getNumCartao().substring((cartao.getNumCartao().length()-4), cartao.getNumCartao().length()),//ultimos 4 digitos
																		null, //senha anterior
																		senha, 
																		ProcessadoraIntegradorService.SENHA_CADASTRAR_NOVA,
																		ProcessadoraIntegradorService.SENHA_SEM_CRIPTOGRAFIA,
																		ProcessadoraIntegradorService.LOG_SISTEMA);
			}
		}
		

	}
	
	private String doDeparaStatusBiometriaMotorCredito(String status){
		
		switch (status) {
	        case "A":
	                return StatusFilaPendencias.STATUS_APROVADO;
	               // break;
	        case "P":
	        		return StatusFilaPendencias.STATUS_PENDENTE;
	                //break;
	        case "R": //reprovado
	        		return StatusFilaPendencias.STATUS_NEGADO;
	        		//break;
	        default :
				return StatusFilaPendencias.STATUS_PENDENTE;
					//break;
		}
	}	
}
