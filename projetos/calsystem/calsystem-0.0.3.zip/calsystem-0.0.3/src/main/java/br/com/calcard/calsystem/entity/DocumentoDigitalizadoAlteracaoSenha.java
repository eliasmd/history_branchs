package br.com.calcard.calsystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;
import br.com.calcard.calsystem.entity.proposta.Proposta;

@Entity
@Table(name = "tbl_documento_digitalizado_alteracao_senha")
public class DocumentoDigitalizadoAlteracaoSenha extends CalsystemEntity {

	private static final long serialVersionUID = -3593672909900033985L;

	public static final String COLUNA_DOCUMENTO_DIGITALIZADO = "id_documento_digitalizado";

	public static final String COLUNA_ALTERACAO_SENHA = "id_alteracao_senha";
	
	@OneToOne
	@JoinColumn(name = COLUNA_DOCUMENTO_DIGITALIZADO, nullable = false, unique = false)
	private DocumentoDigitalizado documentoDigitalizado;

	@OneToOne
	@JoinColumn(name = COLUNA_ALTERACAO_SENHA, nullable = false, unique = false)
	private AlteracaoSenha alteracaoSenha;

	public DocumentoDigitalizadoAlteracaoSenha() {
		super();
	}

	public DocumentoDigitalizadoAlteracaoSenha(
			DocumentoDigitalizado documentoDigitalizado, AlteracaoSenha alteracaoSenha) {
		super();
		this.documentoDigitalizado = documentoDigitalizado;
		this.alteracaoSenha = alteracaoSenha;
	}

	public DocumentoDigitalizado getDocumentoDigitalizado() {
		return documentoDigitalizado;
	}

	public void setDocumentoDigitalizado(
			DocumentoDigitalizado documentoDigitalizado) {
		this.documentoDigitalizado = documentoDigitalizado;
	}

}
