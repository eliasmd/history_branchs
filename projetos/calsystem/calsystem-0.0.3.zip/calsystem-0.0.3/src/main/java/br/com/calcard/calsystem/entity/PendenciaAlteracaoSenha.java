package br.com.calcard.calsystem.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.calcard.calframework.entity.CalsystemEntity;

@Entity
@Table(name = "tbl_pendencia_alteracao_senha")
public class PendenciaAlteracaoSenha extends CalsystemEntity {

	private static final long serialVersionUID = -5319334898669250933L;

	private static final String COLUNA_CONTA = "id_conta";

	private static final String COLUNA_CPF_PORTADOR = "cpf_portador";

	private static final String COLUNA_SENHA = "senha";

	private static final String COLUNA_ESTABELECIMENTO = "id_estabelecimento";

	private static final String COLUNA_DATA_INICIO_ANALISE = "data_inicio_analise";

	private static final String COLUNA_DATA_FIM_ANALISE = "data_fim_analise";

	private static final String COLUNA_PARECER = "parecer";

	private static final String COLUNA_ANALISTA = "id_analista";

	private static final String COLUNA_SOLICITANTE = "id_solicitante";

	private static final String COLUNA_STATUS = "id_status";

	private static final String COLUNA_CREDIT_REQUEST = "id_credit_request";

	@Column(name = COLUNA_CONTA, nullable = false, unique = false)
	private Integer idConta;

	@Column(name = COLUNA_CPF_PORTADOR, length = 11, nullable = false, unique = false)
	private String cpfPortador;

	@Column(name = COLUNA_SENHA, length = 4, nullable = false, unique = false)
	private String senha;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = COLUNA_STATUS, nullable = false, unique = false)
	private StatusFilaPendencias status;

	@Column(name = COLUNA_CREDIT_REQUEST, nullable = false, unique = false)
	private Integer idCreditRequest;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = COLUNA_ESTABELECIMENTO, nullable = false, unique = false)
	private Estabelecimento estabelecimento;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = COLUNA_DATA_INICIO_ANALISE, unique = false, nullable = true)
	private Date dataInicioAnalise;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = COLUNA_DATA_FIM_ANALISE, unique = false, nullable = true)
	private Date dataFimAnalise;

	@Column(name = COLUNA_PARECER, unique = false, nullable = true)
	private String parecer;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = COLUNA_ANALISTA, nullable = true, unique = false)
	private Usuario analista;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = COLUNA_SOLICITANTE, nullable = false, unique = false)
	private Usuario solicitante;

	public PendenciaAlteracaoSenha() {

	}

	public PendenciaAlteracaoSenha(Integer idConta, String cpfPortador,
			String senha, StatusFilaPendencias status, Integer idCreditRequest,
			Estabelecimento estabelecimento, Date dataInicioAnalise,
			Date dataFimAnalise, String parecer, Usuario analista,
			Usuario solicitante) {
		super();
		this.idConta = idConta;
		this.cpfPortador = cpfPortador;
		this.senha = senha;
		this.status = status;
		this.idCreditRequest = idCreditRequest;
		this.estabelecimento = estabelecimento;
		this.dataInicioAnalise = dataInicioAnalise;
		this.dataFimAnalise = dataFimAnalise;
		this.parecer = parecer;
		this.analista = analista;
		this.solicitante = solicitante;
	}

	public Integer getIdConta() {
		return idConta;
	}

	public void setIdConta(Integer idConta) {
		this.idConta = idConta;
	}

	public String getCpfPortador() {
		return cpfPortador;
	}

	public void setCpfPortador(String cpfPortador) {
		this.cpfPortador = cpfPortador;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public Estabelecimento getEstabelecimento() {
		return estabelecimento;
	}

	public void setEstabelecimento(Estabelecimento estabelecimento) {
		this.estabelecimento = estabelecimento;
	}

	public Date getDataInicioAnalise() {
		return dataInicioAnalise;
	}

	public void setDataInicioAnalise(Date dataInicioAnalise) {
		this.dataInicioAnalise = dataInicioAnalise;
	}

	public Date getDataFimAnalise() {
		return dataFimAnalise;
	}

	public void setDataFimAnalise(Date dataFimAnalise) {
		this.dataFimAnalise = dataFimAnalise;
	}

	public String getParecer() {
		return parecer;
	}

	public void setParecer(String parecer) {
		this.parecer = parecer;
	}

	public Usuario getAnalista() {
		return analista;
	}

	public void setAnalista(Usuario analista) {
		this.analista = analista;
	}

	public Usuario getSolicitante() {
		return solicitante;
	}

	public void setSolicitante(Usuario solicitante) {
		this.solicitante = solicitante;
	}

	public StatusFilaPendencias getStatus() {
		return status;
	}

	public void setStatus(StatusFilaPendencias status) {
		this.status = status;
	}

	public Integer getIdCreditRequest() {
		return idCreditRequest;
	}

	public void setIdCreditRequest(Integer idCreditRequest) {
		this.idCreditRequest = idCreditRequest;
	}

}
