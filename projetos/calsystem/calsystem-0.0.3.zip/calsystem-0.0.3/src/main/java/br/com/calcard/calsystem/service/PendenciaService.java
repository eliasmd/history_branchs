package br.com.calcard.calsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calsystem.entity.PendenciaAlteracaoSenha;
import br.com.calcard.calsystem.interfaces.IPendenciaService;

@Service
public class PendenciaService implements IPendenciaService {

	private ICalsystemDAO daoService;

	@Autowired
	public PendenciaService(ICalsystemDAO daoService) {
		this.daoService = daoService;
	}

	@Override
	public PendenciaAlteracaoSenha doCadastrarPendenciaAlteracaoSenha(
			PendenciaAlteracaoSenha pendencia) {

		return null;

	}

}
