package br.com.calcard.calsystem.entity.proposta;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;

import br.com.calcard.calframework.entity.CalsystemEntity;

@Entity
@Table(name = "tbl_foto")
public class Foto extends CalsystemEntity {

	private static final long serialVersionUID = -2456061153434416693L;

	private static final String COLUNA_FOTO_BASE_64 = "foto_base_64";

	private static final String COLUNA_ID_MOTOR_BIOMETRIA = "id_motor_biometria";

	@Lob
	@Column(name = COLUNA_FOTO_BASE_64, unique = false, nullable = false)
	private String fotoBase64;

	@Column(name = COLUNA_ID_MOTOR_BIOMETRIA, unique = false, nullable = true, length = 6)
	private Integer idMotorBiometria;

	public Foto() {
	}

	public Foto(String fotoBase64, Integer idMotorBiometria) {
		this.fotoBase64 = fotoBase64;
		this.idMotorBiometria = idMotorBiometria;
	}

	public String getFotoBase64() {
		return fotoBase64;
	}

	public void setFotoBase64(String fotoBase64) {
		this.fotoBase64 = fotoBase64;
	}

	public Integer getIdMotorBiometria() {
		return idMotorBiometria;
	}

	public void setIdMotorBiometria(Integer idMotorBiometria) {
		this.idMotorBiometria = idMotorBiometria;
	}

}
