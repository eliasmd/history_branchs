package br.com.calcard.calsystem.exception.proposta;

import br.com.calcard.calframework.exception.CalsystemException;

public class DadosCartaoCalcardException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4417227210819507060L;

	public DadosCartaoCalcardException(String message) {
		super(message);
	}

}
