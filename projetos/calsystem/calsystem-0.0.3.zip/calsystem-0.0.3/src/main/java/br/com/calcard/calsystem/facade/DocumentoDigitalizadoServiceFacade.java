package br.com.calcard.calsystem.facade;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.dto.TipoDocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;

@Component
public class DocumentoDigitalizadoServiceFacade {

	private IDigitalizacao documentoDigitalizadoService;

	@Autowired
	public DocumentoDigitalizadoServiceFacade(
			IDigitalizacao documentoDigitalizadoService) {

		this.documentoDigitalizadoService = documentoDigitalizadoService;

	}

	public List<DocumentoDigitalizadoDTO> anexarDocumento(String nomeArquivo) {

		// return
		// this.documentoDigitalizadoService.doGerarMiniaturas(nomeArquivo);

		return null;

	}

	public List<TipoDocumentoDigitalizadoDTO> doListarTiposDocumentos() {

		// List<TipoDocumentoDigitalizadoDTO> tiposDocumentosDigitalizadosDTO =
		// new ArrayList<TipoDocumentoDigitalizadoDTO>();
		//
		// for (TipoDocumentoDigitalizado tipoDocumentoDigitalizado :
		// this.documentoDigitalizadoService
		// .doListarTiposDocumentos(this.tipoDocumentoDigitalizadoDAO))
		// tiposDocumentosDigitalizadosDTO.add(TipoDocumentoDigitalizadoDTO
		// .toDTO(tipoDocumentoDigitalizado));
		//
		// return tiposDocumentosDigitalizadosDTO;

		return null;

	}
}