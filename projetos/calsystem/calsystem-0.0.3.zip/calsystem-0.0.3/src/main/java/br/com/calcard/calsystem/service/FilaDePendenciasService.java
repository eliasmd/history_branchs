package br.com.calcard.calsystem.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.PersistenceException;

import org.apache.commons.lang.time.DurationFormatUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.ws.CalsystemServiceWS;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoAvaliacaoFotoDTO;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calsystem.dto.AnaliseBiometriaDTO;
import br.com.calcard.calsystem.dto.AnalisePendenciaDTO;
import br.com.calcard.calsystem.dto.BiometriaDTO;
import br.com.calcard.calsystem.dto.PendenciaAlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.StatusFilaPendenciasDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.AnalisePendencia;
import br.com.calcard.calsystem.entity.PendenciaAlteracaoSenha;
import br.com.calcard.calsystem.entity.StatusFilaPendencias;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.interfaces.IFilaPendencia;
import br.com.calcard.calsystem.util.Parametro;

@Service
public class FilaDePendenciasService extends CalsystemServiceWS implements
		IFilaPendencia {

	private ICalsystemDAO daoService;

	private IMotorBiometria motorBiometriaService;

	@Autowired
	public FilaDePendenciasService(ICalsystemDAO daoService,
			IMotorBiometria motorBiometriaService) {
		this.daoService = daoService;
		this.motorBiometriaService = motorBiometriaService;
	}

	@Override
	public List<StatusFilaPendencias> doListarStatusFilaDePendencia()
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		List<StatusFilaPendencias> listaStatusPendencia = this.daoService
				.doList(StatusFilaPendencias.class);

		return listaStatusPendencia;

	}

	@Transactional
	@Override
	public List<AlteracaoSenha> doListarFilaDePendencia(String status,
			String cpf) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		if (status == null)
			throw new CalsystemInvalidArgumentException(
					"Campo Status deve ser informado!");

		Criteria criteria = this.daoService.doGetCriteria(AlteracaoSenha.class);

		if (status != null) {
			criteria.add(Restrictions.eq(AlteracaoSenha.COLUNA_STATUS, status));
		}

		if (cpf != null) {
			criteria.add(Restrictions.eq(AlteracaoSenha.COLUNA_CPF, cpf));
		}

		List<AlteracaoSenha> listaAlteracaoSenha = this.daoService.doList(
				criteria, true, "Nenhuma Pend�ncia Encontrada!");

		return listaAlteracaoSenha;

	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public AnalisePendencia doAnalisarPendencia(
			AnalisePendenciaDTO analisePendenciaDTO) throws Exception {

		if (analisePendenciaDTO == null)
			throw new CalsystemInvalidArgumentException(
					"Par�metros da Pend�ncia n�o foram informados!");

		Usuario analista = this.daoService.doRead(analisePendenciaDTO
				.getAnalista().getId(), Usuario.class, true, new StringBuilder(
				"N�o foi encontrado nenhum Analista para o ID informado! ID: ")
				.append(analisePendenciaDTO.getAnalista().getId()).toString(),
				"ID do Analista n�o informado!");

		AlteracaoSenha alteracaoSenha = this.daoService
				.doRead(analisePendenciaDTO.getIdAlteracaoSenha(),
						AlteracaoSenha.class,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhuma Altera��o de Senha para o ID informado! ID: ")
								.append(analisePendenciaDTO
										.getIdAlteracaoSenha()).toString(),
						"ID da Altera��o de Senha n�o informado!");

		AnalisePendencia analisePendencia = new AnalisePendencia();
		analisePendencia.setAnalista(analista);
		analisePendencia.setAlteracaoSenha(alteracaoSenha);
		analisePendencia.setStatus("EM ANALISE");
		analisePendencia.setDataInicio(new Date());
		alteracaoSenha.setStatus("EM ANALISE");

		try {
			this.daoService.doCreate(analisePendencia);
			this.daoService.doUpdate(alteracaoSenha);
		} catch (PersistenceException e) {
			throw new ServiceException("Proposta j� em an�lise pelo operador "
					+ analista.getNome());
			// throw new Exception("Proposta j� em an�lise pelo operador " +
			// analista.getNome());
		}

		return analisePendencia;

	}

	public List<AnalisePendencia> doCarregarAnaliseIniciada(
			List<AlteracaoSenha> listaAlteracaoSenha)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		List<AnalisePendencia> listaAnalisePendencia = new ArrayList<AnalisePendencia>();

		for (int i = 0; i < listaAlteracaoSenha.size(); i++) {

			AnalisePendencia analisePendencia = this.daoService
					.doGetSingleResult(
							AnalisePendencia.NQ_SELECT_PENDENCIA_ALTERACAO_SENHA,
							new Parametro().doAddParametro("alteracaoSenha",
									listaAlteracaoSenha.get(i)).getParametros(),
							AnalisePendencia.class);

			listaAnalisePendencia.add(analisePendencia);

		}

		return listaAnalisePendencia;

	}

	public AlteracaoSenha doListarDocumentosAvaliacao(Integer idAlteracaoSenha)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		AlteracaoSenha alteracaoSenha = this.daoService
				.doRead(idAlteracaoSenha,
						AlteracaoSenha.class,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhuma Altera��o de Senha para o ID informado! ID: ")
								.append(idAlteracaoSenha).toString(),
						"ID da Altera��o de Senha n�o informado!");

		return alteracaoSenha;

	}

	@Transactional
	public ResponseEntity<Object> doListarFotosAvaliacaoAlteracaoDeSenha(
			Integer idAlteracaoSenha) {

		try {

			AlteracaoSenha alteracaoSenha = doListarDocumentosAvaliacao(idAlteracaoSenha);

			AnaliseBiometriaDTO analiseBiometriaDTO = doListarFotosAvaliacao(alteracaoSenha
					.getFoto().getIdMotorBiometria());

			return super
					.doRetornarSucessoWS(new Parametro().doAddParametro(
							"analiseBiometriaDTO", analiseBiometriaDTO)
							.getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}
	}

	private AnaliseBiometriaDTO doListarFotosAvaliacao(Integer idCreditRequest)
			throws CalsystemInvalidArgumentException, ServiceException,
			IntegracaoException, IntegracaoMotorBiometriaException {

		IntegracaoAvaliacaoFotoDTO integracaoPooling = this.motorBiometriaService
				.doConsultarAnaliseComFoto(idCreditRequest);

		return doComporAnaliseBiometriaDTO(integracaoPooling);

	}

	private AnaliseBiometriaDTO doComporAnaliseBiometriaDTO(
			IntegracaoAvaliacaoFotoDTO integracaoAvaliacaoFotoDTO) {

		BiometriaDTO biometriaLoja = null;
		if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO()
				.getCreditrequest().getCol1() != null) {

			biometriaLoja = new BiometriaDTO(integracaoAvaliacaoFotoDTO
					.getResponsePoolingDTO().getCreditrequest().getCol1()
					.getCreditrequest().getPhoto(), integracaoAvaliacaoFotoDTO
					.getResponsePoolingDTO().getCreditrequest().getCol1()
					.getCreditrequest().getIdentifierCode());
		}

		BiometriaDTO biometriaCadastro = null;
		if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO()
				.getCreditrequest().getCol2() != null) {

			biometriaCadastro = new BiometriaDTO(integracaoAvaliacaoFotoDTO
					.getResponsePoolingDTO().getCreditrequest().getCol2()
					.getCustomer().getPhoto(), integracaoAvaliacaoFotoDTO
					.getResponsePoolingDTO().getCreditrequest().getCol2()
					.getCustomer().getIdentifierCode());
		}

		List<BiometriaDTO> listaBiometriaSimilaresLoja = new ArrayList<BiometriaDTO>();
		List<BiometriaDTO> listaBiometriaSimilaresCadastro = new ArrayList<BiometriaDTO>();
		if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO()
				.getCreditrequest().getCol3() != null) {

			if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO()
					.getCreditrequest().getCol3().getCreditrequest_similars() != null) {
				for (int i = 0; i < integracaoAvaliacaoFotoDTO
						.getResponsePoolingDTO().getCreditrequest().getCol3()
						.getCreditrequest_similars().size(); i++) {

					listaBiometriaSimilaresLoja.add(new BiometriaDTO(
							integracaoAvaliacaoFotoDTO.getResponsePoolingDTO()
									.getCreditrequest().getCol3()
									.getCreditrequest_similars().get(i)
									.getPhoto(), integracaoAvaliacaoFotoDTO
									.getResponsePoolingDTO().getCreditrequest()
									.getCol3().getCreditrequest_similars()
									.get(i).getIdentifierCode()));
				}
			}

			if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO()
					.getCreditrequest().getCol3().getCustomer_similars() != null) {
				for (int i = 0; i < integracaoAvaliacaoFotoDTO
						.getResponsePoolingDTO().getCreditrequest().getCol3()
						.getCustomer_similars().size(); i++) {
					listaBiometriaSimilaresCadastro.add(new BiometriaDTO(
							integracaoAvaliacaoFotoDTO.getResponsePoolingDTO()
									.getCreditrequest().getCol3()
									.getCustomer_similars().get(i).getPhoto(),
							integracaoAvaliacaoFotoDTO.getResponsePoolingDTO()
									.getCreditrequest().getCol3()
									.getCustomer_similars().get(i)
									.getIdentifierCode()));

				}
			}

		}

		return new AnaliseBiometriaDTO(integracaoAvaliacaoFotoDTO
				.getResponsePoolingDTO().getCreditrequest().getId(),
				biometriaLoja, biometriaCadastro, listaBiometriaSimilaresLoja,
				listaBiometriaSimilaresCadastro);
	}

	@Transactional
	public AlteracaoSenha doNegarPendencia(Integer idAlteracaoSenha,
			String parecer) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		if (idAlteracaoSenha == null)
			throw new CalsystemInvalidArgumentException(
					"Par�metro do c�digo da Altera��o de Senha n�o informado!");

		AlteracaoSenha alteracaoSenha = this.daoService
				.doRead(idAlteracaoSenha,
						AlteracaoSenha.class,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhuma solicita��o de alteracao de senha com o ID informado! ID: ")
								.append(idAlteracaoSenha).toString(),
						"ID da alteracao de senha n�o encontrado!");

		alteracaoSenha.setStatus("NEGADO");
		this.daoService.doUpdate(alteracaoSenha);

		AnalisePendencia analisePendencia = this.daoService.doGetSingleResult(
				AnalisePendencia.NQ_SELECT_PENDENCIA_ALTERACAO_SENHA,
				new Parametro()
						.doAddParametro("alteracaoSenha", alteracaoSenha)
						.getParametros(), AnalisePendencia.class);

		analisePendencia.setStatus("NEGADO");
		analisePendencia.setDataFim(new Date());
		analisePendencia.setParecer(parecer);
		this.daoService.doUpdate(analisePendencia);

		return alteracaoSenha;

	}

	@Transactional
	public ResponseEntity<Object> doAprovarPendencia(Integer idAlteracaoSenha) {

		try {

			if (idAlteracaoSenha == null)
				throw new CalsystemInvalidArgumentException(
						"Par�metro do c�digo da Altera��o de Senha n�o informado!");

			AlteracaoSenha alteracaoSenha = this.daoService
					.doRead(idAlteracaoSenha,
							AlteracaoSenha.class,
							true,
							new StringBuilder(
									"N�o foi encontrado nenhuma solicita��o de alteracao de senha com o ID informado! ID: ")
									.append(idAlteracaoSenha).toString(),
							"ID da alteracao de senha n�o encontrado!");

			alteracaoSenha.setStatus("APROVADO");
			this.daoService.doUpdate(alteracaoSenha);

			AnalisePendencia analisePendencia = this.daoService
					.doGetSingleResult(
							AnalisePendencia.NQ_SELECT_PENDENCIA_ALTERACAO_SENHA,
							new Parametro().doAddParametro("alteracaoSenha",
									alteracaoSenha).getParametros(),
							AnalisePendencia.class);

			analisePendencia.setStatus("APROVADO");
			analisePendencia.setDataFim(new Date());
			this.daoService.doUpdate(analisePendencia);

			return super.doRetornarSucessoWS(null);

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}
	}

	@Override
	@Transactional
	public List<PendenciaAlteracaoSenha> doListarPendenciasAlteracaoSenha()
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		return this.daoService.doList(PendenciaAlteracaoSenha.class, false,
				null);

	}

	@Override
	@Transactional
	public PendenciaAlteracaoSenha doConsultarPendenciaAlteracaoSenha(
			Integer idPendencia) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		return this.daoService
				.doRead(idPendencia,
						PendenciaAlteracaoSenha.class,
						true,
						new StringBuilder(
								"Nenhuma pend�ncia encontrada para o id informado! ID: ")
								.append(idPendencia).toString(),
						"Id da pendencia n�o informada!");

	}

	@Override
	public PendenciaAlteracaoSenhaDTO doComporPendenciaAlteracaoSenhaDTO(PendenciaAlteracaoSenha pendenciaAlteracaoSenha) 
			throws CalsystemInvalidArgumentException {
		
		return new PendenciaAlteracaoSenhaDTO(pendenciaAlteracaoSenha.getId(), 
											  pendenciaAlteracaoSenha.getDataRegistro(),
											  pendenciaAlteracaoSenha.getDataInicioAnalise(), 
											  pendenciaAlteracaoSenha.getDataFimAnalise(),
											  pendenciaAlteracaoSenha.getAnalista() == null ? null : pendenciaAlteracaoSenha.getAnalista().getId(), 
											  pendenciaAlteracaoSenha.getSolicitante().getId(), 
											  pendenciaAlteracaoSenha.getIdConta(),
											  pendenciaAlteracaoSenha.getCpfPortador(), 
											  pendenciaAlteracaoSenha.getParecer(), 
											  pendenciaAlteracaoSenha.getEstabelecimento().getId(), 
											  new StatusFilaPendenciasDTO(pendenciaAlteracaoSenha.getStatus().getId(), 
													  					  pendenciaAlteracaoSenha.getStatus().getStatus()),
											  this.doCalcularTMA(pendenciaAlteracaoSenha.getDataInicioAnalise(), 
													             pendenciaAlteracaoSenha.getDataFimAnalise()),
											  this.doCalcularTME(pendenciaAlteracaoSenha.getDataRegistro(), 
													  			 pendenciaAlteracaoSenha.getDataInicioAnalise()));
		
		
		
	}
	
	@Override
	public String doCalcularTME(Date dataRegistro, Date dataInicioAnalise) throws CalsystemInvalidArgumentException {

		Date dataFinal = null;

		if (dataRegistro == null)
			throw new CalsystemInvalidArgumentException("Data de registro n�o foi informada!");

		if (dataInicioAnalise == null)
			dataFinal = new Date();
		else
			dataFinal = dataRegistro;

		long duracao = (dataFinal.getTime() - dataRegistro.getTime());

		return DurationFormatUtils.formatDuration(duracao, "H:mm:ss", true);

	}
	
	@Override
	public String doCalcularTMA(Date dataInicioAnalise, Date dataFimAnalise){
		
		Date dataFinal = null;
		
		if (dataInicioAnalise == null)
			return "0:00:00";
		
		if (dataFimAnalise == null)
			dataFinal = new Date();
		else
			dataFinal = dataFimAnalise;	
			
		long duracao = (dataFinal.getTime() - dataInicioAnalise.getTime());
		
		return DurationFormatUtils.formatDuration(duracao, "H:mm:ss", true);
		
	}

}
