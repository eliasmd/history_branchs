package br.com.calcard.calsystem.exception.usuario;

import br.com.calcard.calframework.exception.CalsystemException;

public class UsuarioInvalidoException extends CalsystemException {

	private static final long serialVersionUID = -4814849701069456125L;

	public UsuarioInvalidoException(String mensagem) {
		super(mensagem);
	}

	public UsuarioInvalidoException(String mensagem, Throwable e) {
		super(mensagem, e);
	}

}
