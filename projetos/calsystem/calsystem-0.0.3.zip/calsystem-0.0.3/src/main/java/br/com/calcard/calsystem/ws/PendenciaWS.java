package br.com.calcard.calsystem.ws;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calsystem.entity.PendenciaAlteracaoSenha;
import br.com.calcard.calsystem.service.PendenciaService;
import br.com.calcard.calsystem.util.Parametro;

@RestController
@RequestMapping("/ws/pendencias")
@Scope(value = "request")
public class PendenciaWS extends CalsystemWS {

	private PendenciaService pendenciaService;

	@Autowired
	public PendenciaWS(PendenciaService pendenciaService) {
		this.pendenciaService = pendenciaService;
	}

	@RequestMapping(value = "/alteracaoSenha", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doCadastrarPendenciaAlteracaoSenha(
			@RequestBody PendenciaAlteracaoSenha pendencia,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(tSessao,
				new Parametro().doAddParametro("pendencia", pendencia)
						.getParametros());

		pendencia = pendenciaService
				.doCadastrarPendenciaAlteracaoSenha(pendencia);

		return super.doRetornarSucessoWS(new Parametro().doAddParametro(
				"pendencia", pendencia).getParametros());

	}

}
