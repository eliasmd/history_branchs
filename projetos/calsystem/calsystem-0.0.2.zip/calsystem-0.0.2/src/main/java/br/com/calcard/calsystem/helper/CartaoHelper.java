package br.com.calcard.calsystem.helper;

import java.util.ArrayList;
import java.util.List;

import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calsystem.dto.CartaoDTO;
import br.com.calcard.calsystem.dto.ContaDTO;

public class CartaoHelper {

	public List<CartaoDTO> doListarCartoes(String cpf, String numeroCartao)
			throws CalsystemNoDataFoundException {

		List<CartaoDTO> cartoes = new ArrayList<CartaoDTO>();

		// CPF � titular
		if (cpf != null && cpf.equals("25514775577")) {

			ContaDTO contaDTO = new ContaDTO(1, "Jo�o da Silva", "25514775577",
					"Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000004",
					"Jo�o da Silva", "25514775577", true, "Normal", contaDTO);

			cartoes.add(cartaoDTO);

		}

		/*------------------------ registros de teste para os os gerentes------------------------- */

		else if (cpf != null && cpf.equals("57324760082")) {

			ContaDTO contaDTO = new ContaDTO(1000970, "Mauricio Rufino Silva",
					"57324760082", "Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000004",
					"Mauricio Rufino Silva", "57324760082", true, "Normal",
					contaDTO);

			cartoes.add(cartaoDTO);

		}

		else if (cpf != null && cpf.equals("82691819000")) {

			ContaDTO contaDTO = new ContaDTO(1330246,
					"Fernando Marcolin Peringer", "82691819000", "Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000004",
					"Fernando Marcolin Peringer", "82691819000", true,
					"Normal", contaDTO);

			cartoes.add(cartaoDTO);

		}

		else if (cpf != null && cpf.equals("55968228091")) {

			ContaDTO contaDTO = new ContaDTO(1522360, "Ricardo Leote Machado",
					"55968228091", "Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000004",
					"Ricardo Leote Machado", "55968228091", true, "Normal",
					contaDTO);

			cartoes.add(cartaoDTO);

		}

		else if (cpf != null && cpf.equals("02755806958")) {

			ContaDTO contaDTO = new ContaDTO(887773, "Clovis Fernando Kuhn",
					"02755806958", "Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000004",
					"Clovis Fernando Kuhn", "02755806958", true, "Normal",
					contaDTO);

			cartoes.add(cartaoDTO);

		}

		else if (cpf != null && cpf.equals("01199477737")) {

			ContaDTO contaDTO = new ContaDTO(975955,
					"Jose Carlos Brum Lopes Junior", "01199477737", "Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000004",
					"Jose Carlos Brum Lopes Junior", "01199477737", true,
					"Normal", contaDTO);

			cartoes.add(cartaoDTO);

		}

		else if (cpf != null && cpf.equals("01496209001")) {

			ContaDTO contaDTO = new ContaDTO(1330277, "Gustavo Porto da Silva",
					"01496209001", "Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000004",
					"Gustavo Porto da Silva", "01496209001", true, "Normal",
					contaDTO);

			cartoes.add(cartaoDTO);

		}

		else if (cpf != null && cpf.equals("10236851837")) {

			ContaDTO contaDTO = new ContaDTO(1302142, "Marcelo Rossani Zorzi",
					"10236851837", "Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000004",
					"Marcelo Rossani Zorzi", "10236851837", true, "Normal",
					contaDTO);

			cartoes.add(cartaoDTO);

		}

		/*-------------------------- registros de teste para os os gerentes------------------------ */

		// CPF � dependente
		else if (cpf != null && cpf.equals("72152830628")) {

			ContaDTO contaDTO = new ContaDTO(2, "Flavio Fernandes",
					"01496209001", "Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000005",
					"Maria Fernandes da Rosa", "72152830628", false, "Normal",
					contaDTO);

			cartoes.add(cartaoDTO);

		}

		// CPF � titular de uma conta e dependente em outra
		else if (cpf != null && cpf.equals("18899637989")) {

			ContaDTO contaDTO = new ContaDTO(3, "Mauricio Silva",
					"18899637989", "Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000006",
					"Mauricio Silva", "18899637989", true, "Normal", contaDTO);

			cartoes.add(cartaoDTO);

			contaDTO = new ContaDTO(4, "Elias Decezero", "78786756544",
					"Normal");

			cartaoDTO = new CartaoDTO("6364500000000005", "Mauricio Silva",
					"18899637989", false, "Normal", contaDTO);

			cartoes.add(cartaoDTO);

		}

		// Cart�o Normal
		else if (numeroCartao != null
				&& numeroCartao.equals("6364500000000000")) {

			ContaDTO contaDTO = new ContaDTO(5, "Marcelo Zorzi", "65778265449",
					"Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000000",
					"Marcelo Zorzi", "65778265449", true, "Normal", contaDTO);

			cartoes.add(cartaoDTO);

		}

		// Cart�o Bloqueado
		else if (numeroCartao != null
				&& numeroCartao.equals("6364500000000001")) {

			ContaDTO contaDTO = new ContaDTO(6, "Priscila de S�",
					"56667865412", "Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000001",
					"Priscila de S�", "56667865412", true, "Bloqueado",
					contaDTO);

			cartoes.add(cartaoDTO);

		}

		// Cart�o Cancelado
		else if (numeroCartao != null
				&& numeroCartao.equals("6364500000000002")) {

			ContaDTO contaDTO = new ContaDTO(7, "Gustavo Porto", "59063387911",
					"Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000002",
					"Gustavo Porto", "59063387911", true, "Cancelado", contaDTO);

			cartoes.add(cartaoDTO);

		}

		// Cart�o Bloqueado Senha
		else if (numeroCartao != null
				&& numeroCartao.equals("6364500000000003")) {

			ContaDTO contaDTO = new ContaDTO(8, "Willian Dufau", "44419084511",
					"Normal");

			CartaoDTO cartaoDTO = new CartaoDTO("6364500000000003",
					"Willian Dufau", "44419084511", true, "Bloqueado Senha",
					contaDTO);

			cartoes.add(cartaoDTO);

		}

		else
			throw new CalsystemNoDataFoundException("Nenhum cart�o encontrado!");

		return cartoes;

	}

}
