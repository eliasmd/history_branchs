package br.com.calcard.calsystem.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calframework.ws.CalsystemServiceWS;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoEnvioFotoDTO;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calsystem.dto.AlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.CartaoDTO;
import br.com.calcard.calsystem.dto.ContaDTO;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.DocumentoDigitalizadoAlteracaoSenha;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;
import br.com.calcard.calsystem.entity.proposta.Foto;
import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;
import br.com.calcard.calsystem.enums.Enum.StatusPadraoEnum;
import br.com.calcard.calsystem.exception.proposta.PropostaDocumentosDigitalizadosException;
import br.com.calcard.calsystem.helper.CartaoHelper;
import br.com.calcard.calsystem.helper.CartaoServiceHelper;
import br.com.calcard.calsystem.interfaces.ICartao;


@Component
@Service
public class CartaoService  extends CalsystemServiceWS implements ICartao {

	private ICalsystemDAO daoService;
	
	private IMotorBiometria motorBiometriaService;


	@Autowired
	public CartaoService(ICalsystemDAO daoService,
						 IMotorBiometria motorBiometriaService) {
		this.daoService = daoService;
		this.motorBiometriaService = motorBiometriaService;
	}

	@Override
	public List<CartaoDTO> doListarCartoes(String cpf, String numeroCartao)
			throws CalsystemInvalidArgumentException {

		if (cpf == null && numeroCartao == null)
			throw new CalsystemInvalidArgumentException(
					"CPF ou N�mero do Cart�o precis�o ser informados!");

		List<CartaoDTO> cartoes = new ArrayList<CartaoDTO>();
		ContaDTO conta = null;
		CartaoDTO cartao = null;

		if (cpf == null || numeroCartao != null) {

			cpf = "13644256373";

			conta = new ContaDTO(1229, "Maria da Silva",
					CalsystemUtil.doMascararCPF(cpf), "NORMAL");

			cartao = new CartaoDTO(numeroCartao, "Maria da Silva", cpf, true,
					"NORMAL", conta);

			cartoes.add(cartao);
		}

		if (numeroCartao == null) {

			for (int i = 0; i < 2; i++) {

				// Titular da conta
				if (i == 0) {

					conta = new ContaDTO(8988, "Maria da Silva",
							CalsystemUtil.doMascararCPF(cpf), "NORMAL");

					cartao = new CartaoDTO("6364********0808",
							"Maria da Silva", CalsystemUtil.doMascararCPF(cpf),
							true, "NORMAL", conta);

					cartoes.add(cartao);

					// Depend�nte da conta
				} else if (i == 1) {

					conta = new ContaDTO(7655, "Jo�o Paulo",
							CalsystemUtil.doMascararCPF(cpf), "NORMAL");

					cartao = new CartaoDTO("6364********5632",
							"Maria da Silva", "897******76", false, "NORMAL",
							conta);

					cartoes.add(cartao);

				}

			}

		}

		return cartoes;

	}

	@Override
	public List<CartaoDTO> doListarCartoesCadastroSenhaEDesbloqueio(String cpf,
			String numeroCartao) throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		if (cpf == null && numeroCartao == null)
			throw new CalsystemInvalidArgumentException(
					"CPF ou N�mero do Cart�o n�o foram informados!");

		return new CartaoHelper().doListarCartoes(cpf, numeroCartao);

	}
	
	private AlteracaoSenha doRegistrarAlteracaoSenha(AlteracaoSenhaDTO alteracaoSenhaDTO) throws CalsystemNoDataFoundException, CalsystemInvalidArgumentException, PropostaDocumentosDigitalizadosException{
		
		CartaoServiceHelper cartaoServiceHelper = new CartaoServiceHelper();
		
		AlteracaoSenha alteracaoSenha = cartaoServiceHelper
				.doCarregarDadosAlteracaoDeSenha(alteracaoSenhaDTO);

		alteracaoSenha
				.setDocumentosDigitalizados(doCarregarDocumentosDigitalizados(
						alteracaoSenhaDTO.getDocumentosDigitalizados(),
						alteracaoSenha));

		Foto foto = this.daoService
				.doRead(alteracaoSenhaDTO.getFotoNSU(),
						Foto.class,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhuma biometria facial com o NSU informado! NSU: ")
								.append(alteracaoSenhaDTO.getFotoNSU())
								.toString(), "NSU da foto n�o foi informado!");

		alteracaoSenha.setFoto(foto);

		Estabelecimento estab = this.daoService
				.doRead(alteracaoSenhaDTO.getIdEstabelecimento(),
						Estabelecimento.class,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhum Estabelecimento com o ID informado: ")
								.append(alteracaoSenhaDTO
										.getIdEstabelecimento()).toString(),
						"ID do Estabelecimento n�o foi informado!");

		alteracaoSenha.setEstabelecimento(estab);

		// salva a solicitacao de senha
		this.daoService.doCreate(alteracaoSenha);

		// salva a lista de documentos digitalizados
		for (DocumentoDigitalizado documentoDigitalizadoSenha : alteracaoSenha
				.getDocumentosDigitalizados()) {
			this.daoService.doUpdate(documentoDigitalizadoSenha);
			//this.daoService.doCreate(documentoDigitalizadoSenha);
		}
		
		return alteracaoSenha;
	}
	

	@Override
	@Transactional
	public ResponseEntity<Object>  doAlterarSenhaPortador(AlteracaoSenhaDTO alteracaoSenhaDTO){
		
			try{
				
				AlteracaoSenha alteracaoSenha = this.doRegistrarAlteracaoSenha(alteracaoSenhaDTO);
				
				IntegracaoEnvioFotoDTO integracao = 
						this.motorBiometriaService.doEnviarCreditRequest(alteracaoSenha.getCpf(),
																		 "81",
																		// proposta.getPropostaP1().getEstabelecimento().getId().toString(),
																		 alteracaoSenha.getNome(), 
																		 new Date("01/01/1900"),
																		 alteracaoSenha.getFoto().getFotoBase64());
				
				alteracaoSenha.getFoto().setIdMotorBiometria(integracao.getIdMotorBiometria());
				this.daoService.doUpdate(alteracaoSenha.getFoto());
				
				return super.doRetornarSucessoWS(null);
		
			} catch (CalsystemException e) {
				return super.doRetornarErroWS(e);
			} catch (Exception e) {
				return super.doRetornarErroWS(e);
			}
			
	}

	public List<DocumentoDigitalizado> doCarregarDocumentosDigitalizados(
			List<DocumentoDigitalizadoDTO> listaDocumentoDigitalizadoDTO,
			AlteracaoSenha alteracaoSenha)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

	//	List<DocumentoDigitalizadoAlteracaoSenha> documentosDigitalizadosSenha = new ArrayList<DocumentoDigitalizadoAlteracaoSenha>();
		List<DocumentoDigitalizado> documentosDigitalizadosSenha = new ArrayList<DocumentoDigitalizado>();

		for (DocumentoDigitalizadoDTO documentoDigitalizadoDTO : listaDocumentoDigitalizadoDTO) {

			TipoDocumentoDigitalizado tipoDocumentoDigitalizado = this.daoService
					.doRead(documentoDigitalizadoDTO.getIdTipoDocumento(),
							TipoDocumentoDigitalizado.class,
							true,
							new StringBuilder(
									"N�o foi encontrado nenhum tipo de documento digitalizado com o ID informado! ID: ")
									.append(documentoDigitalizadoDTO
											.getIdTipoDocumento()).toString(),
							"ID do tipo de documento digitalizado n�o foi informado!");

			DocumentoDigitalizado documentoDigitalizado = this.daoService
					.doRead(documentoDigitalizadoDTO.getId(),
							DocumentoDigitalizado.class,
							true,
							new StringBuilder(
									"N�o foi encontrado nenhum documento digitalizado com o ID informado! ID: ")
									.append(documentoDigitalizadoDTO.getId())
									.toString(),
							"ID do documento digitalizado n�o foi informado!");

			// marca o documento para inativo para que n�o seja utilizado em
			// outra solicitacao
			documentoDigitalizado.setStatus(StatusPadraoEnum.INATIVO);
			documentoDigitalizado.setTipo(tipoDocumentoDigitalizado);

			// adiciona na lista da tabela temporaria
			/*documentosDigitalizadosSenha
					.add(new DocumentoDigitalizadoAlteracaoSenha(
							documentoDigitalizado, alteracaoSenha));*/
			documentosDigitalizadosSenha.add(documentoDigitalizado);

		}

		return documentosDigitalizadosSenha;
	}

}
