package br.com.calcard.calsystem.exception;

public class EntidadeStatusInvalidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 339506573973070258L;

	public EntidadeStatusInvalidoException(String mensagem) {
		super(mensagem);
	}

}
