package br.com.calcard.calsystem.dto;

import java.io.Serializable;

public class CartaoDTO implements Serializable {

	private static final long serialVersionUID = 7897889204437645389L;

	private String numeroCartao;

	private String nomePortador;

	private String cpfPortador;

	private boolean titular;

	private String status;

	private ContaDTO conta;

	public CartaoDTO() {
		super();
	}

	public CartaoDTO(String numeroCartao, String nomePortador,
			String cpfPortador, boolean titular, String status, ContaDTO conta) {
		super();
		this.numeroCartao = numeroCartao;
		this.nomePortador = nomePortador;
		this.cpfPortador = cpfPortador;
		this.titular = titular;
		this.conta = conta;
		this.status = status;
	}

	public String getNumeroCartao() {
		return numeroCartao;
	}

	public void setNumeroCartao(String numeroCartao) {
		this.numeroCartao = numeroCartao;
	}

	public String getNomePortador() {
		return nomePortador;
	}

	public void setNomePortador(String nomePortador) {
		this.nomePortador = nomePortador;
	}

	public String getCpfPortador() {
		return cpfPortador;
	}

	public void setCpfPortador(String cpfPortador) {
		this.cpfPortador = cpfPortador;
	}

	public boolean isTitular() {
		return titular;
	}

	public void setTitular(boolean titular) {
		this.titular = titular;
	}

	public ContaDTO getConta() {
		return conta;
	}

	public void setConta(ContaDTO conta) {
		this.conta = conta;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
