package br.com.calcard.calsystem.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.ws.CalsystemFacadeWS;
import br.com.calcard.calsystem.interfaces.IBiometria;
import br.com.calcard.calsystem.util.Parametro;

@Component
public class BiometriaFacadeWS extends CalsystemFacadeWS {

	private IBiometria biometriaService;

	@Autowired
	public BiometriaFacadeWS(IBiometria biometriaService) {

		this.biometriaService = biometriaService;

	}

	public ResponseEntity<Object> doAvaliarFoto(String fotoBase64) {

		try {

			Integer nsu = this.biometriaService.doAvaliarFoto(fotoBase64);

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"NSU", nsu).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

}
