package br.com.calcard.calsystem.exception;

public class TelefoneException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 107036132659292153L;

	public TelefoneException(String mensagem) {
		super(mensagem);
	}

}
