package br.com.calcard.calsystem.entity.proposta;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calsystem.entity.ProcessoDigitalizacao;
import br.com.calcard.calsystem.enums.Enum.StatusPadraoEnum;

@Entity
@NamedQueries({ @NamedQuery(name = DocumentoDigitalizado.NQ_SELECT_DOCUMENTOS_BY_CPF, query = "select e from DocumentoDigitalizado e where e.cpf = :cpf") })
@Table(name = "tbl_documento_digitalizado")
public class DocumentoDigitalizado extends CalsystemEntity {

	private static final long serialVersionUID = -615801916310051684L;

	public static final String NQ_SELECT_DOCUMENTOS_BY_CPF = "NQDocumentoDigitalizadoByCPF";

	private static final String COLUNA_TIPO_DOCUMENTO_DIGITALIZADO = "id_tipo_documento_digitalizado";

	private static final String COLUNA_BASE64 = "base64";

	private static final String COLUNA_CPF = "cpf";

	private static final String COLUNA_PROCESSO_DIGITALIZACAO = "id_processo_digitalizacao";

	@Enumerated(EnumType.STRING)
	@Column(name = COLUNA_STATUS, length = 30, nullable = false, unique = false)
	private StatusPadraoEnum status;

	@OneToOne
	@JoinColumn(name = COLUNA_TIPO_DOCUMENTO_DIGITALIZADO, nullable = true, unique = false)
	private TipoDocumentoDigitalizado tipo;

	@OneToOne
	@JoinColumn(name = COLUNA_PROCESSO_DIGITALIZACAO, nullable = false, unique = false)
	private ProcessoDigitalizacao processoDigitalizacao;

	@Lob
	@Column(name = COLUNA_BASE64, nullable = false, unique = false)
	private String base64;

	@Column(name = COLUNA_CPF, length = 11, nullable = false, unique = false)
	private String cpf;

	public DocumentoDigitalizado() {

	}

	public DocumentoDigitalizado(TipoDocumentoDigitalizado tipo, String cpf,
			String base64, StatusPadraoEnum status,
			ProcessoDigitalizacao processoDigitalizacao) {
		super();
		this.cpf = cpf;
		this.tipo = tipo;
		this.base64 = base64;
		this.status = status;
		this.processoDigitalizacao = processoDigitalizacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((base64 == null) ? 0 : base64.hashCode());
		result = prime * result + ((cpf == null) ? 0 : cpf.hashCode());
		result = prime
				* result
				+ ((processoDigitalizacao == null) ? 0 : processoDigitalizacao
						.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		DocumentoDigitalizado other = (DocumentoDigitalizado) obj;
		if (base64 == null) {
			if (other.base64 != null)
				return false;
		} else if (!base64.equals(other.base64))
			return false;
		if (cpf == null) {
			if (other.cpf != null)
				return false;
		} else if (!cpf.equals(other.cpf))
			return false;
		if (processoDigitalizacao == null) {
			if (other.processoDigitalizacao != null)
				return false;
		} else if (!processoDigitalizacao.equals(other.processoDigitalizacao))
			return false;
		if (status != other.status)
			return false;
		if (tipo == null) {
			if (other.tipo != null)
				return false;
		} else if (!tipo.equals(other.tipo))
			return false;
		return true;
	}

	public TipoDocumentoDigitalizado getTipo() {
		return tipo;
	}

	public void setTipo(TipoDocumentoDigitalizado tipo) {
		this.tipo = tipo;
	}

	public String getBase64() {
		return base64;
	}

	public void setBase64(String base64) {
		this.base64 = base64;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public StatusPadraoEnum getStatus() {
		return status;
	}

	public void setStatus(StatusPadraoEnum status) {
		this.status = status;
	}

	public ProcessoDigitalizacao getProcessoDigitalizacao() {
		return processoDigitalizacao;
	}

	public void setProcessoDigitalizacao(
			ProcessoDigitalizacao processoDigitalizacao) {
		this.processoDigitalizacao = processoDigitalizacao;
	}

}
