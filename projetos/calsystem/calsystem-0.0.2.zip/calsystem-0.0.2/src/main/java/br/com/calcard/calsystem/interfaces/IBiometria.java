package br.com.calcard.calsystem.interfaces;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;

public interface IBiometria {

	public Integer doAvaliarFoto(String fotoBase64) throws IntegracaoException,
			CalsystemInvalidArgumentException, ServiceException,
			IntegracaoMotorBiometriaException;

}
