package br.com.calcard.calsystem.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import br.com.calcard.calframework.util.CustomJsonDateDeserializer;
import br.com.calcard.calframework.util.CustomJsonDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class AnaliseBiometriaDTO {
	
	private Integer idMotorBiometria;
	
	private BiometriaDTO biometriaLoja;
	
	private BiometriaDTO biometriaCadastro;
	
	private List<BiometriaDTO> biometriaSimilaresLoja;
	
	private List<BiometriaDTO> biometriaSimilaresCadastro;
	
	public AnaliseBiometriaDTO() {
		super();
	}

	public AnaliseBiometriaDTO(Integer idMotorBiometria,
			BiometriaDTO biometriaLoja, BiometriaDTO biometriaCadastro,
			List<BiometriaDTO> biometriaSimilaresLoja,
			List<BiometriaDTO> biometriaSimilaresCadastro) {
		super();
		this.idMotorBiometria = idMotorBiometria;
		this.biometriaLoja = biometriaLoja;
		this.biometriaCadastro = biometriaCadastro;
		this.biometriaSimilaresLoja = biometriaSimilaresLoja;
		this.biometriaSimilaresCadastro = biometriaSimilaresCadastro;
	}



	public Integer getIdMotorBiometria() {
		return idMotorBiometria;
	}

	public void setIdMotorBiometria(Integer idMotorBiometria) {
		this.idMotorBiometria = idMotorBiometria;
	}

	public BiometriaDTO getBiometriaLoja() {
		return biometriaLoja;
	}

	public void setBiometriaLoja(BiometriaDTO biometriaLoja) {
		this.biometriaLoja = biometriaLoja;
	}

	public BiometriaDTO getBiometriaCadastro() {
		return biometriaCadastro;
	}

	public void setBiometriaCadastro(BiometriaDTO biometriaCadastro) {
		this.biometriaCadastro = biometriaCadastro;
	}

	public List<BiometriaDTO> getBiometriaSimilaresLoja() {
		return biometriaSimilaresLoja;
	}

	public void setBiometriaSimilaresLoja(List<BiometriaDTO> biometriaSimilaresLoja) {
		this.biometriaSimilaresLoja = biometriaSimilaresLoja;
	}

	public List<BiometriaDTO> getBiometriaSimilaresCadastro() {
		return biometriaSimilaresCadastro;
	}

	public void setBiometriaSimilaresCadastro(
			List<BiometriaDTO> biometriaSimilaresCadastro) {
		this.biometriaSimilaresCadastro = biometriaSimilaresCadastro;
	}
	
}
