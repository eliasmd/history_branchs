package br.com.calcard.calsystem.service;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calsystem.enums.Enum.StatusEstabelecimentoEnum;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.exception.estabelecimento.EstabelecimentoInvalidoException;
import br.com.calcard.calsystem.interfaces.IEstabelecimento;
import br.com.calcard.calsystem.util.Parametro;

@Service
public class EstabelecimentoService implements IEstabelecimento {

	private ICalsystemDAO daoService;

	@Autowired
	public EstabelecimentoService(ICalsystemDAO daoService) {
		this.daoService = daoService;
	}

	@Override
	public void doValidarNovoEstabelecimento(
			Estabelecimento estabelecimentoAtual,
			Estabelecimento estabelecimentoNovo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, EstabelecimentoInvalidoException {

		if (estabelecimentoNovo == null)
			throw new CalsystemInvalidArgumentException(
					"Estabelecimento n�o informado!");

		if (estabelecimentoNovo.getCodigo() == null)
			throw new CalsystemInvalidArgumentException(
					"C�digo do estabelecimento n�o informado!");

		if (estabelecimentoNovo.getCnpj() == null)
			throw new CalsystemInvalidArgumentException(
					"CNPJ do estabelecimento n�o informado!");

		Estabelecimento estabelecimentoMesmoCNPJ = this.daoService
				.doGetSingleResult(
						Estabelecimento.NQ_SELECT_ESTABELECIMENTO_BY_CNPJ,
						new Parametro().doAddParametro("cnpj",
								estabelecimentoNovo.getCnpj()).getParametros(),
						Estabelecimento.class);

		Estabelecimento estabelecimentoMesmoCodigo = this.daoService
				.doGetSingleResult(
						Estabelecimento.NQ_SELECT_ESTABELECIMENTO_BY_CODIGO,
						new Parametro().doAddParametro("codigo",
								estabelecimentoNovo.getCodigo())
								.getParametros(), Estabelecimento.class);

		if (estabelecimentoAtual == null) {

			if (estabelecimentoMesmoCNPJ != null)
				new StringBuilder(
						"J� existe outro estabelecimento cadastrado com esse CNPJ! CNPJ: ")
						.append(estabelecimentoNovo.getCnpj()).toString();

			if (estabelecimentoMesmoCodigo != null)
				throw new EstabelecimentoInvalidoException(
						new StringBuilder(
								"J� existe um estabelecimento cadastrado com o c�digo informado! CÓDIGO: ")
								.append(estabelecimentoNovo.getCodigo())
								.toString());
		} else {

			if (!estabelecimentoAtual.getCnpj().equals(
					estabelecimentoNovo.getCnpj())
					&& estabelecimentoMesmoCNPJ != null)
				throw new EstabelecimentoInvalidoException(new StringBuilder(
						"J� existe um estabelecimento com este CNPJ! CNPJ: ")
						.append(estabelecimentoNovo.getCnpj()).toString());

			else if (!estabelecimentoAtual.getCodigo().equals(
					estabelecimentoNovo.getCodigo())
					&& estabelecimentoMesmoCodigo != null)
				throw new EstabelecimentoInvalidoException(
						new StringBuilder(
								"J� existe um estabelecimento cadastrado com o c�digo informado! CÓDIGO: ")
								.append(estabelecimentoNovo.getCodigo())
								.toString());

		}

	}

	@Override
	public Estabelecimento doCadastrarNovoEstabelecimento(String codigo,
			String cnpj) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException, EstabelecimentoInvalidoException {

		Estabelecimento estabelecimento = new Estabelecimento(codigo, cnpj);

		this.doValidarNovoEstabelecimento(null, estabelecimento);

		return this.daoService.doCreate(estabelecimento,
				"Estabelecimento n�o informado!");

	}

	@Override
	public Estabelecimento doAtualizarCadastroEstabelecimentoExistente(
			Integer idEstabelecimentoExistente, String codigo, String cnpj)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException, EstabelecimentoInvalidoException {

		Estabelecimento estabelecimentoExistente = this.daoService.doRead(
				idEstabelecimentoExistente, Estabelecimento.class, true,
				"Estabelecimento n�o encontrado!",
				"ID do estabelecimento n�o informado!");

		Estabelecimento estabelecimentoNovo = estabelecimentoExistente.clone();

		estabelecimentoNovo.setCodigo(codigo);

		estabelecimentoNovo.setCnpj(cnpj);

		this.doValidarNovoEstabelecimento(estabelecimentoExistente,
				estabelecimentoNovo);

		return this.daoService.doUpdate(estabelecimentoNovo);

	}

	@Override
	public Estabelecimento doInativarEstabelecimento(Integer id)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		Estabelecimento estabelecimento = this.daoService.doRead(id,
				Estabelecimento.class, true,
				"Estabelecimento n�o encontrado!",
				"ID do estabelecimento n�o informado!");

		estabelecimento.setStatus(StatusEstabelecimentoEnum.INATIVO);

		return this.daoService.doUpdate(estabelecimento,
				"Estabelecimento n�o informado!");
	}

	@Transactional
	@Override
	public List<Estabelecimento> doListarEstabelecimentos(String codigo,
			String cnpj, Integer idUsuario,
			StatusEstabelecimentoEnum statusEstabelecimento)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		Criteria criteria = this.daoService
				.doGetCriteria(Estabelecimento.class);

		if (codigo != null)
			criteria.add(Restrictions.eq(Estabelecimento.COLUNA_CODIGO, codigo));

		if (cnpj != null)
			criteria.add(Restrictions.eq(Estabelecimento.COLUNA_CNPJ, cnpj));

		if (statusEstabelecimento != null)
			criteria.add(Restrictions.eq(Estabelecimento.COLUNA_STATUS,
					statusEstabelecimento));

		if (idUsuario != null) {

			Criteria criteriaUsuario = criteria.createCriteria("usuarios");

			criteriaUsuario.add(Restrictions.eq(Usuario.COLUNA_ID, idUsuario));
		}

		return this.daoService.doList(criteria, true,
				"Nenhum estabelecimento encontrado!");

	}

	@Override
	public List<Estabelecimento> doListarEstabelecimentos(Integer idUsuario)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		if (idUsuario == null)
			throw new CalsystemInvalidArgumentException(
					"ID do usu�rio n�o informado!");

		Usuario usuario = this.daoService.doRead(idUsuario, Usuario.class,
				true, "Usu�rio n�o encontrado!",
				"ID do usu�rio n�o informado!");

		return this.daoService
				.doGetResultList(
						Estabelecimento.NQ_SELECT_ESTABELECIMENTO_BY_USUARIO,
						new Parametro().doAddParametro("usuario", usuario)
								.getParametros(),
						Estabelecimento.class,
						true,
						new StringBuilder()
								.append("Nenhum estabelecimento vinculado para o usu�rio informado! ID USUARIO: ")
								.append(usuario.getId()).toString());

	}
}
