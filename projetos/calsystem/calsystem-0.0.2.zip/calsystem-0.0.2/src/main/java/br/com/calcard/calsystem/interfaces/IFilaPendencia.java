package br.com.calcard.calsystem.interfaces;

import java.util.List;

import org.springframework.http.ResponseEntity;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calsystem.dto.AlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.AnaliseBiometriaDTO;
import br.com.calcard.calsystem.dto.AnalisePendenciaDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.AnalisePendencia;
import br.com.calcard.calsystem.entity.StatusFilaPendencias;

public interface IFilaPendencia {

	public List<StatusFilaPendencias> doListarStatusFilaDePendencia() throws CalsystemNoDataFoundException, CalsystemInvalidArgumentException;
	
	public List<AlteracaoSenha> doListarFilaDePendencia(String status, String cpf) throws CalsystemNoDataFoundException, CalsystemInvalidArgumentException;
	
	public AnalisePendencia doAnalisarPendencia(AnalisePendenciaDTO analisePendenciaDTO) throws Exception, CalsystemInvalidArgumentException, CalsystemNoDataFoundException, ServiceException;
	
	public List<AnalisePendencia> doCarregarAnaliseIniciada(List<AlteracaoSenha>  listaAlteracaoSenhaDTO) throws CalsystemNoDataFoundException, CalsystemInvalidArgumentException;
	
	public AlteracaoSenha doNegarPendencia(Integer idAlteracaoSenha, String parecer) throws CalsystemNoDataFoundException, CalsystemInvalidArgumentException;
	
	public AlteracaoSenha doListarDocumentosAvaliacao(Integer idAlteracaoSenha) throws CalsystemNoDataFoundException, CalsystemInvalidArgumentException;
	
	public ResponseEntity<Object> doListarFotosAvaliacaoAlteracaoDeSenha(Integer idAlteracaoSenha);
	
	public ResponseEntity<Object> doAprovarPendencia(Integer idAlteracaoSenha);
	
	}
