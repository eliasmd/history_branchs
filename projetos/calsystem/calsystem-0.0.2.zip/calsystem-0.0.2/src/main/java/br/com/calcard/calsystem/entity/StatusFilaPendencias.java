package br.com.calcard.calsystem.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

import br.com.calcard.calframework.entity.CalsystemEntity;

@Entity
@Table(name = "tbl_status_fila_pendencia")
public class StatusFilaPendencias extends CalsystemEntity {

	private static final long serialVersionUID = 4636712282306612663L;

	@Column(name = COLUNA_STATUS, length = 50, nullable = false, unique = false)
	protected String status;

	public StatusFilaPendencias() {
		super();
	}

	public StatusFilaPendencias(String status) {
		super();
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


}
