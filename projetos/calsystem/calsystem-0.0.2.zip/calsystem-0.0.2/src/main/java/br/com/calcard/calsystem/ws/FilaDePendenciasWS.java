package br.com.calcard.calsystem.ws;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calsystem.dto.AlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.AnalisePendenciaDTO;
import br.com.calcard.calsystem.facade.FilaDePendenciasFacadeWS;
import br.com.calcard.calsystem.interfaces.IFilaPendencia;
import br.com.calcard.calsystem.util.Parametro;

@RestController
@RequestMapping("/ws/filaDePendencias")
@Scope(value = "request")
public class FilaDePendenciasWS extends CalsystemWS {

	private FilaDePendenciasFacadeWS filaDePendenciasFacadeWS;
	private IFilaPendencia filaDePendenciasService;

	@Autowired
	public FilaDePendenciasWS(FilaDePendenciasFacadeWS filaDePendenciasFacadeWS,
							  IFilaPendencia filaDePendenciasService) {
		this.filaDePendenciasFacadeWS = filaDePendenciasFacadeWS;
		this.filaDePendenciasService = filaDePendenciasService;
	}

	@RequestMapping(value = "/listarStatusFilaDePendencia", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarStatusFilaDePendencia(
			@RequestHeader(value = "tSessao") String tSessao) {
		super.doGravarLog(tSessao);

		return this.filaDePendenciasFacadeWS.doListarStatusFilaDePendencia();

	}

	@RequestMapping(value = "/listarFilaDePendencia", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarFilaDePendencia(
			@RequestParam(value = "cpf", required = false) String cpf,
			@RequestParam(value = "status", required = true) String status,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(tSessao, new Parametro().doAddParametro("cpf", cpf)
				.doAddParametro("status", status).getParametros());

		return this.filaDePendenciasFacadeWS
				.doListarFilaDePendencias(status, cpf);

	}
	
	@RequestMapping(value = "/listarDocumentosAvaliacao", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarDocumentosAvaliacao(
			@RequestParam(value = "id", required = true) Integer idAlteracaoSenha,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(tSessao, new Parametro().doAddParametro("idAlteracaoSenha", idAlteracaoSenha)
				.getParametros());

		return this.filaDePendenciasFacadeWS.doListarDocumentosAvaliacao(idAlteracaoSenha);

	}

	@RequestMapping(value = "/analisarPendencia", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doAnalisarPendencia(
			@RequestBody AnalisePendenciaDTO analisePendenciaDTO,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(
				tSessao,
				new Parametro().doAddParametro("alteracaoSenhaDTO",
						analisePendenciaDTO).getParametros());

		return this.filaDePendenciasFacadeWS
				.doAnalisarPendencia(analisePendenciaDTO);

	}
	
	@RequestMapping(value = "/negarPendencia", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doNegarPendencia(
			@RequestParam(value = "id", required = true) Integer idAlteracaoSenha,
			@RequestBody Map<String, String> requestBody,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(
				tSessao,
				new Parametro().doAddParametro("idAlteracaoSenha",
						idAlteracaoSenha).doAddParametro("parecer",
								requestBody.get("parecer")).getParametros());

		return this.filaDePendenciasFacadeWS
				.doNegarPendencia(idAlteracaoSenha, requestBody.get("parecer"));

	}
	
	@RequestMapping(value = "/aprovarPendencia", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doAprovarPendencia(
			@RequestParam(value = "id", required = true) Integer idAlteracaoSenha,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(
				tSessao,
				new Parametro().doAddParametro("idAlteracaoSenha",
						idAlteracaoSenha).getParametros());

		return this.filaDePendenciasService.doAprovarPendencia(idAlteracaoSenha);

	}
	
	
	@RequestMapping(value = "/listarFotosAvaliacao", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarFotosAvaliacao(
			@RequestParam(value = "idAlteracaoSenha", required = true) Integer idAlteracaoSenha,
			@RequestHeader(value = "tSessao") String tSessao) {
		super.doGravarLog(
				tSessao,
				new Parametro().doAddParametro("idAlteracaoSenha",
						idAlteracaoSenha).getParametros());

		return this.filaDePendenciasService.doListarFotosAvaliacaoAlteracaoDeSenha(idAlteracaoSenha);

	}

}