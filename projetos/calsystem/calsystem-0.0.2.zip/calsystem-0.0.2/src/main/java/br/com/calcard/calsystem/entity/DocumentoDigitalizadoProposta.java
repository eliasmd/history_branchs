package br.com.calcard.calsystem.entity;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;
import br.com.calcard.calsystem.entity.proposta.Proposta;

@Entity
@Table(name = "tbl_documento_digitalizado_proposta", uniqueConstraints = { @UniqueConstraint(columnNames = {
		DocumentoDigitalizadoProposta.COLUNA_DOCUMENTO_DIGITALIZADO,
		DocumentoDigitalizadoProposta.COLUNA_PROPOSTA }) })
public class DocumentoDigitalizadoProposta extends CalsystemEntity {

	private static final long serialVersionUID = -3593672909900033985L;

	public static final String COLUNA_DOCUMENTO_DIGITALIZADO = "id_documento_digitalizado";

	public static final String COLUNA_PROPOSTA = "id_proposta";

	@OneToOne
	@JoinColumn(name = COLUNA_DOCUMENTO_DIGITALIZADO, nullable = false, unique = false)
	private DocumentoDigitalizado documentoDigitalizado;

	@OneToOne
	@JoinColumn(name = COLUNA_PROPOSTA, nullable = false, unique = false)
	private Proposta proposta;

	public DocumentoDigitalizadoProposta() {
		super();
	}

	public DocumentoDigitalizadoProposta(
			DocumentoDigitalizado documentoDigitalizado, Proposta proposta) {
		super();
		this.documentoDigitalizado = documentoDigitalizado;
		this.proposta = proposta;
	}

	public DocumentoDigitalizado getDocumentoDigitalizado() {
		return documentoDigitalizado;
	}

	public void setDocumentoDigitalizado(
			DocumentoDigitalizado documentoDigitalizado) {
		this.documentoDigitalizado = documentoDigitalizado;
	}

	public Proposta getProposta() {
		return proposta;
	}

	public void setProposta(Proposta proposta) {
		this.proposta = proposta;
	}

}
