package br.com.calcard.calsystem.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import br.com.calcard.calframework.util.CustomJsonDateDeserializer;
import br.com.calcard.calframework.util.CustomJsonDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class AnalisePendenciaDTO {
	
	private Integer id;
	
	private UsuarioDTO analista;

	private String parecer;
	
	private Integer idAlteracaoSenha;
	
	private String etapa;
	
	@JsonDeserialize(using = CustomJsonDateDeserializer.class)
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date dataInicio;
	
	@JsonDeserialize(using = CustomJsonDateDeserializer.class)
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date dataFim;
	
	public AnalisePendenciaDTO() {
		super();
	}

	public AnalisePendenciaDTO(Integer id, UsuarioDTO analista, String parecer,
			Integer idAlteracaoSenha, String etapa, Date dataInicio,
			Date dataFim) {
		super();
		this.id = id;
		this.analista = analista;
		this.parecer = parecer;
		this.idAlteracaoSenha = idAlteracaoSenha;
		this.etapa = etapa;
		this.dataInicio = dataInicio;
		this.dataFim = dataFim;
	}



	public UsuarioDTO getAnalista() {
		return analista;
	}

	public void setAnalista(UsuarioDTO analista) {
		this.analista = analista;
	}

	public String getParecer() {
		return parecer;
	}

	public void setParecer(String parecer) {
		this.parecer = parecer;
	}

	public Integer getIdAlteracaoSenha() {
		return idAlteracaoSenha;
	}

	public void setIdAlteracaoSenha(Integer idAlteracaoSenha) {
		this.idAlteracaoSenha = idAlteracaoSenha;
	}

	public String getEtapa() {
		return etapa;
	}

	public void setEtapa(String etapa) {
		this.etapa = etapa;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	
	

}
