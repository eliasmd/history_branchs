package br.com.calcard.calsystem.exception.token;

import br.com.calcard.calframework.exception.CalsystemException;

public class TokenLoginInvalidoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1033919753034665423L;

	public TokenLoginInvalidoException(String mensagem) {
		super(mensagem);
	}

}
