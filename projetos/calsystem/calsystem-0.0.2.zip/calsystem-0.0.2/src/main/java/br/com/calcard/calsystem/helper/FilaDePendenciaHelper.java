package br.com.calcard.calsystem.helper;

import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.axis.encoding.ser.Base64Deserializer;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calsystem.dto.AlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.AnalisePendenciaDTO;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.dto.UsuarioDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.AnalisePendencia;
import br.com.calcard.calsystem.enums.Enum.StatusPadraoEnum;
import br.com.calcard.calsystem.util.ListagemArquivosFilter;

@Component
public class FilaDePendenciaHelper {

	public List<AlteracaoSenhaDTO> doComporFilaDePendenciaDTO(List<AlteracaoSenha> listaAlteracaoSenha,
															  List<AnalisePendencia> listaAnalisePendencia) {
		
		List<AlteracaoSenhaDTO> listaAlteracaoSenhaDTO = new ArrayList<AlteracaoSenhaDTO>();
		
		for (int i = 0; i < listaAlteracaoSenha.size(); i++) {
			
			AlteracaoSenhaDTO alteracaoSenhaDTO = new AlteracaoSenhaDTO();
			
			alteracaoSenhaDTO.setCpfPortador(CalsystemUtil.doMascararCPF(listaAlteracaoSenha.get(i).getCpf()));
			alteracaoSenhaDTO.setIdConta(listaAlteracaoSenha.get(i).getConta());
			alteracaoSenhaDTO.setStatus(listaAlteracaoSenha.get(i).getStatus());
			alteracaoSenhaDTO.setDataRegistro(listaAlteracaoSenha.get(i).getDataRegistro());
			alteracaoSenhaDTO.setNome(listaAlteracaoSenha.get(i).getNome());
			alteracaoSenhaDTO.setIdEstabelecimento(listaAlteracaoSenha.get(i).getEstabelecimento().getId());
			alteracaoSenhaDTO.setId(listaAlteracaoSenha.get(i).getId());
			
			
				//busca se j� possui analise para a solicitacao de senha
				for (int j = 0; j < listaAnalisePendencia.size(); j++) {
					try{
						if( listaAnalisePendencia.get(j) != null && listaAlteracaoSenha.get(i) != null &&
							listaAnalisePendencia.get(j).getAlteracaoSenha().getId() == listaAlteracaoSenha.get(i).getId()){
	
							alteracaoSenhaDTO.setAnalisePendencia(new AnalisePendenciaDTO(listaAnalisePendencia.get(j).getId(),
																						  new UsuarioDTO(listaAnalisePendencia.get(j).getAnalista().getId(),
																								  		 listaAnalisePendencia.get(j).getAnalista().getNome(),
																								  		 listaAnalisePendencia.get(j).getAnalista().getPerfil().getNome(),
																								  		 listaAnalisePendencia.get(j).getAnalista().getCpf()),
																						  listaAnalisePendencia.get(j).getParecer(),
																						  listaAnalisePendencia.get(j).getAlteracaoSenha().getId(),
																						  listaAnalisePendencia.get(j).getEtapa_status(),
																						  listaAnalisePendencia.get(j).getDataInicio(),
																						  listaAnalisePendencia.get(j).getDataFim()
																						  ));
							listaAnalisePendencia.remove(j);
							break;
						}
						
					}catch(Exception e){
						 int teste = j;
					}
				}
			
			
			listaAlteracaoSenhaDTO.add(alteracaoSenhaDTO);

		}

		return listaAlteracaoSenhaDTO;

	}

}
