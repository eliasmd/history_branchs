package br.com.calcard.calsystem.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calsystem.entity.ParametroGlobal;
import br.com.calcard.calsystem.interfaces.IParametroGlobal;

@Service
public class ParametroService implements IParametroGlobal {

	private Map<String, ParametroGlobal> parametrosGlobais;

	private ICalsystemDAO daoService;

	@Autowired
	public ParametroService(ICalsystemDAO daoService)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		this.daoService = daoService;

		parametrosGlobais = new HashMap<String, ParametroGlobal>();

		this.doCarregarParametrosGlobais();

	}

	@Override
	public void doCarregarParametrosGlobais()
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		for (ParametroGlobal parametroGlobal : this.daoService.doList(
				ParametroGlobal.class, true,
				"Nenhum parâmetro global configirado no banco de dados!"))
			parametrosGlobais.put(parametroGlobal.getNome(), parametroGlobal);

	}

	@Override
	public ParametroGlobal doConsultar(String nomeParametro)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		if (nomeParametro == null)
			throw new CalsystemInvalidArgumentException(
					"Nome do parâmetro n�o informado para a pesquisa!");

		ParametroGlobal parametroGlobal = this.parametrosGlobais
				.get(nomeParametro);

		if (parametroGlobal == null)
			throw new CalsystemNoDataFoundException(new StringBuilder(
					"Parametro Global n�o encontrado!").append(" PARÂMETRO: ")
					.append(nomeParametro).toString());

		return parametroGlobal;

	}

	@Override
	public Map<String, ParametroGlobal> doListarParametrosByNome(
			String... parametros) throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		if (parametros == null)
			throw new CalsystemInvalidArgumentException(
					"Nome do parâmetro n�o informado para a pesquisa!");

		Map<String, ParametroGlobal> parametrosGlobais = new HashMap<String, ParametroGlobal>();

		for (String parametro : Arrays.asList(parametros)) {

			ParametroGlobal p = this.doConsultar(parametro);

			parametrosGlobais.put(parametro, p);

		}

		return parametrosGlobais;
	}

}
