package br.com.calcard.calsystem.enums;

public enum StatusPropostaEnum {

	INICIADO, REGISTRADO_P1, APROVADO_P1, PENDENTE_ENVIO_MOTOR_FRAUDE;

}
