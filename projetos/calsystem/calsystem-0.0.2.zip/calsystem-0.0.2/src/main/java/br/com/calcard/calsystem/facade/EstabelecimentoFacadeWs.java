package br.com.calcard.calsystem.facade;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.ws.CalsystemFacadeWS;
import br.com.calcard.calsystem.dto.EstabelecimentoDTO;
import br.com.calcard.calsystem.enums.Enum.StatusEstabelecimentoEnum;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.interfaces.IEstabelecimento;
import br.com.calcard.calsystem.interfaces.IUsuario;
import br.com.calcard.calsystem.util.Parametro;

@Component
public class EstabelecimentoFacadeWs extends CalsystemFacadeWS {

	private IEstabelecimento estabelecimentoService;

	private IUsuario usuarioService;

	@Autowired
	public EstabelecimentoFacadeWs(IEstabelecimento estabelecimentoService,
			IUsuario usuarioService) {
		this.estabelecimentoService = estabelecimentoService;
		this.usuarioService = usuarioService;
	}

	public ResponseEntity<Object> doCadastrar(String codigo, String cnpj) {

		try {

			Estabelecimento estabelecimento = this.estabelecimentoService
					.doCadastrarNovoEstabelecimento(codigo, cnpj);

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Estabelecimento", new EstabelecimentoDTO(estabelecimento))
					.getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doAtualizar(
			Integer idEstabelecimentoExistente, String codigo, String cnpj) {
		try {

			Estabelecimento estabelecimento = this.estabelecimentoService
					.doAtualizarCadastroEstabelecimentoExistente(
							idEstabelecimentoExistente, codigo, cnpj);

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Estabelecimento", new EstabelecimentoDTO(estabelecimento))
					.getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doListar(String codigo, String cnpj,
			Integer idUsuario, StatusEstabelecimentoEnum status) {
		try {

			List<EstabelecimentoDTO> estabelecimentosDTO = new ArrayList<EstabelecimentoDTO>();

			for (Estabelecimento estabelecimento : this.estabelecimentoService
					.doListarEstabelecimentos(codigo, cnpj, idUsuario, status))
				estabelecimentosDTO
						.add(new EstabelecimentoDTO(estabelecimento));

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Estabelecimentos", estabelecimentosDTO).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doInativar(Integer id) {
		try {

			Estabelecimento estabelecimento = this.estabelecimentoService
					.doInativarEstabelecimento(id);

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Estabelecimento", new EstabelecimentoDTO(estabelecimento))
					.getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doListarEstabelecimentosPorUsuario(
			Integer idUsuario) {

		try {

			List<Estabelecimento> estabelecimentos = this.estabelecimentoService
					.doListarEstabelecimentos(idUsuario);

			List<EstabelecimentoDTO> estabelecimentosDTO = new ArrayList<EstabelecimentoDTO>();

			for (Estabelecimento estabelecimento : estabelecimentos)
				estabelecimentosDTO
						.add(new EstabelecimentoDTO(estabelecimento));

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Estabelecimentos", estabelecimentosDTO).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}
}
