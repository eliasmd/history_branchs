package br.com.calcard.calsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calsystem.entity.proposta.Foto;
import br.com.calcard.calsystem.interfaces.IBiometria;

@Service
public class BiometriaService implements IBiometria {

	private IMotorBiometria motorBiometriaService;

	private ICalsystemDAO daoService;

	@Autowired
	public BiometriaService(IMotorBiometria motorBiometriaService,
			ICalsystemDAO daoService) {

		this.motorBiometriaService = motorBiometriaService;

		this.daoService = daoService;

	}

	@Transactional
	@Override
	public Integer doAvaliarFoto(String fotoBase64) throws IntegracaoException,
			CalsystemInvalidArgumentException, ServiceException,
			IntegracaoMotorBiometriaException {

		this.motorBiometriaService.doAvaliarFoto(fotoBase64);

		Foto foto = this.daoService.doCreate(new Foto(fotoBase64, null));

		return foto.getId();

	}

}
