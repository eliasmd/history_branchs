package br.com.calcard.calsystem.exception;

public class CriptografiaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1108533022268722052L;

}
