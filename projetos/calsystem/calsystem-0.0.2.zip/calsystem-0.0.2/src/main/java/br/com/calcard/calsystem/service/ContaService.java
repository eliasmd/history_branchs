package br.com.calcard.calsystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calsystem.entity.Conta;
import br.com.calcard.calsystem.interfaces.IConta;

@Service
public class ContaService implements IConta {

	public ContaService() {
		super();
	}

	public List<Conta> doListarContasPorCPF(String cpf) throws ServiceException {

		if (CalsystemUtil.isNull(cpf))
			throw new ServiceException("CPF n�o informado!");

		List<Conta> listaContas = new ArrayList<Conta>();

		Conta conta = new Conta();
		conta.setId(1);
		conta.setCpf(cpf);
		conta.setNomeCliente("Cliente Teste da Silva");
		conta.setStatus("ATIVO");

		listaContas.add(conta);

		return listaContas;

	}
}
