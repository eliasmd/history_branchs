package br.com.calcard.calsystem.interfaces;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calsystem.entity.LogTabela;
import br.com.calcard.calsystem.entity.Usuario;

public interface ILogTabela {

	public LogTabela doRegistrarLogTabela(String nomeTabela, String nomeColuna,
			String de, String para, Usuario usuario, CalsystemEntity entity)
			throws CalsystemInvalidArgumentException;

}
