package br.com.calcard.calsystem.exception.estabelecimento;

import br.com.calcard.calframework.exception.CalsystemException;

public class EstabelecimentoIdInvalidoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4692456551363095211L;

	public EstabelecimentoIdInvalidoException(String mensagem) {
		super(mensagem);
	}

}
