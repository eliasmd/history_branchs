package br.com.calcard.calsystem.interfaces;

import java.util.List;

import org.springframework.http.ResponseEntity;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calsystem.dto.AlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.CartaoDTO;
import br.com.calcard.calsystem.exception.proposta.PropostaDocumentosDigitalizadosException;

public interface ICartao {

	public List<CartaoDTO> doListarCartoes(String cpf, String numeroCartao)
			throws CalsystemInvalidArgumentException;

	public List<CartaoDTO> doListarCartoesCadastroSenhaEDesbloqueio(String cpf,
			String numeroCartao) throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;
	
	public ResponseEntity<Object> doAlterarSenhaPortador(AlteracaoSenhaDTO alteracaoSenhaDTO);


}
