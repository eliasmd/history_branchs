package br.com.calcard.calsystem.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.ws.CalsystemFacadeWS;

@Component
public class DocumentoDigitalizadoWSFacade extends CalsystemFacadeWS {

	private DocumentoDigitalizadoServiceFacade documentoServiceFacade;

	@Autowired
	public DocumentoDigitalizadoWSFacade(
			DocumentoDigitalizadoServiceFacade documentoServiceFacade) {

		this.documentoServiceFacade = documentoServiceFacade;

	}

	public ResponseEntity<Object> doListarMiniaturas(String nomeArquivo) {

		// try {
		//
		// List<DocumentoDigitalizadoDTO> documentoRetorno =
		// this.documentoServiceFacade
		// .anexarDocumento(nomeArquivo);
		//
		// return super.doRetornarSucessoWS(new Parametro().doAddParametro(
		// "Miniaturas", documentoRetorno).getParametros());
		//
		// } catch (CalsystemException e) {
		// return super.doRetornarErroWS(e);
		// } catch (Exception e) {
		// return super.doRetornarErroWS(e);
		// }

		return null;

	}

	public ResponseEntity<Object> doListarTiposDocumentos() {

		// try {
		//
		// List<TipoDocumentoDigitalizadoDTO> tiposDocumentosDigitalizados =
		// this.documentoServiceFacade
		// .doListarTiposDocumentos();
		//
		// return super.doRetornarSucessoWS(new Parametro().doAddParametro(
		// "TiposDocumentosDigitalizados",
		// tiposDocumentosDigitalizados).getParametros());
		//
		// } catch (CalsystemException e) {
		// return super.doRetornarErroWS(e);
		// } catch (Exception e) {
		// return super.doRetornarErroWS(e);
		// }

		return null;

	}
}
