package br.com.calcard.calsystem.interfaces;

import java.util.List;

import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calsystem.entity.Conta;

public interface IConta {

	public List<Conta> doListarContasPorCPF(String cpf) throws ServiceException;

}
