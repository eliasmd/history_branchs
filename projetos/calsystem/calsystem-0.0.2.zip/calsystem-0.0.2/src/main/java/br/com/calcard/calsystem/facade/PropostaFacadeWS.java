package br.com.calcard.calsystem.facade;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.ws.CalsystemFacadeWS;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calsystem.dto.proposta.PropostaDTO;
import br.com.calcard.calsystem.entity.proposta.Proposta;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;
import br.com.calcard.calsystem.interfaces.IProposta;
import br.com.calcard.calsystem.util.Parametro;

@Component
public class PropostaFacadeWS extends CalsystemFacadeWS {

	private IProposta propostaService;

	private IMotorBiometria motorBiometriaService;

	private IDigitalizacao digitalizacaoService;

	@Autowired
	public PropostaFacadeWS(IProposta propostaService,
			IMotorBiometria motorBiometriaService,
			IDigitalizacao digitalizacaoService) {

		this.propostaService = propostaService;

		this.motorBiometriaService = motorBiometriaService;

		this.digitalizacaoService = digitalizacaoService;

	}

	public ResponseEntity<Object> doIniciarCadastroProposta() {

		try {

			Proposta proposta = this.propostaService
					.doIniciarCadastroProposta();

			PropostaDTO propostaDTO = new PropostaDTO();

			propostaDTO.setNumeroProposta(proposta.getId());

			propostaDTO.setStatus(proposta.getStatus());

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Proposta", propostaDTO).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doCadastrarP1(PropostaDTO propostaDTO) {

		try {

			Proposta proposta = this.propostaService
					.doCadastrarPropostaP1(propostaDTO);

			PropostaDTO propostaRetorno = new PropostaDTO();

			propostaRetorno.setNumeroProposta(proposta.getId());

			propostaRetorno.setStatus(proposta.getStatus());

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Proposta", propostaRetorno).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);

		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doListarPropostas(String tSessao,
			Date dataInicio, Date dataFim, Integer idProposta) {

		// try {

		List<Proposta> propostas = null;

		List<PropostaDTO> propostasDTO = new ArrayList<PropostaDTO>();

		for (Proposta proposta : propostas) {

			PropostaDTO propostaDTO = new PropostaDTO();
			propostaDTO.setNumeroProposta(proposta.getId());

			propostaDTO
					.setIdEstabelecimento(proposta.getPropostaP1() == null ? null
							: proposta.getPropostaP1().getEstabelecimento()
									.getId());

			propostaDTO.setStatus(proposta.getStatus());

			propostaDTO.setDataRegistro(proposta.getDataRegistro());

			propostasDTO.add(propostaDTO);

		}

		return super.doRetornarSucessoWS(new Parametro().doAddParametro(
				"Propostas", propostasDTO).getParametros());

		// } catch (CalsystemException e) {
		// return super.doRetornarErroWS(e);
		// } catch (Exception e) {
		// return super.doRetornarErroWS(e);
		// }

	}

	public ResponseEntity<Object> doCadastrarP2(PropostaDTO propostaDTO) {

		try {

			Proposta proposta = this.propostaService
					.doCadastrarPropostaP2(propostaDTO);

			// Proposta proposta = this.propostaServiceFacade
			// .doCadastrarP2(propostaDTO);

			PropostaDTO propostaRetorno = new PropostaDTO();

			propostaRetorno.setNumeroProposta(proposta.getId());

			propostaRetorno.setStatus(proposta.getStatus());

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Proposta", propostaRetorno).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doAvaliarFoto(String fotoBase64) {

		try {

			this.motorBiometriaService.doAvaliarFoto(fotoBase64);

			return super.doRetornarSucessoWS(null);

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doDescartarDocumentos(String nomeDocumento) {

		try {

			this.digitalizacaoService.doDescartarDocumentos(0);

			return super.doRetornarSucessoWS(null);

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

}
