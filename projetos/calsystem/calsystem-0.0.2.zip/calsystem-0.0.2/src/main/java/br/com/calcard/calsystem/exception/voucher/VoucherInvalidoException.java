package br.com.calcard.calsystem.exception.voucher;

public class VoucherInvalidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2959276686214682361L;

	public VoucherInvalidoException() {
		super();
	}

	public VoucherInvalidoException(String mensagem) {
		super(mensagem);
	}

}
