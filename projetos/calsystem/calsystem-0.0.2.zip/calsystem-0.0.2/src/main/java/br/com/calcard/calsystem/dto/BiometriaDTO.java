package br.com.calcard.calsystem.dto;

import java.io.Serializable;

public class BiometriaDTO implements Serializable {

	private String fotoBase64;
	
	private String cpfBiometria;

	public BiometriaDTO() {
		super();
	}

	public BiometriaDTO(String fotoBase64, String cpfBiometria) {
		super();
		this.fotoBase64 = fotoBase64;
		this.cpfBiometria = cpfBiometria;
	}



	public String getFotoBase64() {
		return fotoBase64;
	}

	public void setFotoBase64(String fotoBase64) {
		this.fotoBase64 = fotoBase64;
	}

	public String getCpfBiometria() {
		return cpfBiometria;
	}

	public void setCpfBiometria(String cpfBiometria) {
		this.cpfBiometria = cpfBiometria;
	}
	
	

}
