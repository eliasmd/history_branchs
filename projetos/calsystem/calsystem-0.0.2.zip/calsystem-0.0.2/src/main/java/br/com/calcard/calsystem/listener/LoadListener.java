package br.com.calcard.calsystem.listener;

import org.springframework.beans.factory.annotation.Autowired;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calsystem.interfaces.IParametroGlobal;

public class LoadListener {

	private IParametroGlobal parametroGlobalService;

	@Autowired
	public LoadListener(IParametroGlobal parametroGlobalService) {
		this.parametroGlobalService = parametroGlobalService;
	}

	public void init() throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		this.doCarregarParametrosGlobais();

	}

	private void doCarregarParametrosGlobais()
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		this.parametroGlobalService.doCarregarParametrosGlobais();

	}

}
