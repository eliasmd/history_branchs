package br.com.calcard.calsystem.ws;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calsystem.facade.DigitalizacaoFacadeWS;
import br.com.calcard.calsystem.util.Parametro;

@RestController
@RequestMapping("/ws/digitalizacao")
@Scope(value = "request")
public class DigitalizacaoWS extends CalsystemWS {

	private DigitalizacaoFacadeWS digitalizacaoFacadeWS;

	@Autowired
	public DigitalizacaoWS(DigitalizacaoFacadeWS digitalizacaoFacadeWS) {
		super();
		this.digitalizacaoFacadeWS = digitalizacaoFacadeWS;
	}

	@RequestMapping(value = "/listarProcessos", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarProcessos(
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(tSessao);

		return this.digitalizacaoFacadeWS.doListarProcessosDigitalizacao();

	}

	@RequestMapping(value = "/listarTiposDocumentosDigitalizaveis", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarTiposDocumentosDigitalizaveis(
			@RequestParam(value = "idProcesso", required = true) Integer idProcesso,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(tSessao,
				new Parametro().doAddParametro("idProcesso", idProcesso)
						.getParametros());

		return this.digitalizacaoFacadeWS
				.doListarTiposDocumentosDigitalizaveis(idProcesso);

	}

	@RequestMapping(value = "/listarMiniaturas", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarMiniaturas(
			@RequestParam(value = "cpf", required = true) String cpf,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(tSessao, new Parametro().doAddParametro("cpf", cpf)
				.getParametros());

		return this.digitalizacaoFacadeWS.doListarMiniaturas(cpf);

	}

	@RequestMapping(value = "/descartarDocumentos", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doDescartarDocumentos(
			@RequestHeader(value = "tSessao") String tSessao,
			@RequestParam(value = "idDocumento", required = true) Integer idDocumento) {
		super.doGravarLog(tSessao);

		return this.digitalizacaoFacadeWS.doDescartarDocumentos(idDocumento);

	}

	@RequestMapping(value = "/alterarTipoDocumento", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doAlterarTipoDocumento(
			@RequestHeader(value = "tSessao") String tSessao,
			@RequestParam(value = "idTipoDocumento", required = true) Integer idTipoDocumento,
			@RequestParam(value = "idDocumento", required = true) Integer idDocumento) {
		super.doGravarLog(
				tSessao,
				new Parametro()
						.doAddParametro("idTipoDocumento", idTipoDocumento)
						.doAddParametro("idDocumento", idDocumento)
						.getParametros());

		return this.digitalizacaoFacadeWS.doAlterarTipoDocumento(
				idTipoDocumento, idDocumento);

	}

}
