package br.com.calcard.calsystem.helper;

import br.com.calcard.calsystem.dto.TelefoneDTO;
import br.com.calcard.calsystem.exception.TelefoneException;

public class TelefonePropostaHelper {

	public void doValidarTelefone(TelefoneDTO telefoneDTO)
			throws TelefoneException {

		if (telefoneDTO == null)
			throw new TelefoneException("Telefone n�o informado!");

		if (telefoneDTO.getDddEnum() == null)
			throw new TelefoneException("DDD do telefone n�o informado!");

		if (telefoneDTO.getNumero() == null)
			throw new TelefoneException("N�mero do telefone n�o informado!");

	}

}
