package br.com.calcard.calsystem.helper;

import java.util.ArrayList;
import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.entity.RegraDigitalizacao;
import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;
import br.com.calcard.calsystem.enums.Enum.StatusPadraoEnum;
import br.com.calcard.calsystem.exception.documento.DigitalizacaoException;
import br.com.calcard.calsystem.exception.proposta.PropostaDocumentosDigitalizadosException;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;

public class DocumentosDigitalizadosPropostaHelper {

	private IDigitalizacao digitalizacaoService;

	public DocumentosDigitalizadosPropostaHelper(
			IDigitalizacao digitalizacaoService) {
		this.digitalizacaoService = digitalizacaoService;
	}

	public List<DocumentoDigitalizado> doCarregarDocumentosDigitalizados(
			List<RegraDigitalizacao> regrasDigitalizacao,
			List<DocumentoDigitalizadoDTO> documentosDigitalizadosDTO)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, DigitalizacaoException,
			PropostaDocumentosDigitalizadosException, ServiceException {

		if (regrasDigitalizacao == null || regrasDigitalizacao.size() == 0)
			throw new CalsystemInvalidArgumentException(
					"Tipos de documentos existentes n�o informados!");

		if (documentosDigitalizadosDTO == null
				|| documentosDigitalizadosDTO.size() == 0)
			throw new CalsystemInvalidArgumentException(
					"Documentos digitalizados n�o informados!");

		List<DocumentoDigitalizado> documentosDigitalizados = new ArrayList<DocumentoDigitalizado>();

		for (DocumentoDigitalizadoDTO documentoDigitalizadoDTO : documentosDigitalizadosDTO) {

			if (documentoDigitalizadoDTO.getIdTipoDocumento() == null)
				throw new CalsystemInvalidArgumentException(
						"Id do tipo do documento n�o informado!");

			if (CalsystemUtil.isNull(documentoDigitalizadoDTO.getNomeArquivo()))
				throw new CalsystemInvalidArgumentException(
						"Nome do arquivo n�o informado!");

			String base64 = this.digitalizacaoService
					.doConverterBase64(documentoDigitalizadoDTO
							.getNomeArquivo());

			// Valida se os documentos digitalizados s�o necess�rios
			boolean achou = false;
			TipoDocumentoDigitalizado documentoDigitalizado = null;
			for (int x = 0; x < regrasDigitalizacao.size(); x++) {

				if (regrasDigitalizacao.get(x).getTipoDocumentoDigitalizavel()
						.getId()
						.equals(documentoDigitalizadoDTO.getIdTipoDocumento())) {
					achou = true;
					documentoDigitalizado = regrasDigitalizacao.get(x)
							.getTipoDocumentoDigitalizavel();
					regrasDigitalizacao.remove(x);
				}

			}

			if (!achou)
				throw new PropostaDocumentosDigitalizadosException(
						new StringBuilder(
								"Tipo de documento definido � inv�lido! ID TIPO DOCUMENTO: ")
								.append(documentoDigitalizadoDTO
										.getIdTipoDocumento())
								.append(" NOME ARQUIVO: ")
								.append(documentoDigitalizadoDTO
										.getNomeArquivo()).toString());
			
			

			documentosDigitalizados.add(new DocumentoDigitalizado(
					documentoDigitalizado, "cpf", base64, StatusPadraoEnum.ATIVO, null));


		}

		for (RegraDigitalizacao regra : regrasDigitalizacao) {
			if (regra.getDigitalizacaoObrigatoria())
				throw new PropostaDocumentosDigitalizadosException(
						new StringBuilder(
								"Documento obrigat�rio n�o digitalizado!")
								.append(regra.getTipoDocumentoDigitalizavel()
										.getNome()).toString());
		}

		return documentosDigitalizados;

	}

}
