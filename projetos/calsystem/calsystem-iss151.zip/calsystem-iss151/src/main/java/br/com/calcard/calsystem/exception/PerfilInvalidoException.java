package br.com.calcard.calsystem.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class PerfilInvalidoException extends CalsystemException {

	private static final long serialVersionUID = 6848502627201991059L;

	public PerfilInvalidoException(String mensagem) {
		super(mensagem);
	}

}
