package br.com.calcard.calsystem.interfaces;

import java.io.File;
import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.DocumentDTO;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.entity.RegraDigitalizacao;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;
import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;
import br.com.calcard.calsystem.exception.DocumentoDigitalizadoInvalido;
import br.com.calcard.calsystem.exception.TipoDocumentoDigitalizadoInvalido;
import br.com.calcard.calsystem.exception.documento.DigitalizacaoException;

public interface IDigitalizacao {

	public File doConsultarArquivoRede(String nomeArquivo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public String doConverterBase64(String nomeArquivo)
			throws DigitalizacaoException, CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException, ServiceException;

	public List<DocumentoDigitalizadoDTO> doListarMiniaturas(String nomeArquivo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, ServiceException;

	public void doDescartarDocumentos(Integer idDocumento)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public List<RegraDigitalizacao> doListarTiposDocumentosDigitalizaveis(
			Integer idProcesso) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public DocumentoDigitalizado doAlterarTipoDocumento(
			Integer idTipoDocumento, Integer idDocumento)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException, DocumentoDigitalizadoInvalido,
			TipoDocumentoDigitalizadoInvalido;

	public List<DocumentoDigitalizadoDTO> doListarDocumentosDigitalizados(
			String cpf) throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, ServiceException;

	public void doDescartarDocumento(String nomeDocumento)
			throws CalsystemNoDataFoundException;

	public List<DocumentDTO> doConsultarDocumentosDigitalizados(Integer creditRequestId) throws IntegracaoException, 
																						 CalsystemInvalidArgumentException, 
																						 ServiceException, 
																						 IntegracaoMotorBiometriaException;

	public TipoDocumentoDigitalizado doConsultarTipoDocumentoDigitalizado(Integer id,
																	      boolean validarRetornoNull, 
																	      String mensagemRetornoNull,
																	      String mensagemIdNull) throws CalsystemNoDataFoundException,
																	   		   						    CalsystemInvalidArgumentException;

}
