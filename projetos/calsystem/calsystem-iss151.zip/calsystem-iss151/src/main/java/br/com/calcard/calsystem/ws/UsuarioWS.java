package br.com.calcard.calsystem.ws;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.interfaces.ICalsystemLog;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calsystem.dto.UsuarioDTO;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.facade.UsuarioFacadeWS;
import br.com.calcard.calsystem.interfaces.IEstabelecimento;
import br.com.calcard.calsystem.interfaces.IUsuario;
import br.com.calcard.calsystem.util.Parametro;

@RestController
@RequestMapping("/ws/usuarios")
@Scope(value = "request")
public class UsuarioWS extends CalsystemWS {

	private UsuarioFacadeWS usuarioFacadeWs;

	private IEstabelecimento estabelecimentoService;

	private IUsuario usuarioService;

	@Autowired
	public UsuarioWS(UsuarioFacadeWS usuarioFacadeWs,
			IEstabelecimento estabelecimentoService, 
			IUsuario usuarioService,
			  ICalsystemLog 			logService) {
		
		super(logService);

		this.usuarioFacadeWs = usuarioFacadeWs;
		this.estabelecimentoService = estabelecimentoService;
		this.usuarioService = usuarioService;
	}

	@RequestMapping(value = "/estabelecimento/{id}/listar", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doListar(@PathVariable Integer id) {

		return this.usuarioFacadeWs.doListarUsuariosPorEstabelecimento(id);

	}

	@RequestMapping(value = "/adicionar", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doAdicionar(
			@RequestBody Map<String, String> requestBody) {

		return null;
	}

	/**
	 * Servi�o respons�vel por listar todos os Estabelecimentos vinculados a um
	 * determinado Usu�rio.
	 * 
	 * @param id
	 *            Id do Usu�rio consultado
	 * @return
	 */
	@RequestMapping(value = "/{id}/estabelecimentos", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doListarEstabelecimentos(
			@PathVariable("id") Integer id,
			@RequestHeader(value = "tSessao") String tSessao) {
		try {
			
			super.logService.setTokenSessao(tSessao);
			
			super.doGravarLog(new Parametro().doAddParametro("id", id)
					.getParametros());

			List<Estabelecimento> estabelecimentos = this.estabelecimentoService
					.doListarEstabelecimentosPorUsuario(id);

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Estabelecimentos", estabelecimentos).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	@Transactional
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doConsultarUsuario(
			@PathVariable("id") Integer idUsuario,
			@RequestHeader(value = "tSessao") String tSessao) {
		try {
			
			super.logService.setTokenSessao(tSessao);
			
			super.doGravarLog(new Parametro().doAddParametro("id", idUsuario)
							.getParametros());

			Usuario usuario = this.usuarioService.doConsultarUsuarioPorId(idUsuario);

			UsuarioDTO usuarioDTO = new UsuarioDTO(usuario.getId(),
												   usuario.getLogin(), 
												   usuario.getNome(), 
												   usuario.getPerfil().getId(), 
												   CalsystemUtil.doMascararCPF(usuario.getCpf()), 
												   usuario.getDataRegistro());

			return super.doRetornarSucessoWS(new Parametro().doAddParametro("Usuario", usuarioDTO).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}
}
