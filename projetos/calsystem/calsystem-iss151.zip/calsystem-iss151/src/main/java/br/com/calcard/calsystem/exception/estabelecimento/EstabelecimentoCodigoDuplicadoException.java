package br.com.calcard.calsystem.exception.estabelecimento;

import br.com.calcard.calframework.exception.CalsystemException;

public class EstabelecimentoCodigoDuplicadoException extends CalsystemException {

	private static final long serialVersionUID = -6850248912549662555L;

	public EstabelecimentoCodigoDuplicadoException(String mensagem) {
		super(mensagem);
	}

}
