package br.com.calcard.calsystem.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import br.com.calcard.calframework.entity.CalsystemEntity;

@Entity
@NamedQueries({@NamedQuery(name = AnalisePendenciaAlteracaoSenha.NQ_SELECT_PENDENCIA_ALTERACAO_SENHA, 
						   query = "select a from AnalisePendenciaAlteracaoSenha a where a.alteracaoSenha = :alteracaoSenha") })
@Table(name = "tbl_analise_pendencia_alteracao_senha", 
	   uniqueConstraints = @UniqueConstraint(columnNames = {AnalisePendenciaAlteracaoSenha.COLUNA_ALTERACAO_SENHA}, 
	   								         name = "UK_LOCK_ANALISE"))
public class AnalisePendenciaAlteracaoSenha extends CalsystemEntity {

	private static final long serialVersionUID = -205419571267730149L;
	
	public static final String NQ_SELECT_PENDENCIA_ALTERACAO_SENHA = "NQPendenciaAlteracaoSenha";
	
	public static final String COLUNA_DATA_INICIO 		= "data_inicio";
	public static final String COLUNA_DATA_FIM 			= "data_fim";
	public static final String COLUNA_ANALISTA 			= "id_analista";
	public static final String COLUNA_PARECER 			= "parecer";
	public static final String COLUNA_ALTERACAO_SENHA 	= "id_alteracao_senha";
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = COLUNA_DATA_INICIO, unique = false, nullable = false)
	protected Date dataInicio;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = COLUNA_DATA_FIM, unique = false, nullable = true)
	protected Date dataFim;
	
	@ManyToOne
	@JoinColumn(name = COLUNA_ANALISTA,  nullable = false, unique = false)
	private Usuario analista;
	
	@Column(name = COLUNA_PARECER, length = 200, nullable = true, unique = false)
	private String parecer;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = COLUNA_ALTERACAO_SENHA, nullable = false,  unique = true)
	private AlteracaoSenha alteracaoSenha;
	
	public AnalisePendenciaAlteracaoSenha() {
		super();
	}

	public AnalisePendenciaAlteracaoSenha(Date dataInicio,
										  Date dataFim,
										  Usuario analista,
										  String parecer,
										  AlteracaoSenha alteracaoSenha) {
		super();
		this.dataInicio 	= dataInicio;
		this.dataFim 		= dataFim;
		this.analista 		= analista;
		this.parecer 		= parecer;
		this.alteracaoSenha = alteracaoSenha;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	public Usuario getAnalista() {
		return analista;
	}

	public void setAnalista(Usuario analista) {
		this.analista = analista;
	}

	public String getParecer() {
		return parecer;
	}

	public void setParecer(String parecer) {
		this.parecer = parecer;
	}

	public AlteracaoSenha getAlteracaoSenha() {
		return alteracaoSenha;
	}

	public void setAlteracaoSenha(AlteracaoSenha alteracaoSenha) {
		this.alteracaoSenha = alteracaoSenha;
	}

}
