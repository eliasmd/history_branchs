package br.com.calcard.calsystem.interfaces;

import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calsystem.entity.Usuario;

public interface IUsuario {

	public Usuario doConsultarByLogin(String loginUsuario)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public List<Usuario> doListarUsuariosPorEstabelecimento(
			Integer idEstabelecimento)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public Usuario doConsultarUsuarioPorId(Integer id)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public Usuario doConsultarUsuarioPorId(Integer idUsuario,
			boolean validarRetornoNull, String mensagemRetornoNull,
			String mensagemIdUsuarioNull) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

}
