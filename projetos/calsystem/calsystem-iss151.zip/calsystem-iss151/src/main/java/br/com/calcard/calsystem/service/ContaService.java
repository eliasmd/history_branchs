package br.com.calcard.calsystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.processadora.exception.IntegracaoProcessadoraException;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.ContaCartao;
import br.com.calcard.calintegrador.processadora.interfaces.IProcessadoraIntegracao;
import br.com.calcard.calsystem.dto.ContaDTO;
import br.com.calcard.calsystem.interfaces.IConta;

@Service
public class ContaService implements IConta {

	private IProcessadoraIntegracao integracaoProcessadoraService;

	@Autowired
	public ContaService(IProcessadoraIntegracao integracaoProcessadoraService) {
		this.integracaoProcessadoraService = integracaoProcessadoraService;
	}

	public ContaService() {
		super();
	}

	@Override
	public List<ContaDTO> doConsultarContas(String cpf, Integer idConta)
			throws IntegracaoProcessadoraException, IntegracaoException,
			CalsystemInvalidArgumentException {

		// caso nenhum parametro seja informado devera retornar todas as contas
		// cadastradas no dia (regra no WS Conductor)
		/*
		 * if ( CalsystemUtil.isNull(cpf) && CalsystemUtil.isNull(idConta) )
		 * throw new IntegracaoException(
		 * "CPF ou ID da Conta devem ser informados!");
		 */

		List<ContaCartao> contas = this.integracaoProcessadoraService
				.doConsultarContasProcessadora(cpf, idConta);

		List<ContaDTO> ContasDTO = doComporContasDTO(contas);

		return ContasDTO;
	}

	private List<ContaDTO> doComporContasDTO(List<ContaCartao> contas) {

		List<ContaDTO> ContasDTO = new ArrayList<ContaDTO>();

		for (int i = 0; i < contas.size(); i++) {
			ContaDTO contaDTO = new ContaDTO();

			contaDTO.setCpf(contas.get(i).getCPF());
			contaDTO.setId(contas.get(i).getIDConta());
			contaDTO.setNome(contas.get(i).getNome());
			contaDTO.setStatus(Integer.toString(contas.get(i).getStatusConta()));

			ContasDTO.add(contaDTO);
		}

		return ContasDTO;

	}

}
