package br.com.calcard.calsystem.interfaces;

import java.util.List;

import br.com.calcard.calframework.exception.CalsystemDAOException;

public interface IDAO {

	public List<? extends Object> doList(Class<?> clazz) throws CalsystemDAOException;

}
