package br.com.calcard.calsystem.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class LojistaNaoEncontradoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4262338175259782582L;

	public LojistaNaoEncontradoException(String mensagem) {
		super(mensagem);
	}

}
