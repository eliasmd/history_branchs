package br.com.calcard.calsystem.interfaces;

import br.com.calcard.calframework.exception.CalsystemDAOException;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calsystem.dto.proposta.PropostaDTO;
import br.com.calcard.calsystem.entity.proposta.Proposta;
import br.com.calcard.calsystem.exception.documento.DigitalizacaoException;
import br.com.calcard.calsystem.exception.proposta.DadosComplementaresException;
import br.com.calcard.calsystem.exception.proposta.DadosProfissionaisException;
import br.com.calcard.calsystem.exception.proposta.DadosResidenciaisException;
import br.com.calcard.calsystem.exception.proposta.OutrosDocumentosException;
import br.com.calcard.calsystem.exception.proposta.PropostaDocumentosDigitalizadosException;
import br.com.calcard.calsystem.exception.proposta.PropostaException;
import br.com.calcard.calsystem.exception.proposta.ReferenciaException;

public interface IProposta {

	public Proposta doIniciarCadastroProposta()
			throws CalsystemInvalidArgumentException;

	public Proposta doCadastrarPropostaP1(PropostaDTO propostaDTO)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException, PropostaException,
			IntegracaoException, ServiceException,
			IntegracaoMotorBiometriaException;

	public Proposta doCadastrarPropostaP2(PropostaDTO propostaDTO)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, PropostaException,
			DadosComplementaresException, OutrosDocumentosException,
			DadosResidenciaisException, DadosProfissionaisException,
			ReferenciaException, DigitalizacaoException,
			PropostaDocumentosDigitalizadosException, ServiceException,
			CalsystemDAOException, IntegracaoException,
			IntegracaoMotorBiometriaException;

}
