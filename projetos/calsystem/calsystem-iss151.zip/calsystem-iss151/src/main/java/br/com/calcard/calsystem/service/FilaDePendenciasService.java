package br.com.calcard.calsystem.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.PersistenceException;

import org.apache.commons.lang.time.DurationFormatUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.interfaces.ICalsystemLog;
import br.com.calcard.calframework.service.CalsystemService;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.DocumentDTO;
import br.com.calcard.calintegrador.motorBiometria.enums.StatusSolicitacaoDeCredito;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calsystem.dto.AnaliseBiometriaDTO;
import br.com.calcard.calsystem.dto.AnalisePendenciaAlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.AnalisePendenciaDTO;
import br.com.calcard.calsystem.dto.DocumentoDTO;
import br.com.calcard.calsystem.dto.PendenciaAlteracaoSenhaDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.AnalisePendenciaAlteracaoSenha;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;
import br.com.calcard.calsystem.enums.StatusSolicitacaoEnum;
import br.com.calcard.calsystem.interfaces.IBiometria;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;
import br.com.calcard.calsystem.interfaces.IFilaPendencia;
import br.com.calcard.calsystem.util.Parametro;

@Service
public class FilaDePendenciasService extends CalsystemService implements IFilaPendencia {

	private ICalsystemDAO daoService;
	
	private IBiometria biometriaService;

	private IDigitalizacao digitalizacaoService;
	
	private IMotorBiometria motorBiometriaService;
	
	@Autowired
	public FilaDePendenciasService(ICalsystemDAO daoService,
								   IBiometria biometriaService,
								   IDigitalizacao digitalizacaoService,
								   IMotorBiometria motorBiometriaService,
								   ICalsystemLog logService) {
		
		super(logService);
		
		this.daoService 			= daoService;
		this.biometriaService 		= biometriaService;
		this.digitalizacaoService	= digitalizacaoService;
		this.motorBiometriaService  = motorBiometriaService;

	}

	@Override
	public List<String> doListarStatusFilaDePendencia() {
		//super.logService.doGravarLogService();
		
		List<String> lista = new ArrayList<String>();
		
		for (StatusSolicitacaoEnum status : StatusSolicitacaoEnum.values()) {
			lista.add(status.getCodigo());
		}

		return lista;

	}

	@Transactional
	@Override
	public List<AlteracaoSenha> doListarFilaDePendencia(String status,
														String cpf) throws CalsystemNoDataFoundException,
																		   CalsystemInvalidArgumentException {
		
		super.logService.doGravarLogService(new Parametro("status", status)
												.doAddParametro("cpf", cpf).getParametros());
		
		if (status == null)
			throw new CalsystemInvalidArgumentException(
					"Campo Status deve ser informado!");

		Criteria criteria = this.daoService.doGetCriteria(AlteracaoSenha.class);

		if (status != null) {
			criteria.add(Restrictions.eq(AlteracaoSenha.COLUNA_STATUS, status));
		}

		if (cpf != null) {
			criteria.add(Restrictions.eq(AlteracaoSenha.COLUNA_CPF_PORTADOR, cpf));
		}

		List<AlteracaoSenha> listaAlteracaoSenha = this.daoService.doList(criteria, true, "Nenhuma Pend�ncia Encontrada!");

		return listaAlteracaoSenha;

	}
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public AnalisePendenciaAlteracaoSenha doAnalisarPendencia(AnalisePendenciaDTO analisePendenciaDTO) throws CalsystemInvalidArgumentException, 
																											  CalsystemNoDataFoundException, 
																											  ServiceException {
		
		super.logService.doGravarLogService(new Parametro("analisePendenciaDTO", analisePendenciaDTO).getParametros());
		
		if (analisePendenciaDTO == null)
			throw new CalsystemInvalidArgumentException(
					"Par�metros da Pend�ncia n�o foram informados!");

		Usuario analista = this.daoService.doRead(analisePendenciaDTO.getAnalista().getId(), 
												  Usuario.class, 
												  true, 
												  new StringBuilder("N�o foi encontrado nenhum Analista para o ID informado! ID: ")
												  		.append(analisePendenciaDTO.getAnalista().getId()).toString(),
												  "ID do Analista n�o informado!");

		AlteracaoSenha alteracaoSenha = this.daoService.doRead(analisePendenciaDTO.getIdAlteracaoSenha(),
															   AlteracaoSenha.class,
															   true,
															   new StringBuilder("N�o foi encontrado nenhuma Altera��o de Senha para o ID informado! ID: ")
																	.append(analisePendenciaDTO.getIdAlteracaoSenha()).toString(),
															   "ID da Altera��o de Senha n�o informado!");
		
		alteracaoSenha.setStatus(StatusSolicitacaoEnum.EM_ANALISE.getCodigo());
		
		this.daoService.doUpdate(alteracaoSenha);
		
		AnalisePendenciaAlteracaoSenha analisePendenciaAlteracaoSenha = new AnalisePendenciaAlteracaoSenha(new Date(), 
																										   null, 
																										   analista, 
																										   null, 
																										   alteracaoSenha);

		try {
			this.daoService.doCreate(analisePendenciaAlteracaoSenha);
			
		} catch (PersistenceException e) {
			throw new ServiceException("Proposta j� em an�lise pelo operador " + analista.getNome());
		}

		return analisePendenciaAlteracaoSenha;

	}

	public List<AnalisePendenciaAlteracaoSenha> doCarregarAnaliseIniciada(List<AlteracaoSenha> listaAlteracaoSenha) throws CalsystemNoDataFoundException,
																														   CalsystemInvalidArgumentException {

		super.logService.doGravarLogService(new Parametro("listaAlteracaoSenha", listaAlteracaoSenha).getParametros());
		
		List<AnalisePendenciaAlteracaoSenha> listaAnalisePendencia = new ArrayList<AnalisePendenciaAlteracaoSenha>();
			
	    for (AlteracaoSenha alteracaoSenha : listaAlteracaoSenha) {

	    	AnalisePendenciaAlteracaoSenha analisePendenciaAlteracaoSenha = this.daoService.doGetSingleResult(AnalisePendenciaAlteracaoSenha.NQ_SELECT_PENDENCIA_ALTERACAO_SENHA,
																				  							  new Parametro()
																												.doAddParametro("alteracaoSenha", alteracaoSenha).getParametros(),
																											  AnalisePendenciaAlteracaoSenha.class);

			listaAnalisePendencia.add(analisePendenciaAlteracaoSenha);

		}

		return listaAnalisePendencia;

	}

	public AlteracaoSenha doListarDocumentosAvaliacao(Integer idAlteracaoSenha) throws CalsystemNoDataFoundException,
																					   CalsystemInvalidArgumentException {
		
		super.logService.doGravarLogService(new Parametro("idAlteracaoSenha", idAlteracaoSenha).getParametros());

		AlteracaoSenha alteracaoSenha = this.daoService
				.doRead(idAlteracaoSenha,
						AlteracaoSenha.class,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhuma Altera��o de Senha para o ID informado! ID: ")
								.append(idAlteracaoSenha).toString(),
						"ID da Altera��o de Senha n�o informado!");

		return alteracaoSenha;

	}
	
	@Transactional(rollbackFor = Exception.class)
	public void doNegarPendenciaAlteracaoSenha(Integer idPendencia,
											   String parecer) throws CalsystemNoDataFoundException,
											   						  CalsystemInvalidArgumentException, 
											   						  IntegracaoException, 
											   						  ServiceException, 
											   						  IntegracaoMotorBiometriaException {		
		
		super.logService.doGravarLogService(new Parametro("idPendencia", idPendencia).doAddParametro("parecer", parecer).getParametros());
		
		AlteracaoSenha alteracaoSenha = this.daoService.doRead(idPendencia,
															   AlteracaoSenha.class,
															   true,
															   new StringBuilder("N�o foi encontrada nenhuma alteracao de senha com o ID informado! ID: ")
																	.append(idPendencia).toString(),
															   "ID da alteracao de senha n�o encontrado!");

		if( !alteracaoSenha.getStatus().equalsIgnoreCase(StatusSolicitacaoEnum.EM_ANALISE.getCodigo()) )
			throw new ServiceException(new StringBuilder("O status da pend�ncia n�o permite reprova��o! STATUS: ")
											.append(alteracaoSenha.getStatus()).toString());
		
		alteracaoSenha.setStatus(StatusSolicitacaoEnum.NEGADA.getCodigo());
		
		alteracaoSenha.getAnalisePendencia().setDataFim(new Date());
		
		alteracaoSenha.getAnalisePendencia().setParecer(parecer);
		
		this.daoService.doUpdate(alteracaoSenha);
		
		motorBiometriaService.doAlterarStatusSolicitacaoCredito(alteracaoSenha.getIdCreditRequest(), 
																StatusSolicitacaoDeCredito.INATIVO, 
																parecer);

	}
	

	@Transactional(rollbackFor = Exception.class)
	public void doAprovarPendencia(Integer idAlteracaoSenha) throws CalsystemInvalidArgumentException, 
																 	CalsystemNoDataFoundException, 
																 	IntegracaoException, 
																 	ServiceException, 
																 	IntegracaoMotorBiometriaException {
		
		super.logService.doGravarLogService(new Parametro("idAlteracaoSenha", idAlteracaoSenha).getParametros());
		
		if (idAlteracaoSenha == null)
			throw new CalsystemInvalidArgumentException("ID da altera��o de senha n�o informado!");
	
		AlteracaoSenha alteracaoSenha = this.daoService.doRead(idAlteracaoSenha,
															   AlteracaoSenha.class,
															   true,
															   new StringBuilder("N�o foi encontrado nenhuma solicita��o de alteracao de senha com o ID informado! ID: ")
																	.append(idAlteracaoSenha).toString(),
															   "ID da alteracao de senha n�o encontrado!");
		
		if (alteracaoSenha.getStatus().equals(StatusSolicitacaoEnum.EM_ANALISE.getCodigo())){
			
			alteracaoSenha.setStatus(StatusSolicitacaoEnum.APROVADA.getCodigo());
	
			alteracaoSenha.getAnalisePendencia().setDataFim(new Date());
			
			this.daoService.doUpdate(alteracaoSenha);
			
			this.biometriaService.doAlterarStatusSolicitacaoCredito(alteracaoSenha.getIdCreditRequest(), 
																	StatusSolicitacaoDeCredito.ATIVO, 
																	"Aprovado.");
			
		}else{
			
			throw new ServiceException(new StringBuilder("O status da pend�ncia n�o permite aprova��o! STATUS: ")
											.append(alteracaoSenha.getStatus()).toString());
		}
			
	}
	
	private StatusSolicitacaoEnum doConsultarStatusPedencia(String codigoStatus) throws CalsystemInvalidArgumentException{
		
		super.logService.doGravarLogService(new Parametro("codigoStatus", codigoStatus).getParametros());
		
		StatusSolicitacaoEnum status = null;
		
		for (StatusSolicitacaoEnum statusPendencia : StatusSolicitacaoEnum.values()){
			
			if (statusPendencia.getCodigo().equals(codigoStatus))
				status = statusPendencia;
			
		}
		
		if (status == null)
			throw new CalsystemInvalidArgumentException("Status n�o encontrado!");
		
		return status;
		
	}
	
	@Override
	@Transactional
	public List<AlteracaoSenha> doListarAlteracoesSenha(String codigoStatus, String cpf) throws CalsystemNoDataFoundException,
																	   				    	    CalsystemInvalidArgumentException {
		
		super.logService.doGravarLogService(new Parametro("codigoStatus", codigoStatus).doAddParametro("cpf", cpf).getParametros());
		
		StatusSolicitacaoEnum status = this.doConsultarStatusPedencia(codigoStatus);
		
		Criteria criteria = this.daoService.doGetCriteria(AlteracaoSenha.class, "alteracaoSenha");
		
		if (!status.equals(StatusSolicitacaoEnum.TODOS))
			criteria.add(Restrictions.eq("alteracaoSenha.status", status.getCodigo()));
		
		if (cpf != null)
			criteria.add(Restrictions.eq("alteracaoSenha.cpfPortador", cpf));
		
		if (status.equals(StatusSolicitacaoEnum.TODOS))
			criteria.addOrder(Order.desc("alteracaoSenha.dataRegistro"));
		else
			criteria.addOrder(Order.asc("alteracaoSenha.dataRegistro"));
		
		List<AlteracaoSenha> pendencias =  this.daoService.doList(criteria, false, null);
		
		return pendencias;

	}

	@Override
	@Transactional
	public AlteracaoSenha doConsultarPendenciaAlteracaoSenha(Integer idPendencia) throws CalsystemNoDataFoundException,
																						 CalsystemInvalidArgumentException {
		
		super.logService.doGravarLogService(new Parametro("idPendencia", idPendencia).getParametros());
		
		return this.daoService
				.doRead(idPendencia,
						AlteracaoSenha.class,
						true,
						new StringBuilder(
								"Nenhuma pend�ncia encontrada para o id informado! ID: ")
								.append(idPendencia).toString(),
						"Id da pendencia n�o informada!");

	}

	@Override
	public PendenciaAlteracaoSenhaDTO doComporPendenciaAlteracaoSenhaDTO(AlteracaoSenha alteracaoSenha) throws CalsystemInvalidArgumentException {
		
		//super.logService.doGravarLogService(new Parametro("alteracaoSenha", alteracaoSenha).getParametros());
		
		if(alteracaoSenha.getAnalisePendencia() != null)
			
			return new PendenciaAlteracaoSenhaDTO(alteracaoSenha.getId(), 
												  alteracaoSenha.getDataRegistro(),
												  alteracaoSenha.getAnalisePendencia().getDataInicio(), 
												  alteracaoSenha.getAnalisePendencia().getDataFim(),
												  alteracaoSenha.getAnalisePendencia().getAnalista().getId(), 
												  alteracaoSenha.getOperador().getId(), 
												  alteracaoSenha.getIdConta(),
												  alteracaoSenha.getCpfPortador(), 
												  alteracaoSenha.getAnalisePendencia().getParecer(), 
												  alteracaoSenha.getEstabelecimento().getId(), 
												  alteracaoSenha.getStatus(),
												  this.doCalcularTMA(alteracaoSenha.getAnalisePendencia().getDataInicio(), 
														  		     alteracaoSenha.getAnalisePendencia().getDataFim()),
												  this.doCalcularTME(alteracaoSenha.getDataRegistro(), 
														  			 alteracaoSenha.getAnalisePendencia().getDataInicio()),
												  alteracaoSenha.getIdCreditRequest());
			
		else {
			
			return new PendenciaAlteracaoSenhaDTO(alteracaoSenha.getId(), 
												  alteracaoSenha.getDataRegistro(),
												  null, 
												  null,
												  null,					  
												  alteracaoSenha.getOperador().getId(), 
												  alteracaoSenha.getIdConta(),
												  alteracaoSenha.getCpfPortador(), 
												  null, 
												  alteracaoSenha.getEstabelecimento().getId(),
												  alteracaoSenha.getStatus(),												  
												  this.doCalcularTMA(null, null),
												  this.doCalcularTME(alteracaoSenha.getDataRegistro(), 
														  			 null),
												  alteracaoSenha.getIdCreditRequest());
			
		}
		
	}
	
	private String doCalcularTME(Date dataRegistro, Date dataInicioAnalise) throws CalsystemInvalidArgumentException {
		
		Date dataFinal = null;

		if (dataRegistro == null)
			throw new CalsystemInvalidArgumentException("Data de registro n�o foi informada!");

		if (dataInicioAnalise == null)
			dataFinal = new Date();
		else
			dataFinal = dataInicioAnalise;

		long duracao = (dataFinal.getTime() - dataRegistro.getTime());

		return DurationFormatUtils.formatDuration(duracao, "H:mm:ss", true);

	}
	
	
	private String doCalcularTMA(Date dataInicioAnalise, Date dataFimAnalise){
		
		Date dataFinal = null;
		
		if (dataInicioAnalise == null)
			return "0:00:00";
		
		if (dataFimAnalise == null)
			dataFinal = new Date();
		else
			dataFinal = dataFimAnalise;	
			
		long duracao = (dataFinal.getTime() - dataInicioAnalise.getTime());
		
		return DurationFormatUtils.formatDuration(duracao, "H:mm:ss", true);
		
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public AnalisePendenciaAlteracaoSenhaDTO doIniciarAnalisePendenciaAlteracaoSenha(Integer idPendencia, 
																				  	 Usuario analista) throws CalsystemNoDataFoundException, 
																							     			  CalsystemInvalidArgumentException, 
																							     			  ServiceException, 
																							     			  IntegracaoException, 
																							     			  IntegracaoMotorBiometriaException {
		
		super.logService.doGravarLogService(new Parametro("idPendencia", idPendencia).doAddParametro("analista", analista).getParametros());
		
		AnalisePendenciaAlteracaoSenha analisePendenciaAlteracaoSenha = doCarregarAnaliseAlteracaoSenha(idPendencia, analista);
		
		AnaliseBiometriaDTO analiseBiometriaDTO = this.biometriaService
														.doConsultarAvaliacaoBiometrica(analisePendenciaAlteracaoSenha
																							.getAlteracaoSenha().getIdCreditRequest());
		
		List<TipoDocumentoDigitalizado> tiposDocumentosDigitalizados = this.daoService.doList(TipoDocumentoDigitalizado.class);
		
		List<DocumentoDTO> documentos = new ArrayList<DocumentoDTO>();		
		for (DocumentDTO document : this.digitalizacaoService
										.doConsultarDocumentosDigitalizados(analisePendenciaAlteracaoSenha.getAlteracaoSenha()
																				.getIdCreditRequest())){
			boolean encontrou = false;
			for (TipoDocumentoDigitalizado tipoDocumento : tiposDocumentosDigitalizados){
				
				if (tipoDocumento.getDocumentType().equals(document.getType())){
					
					encontrou = true;
					documentos.add(new DocumentoDTO(tipoDocumento.getId(), document.getImage()));
					break;
					
				}				
			}
			
			if (encontrou == false)
				throw new ServiceException(new StringBuilder("Tipo de documento n�o encontrado! DOCUMENTO_TYPE: ")
												.append(document.getType()).toString());
			
		}
		
		
		
		return new AnalisePendenciaAlteracaoSenhaDTO(analiseBiometriaDTO,
													 documentos);
		
	}

	private AnalisePendenciaAlteracaoSenha doCarregarAnaliseAlteracaoSenha(Integer idPendencia, 
																		   Usuario analista) throws CalsystemInvalidArgumentException,
																									CalsystemNoDataFoundException, 
																									ServiceException {
		
		super.logService.doGravarLogService(new Parametro("idPendencia", idPendencia).doAddParametro("analista", analista).getParametros());
		
		AlteracaoSenha alteracaoSenha = this.daoService.doRead(idPendencia,
															   AlteracaoSenha.class,
													           true,
													           new StringBuilder("N�o foi encontrado nenhuma pend�ncia de altera��o de senha para o ID informado! ID: ")
																	.append(idPendencia).toString(),
															   "Id da pendencia de altera��o de senha n�o informado!");	
				
		if (alteracaoSenha.getStatus().equals(StatusSolicitacaoEnum.PENDENTE.getCodigo())) {
			
			AnalisePendenciaAlteracaoSenha analisePendencia = new AnalisePendenciaAlteracaoSenha(new Date(), 
																				   				 null, 
																				   				 analista, 
																				   				 null, 
																				   				 alteracaoSenha);
			try {
				this.daoService.doCreate(analisePendencia);			
			} catch (PersistenceException e) {
				throw new ServiceException(new StringBuilder("Esta pend�ncia j� est� sendo analisada pelo operador ")
												.append(analista.getNome()).toString());
			}
			
			alteracaoSenha.setStatus(StatusSolicitacaoEnum.EM_ANALISE.getCodigo());
			
			this.daoService.doUpdate(alteracaoSenha);
			
			return analisePendencia;
		
						
		} else if (alteracaoSenha.getStatus().equals(StatusSolicitacaoEnum.EM_ANALISE.getCodigo())){
			
			if (alteracaoSenha.getAnalisePendencia().getAnalista().getId() != analista.getId()){
				throw new ServiceException(new StringBuilder("Esta pend�ncia j� est� sendo analisada pelo operador ")
					.append(alteracaoSenha.getAnalisePendencia().getAnalista().getNome()).toString());				
			} 
			
			return alteracaoSenha.getAnalisePendencia();
			
		} else {
			throw new ServiceException(new StringBuilder("O status atual da pend�ncia n�o possibilita an�lise! STATUS: ")
											.append(alteracaoSenha.getStatus()).toString());
		}
	}

	@Override
	@Transactional
	public AlteracaoSenha doRegistrarPendenciaAlteracaoSenha(Estabelecimento estabelecimento, 
														     Usuario operador, 
														     Integer idConta,
														     String cpfPortador,
														     String senha,
														     Integer idCreditRequest) throws CalsystemNoDataFoundException, 
														  								     CalsystemInvalidArgumentException {
		
		super.logService.doGravarLogService(new Parametro("estabelecimento", estabelecimento)
												.doAddParametro("operador", operador).doAddParametro("idConta", idConta)
													.doAddParametro("cpfPortador", cpfPortador).doAddParametro("senha", "****")
														.doAddParametro("idCreditRequest", idCreditRequest).getParametros());
		
		AlteracaoSenha pendenciaAlteracaoSenha = new AlteracaoSenha(StatusSolicitacaoEnum.PENDENTE.getCodigo(), 
																	estabelecimento, 
																	operador, 
																	idConta, 
																	cpfPortador, 
																	senha, 
																	idCreditRequest);

		return this.daoService.doCreate(pendenciaAlteracaoSenha);

	}


}
