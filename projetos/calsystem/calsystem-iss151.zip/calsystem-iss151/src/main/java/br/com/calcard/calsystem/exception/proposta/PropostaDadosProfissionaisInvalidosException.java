package br.com.calcard.calsystem.exception.proposta;

public class PropostaDadosProfissionaisInvalidosException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3281694723904937253L;

	public PropostaDadosProfissionaisInvalidosException(String mensagem) {
		super(mensagem);
	}

}
