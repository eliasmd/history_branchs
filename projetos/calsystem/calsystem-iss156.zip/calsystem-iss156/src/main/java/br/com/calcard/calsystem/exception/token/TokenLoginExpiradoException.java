package br.com.calcard.calsystem.exception.token;

import br.com.calcard.calframework.exception.CalsystemException;

public class TokenLoginExpiradoException extends CalsystemException {

	private static final long serialVersionUID = 7179728572735642814L;

	public TokenLoginExpiradoException(String mensagem) {
		super(mensagem);
	}

}
