package br.com.calcard.calsystem.enums;

public enum RespostaCrivoEnum {
	
	APROVADA(1, "APROVADA"),
	NEGADA(2, "NEGADA"),
	PENDENTE(3, "PENDENTE");
	
	private Integer id;
	
	private String codigo;
	
	private RespostaCrivoEnum(Integer id, String codigo) {
		this.id = id;
		this.codigo = codigo;
	}

	public Integer getId() {
		return id;
	}

	public String getCodigo() {
		return codigo;
	}
	
	
	
	
	
	
	
}
