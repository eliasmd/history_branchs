package br.com.calcard.calsystem.service;

import br.com.calcard.calframework.exception.EmailException;
import br.com.calcard.calframework.exception.NomeException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calsystem.dto.proposta.DadosComplementaresDTO;
import br.com.calcard.calsystem.entity.proposta.Proposta;
import br.com.calcard.calsystem.entity.proposta.PropostaP2;
import br.com.calcard.calsystem.entity.proposta.Telefone;
import br.com.calcard.calsystem.enums.PropostaEnum.FaturaPorEmailEnum;
import br.com.calcard.calsystem.enums.PropostaEnum.TipoTelefoneEnum;
import br.com.calcard.calsystem.enums.StatusPropostaEnum;
import br.com.calcard.calsystem.exception.proposta.DadosComplementaresException;
import br.com.calcard.calsystem.exception.proposta.PropostaException;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;

public class PropostaP2Helper {

	private IDigitalizacao digitalizacaoService;

	public PropostaP2Helper(IDigitalizacao digitalizacaoService) {

		this.digitalizacaoService = digitalizacaoService;

	}

	public void doValidarProposta(Proposta proposta) throws PropostaException {

		this.doValidarStatus(proposta.getStatus());

		if (proposta.getPropostaP2() != null)
			throw new PropostaException(new StringBuilder(
					"Proposta j� utilizada!").append(" STATUS: ")
					.append(proposta.getStatus()).toString());

		if (proposta.getPropostaP1() == null)
			throw new PropostaException(new StringBuilder(
					"Proposta P1 n�o encontrada!").append(" STATUS: ")
					.append(proposta.getStatus()).toString());

	}

	private void doValidarStatus(StatusPropostaEnum status)
			throws PropostaException {

		if (status == null)
			throw new PropostaException("Status da Proposta n�o informado!");

		if (!status.equals(StatusPropostaEnum.APROVADO_P1))
			throw new PropostaException("Proposta P1 n�o est� aprovada!");

	}

	public PropostaP2 doCarregarPropostaP2(
			DadosComplementaresDTO dadosComplementares)
			throws DadosComplementaresException {

		PropostaP2 propostaP2 = new PropostaP2();

		this.doValidarDadosComplementares(dadosComplementares);

		propostaP2.setVencimentoFatura(dadosComplementares
				.getVencimentoFaturaEnum());

		propostaP2.setFaturaPorEmail(dadosComplementares.getFaturaPorEmail());

		propostaP2.setEnderecoCorrespondencia(dadosComplementares
				.getEnderecoCorrespondenciaEnum());

		propostaP2.setEmail(dadosComplementares.geteMail());

		propostaP2.setEstadoCivil(dadosComplementares.getEstadoCivilEnum());

		propostaP2.setGrauInstrucao(dadosComplementares.getGrauInstrucaoEnum());

		propostaP2.setNacionalidade(dadosComplementares.getNacionalidadeEnum());

		propostaP2.setNaturalidade(dadosComplementares.getNaturalidade());

		propostaP2.setNomeMae(dadosComplementares.getNomeMae());

		propostaP2.setNomePai(dadosComplementares.getNomePai());

		propostaP2.setNumeroDependentes(dadosComplementares
				.getNumeroDependentes());

		propostaP2.setCelular(new Telefone(dadosComplementares
				.getTelefoneCelular().getDddEnum(), dadosComplementares
				.getTelefoneCelular().getNumero(), dadosComplementares
				.getTelefoneCelular().getRamal(), TipoTelefoneEnum.CELULAR));

		propostaP2.setUf(dadosComplementares.getUf());

		return propostaP2;

	}

	private void doValidarDadosComplementares(
			DadosComplementaresDTO dadosComplementaresDTO)
			throws DadosComplementaresException {

		if (dadosComplementaresDTO == null)
			throw new DadosComplementaresException(
					"Dados Complementares n�o informados!");

		if (dadosComplementaresDTO.getEnderecoCorrespondenciaEnum() == null)
			throw new DadosComplementaresException(
					"Endere�o de correspond�ncia n�o informado!");

		if (dadosComplementaresDTO.getVencimentoFaturaEnum() == null)
			throw new DadosComplementaresException(
					"Vencimento da fatura n�o informado!");

		if (dadosComplementaresDTO.getEstadoCivil() == null)
			throw new DadosComplementaresException(
					"Estado civil n�o informado!");

		if (dadosComplementaresDTO.getGrauInstrucaoEnum() == null)
			throw new DadosComplementaresException(
					"Grau de instru��o n�o informado!");

		if (dadosComplementaresDTO.getNacionalidadeEnum() == null)
			throw new DadosComplementaresException(
					"Nacionalidade n�o informada!");

		if (CalsystemUtil.isNull(dadosComplementaresDTO.getNaturalidade()))
			throw new DadosComplementaresException(
					"Naturalidade n�o informada!");

		if (CalsystemUtil.isNull(dadosComplementaresDTO.getNomeMae()))
			throw new DadosComplementaresException("Nome da m�e n�o informado!");

		try {
			CalsystemUtil.doValidarNome(dadosComplementaresDTO.getNomeMae());
		} catch (NomeException e) {
			throw new DadosComplementaresException("Nome da m�e inv�lido!", e);
		}

		if (!CalsystemUtil.isNull(dadosComplementaresDTO.geteMail())) {
			try {
				CalsystemUtil.doValidarEmail(dadosComplementaresDTO.geteMail());
			} catch (EmailException e) {
				throw new DadosComplementaresException("E-mail inv�lido!", e);
			}
		}

		if (dadosComplementaresDTO.getFaturaPorEmail().equals(
				FaturaPorEmailEnum.SIM)
				&& CalsystemUtil.isNull(dadosComplementaresDTO.geteMail())) {
			throw new DadosComplementaresException(
					"E-mail n�o informado para o recebimento da fatura!");
		}

		if (dadosComplementaresDTO.getUf() == null)
			throw new DadosComplementaresException(
					"UF dos dados complementares n�o informadab!");

		if (!CalsystemUtil.isNull(dadosComplementaresDTO.getNomePai())) {
			try {
				CalsystemUtil
						.doValidarNome(dadosComplementaresDTO.getNomePai());
			} catch (NomeException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

}
