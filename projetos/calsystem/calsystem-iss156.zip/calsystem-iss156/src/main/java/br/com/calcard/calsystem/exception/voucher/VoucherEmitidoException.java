package br.com.calcard.calsystem.exception.voucher;

public class VoucherEmitidoException extends VoucherException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5803023454509761826L;

}
