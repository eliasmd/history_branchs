package br.com.calcard.calsystem.exception.voucher;

public class VoucherNaoEncontradoException extends VoucherException {

	private static final long serialVersionUID = 4613946886201708614L;

}
