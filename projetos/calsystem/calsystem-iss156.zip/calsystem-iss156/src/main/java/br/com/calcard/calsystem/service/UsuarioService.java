package br.com.calcard.calsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.interfaces.IUsuario;
import br.com.calcard.calsystem.util.Parametro;

@Service
public class UsuarioService implements IUsuario {

	private ICalsystemDAO daoService;

	@Autowired
	public UsuarioService(ICalsystemDAO daoService) {
		this.daoService = daoService;
	}

	@Override
	public List<Usuario> doListarUsuariosPorEstabelecimento(
			Integer idEstabelecimento)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		Estabelecimento estabelecimento = this.daoService.doRead(
				idEstabelecimento, Estabelecimento.class, true,
				"Estabelecimento n�o encontrado!",
				"ID do estabelecimento n�o informado!");

		return this.daoService
				.doGetResultList(
						Usuario.NQ_SELECT_USUARIOS_BY_ESTABELECIMENTO,
						new Parametro().doAddParametro("estabelecimento",
								estabelecimento).getParametros(),
						Usuario.class,
						true,
						new StringBuilder()
								.append("Nenhum usu�rio vinculado ao Estabelecimento informado! ID Estabelecimento: ")
								.append(estabelecimento.getId()).toString());

	}

	@Override
	public Usuario doConsultarByLogin(String loginUsuario)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		if (loginUsuario == null)
			throw new CalsystemInvalidArgumentException(
					"Login do usu�rio n�o informado!");

		return this.daoService.doGetSingleResult(
				Usuario.NQ_SELECT_USUARIO_BY_LOGIN, new Parametro()
						.doAddParametro("login", loginUsuario).getParametros(),
				Usuario.class, true, "Usu�rio n�o encontrado!");

	}

	@Override
	@Transactional
	public Usuario doConsultarUsuarioPorId(Integer id)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		return this.doConsultarUsuarioPorId(id, true,
				new StringBuilder(
						"Nenhum usu�rio encontrado para o id informado! ID: ")
						.append(id).toString(), "Id do Usu�rio n�o informado!");

	}

	@Override
	@Transactional
	public Usuario doConsultarUsuarioPorId(Integer idUsuario,
			boolean validarRetornoNull, String mensagemRetornoNull,
			String mensagemIdUsuarioNull) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		return this.daoService.doRead(idUsuario, Usuario.class,
				validarRetornoNull, mensagemRetornoNull, mensagemIdUsuarioNull);

	}

}
