package br.com.calcard.calsystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemDAOException;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoAnexoDocumentosDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoEnvioFotoDTO;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calsystem.dto.proposta.DadosBasicosDTO;
import br.com.calcard.calsystem.dto.proposta.PropostaDTO;
import br.com.calcard.calsystem.entity.DocumentoDigitalizadoProposta;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.RegraDigitalizacao;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;
import br.com.calcard.calsystem.entity.proposta.Proposta;
import br.com.calcard.calsystem.entity.proposta.PropostaDadosProfissionais;
import br.com.calcard.calsystem.entity.proposta.PropostaDadosResidenciais;
import br.com.calcard.calsystem.entity.proposta.PropostaOutrosDocumentos;
import br.com.calcard.calsystem.entity.proposta.PropostaP1;
import br.com.calcard.calsystem.entity.proposta.PropostaP2;
import br.com.calcard.calsystem.entity.proposta.PropostaReferencia;
import br.com.calcard.calsystem.enums.StatusPropostaEnum;
import br.com.calcard.calsystem.exception.documento.DigitalizacaoException;
import br.com.calcard.calsystem.exception.proposta.DadosComplementaresException;
import br.com.calcard.calsystem.exception.proposta.DadosProfissionaisException;
import br.com.calcard.calsystem.exception.proposta.DadosResidenciaisException;
import br.com.calcard.calsystem.exception.proposta.OutrosDocumentosException;
import br.com.calcard.calsystem.exception.proposta.PropostaDocumentosDigitalizadosException;
import br.com.calcard.calsystem.exception.proposta.PropostaException;
import br.com.calcard.calsystem.exception.proposta.ReferenciaException;
import br.com.calcard.calsystem.helper.DadosProfissionaisPropostaHelper;
import br.com.calcard.calsystem.helper.DadosResidenciaisPropostaHelper;
import br.com.calcard.calsystem.helper.DocumentosDigitalizadosPropostaHelper;
import br.com.calcard.calsystem.helper.IntegracaoPropostaHelper;
import br.com.calcard.calsystem.helper.OutrosDocumentosPropostaHelper;
import br.com.calcard.calsystem.helper.PropostaHelper;
import br.com.calcard.calsystem.helper.ReferenciasPropostaHelper;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;

@Service
public class PropostaService {

	private ICalsystemDAO daoService;

	private IDigitalizacao digitalizacaoService;

	private IMotorBiometria motorBiometriaService;

	private PropostaHelper propostaHelper;

	@Autowired
	public PropostaService(ICalsystemDAO daoService,
			IDigitalizacao digitalizacaoService,
			IMotorBiometria motorBiometriaService) {
		this.daoService = daoService;
		this.digitalizacaoService = digitalizacaoService;
		this.motorBiometriaService = motorBiometriaService;

		this.propostaHelper = new PropostaHelper(digitalizacaoService);
	}

	@Transactional
	public Proposta doIniciarCadastroProposta()
			throws CalsystemInvalidArgumentException {

		Proposta proposta = new Proposta();

		proposta.setStatus(StatusPropostaEnum.INICIADO);

		return this.daoService.doCreate(proposta);

	}

	public void doEnviarPropostaMotorCredito(Proposta proposta)
			throws CalsystemInvalidArgumentException {

		proposta.setStatus(StatusPropostaEnum.APROVADO_P1);

		this.daoService.doUpdate(proposta);

	}

	@Transactional
	public Proposta doRegistrarPropostaP1(Integer idUsuario,
			Integer idEstabelecimento, Integer idProposta,
			DadosBasicosDTO dadosP1) throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, PropostaException {

		Proposta proposta = this.daoService.doRead(idProposta, Proposta.class,
				true, "Proposta n�o encontrada!",
				"ID da proposta n�o informada!");

		if (proposta.getPropostaP1() != null)
			throw new PropostaException(new StringBuilder(
					"Proposta j� utilizada!").append(" STATUS: ")
					.append(proposta.getStatus()).toString());

		if (!proposta.getStatus().equals(StatusPropostaEnum.INICIADO))
			throw new PropostaException(new StringBuilder(
					"Status da proposta inv�lido!").append(" STATUS: ")
					.append(proposta.getStatus()).toString());

		Usuario usuario = this.daoService
				.doRead(idUsuario, Usuario.class, true,
						"Usu�rio n�o encontrado!",
						"ID do usu�rio n�o informado!");

		Estabelecimento estabelecimento = this.daoService.doRead(
				idEstabelecimento, Estabelecimento.class, true,
				"Estabelecimento n�o encontrado!",
				"ID do estabelecimento n�o informado!");

		PropostaP1 propostaP1 = this.propostaHelper.doCarregarPropostaP1(
				dadosP1, usuario, estabelecimento, proposta);

		proposta.setStatus(StatusPropostaEnum.REGISTRADO_P1);

		proposta.setPropostaP1(propostaP1);

		return this.daoService.doUpdate(proposta);
	}

	public Proposta doCadastrarPropostaP2(PropostaDTO propostaDTO)
			throws CalsystemInvalidArgumentException, PropostaException,
			DadosComplementaresException, OutrosDocumentosException,
			DadosResidenciaisException, DadosProfissionaisException,
			ReferenciaException, DigitalizacaoException,
			PropostaDocumentosDigitalizadosException, ServiceException,
			CalsystemDAOException, IntegracaoException,
			IntegracaoMotorBiometriaException {

		if (propostaDTO == null)
			throw new CalsystemInvalidArgumentException(
					"Proposta n�o informada!");

		Proposta proposta = this.daoService.doRead(
				propostaDTO.getNumeroProposta(), Proposta.class, true,
				"Proposta n�o encontrada!", "Proposta n�o informada!");

		this.propostaHelper.doValidarProposta(proposta);

		PropostaP2 propostaP2 = this.propostaHelper
				.doCarregarPropostaP2(propostaDTO.getDadosComplementares());

		propostaP2.setProposta(proposta);

		PropostaOutrosDocumentos outrosDocumentos = new OutrosDocumentosPropostaHelper()
				.doCarregarOutrosDocumentos(propostaDTO.getOutrosDocumentos());

		outrosDocumentos.setPropostaP2(propostaP2);

		propostaP2.setOutrosDocumentos(outrosDocumentos);

		PropostaDadosResidenciais dadosResidenciais = new DadosResidenciaisPropostaHelper()
				.doCarregarDadosResidenciais(propostaDTO.getDadosResidenciais());

		dadosResidenciais.setPropostaP2(propostaP2);

		propostaP2.setDadosResidenciais(dadosResidenciais);

		PropostaDadosProfissionais dadosProfissionais = new DadosProfissionaisPropostaHelper()
				.doCarregarDadosProfissionais(propostaDTO
						.getDadosProfissionais());

		dadosProfissionais.setPropostaP2(propostaP2);

		propostaP2.setDadosProfissionais(dadosProfissionais);

		List<PropostaReferencia> referencias = new ReferenciasPropostaHelper()
				.doCarregarReferencias(propostaDTO.getReferencias());

		for (PropostaReferencia referencia : referencias)
			referencia.setPropostaP2(propostaP2);

		propostaP2.setReferencias(referencias);

		proposta.setPropostaP2(propostaP2);

		/*
		 * Valida e carrega os documentos digitalizados enviados
		 */
		List<RegraDigitalizacao> tiposDocumentosExistentes = this.daoService
				.doList(RegraDigitalizacao.class,
						true,
						"N�o foi encontrado nenhum tipo de documento de digitalizaç�o cadastrado no banco de dados!");

		List<DocumentoDigitalizado> documentosDigitalizados = new DocumentosDigitalizadosPropostaHelper(
				this.digitalizacaoService).doCarregarDocumentosDigitalizados(
				tiposDocumentosExistentes,
				propostaDTO.getDocumentosDigitalizados());

		List<DocumentoDigitalizadoProposta> documentosDigitalizadosProposta = new ArrayList<DocumentoDigitalizadoProposta>();

		for (DocumentoDigitalizado documentoDigitalizado : documentosDigitalizados) {

			documentosDigitalizadosProposta
					.add(new DocumentoDigitalizadoProposta(
							documentoDigitalizado, proposta));

		}

		proposta.setDocumentosDigitalizados(documentosDigitalizadosProposta);

		IntegracaoAnexoDocumentosDTO integracaoAnexoDocumentos = new IntegracaoMotorBiometriaPropostaHelper(
				this.motorBiometriaService).doAnexarDocumentos(
				documentosDigitalizados, null);

		// Integer idIntegracao = this.motorFraude.doEnviarProposta(dto);

		// Integer idIntegracao = null;
		// this.motorFraudeService
		// .doEnviarProposta(proposta);

		new IntegracaoPropostaHelper().doVincularIntegracao(proposta,
				integracaoAnexoDocumentos.getIntegracaoLogin()
						.getIdIntegracao(), integracaoAnexoDocumentos
						.getIdIntegracao(), integracaoAnexoDocumentos
						.getIntegracaoLogout().getIdIntegracao());

		proposta.setStatus(StatusPropostaEnum.PENDENTE_ENVIO_MOTOR_FRAUDE);

		return proposta;

	}

	@Transactional
	public void doEnviarPropostaMotorBiometria(Proposta proposta,
			String fotoBase64) throws IntegracaoException,
			CalsystemInvalidArgumentException, ServiceException,
			IntegracaoMotorBiometriaException {

		if (proposta.getPropostaP1().getCpf() == null)
			throw new CalsystemInvalidArgumentException("CPF n�o informado!");

		if (proposta.getPropostaP1().getEstabelecimento() == null)
			throw new CalsystemInvalidArgumentException(
					"Estabelcimento n�o informado!");

		if (proposta.getPropostaP1().getNome() == null)
			throw new CalsystemInvalidArgumentException("Nome n�o informado!");

		if (proposta.getPropostaP1().getDataNascimento() == null)
			throw new CalsystemInvalidArgumentException(
					"Data de nascimento n�o informada!");

		if (fotoBase64 == null)
			throw new CalsystemInvalidArgumentException("Foto n�o informada!");

		IntegracaoEnvioFotoDTO integracao = this.motorBiometriaService
				.doEnviarCreditRequest(
						proposta.getPropostaP1().getCpf(),
						"81",
						// proposta.getPropostaP1().getEstabelecimento().getId()
						// .toString(),
						proposta.getPropostaP1().getNome(), proposta
								.getPropostaP1().getDataNascimento(),
						fotoBase64);

		this.propostaHelper.doIncluirIntegracao(proposta, integracao
				.getIdIntegracao(), integracao.getIntegracaoLogin()
				.getIdIntegracao(), integracao.getIntegracaoLogout()
				.getIdIntegracao());

		this.daoService.doUpdate(proposta);

	}

}
