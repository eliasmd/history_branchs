package br.com.calcard.calsystem.dto;

import java.io.Serializable;

public class BiometriaDTO implements Serializable {

	private static final long serialVersionUID = 7331949316802799521L;

	private String fotoBase64;
	
	private String cpf;

	private String identificacao;
	
	private String similaridade;
	
	private String nome;

	public BiometriaDTO() {
		super();
	}

	public BiometriaDTO(String fotoBase64, 
						String cpf, 
						String identificacao,
						String similaridade,
						String nome) {
		super();
		this.fotoBase64 	= fotoBase64;
		this.cpf 			= cpf;
		this.identificacao 	= identificacao;
		this.similaridade 	= similaridade;
		this.nome 			= nome;
	}



	public String getFotoBase64() {
		return fotoBase64;
	}

	public void setFotoBase64(String fotoBase64) {
		this.fotoBase64 = fotoBase64;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getIdentificacao() {
		return identificacao;
	}

	public void setIdentificacao(String identificacao) {
		this.identificacao = identificacao;
	}

	public String getSimilaridade() {
		return similaridade;
	}

	public void setSimilaridade(String similaridade) {
		this.similaridade = similaridade;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	

}
