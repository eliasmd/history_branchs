package br.com.calcard.calsystem.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import br.com.calcard.calframework.entity.CalsystemEntity;

@Entity
@Table(name = "tbl_alteracao_senha")
public class AlteracaoSenha extends CalsystemEntity {

	private static final long serialVersionUID = 1151203777278843980L;

	private static final String COLUNA_ESTABELECIMENTO = "id_estabelecimento";

	private static final String COLUNA_OPERADOR = "operador";

	private static final String COLUNA_CONTA = "idConta";
	
	public static final String COLUNA_CPF_PORTADOR = "cpf_portador";

	public static final String COLUNA_SENHA = "senha";
	
	public static final String COLUNA_CREDIT_REQUEST = "id_credit_request";
	
	@Column(length = 30, name = COLUNA_STATUS, nullable = false, unique = false)
	private String status;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = COLUNA_ESTABELECIMENTO, nullable = false, unique = false)
	private Estabelecimento estabelecimento;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = COLUNA_OPERADOR, nullable = false, unique = false)
	private Usuario operador;
	
	@Column(name = COLUNA_CONTA, nullable = false, unique = false)
	private Integer idConta;
	
	@OneToOne(mappedBy = "alteracaoSenha", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private AnalisePendenciaAlteracaoSenha analisePendencia;
	
	@Column(name = COLUNA_CPF_PORTADOR, length = 11, nullable = false, unique = false)
	private String cpfPortador;

	@Column(name = COLUNA_SENHA, length = 4, nullable = false, unique = false)
	private String senha;

	@Column(name = COLUNA_CREDIT_REQUEST, nullable = false, unique = false)
	private Integer idCreditRequest;
	
	public AlteracaoSenha() {
	
	}
	
	public AlteracaoSenha(String status, 
						  Estabelecimento estabelecimento,
						  Usuario operador, 
						  Integer idConta, 
						  String cpfPortador,
						  String senha, 
						  Integer idCreditRequest) {
		super();
		this.status = status;
		this.estabelecimento = estabelecimento;
		this.operador = operador;
		this.idConta = idConta;
		this.cpfPortador = cpfPortador;
		this.senha = senha;
		this.idCreditRequest = idCreditRequest;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Estabelecimento getEstabelecimento() {
		return estabelecimento;
	}

	public void setEstabelecimento(Estabelecimento estabelecimento) {
		this.estabelecimento = estabelecimento;
	}

	public Usuario getOperador() {
		return operador;
	}

	public void setOperador(Usuario operador) {
		this.operador = operador;
	}

	public Integer getIdConta() {
		return idConta;
	}

	public void setIdConta(Integer idConta) {
		this.idConta = idConta;
	}

	public String getCpfPortador() {
		return cpfPortador;
	}

	public void setCpfPortador(String cpfPortador) {
		this.cpfPortador = cpfPortador;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public Integer getIdCreditRequest() {
		return idCreditRequest;
	}

	public void setIdCreditRequest(Integer idCreditRequest) {
		this.idCreditRequest = idCreditRequest;
	}

	public AnalisePendenciaAlteracaoSenha getAnalisePendencia() {
		return analisePendencia;
	}

	public void setAnalisePendencia(AnalisePendenciaAlteracaoSenha analisePendencia) {
		this.analisePendencia = analisePendencia;
	}

	
}
