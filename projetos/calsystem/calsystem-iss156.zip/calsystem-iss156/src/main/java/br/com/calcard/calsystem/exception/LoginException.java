package br.com.calcard.calsystem.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class LoginException extends CalsystemException {

	private static final long serialVersionUID = 3811090508481465607L;

	public LoginException(String mensagem) {
		super(mensagem);
	}

}
