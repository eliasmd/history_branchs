package br.com.calcard.calsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.ws.CalsystemServiceWS;
import br.com.calcard.calsystem.dto.DocumentoDTO;
import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;
import br.com.calcard.calsystem.interfaces.IDocumentoDigitalizado;

@Service
public class DocumentoDigitalizadoService extends CalsystemServiceWS implements
		IDocumentoDigitalizado {

	private ICalsystemDAO daoService;

	@Autowired
	public DocumentoDigitalizadoService(ICalsystemDAO daoService) {
		this.daoService = daoService;
	}

	@Override
	public void doValidarDocumento(List<DocumentoDTO> documentos)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		if (documentos == null)
			throw new CalsystemInvalidArgumentException(
					"Documentos n�o informados!");

		for (DocumentoDTO documento : documentos) {

			if (documento.getImagem() == null)
				throw new CalsystemInvalidArgumentException(
						"Imagem do documento n�o informada!");

			this.doConsultarTipoDocumentoDigitalizado(documento
					.getIdTipoDocumento(), true,
					new StringBuilder("Tipo de documento inv�lido! ID: ")
							.append(documento.getIdTipoDocumento()).toString(),
					"Id do tipo de documento n�o informado!");

		}

	}

	@Override
	public TipoDocumentoDigitalizado doConsultarTipoDocumentoDigitalizado(
			Integer id, boolean validarRetornoNull, String mensagemRetornoNull,
			String mensagemIdNull) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		return this.daoService.doRead(id, TipoDocumentoDigitalizado.class,
				validarRetornoNull, mensagemRetornoNull, mensagemIdNull);

	}
}
