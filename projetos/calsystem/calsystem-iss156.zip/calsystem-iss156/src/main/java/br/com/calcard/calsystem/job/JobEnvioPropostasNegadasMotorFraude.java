package br.com.calcard.calsystem.job;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import br.com.calcard.calframework.job.CalsystemJob;

public class JobEnvioPropostasNegadasMotorFraude extends CalsystemJob {

	@Override
	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException {

	}

}
