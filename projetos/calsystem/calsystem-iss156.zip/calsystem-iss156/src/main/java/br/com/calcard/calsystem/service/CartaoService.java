package br.com.calcard.calsystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calframework.ws.CalsystemServiceWS;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.DocumentDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoEnvioFotoDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoLoginDTO;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calintegrador.motorCredito.exception.IntegracaoMotorCreditoException;
import br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultEvalValuesXml;
import br.com.calcard.calintegrador.motorCredito.integracao.WS.ResultRespostasXml;
import br.com.calcard.calintegrador.motorCredito.interfaces.IMotorCredito;
import br.com.calcard.calintegrador.processadora.exception.IntegracaoProcessadoraException;
import br.com.calcard.calintegrador.processadora.integracao.ws.conta.CartaoConsulta;
import br.com.calcard.calintegrador.processadora.interfaces.IProcessadoraIntegracao;
import br.com.calcard.calintegrador.processadora.service.ProcessadoraIntegradorService;
import br.com.calcard.calsystem.dto.CartaoDTO;
import br.com.calcard.calsystem.dto.ContaDTO;
import br.com.calcard.calsystem.dto.DocumentoDTO;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.ParametroGlobal;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;
import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;
import br.com.calcard.calsystem.enums.Enum.StatusPadraoEnum;
import br.com.calcard.calsystem.enums.RespostaCrivoEnum;
import br.com.calcard.calsystem.enums.StatusSolicitacaoEnum;
import br.com.calcard.calsystem.interfaces.ICartao;
import br.com.calcard.calsystem.interfaces.IDocumentoDigitalizado;
import br.com.calcard.calsystem.interfaces.IEstabelecimento;
import br.com.calcard.calsystem.interfaces.IFilaPendencia;
import br.com.calcard.calsystem.interfaces.IParametroGlobal;
import br.com.calcard.calsystem.interfaces.IUsuario;
import br.com.calcard.calsystem.util.Parametro;

@Component
@Service
public class CartaoService extends CalsystemServiceWS implements ICartao {

	private ICalsystemDAO daoService;

	private IProcessadoraIntegracao integracaoProcessadoraService;

	private IMotorBiometria motorBiometriaService;

	private IProcessadoraIntegracao processadoraService;

	private IUsuario usuarioService;

	private IEstabelecimento estabelecimentoService;

	private IDocumentoDigitalizado documentoDigitalizadoService;
	
	private IMotorCredito motorCreditoService;
	
	private IParametroGlobal parametroGlobalService;

	private IFilaPendencia filaPendenciaService;

	@Autowired
	public CartaoService(ICalsystemDAO daoService,
			IMotorBiometria motorBiometriaService,
			IProcessadoraIntegracao processadoraService,
			IUsuario usuarioService, IEstabelecimento estabelecimentoService,
			IDocumentoDigitalizado documentoDigitalizadoService,
			IProcessadoraIntegracao integracaoProcessadoraService,
			IFilaPendencia filaPendenciaService,
			IMotorCredito motorCreditoService,
			IParametroGlobal parametroGlobalService) {

		this.daoService = daoService;
		this.motorBiometriaService = motorBiometriaService;
		this.processadoraService = processadoraService;
		this.usuarioService = usuarioService;
		this.estabelecimentoService = estabelecimentoService;
		this.documentoDigitalizadoService = documentoDigitalizadoService;
		this.integracaoProcessadoraService = integracaoProcessadoraService;
		this.filaPendenciaService = filaPendenciaService;
		this.motorCreditoService = motorCreditoService;
		this.parametroGlobalService = parametroGlobalService;
		
	}

	@Override
	public List<CartaoDTO> doListarCartoes(String cpf, String numeroCartao)
			throws CalsystemInvalidArgumentException {

		if (cpf == null && numeroCartao == null)
			throw new CalsystemInvalidArgumentException(
					"CPF ou N�mero do Cart�o precis�o ser informados!");

		List<CartaoDTO> cartoes = new ArrayList<CartaoDTO>();
		ContaDTO conta = null;
		CartaoDTO cartao = null;

		if (cpf == null || numeroCartao != null) {

			cpf = "13644256373";

			conta = new ContaDTO(1229, "Maria da Silva",
					CalsystemUtil.doMascararCPF(cpf), "NORMAL");

			cartao = new CartaoDTO(numeroCartao, "Maria da Silva", cpf, true,
					"NORMAL", conta);

			cartoes.add(cartao);
		}

		if (numeroCartao == null) {

			for (int i = 0; i < 2; i++) {

				// Titular da conta
				if (i == 0) {

					conta = new ContaDTO(8988, "Maria da Silva",
							CalsystemUtil.doMascararCPF(cpf), "NORMAL");

					cartao = new CartaoDTO("6364********0808",
							"Maria da Silva", CalsystemUtil.doMascararCPF(cpf),
							true, "NORMAL", conta);

					cartoes.add(cartao);

					// Depend�nte da conta
				} else if (i == 1) {

					conta = new ContaDTO(7655, "Jo�o Paulo",
							CalsystemUtil.doMascararCPF(cpf), "NORMAL");

					cartao = new CartaoDTO("6364********5632",
							"Maria da Silva", "897******76", false, "NORMAL",
							conta);

					cartoes.add(cartao);

				}

			}

		}

		return cartoes;

	}

	@Override
	@Transactional
	public List<CartaoDTO> doListarCartoesCadastroSenhaEDesbloqueio(String cpf,
			String numeroCartao) throws IntegracaoProcessadoraException,
			IntegracaoException, CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		// try {

		if (cpf == null && numeroCartao == null)
			throw new CalsystemInvalidArgumentException(
					"CPF ou N�mero do Cart�o n�o foram informados!");

		List<CartaoDTO> cartoesDTO = doComporCartoesDTO(this.integracaoProcessadoraService
				.doConsultarCartoesProcessadoraAsList(null, cpf, null, null,
						false, null));

		return cartoesDTO;

	}

	private List<CartaoDTO> doComporCartoesDTO(
			List<CartaoConsulta> cartaoConsulta) throws CalsystemInvalidArgumentException {

		List<CartaoDTO> cartoesDTO = new ArrayList<CartaoDTO>();

		CartaoDTO cartaoDTO = null;
		
		for (CartaoConsulta cartao : cartaoConsulta){
			
			cartaoDTO = new CartaoDTO(cartao.getNumCartao(),
									  cartao.getNomePortador(),
									  cartao.getCPFTitular(), 
									  cartao.getTitularidade().equalsIgnoreCase("S") ? true : false, 
									  Integer.toString(cartao.getStatusCartao()),
									  cartao.getIDConta());

			cartoesDTO.add(cartaoDTO);

		}
		
		return cartoesDTO;

	}

	public List<DocumentoDigitalizado> doCarregarDocumentosDigitalizados(
			List<DocumentoDigitalizadoDTO> listaDocumentoDigitalizadoDTO,
			AlteracaoSenha alteracaoSenha)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		// List<DocumentoDigitalizadoAlteracaoSenha>
		// documentosDigitalizadosSenha = new
		// ArrayList<DocumentoDigitalizadoAlteracaoSenha>();
		List<DocumentoDigitalizado> documentosDigitalizadosSenha = new ArrayList<DocumentoDigitalizado>();

		for (DocumentoDigitalizadoDTO documentoDigitalizadoDTO : listaDocumentoDigitalizadoDTO) {

			TipoDocumentoDigitalizado tipoDocumentoDigitalizado = this.daoService
					.doRead(documentoDigitalizadoDTO.getIdTipoDocumento(),
							TipoDocumentoDigitalizado.class,
							true,
							new StringBuilder(
									"N�o foi encontrado nenhum tipo de documento digitalizado com o ID informado! ID: ")
									.append(documentoDigitalizadoDTO
											.getIdTipoDocumento()).toString(),
							"ID do tipo de documento digitalizado n�o foi informado!");

			DocumentoDigitalizado documentoDigitalizado = this.daoService
					.doRead(documentoDigitalizadoDTO.getId(),
							DocumentoDigitalizado.class,
							true,
							new StringBuilder(
									"N�o foi encontrado nenhum documento digitalizado com o ID informado! ID: ")
									.append(documentoDigitalizadoDTO.getId())
									.toString(),
							"ID do documento digitalizado n�o foi informado!");

			// marca o documento para inativo para que n�o seja utilizado em
			// outra solicitacao
			documentoDigitalizado.setStatus(StatusPadraoEnum.INATIVO);
			documentoDigitalizado.setTipo(tipoDocumentoDigitalizado);

			// adiciona na lista da tabela temporaria
			/*
			 * documentosDigitalizadosSenha .add(new
			 * DocumentoDigitalizadoAlteracaoSenha( documentoDigitalizado,
			 * alteracaoSenha));
			 */
			documentosDigitalizadosSenha.add(documentoDigitalizado);

		}

		return documentosDigitalizadosSenha;
	}

	@Override
	@Transactional
	public String doAlterarSenhaPortador(Integer idConta, 
									     String cpfPortador,
									     String senha, 
									     Integer idUsuario, 
									     String foto,
									     Integer idEstabelecimento, 
									     List<DocumentoDTO> documentoDTO) throws CalsystemInvalidArgumentException,
									   	   									     CalsystemNoDataFoundException, 
									   										     IntegracaoException,
									   										     ServiceException, 
									   										     IntegracaoMotorBiometriaException,
									   										     IntegracaoProcessadoraException, 
									   										     IntegracaoMotorCreditoException {

		Usuario operador = this.usuarioService
				.doConsultarUsuarioPorId(
						idUsuario,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhum usu�rio com o id informado! ID: ")
								.append(idUsuario).toString(),
						"ID do usu�rio n�o informado!");

		Estabelecimento estabelecimento = this.estabelecimentoService
				.doConsultarEstabelecimentoPorId(
						idEstabelecimento,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhum estabelecimento com o id informado! ID: ")
								.append(idEstabelecimento).toString(),
						"Id do estabelecimento n�o informado!");

		if (documentoDTO == null)
			throw new CalsystemInvalidArgumentException(
					"Documentos n�o informados!");

		List<DocumentDTO> documentDTO = new ArrayList<DocumentDTO>();

		for (DocumentoDTO documento : documentoDTO) {

			if (documento.getImagem() == null)
				throw new CalsystemInvalidArgumentException(
						"Imagem do documento n�o informada!");

			TipoDocumentoDigitalizado tipoDocumentoDigitalizado = this.documentoDigitalizadoService
					.doConsultarTipoDocumentoDigitalizado(
							documento.getIdTipoDocumento(),
							true,
							new StringBuilder(
									"Tipo de documento inv�lido! ID: ").append(
									documento.getIdTipoDocumento()).toString(),
							"Id do tipo de documento n�o informado!");

			documentDTO.add(new DocumentDTO(tipoDocumentoDigitalizado
					.getDocumentType(), documento.getImagem()));

		}

		CartaoConsulta[] cartoes = this.processadoraService
				.doConsultarCartoesProcessadora(idConta, cpfPortador, null,
						null, true,
						"Nenhum cart�o foi encontrado na processadora para os par�metros informados!");

		IntegracaoEnvioFotoDTO integracao = this.motorBiometriaService.doEnviarCreditRequest(cpfPortador,
																							 String.valueOf(estabelecimento.getCodigo()),
																							 cartoes[0].getNomePortador(), 
																							 null, 
																							 foto, 
																							 documentDTO);
		
		String politica = parametroGlobalService.doConsultar(ParametroGlobal.PARAMETRO_CREDDEFENSE_POLITICA_BIOMETRIA).getValorTexto();
		
		String usuarioCredDefense = parametroGlobalService.doConsultar(ParametroGlobal.PARAMETRO_CREDDEFENSE_USUARIO).getValorTexto();
		
		String senhaCredDefense = parametroGlobalService.doConsultar(ParametroGlobal.PARAMETRO_CREDDEFENSE_SENHA).getValorTexto();
		
		//faz login na CredDefense
		IntegracaoLoginDTO tokenLogin = this.motorBiometriaService.doLogin();
		
		Parametro parametros = new Parametro();
		//parametros.doAddParametro("CPF", "00366172964");
		
		parametros.doAddParametro("token", tokenLogin.getToken());
		parametros.doAddParametro("ID", integracao.getIdMotorBiometria());
		parametros.doAddParametro("CPF", cpfPortador);
		
		//BUSCA O RESULTADO DA BIOMETRIA NO CRIVO
		ResultEvalValuesXml retorno =  motorCreditoService.doConsultarPoliticaDeCredito(usuarioCredDefense,
																						senhaCredDefense, 
																						politica,
																						parametros.getParametros(),
																						true, 
																						"Nenhuma resposta da consulta da pol�tica foi encontrada");

		//faz logout na CredDefense
		this.motorBiometriaService.doLogout(tokenLogin.getToken());
		
		 String resultadoBiometria = null;
		 for (ResultRespostasXml resultRespostasXml : retorno.getRespostas()) {
			if(resultRespostasXml.getCriterio().equalsIgnoreCase(politica)){
				resultadoBiometria = resultRespostasXml.getSistema();
			}
		 }
		
		super.getLogger().info(new StringBuilder("retorno do Crivo foi: ")
							.append(resultadoBiometria).append(" Para o ID biometria: ")
							.append(integracao.getIdMotorBiometria()));
		
		RespostaCrivoEnum respostaCrivo = doDeparaRespostaCrivo(resultadoBiometria);
		
		//altera a senha dos cartoes na conductor caso tenha sido aprovado no motor Biometria
		if(respostaCrivo.equals(RespostaCrivoEnum.APROVADA)){
			
			AlteracaoSenha alteracaoSenha = new AlteracaoSenha(StatusSolicitacaoEnum.APROVADA.getCodigo(),
														      estabelecimento, 
														      operador, 
														      idConta, 
														      cpfPortador, 
														      senha, 
														      integracao.getIdMotorBiometria());
			
			this.daoService.doCreate(alteracaoSenha);
			
			for (CartaoConsulta cartao : cartoes) {
				this.integracaoProcessadoraService.doAlterarSenhaCartao(cartao.getIDConta(), 
																		cartao.getNumCartao().substring((cartao.getNumCartao().length()-4), cartao.getNumCartao().length()),//ultimos 4 digitos
																		null, //senha anterior
																		senha, 
																		ProcessadoraIntegradorService.SENHA_CADASTRAR_NOVA,
																		ProcessadoraIntegradorService.SENHA_SEM_CRIPTOGRAFIA,
																		ProcessadoraIntegradorService.LOG_SISTEMA);
			}
			
		} else if (respostaCrivo.equals(RespostaCrivoEnum.PENDENTE)) {
			
			AlteracaoSenha alteracaoSenha = new AlteracaoSenha(StatusSolicitacaoEnum.PENDENTE.getCodigo(),
															   estabelecimento, 
															   operador, 
															   idConta, 
															   cpfPortador, 
															   senha, 
															   integracao.getIdMotorBiometria());
			
			this.daoService.doCreate(alteracaoSenha);

			

		} else if (respostaCrivo.equals(RespostaCrivoEnum.NEGADA)){
			
			AlteracaoSenha alteracaoSenha = new AlteracaoSenha(StatusSolicitacaoEnum.NEGADA.getCodigo(),
															   estabelecimento, 
															   operador, 
															   idConta, 
															   cpfPortador, 
															   senha, 
															   integracao.getIdMotorBiometria());
			
			this.daoService.doCreate(alteracaoSenha);
			
		}
		
		return respostaCrivo.getCodigo();

	}
	
	private RespostaCrivoEnum doDeparaRespostaCrivo(String status){
		
		switch (status) {
	        case "A":
	                return RespostaCrivoEnum.APROVADA;
	        case "P":
	        		return RespostaCrivoEnum.PENDENTE;
	        case "R":
	        		return RespostaCrivoEnum.NEGADA;
	        default :
				return RespostaCrivoEnum.PENDENTE;

		}
	}
	
}
