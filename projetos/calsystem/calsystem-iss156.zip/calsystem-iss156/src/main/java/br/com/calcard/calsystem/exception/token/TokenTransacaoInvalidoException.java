package br.com.calcard.calsystem.exception.token;

import br.com.calcard.calframework.exception.CalsystemException;

public class TokenTransacaoInvalidoException extends CalsystemException {

	private static final long serialVersionUID = 1290693108668306462L;

	public TokenTransacaoInvalidoException(String mensagem) {
		super(mensagem);
	}

}
