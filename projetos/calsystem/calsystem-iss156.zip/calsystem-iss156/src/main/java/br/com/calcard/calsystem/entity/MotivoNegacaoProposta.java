package br.com.calcard.calsystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calsystem.entity.proposta.Proposta;
import br.com.calcard.calsystem.enums.MotivoNegacaoPropostaEnum;

@Entity
@Table(name = "tbl_motivo_negacao_proposta")
public class MotivoNegacaoProposta extends CalsystemEntity {

	private static final long serialVersionUID = -1456537307125433158L;

	private static final String COLUNA_PROPOSTA = "id_proposta";

	private static final String COLUNA_MOTIVO = "motivo";

	@OneToOne
	@JoinColumn(name = COLUNA_PROPOSTA, nullable = false, unique = false)
	private Proposta proposta;

	@Enumerated(EnumType.STRING)
	@Column(name = COLUNA_MOTIVO, length = 30, nullable = false, unique = false)
	private MotivoNegacaoPropostaEnum motivo;

	public Proposta getProposta() {
		return proposta;
	}

	public void setProposta(Proposta proposta) {
		this.proposta = proposta;
	}

	public MotivoNegacaoPropostaEnum getMotivo() {
		return motivo;
	}

	public void setMotivo(MotivoNegacaoPropostaEnum motivo) {
		this.motivo = motivo;
	}

}
