package br.com.calcard.calsystem.exception.proposta;

import br.com.calcard.calframework.exception.CalsystemException;

public class PropostaDocumentosDigitalizadosException extends
		CalsystemException {

	private static final long serialVersionUID = -857188453336551158L;

	public PropostaDocumentosDigitalizadosException(String message) {
		super(message);
	}
}
