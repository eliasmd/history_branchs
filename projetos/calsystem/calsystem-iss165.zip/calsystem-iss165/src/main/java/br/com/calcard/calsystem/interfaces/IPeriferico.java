package br.com.calcard.calsystem.interfaces;

public interface IPeriferico {

}
