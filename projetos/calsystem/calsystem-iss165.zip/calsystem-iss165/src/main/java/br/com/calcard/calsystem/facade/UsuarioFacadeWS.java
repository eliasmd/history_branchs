package br.com.calcard.calsystem.facade;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.ws.CalsystemFacadeWS;
import br.com.calcard.calsystem.dto.UsuarioDTO;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.interfaces.IUsuario;
import br.com.calcard.calsystem.util.Parametro;

@Component
public class UsuarioFacadeWS extends CalsystemFacadeWS {

	private IUsuario usuarioService;

	@Autowired
	public UsuarioFacadeWS(IUsuario usuarioService) {

		this.usuarioService = usuarioService;
	}

	public ResponseEntity<Object> doListarUsuariosPorEstabelecimento(
			Integer idEstabelecimento) {

		try {

			List<Usuario> usuarios = this.usuarioService
					.doListarUsuariosPorEstabelecimento(idEstabelecimento);

			List<UsuarioDTO> usuariosDTO = new ArrayList<UsuarioDTO>();

			for (Usuario usuario : usuarios)
				usuariosDTO.add(new UsuarioDTO(usuario));

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Usuarios", usuariosDTO).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}
}
