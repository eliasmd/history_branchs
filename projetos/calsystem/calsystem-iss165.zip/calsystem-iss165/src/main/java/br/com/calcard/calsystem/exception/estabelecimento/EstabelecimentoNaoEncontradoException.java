package br.com.calcard.calsystem.exception.estabelecimento;

import br.com.calcard.calframework.exception.CalsystemException;

public class EstabelecimentoNaoEncontradoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9214272776071411746L;

	public EstabelecimentoNaoEncontradoException(String mensagem) {
		super(mensagem);
	}

}
