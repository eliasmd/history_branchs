package br.com.calcard.calsystem.exception.proposta;

public class PropostaCadastradaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5032068343144707087L;

	public PropostaCadastradaException(String mensagem) {
		super(mensagem);
	}

}
