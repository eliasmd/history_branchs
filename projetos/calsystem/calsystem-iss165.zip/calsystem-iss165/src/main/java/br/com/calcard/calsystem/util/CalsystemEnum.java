package br.com.calcard.calsystem.util;

public interface CalsystemEnum {

	public Integer getId();

}
