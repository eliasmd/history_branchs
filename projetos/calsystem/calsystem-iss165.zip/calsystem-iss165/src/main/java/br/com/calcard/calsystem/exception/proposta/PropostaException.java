package br.com.calcard.calsystem.exception.proposta;

import br.com.calcard.calframework.exception.CalsystemException;

public class PropostaException extends CalsystemException {

	private static final long serialVersionUID = -5324621130649897112L;

	public PropostaException(String mensagem) {
		super(mensagem);
	}

	public PropostaException(String mensagem, Throwable e) {
		super(mensagem, e);
	}

}
