package br.com.calcard.calsystem.interfaces;

import br.com.calcard.calframework.exception.CalsystemDAOException;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calsystem.entity.Periferico;
import br.com.calcard.calsystem.entity.TokenLogin;
import br.com.calcard.calsystem.entity.TokenSessao;
import br.com.calcard.calsystem.entity.TokenTransacao;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.exception.TokenInvalidoException;
import br.com.calcard.calsystem.exception.token.TokenSessaoInvalidoException;
import br.com.calcard.calsystem.exception.token.TokenSessaoNaoEncontradoException;

public interface IToken {

	public String doGerarToken() throws ServiceException;

	public TokenSessao doValidarTokens(String tSessao, String tTransacao)
			throws CalsystemNoDataFoundException, TokenInvalidoException,
			CalsystemInvalidArgumentException;

	public TokenTransacao doGerarTokenTransacao(TokenSessao tokenSessao)
			throws ServiceException, TokenSessaoInvalidoException,
			CalsystemDAOException, TokenSessaoNaoEncontradoException;

	public TokenLogin doGerarTokenLogin(Periferico periferico)
			throws CalsystemInvalidArgumentException, ServiceException;

	public TokenSessao doConsultarTokenSessao(String tSessao)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public TokenLogin doValidarTokenLogin(String tLogin)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, TokenInvalidoException;

	public TokenSessao doGerarTokenSessao(TokenLogin tokenLogin, Usuario usuario)
			throws CalsystemInvalidArgumentException, ServiceException;

}
