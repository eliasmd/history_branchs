package br.com.calcard.calsystem.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class PerifericoInvalidoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 33908269716526351L;

	public PerifericoInvalidoException(String mensagem) {
		super(mensagem);
	}

}
