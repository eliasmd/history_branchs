package br.com.calcard.calsystem.exception.proposta;

public class RGException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2711325099310859480L;

	public RGException(String mensagem) {
		super(mensagem);
	}

}
