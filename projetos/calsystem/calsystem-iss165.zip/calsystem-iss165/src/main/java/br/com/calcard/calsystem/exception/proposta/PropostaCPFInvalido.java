package br.com.calcard.calsystem.exception.proposta;

public class PropostaCPFInvalido extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8523223329810489712L;

	public PropostaCPFInvalido() {
		super();
	}

	public PropostaCPFInvalido(String mensagem) {
		super(mensagem);
	}

}
