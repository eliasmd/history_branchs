package br.com.calcard.calsystem.exception.voucher;

public class VoucherExpiradoException extends VoucherException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5957483834783837023L;

}
