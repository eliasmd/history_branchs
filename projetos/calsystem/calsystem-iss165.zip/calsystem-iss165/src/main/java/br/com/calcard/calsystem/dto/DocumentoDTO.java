package br.com.calcard.calsystem.dto;

public class DocumentoDTO {

	private Integer idTipoDocumento;

	private String imagem;
	
	public DocumentoDTO() {
		super();
	}
	
	public DocumentoDTO(Integer idTipoDocumento, String imagem) {
		super();
		this.idTipoDocumento = idTipoDocumento;
		this.imagem = imagem;
	}

	public Integer getIdTipoDocumento() {
		return idTipoDocumento;
	}

	public void setIdTipoDocumento(Integer idTipoDocumento) {
		this.idTipoDocumento = idTipoDocumento;
	}

	public String getImagem() {
		return imagem;
	}

	public void setImagem(String imagem) {
		this.imagem = imagem;
	}

}
