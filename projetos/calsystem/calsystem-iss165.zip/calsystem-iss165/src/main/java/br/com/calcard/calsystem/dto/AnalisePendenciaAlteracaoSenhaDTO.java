package br.com.calcard.calsystem.dto;

import java.util.List;

public class AnalisePendenciaAlteracaoSenhaDTO {
	
	private AnaliseBiometriaDTO analiseBiometriaDTO;
	
	private List<DocumentoDTO> documentosDTO;

	public AnalisePendenciaAlteracaoSenhaDTO(AnaliseBiometriaDTO analiseBiometriaDTO,
											 List<DocumentoDTO> documentosDTO) {
		this.analiseBiometriaDTO 	= analiseBiometriaDTO;
		this.documentosDTO 			= documentosDTO;
	}

	public AnaliseBiometriaDTO getAnaliseBiometriaDTO() {
		return analiseBiometriaDTO;
	}

	public void setAnaliseBiometriaDTO(AnaliseBiometriaDTO analiseBiometriaDTO) {
		this.analiseBiometriaDTO = analiseBiometriaDTO;
	}

	public List<DocumentoDTO> getDocumentosDTO() {
		return documentosDTO;
	}

	public void setDocumentosDTO(List<DocumentoDTO> documentosDTO) {
		this.documentosDTO = documentosDTO;
	}

}
