package br.com.calcard.calsystem.exception.documento;

import br.com.calcard.calframework.exception.CalsystemException;

public class DigitalizacaoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3183921323281207941L;

	public DigitalizacaoException(String mensagem) {
		super(mensagem);
	}

	public DigitalizacaoException(String mensagem, Throwable e) {
		super(mensagem, e);
	}
}