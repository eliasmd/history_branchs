package br.com.calcard.calsystem.interfaces;

import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.enums.Enum.StatusEstabelecimentoEnum;
import br.com.calcard.calsystem.exception.estabelecimento.EstabelecimentoInvalidoException;

public interface IEstabelecimento {

	public void doValidarNovoEstabelecimento(
			Estabelecimento estabelecimentoAtual,
			Estabelecimento estabelecimentoNovo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, EstabelecimentoInvalidoException;

	public Estabelecimento doCadastrarNovoEstabelecimento(String codigo,
			String cnpj) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException, EstabelecimentoInvalidoException;

	public Estabelecimento doAtualizarCadastroEstabelecimentoExistente(
			Integer idEstabelecimentoExistente, String codigo, String cnpj)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException, EstabelecimentoInvalidoException;

	public Estabelecimento doInativarEstabelecimento(Integer id)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public List<Estabelecimento> doListarEstabelecimentos(String codigo,
			String cnpj, Integer idUsuario,
			StatusEstabelecimentoEnum statusEstabelecimento)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public Estabelecimento doConsultarEstabelecimentoPorId(Integer id,
			boolean validarRetornoNull, String mensagemRetornoNull,
			String mensagemIdNull) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;
	
	public Estabelecimento doConsultarEstabelecimentosPorUsuario(Integer idUsuario) throws CalsystemInvalidArgumentException,
	  																					   CalsystemNoDataFoundException;

	Estabelecimento doConsultarEstabelecimentoPorId(Integer id)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

}
