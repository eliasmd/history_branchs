package br.com.calcard.calsystem.service;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;

public abstract class CalsystemService {

	public abstract <T extends CalsystemEntity> T doConsultarPorId(Integer id)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

}
