package br.com.calcard.calsystem.exception.proposta;

public class PropostaOutrosDocumentosInvalidosException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5279790622233903850L;

	public PropostaOutrosDocumentosInvalidosException(String mensagem) {
		super(mensagem);
	}

}
