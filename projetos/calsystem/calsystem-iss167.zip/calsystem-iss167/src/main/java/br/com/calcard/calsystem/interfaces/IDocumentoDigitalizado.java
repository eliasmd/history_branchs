package br.com.calcard.calsystem.interfaces;

import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calsystem.dto.DocumentoDTO;
import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;

public interface IDocumentoDigitalizado {

	public void doValidarDocumento(List<DocumentoDTO> documentos)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	TipoDocumentoDigitalizado doConsultarTipoDocumentoDigitalizado(Integer id,
			boolean validarRetornoNull, String mensagemRetornoNull,
			String mensagemIdNull) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

}
