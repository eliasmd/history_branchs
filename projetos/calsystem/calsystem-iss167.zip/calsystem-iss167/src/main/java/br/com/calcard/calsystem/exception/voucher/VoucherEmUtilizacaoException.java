package br.com.calcard.calsystem.exception.voucher;

public class VoucherEmUtilizacaoException extends VoucherException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1268907769002887508L;

}
