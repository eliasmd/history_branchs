package br.com.calcard.calsystem.interfaces;

import java.util.Map;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calsystem.entity.ParametroGlobal;

public interface IParametroGlobal {

	public void doCarregarParametrosGlobais()
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public ParametroGlobal doConsultar(String nomeParametro)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public Map<String, ParametroGlobal> doListarParametrosByNome(
			String... parametros) throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;
}
