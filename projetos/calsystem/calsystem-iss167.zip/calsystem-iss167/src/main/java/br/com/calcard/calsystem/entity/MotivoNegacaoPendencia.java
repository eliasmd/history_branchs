package br.com.calcard.calsystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calintegrador.motorBiometria.enums.StatusSolicitacaoDeCredito;
import br.com.calcard.calsystem.entity.proposta.Proposta;
import br.com.calcard.calsystem.enums.MotivoNegacaoPropostaEnum;

@Entity
@Table(name = "tbl_motivo_negacao_pendencia")
public class MotivoNegacaoPendencia extends CalsystemEntity {

	private static final long serialVersionUID = -1456537307125433158L;

	//private static final String COLUNA_PENDENCIA = "id_pendencia";

	private static final String COLUNA_MOTIVO = "motivo";
	
	private static final String COLUNA_STATUS = "status_motor_biometria";

	/*@OneToOne
	@JoinColumn(name = COLUNA_PENDENCIA, nullable = false, unique = false)
	private Pendencia pendencia;*/

	@Column(name = COLUNA_MOTIVO, length = 50, nullable = false, unique = false)
	private String motivo;
	
	@Enumerated(EnumType.STRING)
	@Column(name = COLUNA_STATUS, length = 30, nullable = false, unique = false)
	private StatusSolicitacaoDeCredito statusMotorBiometria;

	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public StatusSolicitacaoDeCredito getStatusMotorBiometria() {
		return statusMotorBiometria;
	}

	public void setStatusMotorBiometria(
			StatusSolicitacaoDeCredito statusMotorBiometria) {
		this.statusMotorBiometria = statusMotorBiometria;
	}
	
	

}
