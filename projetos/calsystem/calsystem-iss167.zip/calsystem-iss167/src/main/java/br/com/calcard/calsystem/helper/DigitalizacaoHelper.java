package br.com.calcard.calsystem.helper;

import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.commons.codec.binary.Base64;

import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calsystem.util.ListagemArquivosFilter;

public class DigitalizacaoHelper {

	public File[] doListarArquivosRede(String localArquivo, String nomeArquivo,
			String extensaoArquivo) throws CalsystemNoDataFoundException {

		File base = new File(localArquivo);

		ListagemArquivosFilter filtrarArquivos = new ListagemArquivosFilter();

		filtrarArquivos.setFiltro(nomeArquivo);

		File[] arquivos = base.listFiles(filtrarArquivos);

		/*if (arquivos.length == 0)
			throw new CalsystemNoDataFoundException(
					new StringBuilder(
							"N�o foi encontrado nenhum arquivo na rede com o nome informado!")
							.append(" NOME ARQUIVO: ").append(nomeArquivo)
							.toString());*/

		return arquivos;

	}

	public String doConverterBase64(BufferedImage image, String extensaoArquivo)
			throws ServiceException {

		try {

			String type;

			type = extensaoArquivo.replace(".", "");
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			ImageIO.write(image, type, out);
			byte[] bytes = out.toByteArray();

			String base64bytes = org.apache.commons.codec.binary.Base64
					.encodeBase64String(bytes);

			return new StringBuilder("data:image/jpeg").append(";base64,")
					.append(base64bytes).toString();

		} catch (IOException e) {
			throw new ServiceException(
					"N�o foi poss�vel converter a miniatura em base64", e);
		}

	}

	public File doConverterFile(String fotoBase64) {
		
		
		
		Base64.decodeBase64(fotoBase64);

		return null;

	}

	public String doConverterBase64(File arquivo, String extensaoArquivo)
			throws ServiceException {

		try {

			return this.doConverterBase64(ImageIO.read(arquivo),
					extensaoArquivo);

		} catch (IOException e) {
			throw new ServiceException(
					"N�o foi poss�vel converter a miniatura em base64", e);
		}

	}
	
	
	public BufferedImage decodeBase64ToImage(String imageString) {
        BufferedImage image = null;
        byte[] imageByte;
        try {
        	imageString = imageString.replace("data:image/jpeg;base64,", "");
            imageByte = org.apache.commons.codec.binary.Base64.decodeBase64(imageString);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
            image = ImageIO.read(bis);
            bis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return image;
    }

	public String doCriarThm(File arquivo, Double proporcao,
			String extensaoArquivo) throws ServiceException {

		try {

			BufferedImage img = ImageIO.read(arquivo);

			return doCriarThmImagem(img,proporcao,extensaoArquivo);

		} catch (IOException e) {
			throw new ServiceException(
					new StringBuilder(
							"N�o foi poss�vel gerar a miniatuda do arquivo solicitad!.")
							.append(" NOME ARQUIVO: ")
							.append(arquivo.getName()).toString(), e);
		}
	}
	
	public String doCriarThmImagem(BufferedImage img, Double proporcao,
			String extensaoArquivo) throws ServiceException {

			return doConverterBase64(this.scale(img, proporcao),
					extensaoArquivo);

	}

	public BufferedImage scale(BufferedImage source, double ratio) {
		int w = (int) (source.getWidth() * ratio);
		int h = (int) (source.getHeight() * ratio);
		BufferedImage bi = getCompatibleImage(w, h);
		Graphics2D g2d = bi.createGraphics();
		double xScale = (double) w / source.getWidth();
		double yScale = (double) h / source.getHeight();
		AffineTransform at = AffineTransform.getScaleInstance(xScale, yScale);
		g2d.drawRenderedImage(source, at);
		g2d.dispose();
		return bi;
	}

	private BufferedImage getCompatibleImage(int w, int h) {
		GraphicsEnvironment ge = GraphicsEnvironment
				.getLocalGraphicsEnvironment();
		GraphicsDevice gd = ge.getDefaultScreenDevice();
		GraphicsConfiguration gc = gd.getDefaultConfiguration();
		BufferedImage image = gc.createCompatibleImage(w, h);
		return image;
	}

}
