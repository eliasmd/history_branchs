package br.com.calcard.calsystem.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class ParametroGlobalNaoEncontradoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5539376633806475653L;

	public ParametroGlobalNaoEncontradoException(String mensagem) {
		super(mensagem);
	}

}
