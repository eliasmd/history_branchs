package br.com.calcard.calsystem.facade;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.ws.CalsystemFacadeWS;

@Component
public class LojistaFacadeWS extends CalsystemFacadeWS {

	public LojistaFacadeWS() {

	}

	public ResponseEntity<Object> doListar(Integer[] ids) {

		// try {
		//
		// List<LojistaDTO> lojistasDTO = new ArrayList<LojistaDTO>();
		//
		// for (Lojista lojista : lojistaRN.doListar(ids))
		// lojistasDTO.add(new LojistaDTO(lojista));
		//
		// return super.doRetornarSucessoWS(new Parametro().doAddParametro(
		// "Lojistas", lojistasDTO).getParametros());
		//
		// } catch (CalsystemException e) {
		// return super.doRetornarErroWS(e);
		// } catch (Exception e) {
		// return super.doRetornarErroWS(e);
		// }

		return null;

	}
}
