package br.com.calcard.calsystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;

@Entity
@Table(name = "tbl_regra_digitalizacao", uniqueConstraints = { @UniqueConstraint(columnNames = {
		RegraDigitalizacao.COLUNA_PROCESSO_DIGITALIZACAO,
		RegraDigitalizacao.COLUNA_TIPO_DOCUMENTO_DIGITALIZAVEL }) })
@NamedQueries({
		@NamedQuery(name = RegraDigitalizacao.NQ_SELECT_REGRA_BY_PROCESSO, query = "select r from RegraDigitalizacao r where r.processoDigitalizacao = :processo"),
		@NamedQuery(name = RegraDigitalizacao.NQ_SELECT_REGRA_BY_TIPO_DOCUMENTO, query = "select r from RegraDigitalizacao r where r.tipoDocumentoDigitalizavel = :tipoDocumento") })
public class RegraDigitalizacao extends CalsystemEntity {

	private static final long serialVersionUID = -1459589834389981535L;

	public static final String NQ_SELECT_REGRA_BY_PROCESSO = "NQRegraByProcesso";

	public static final String NQ_SELECT_REGRA_BY_TIPO_DOCUMENTO = "NQRegraByTipoDocumento";

	public static final String COLUNA_PROCESSO_DIGITALIZACAO = "id_processo_digitalizacao";

	public static final String COLUNA_TIPO_DOCUMENTO_DIGITALIZAVEL = "id_tipo_documento_digitalizavel";

	public static final String COLUNA_DIGITALIZACAO_OBRIGATORIA = "digitalizacao_obrigatoria";

	@OneToOne
	@JoinColumn(name = COLUNA_PROCESSO_DIGITALIZACAO, nullable = false, unique = false)
	private ProcessoDigitalizacao processoDigitalizacao;

	@OneToOne
	@JoinColumn(name = COLUNA_TIPO_DOCUMENTO_DIGITALIZAVEL, nullable = false, unique = false)
	private TipoDocumentoDigitalizado tipoDocumentoDigitalizavel;

	@Type(type = "yes_no")
	@Column(name = COLUNA_DIGITALIZACAO_OBRIGATORIA, nullable = false, unique = false)
	private Boolean digitalizacaoObrigatoria;

	public ProcessoDigitalizacao getProcessoDigitalizacao() {
		return processoDigitalizacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((digitalizacaoObrigatoria == null) ? 0
						: digitalizacaoObrigatoria.hashCode());
		result = prime
				* result
				+ ((processoDigitalizacao == null) ? 0 : processoDigitalizacao
						.hashCode());
		result = prime
				* result
				+ ((tipoDocumentoDigitalizavel == null) ? 0
						: tipoDocumentoDigitalizavel.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegraDigitalizacao other = (RegraDigitalizacao) obj;
		if (digitalizacaoObrigatoria == null) {
			if (other.digitalizacaoObrigatoria != null)
				return false;
		} else if (!digitalizacaoObrigatoria
				.equals(other.digitalizacaoObrigatoria))
			return false;
		if (processoDigitalizacao == null) {
			if (other.processoDigitalizacao != null)
				return false;
		} else if (!processoDigitalizacao.equals(other.processoDigitalizacao))
			return false;
		if (tipoDocumentoDigitalizavel == null) {
			if (other.tipoDocumentoDigitalizavel != null)
				return false;
		} else if (!tipoDocumentoDigitalizavel
				.equals(other.tipoDocumentoDigitalizavel))
			return false;
		return true;
	}

	public void setProcessoDigitalizacao(
			ProcessoDigitalizacao processoDigitalizacao) {
		this.processoDigitalizacao = processoDigitalizacao;
	}

	public TipoDocumentoDigitalizado getTipoDocumentoDigitalizavel() {
		return tipoDocumentoDigitalizavel;
	}

	public void setTipoDocumentoDigitalizavel(
			TipoDocumentoDigitalizado tipoDocumentoDigitalizavel) {
		this.tipoDocumentoDigitalizavel = tipoDocumentoDigitalizavel;
	}

	public Boolean getDigitalizacaoObrigatoria() {
		return digitalizacaoObrigatoria;
	}

	public void setDigitalizacaoObrigatoria(Boolean digitalizacaoObrigatoria) {
		this.digitalizacaoObrigatoria = digitalizacaoObrigatoria;
	}

}
