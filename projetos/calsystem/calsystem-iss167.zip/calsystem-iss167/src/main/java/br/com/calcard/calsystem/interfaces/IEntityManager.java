package br.com.calcard.calsystem.interfaces;

import javax.persistence.EntityManager;

public interface IEntityManager {

	public EntityManager doGetEntityManager();

}
