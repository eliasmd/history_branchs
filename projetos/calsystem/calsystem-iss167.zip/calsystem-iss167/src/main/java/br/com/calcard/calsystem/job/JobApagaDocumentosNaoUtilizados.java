package br.com.calcard.calsystem.job;

import org.quartz.JobExecutionContext;

import br.com.calcard.calframework.job.CalsystemJob;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;

public class JobApagaDocumentosNaoUtilizados extends CalsystemJob {

	private IDigitalizacao digitalizacaoService;
	
	@Override
	protected void executeInternal(JobExecutionContext context) {
		
		try {
			
			this.digitalizacaoService.doApagarDocumentosDigitalizados();
		
		} catch(Exception e){
			e.printStackTrace();
		}
		
	}

	public IDigitalizacao getDigitalizacaoService() {
		return digitalizacaoService;
	}

	public void setDigitalizacaoService(IDigitalizacao digitalizacaoService) {
		this.digitalizacaoService = digitalizacaoService;
	}

}
