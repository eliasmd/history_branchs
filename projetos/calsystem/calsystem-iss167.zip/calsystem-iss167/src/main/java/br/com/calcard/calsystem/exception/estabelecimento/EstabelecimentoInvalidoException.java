package br.com.calcard.calsystem.exception.estabelecimento;

import br.com.calcard.calframework.exception.CalsystemException;

public class EstabelecimentoInvalidoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7671985439709683882L;

	public EstabelecimentoInvalidoException(String mensagem) {
		super(mensagem);
	}

	public EstabelecimentoInvalidoException(String mensagem, Throwable e) {
		super(mensagem);
	}

}
