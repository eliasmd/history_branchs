package br.com.calcard.calsystem.ws;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.interfaces.ICalsystemLog;
import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calsystem.interfaces.IConta;
import br.com.calcard.calsystem.util.Parametro;

@RestController
@RequestMapping("/ws/contas")
@Scope(value="request")
public class ContaWS extends CalsystemWS {

	private IConta ContaService;

	@Autowired
	public ContaWS(IConta 			ContaService,
			  ICalsystemLog 			logService) {
		
super(logService);

		this.ContaService = ContaService;
	}

	@RequestMapping(value = "", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doListarContas(
			@RequestHeader(value = "tSessao") String tSessao,
			@RequestParam(value = "cpf", required = false) String cpf) {
		
		try{
			super.logService.setTokenSessao(tSessao);
			
			super.doGravarLog(new Parametro().doAddParametro("cpf", cpf)
					.getParametros());
			
			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"contasDTO", this.ContaService.doConsultarContas(cpf, null)).getParametros());
	      
		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<Object> doRetornarConta(
    		@PathVariable Integer id,
            @RequestHeader(value = "tSessao") String tSessao) {
		
		try{
			super.logService.setTokenSessao(tSessao);
			
		    super.doGravarLog(new Parametro().doAddParametro("id", id)
		                  .getParametros());
		      
			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
						"contaDTO", this.ContaService.doConsultarContas(null, id).get(0)).getParametros());
		      
		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}


}
