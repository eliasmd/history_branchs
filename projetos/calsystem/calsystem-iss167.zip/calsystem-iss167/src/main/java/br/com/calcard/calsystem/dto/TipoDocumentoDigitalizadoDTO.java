package br.com.calcard.calsystem.dto;

public class TipoDocumentoDigitalizadoDTO {

	private Integer id;

	private String nome;
	
	private String sigla;

	private Boolean digitalizacaoObrigatoria;

	public TipoDocumentoDigitalizadoDTO() {

	}

	public TipoDocumentoDigitalizadoDTO(Integer id, String nome,
			Boolean digitalizacaoObrigatoria,String sigla) {
		super();
		this.id = id;
		this.nome = nome;
		this.digitalizacaoObrigatoria = digitalizacaoObrigatoria;
		this.sigla = sigla;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Boolean getDigitalizacaoObrigatoria() {
		return digitalizacaoObrigatoria;
	}

	public void setDigitalizacaoObrigatoria(Boolean digitalizacaoObrigatoria) {
		this.digitalizacaoObrigatoria = digitalizacaoObrigatoria;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	
	

}
