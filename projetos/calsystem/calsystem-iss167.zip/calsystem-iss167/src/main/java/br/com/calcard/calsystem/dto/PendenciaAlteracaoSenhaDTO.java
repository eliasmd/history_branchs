package br.com.calcard.calsystem.dto;

import java.util.Date;

import br.com.calcard.calframework.util.CustomJsonDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class PendenciaAlteracaoSenhaDTO {

	private Integer idPendencia;

	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date dataRegistroPendencia;

	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date dataInicioAnalise;

	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date dataFimAnalise;

	private Integer idAnalista;

	private Integer idPromotor;

	private Integer idConta;

	private String cpfPortador;

	private String parecer;

	private Integer idEstabelecimento;

	private String status;
	
	private String TMA;
	
	private String TME;
	
	private Integer idCreditRequest;

	public PendenciaAlteracaoSenhaDTO() {

	}

	public PendenciaAlteracaoSenhaDTO(Integer idPendencia,
									  Date dataRegistroPendencia, 
									  Date dataInicioAnalise,
									  Date dataFimAnalise, 
									  Integer idAnalista, 
									  Integer idPromotor,
									  Integer idConta, 
									  String cpfPortador, 
									  String parecer,
									  Integer idEstabelecimento, 
									  String status, 
									  String TMA, 
									  String TME,
									  Integer idCreditRequest) {
		super();
		this.idPendencia 			= idPendencia;
		this.dataRegistroPendencia 	= dataRegistroPendencia;
		this.dataInicioAnalise 		= dataInicioAnalise;
		this.dataFimAnalise 		= dataFimAnalise;
		this.idAnalista 			= idAnalista;
		this.idPromotor 			= idPromotor;
		this.idConta 				= idConta;
		this.cpfPortador 			= cpfPortador;
		this.parecer 				= parecer;
		this.idEstabelecimento 		= idEstabelecimento;
		this.status 				= status;
		this.TMA 					= TMA;
		this.TME 					= TME;
		this.idCreditRequest 		= idCreditRequest;
		
	}

	public Integer getIdPendencia() {
		return idPendencia;
	}

	public void setIdPendencia(Integer idPendencia) {
		this.idPendencia = idPendencia;
	}

	public Date getDataRegistroPendencia() {
		return dataRegistroPendencia;
	}

	public void setDataRegistroPendencia(Date dataRegistroPendencia) {
		this.dataRegistroPendencia = dataRegistroPendencia;
	}

	public Date getDataInicioAnalise() {
		return dataInicioAnalise;
	}

	public void setDataInicioAnalise(Date dataInicioAnalise) {
		this.dataInicioAnalise = dataInicioAnalise;
	}

	public Date getDataFimAnalise() {
		return dataFimAnalise;
	}

	public void setDataFimAnalise(Date dataFimAnalise) {
		this.dataFimAnalise = dataFimAnalise;
	}

	public Integer getIdAnalista() {
		return idAnalista;
	}

	public void setIdAnalista(Integer idAnalista) {
		this.idAnalista = idAnalista;
	}

	public Integer getIdPromotor() {
		return idPromotor;
	}

	public void setIdPromotor(Integer idPromotor) {
		this.idPromotor = idPromotor;
	}

	public Integer getIdConta() {
		return idConta;
	}

	public void setIdConta(Integer idConta) {
		this.idConta = idConta;
	}

	public String getCpfPortador() {
		return cpfPortador;
	}

	public void setCpfPortador(String cpfPortador) {
		this.cpfPortador = cpfPortador;
	}

	public String getParecer() {
		return parecer;
	}

	public void setParecer(String parecer) {
		this.parecer = parecer;
	}

	public Integer getIdEstabelecimento() {
		return idEstabelecimento;
	}

	public void setIdEstabelecimento(Integer idEstabelecimento) {
		this.idEstabelecimento = idEstabelecimento;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTMA() {
		return TMA;
	}

	public void setTMA(String tMA) {
		TMA = tMA;
	}

	public String getTME() {
		return TME;
	}

	public void setTME(String tME) {
		TME = tME;
	}

	public Integer getIdCreditRequest() {
		return idCreditRequest;
	}

	public void setIdCreditRequest(Integer idCreditRequest) {
		this.idCreditRequest = idCreditRequest;
	}

}
