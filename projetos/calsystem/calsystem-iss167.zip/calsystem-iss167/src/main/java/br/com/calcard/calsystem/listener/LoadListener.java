package br.com.calcard.calsystem.listener;

import org.springframework.beans.factory.annotation.Autowired;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.interfaces.IParametro;
import br.com.calcard.calsystem.entity.ParametroGlobal;
import br.com.calcard.calsystem.interfaces.IParametroGlobal;


public class LoadListener {

	private IParametroGlobal parametroGlobalService;
	
	private IParametro parametroIntegradorService;

	@Autowired
	public LoadListener(IParametroGlobal parametroGlobalService,
						IParametro parametroIntegradorService) {

		this.parametroGlobalService 		= parametroGlobalService;
		this.parametroIntegradorService 	= parametroIntegradorService;
	}

	public void init() throws CalsystemNoDataFoundException,
							  CalsystemInvalidArgumentException, 
							  ServiceException {

		this.doCarregarParametrosGlobais();
		
		this.parametroIntegradorService
			.doCarregarParametros(parametroGlobalService
					.doConsultar(ParametroGlobal.PARAMETRO_ARQUIVO_CONFIGURACAO_INTEGRADOR).getValorTexto());

	}

	private void doCarregarParametrosGlobais() throws CalsystemNoDataFoundException,
													  CalsystemInvalidArgumentException {

		this.parametroGlobalService.doCarregarParametrosGlobais();

	}

}
