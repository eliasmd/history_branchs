package br.com.calcard.calsystem.dto;

public class DocumentoDigitalizadoDTO {

	private Integer id;

	private String nomeArquivo;

	private Integer idTipoDocumento;

	private String base64;

	public DocumentoDigitalizadoDTO() {

	}

	public DocumentoDigitalizadoDTO(Integer id, String nomeArquivo,
			Integer idTipoDocumento, String base64) {
		super();

		this.id = id;

		this.idTipoDocumento = idTipoDocumento;

		this.nomeArquivo = nomeArquivo;

		this.base64 = base64;
	}

	public String getBase64() {
		return base64;
	}

	public void setBase64(String base64) {
		this.base64 = base64;
	}

	public Integer getIdTipoDocumento() {
		return idTipoDocumento;
	}

	public void setIdTipoDocumento(Integer idTipoDocumento) {
		this.idTipoDocumento = idTipoDocumento;
	}

	public String getNomeArquivo() {
		return nomeArquivo;
	}

	public void setNomeArquivo(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}