package br.com.calcard.calsystem.service;

import br.com.calcard.calframework.exception.CPFException;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.NomeException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calsystem.dto.proposta.DadosBasicosDTO;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.entity.proposta.Proposta;
import br.com.calcard.calsystem.entity.proposta.PropostaP1;
import br.com.calcard.calsystem.exception.proposta.PropostaException;

public class PropostaP1Helper {

	public PropostaP1 doCarregarPropostaP1(DadosBasicosDTO dadosBasicosDTO,
			Usuario usuario, Estabelecimento estabelecimento, Proposta proposta)
			throws CalsystemInvalidArgumentException, PropostaException {

		if (dadosBasicosDTO == null)
			throw new CalsystemInvalidArgumentException(
					"Dados b�sicos n�o informados!");

		if (usuario == null)
			throw new CalsystemInvalidArgumentException(
					"Usu�rio n�o informado!");

		if (estabelecimento == null)
			throw new CalsystemInvalidArgumentException(
					"Estabelecimento n�o informado!");

		if (proposta == null)
			throw new CalsystemInvalidArgumentException(
					"Proposta n�o informada!");

		this.doValidarDadosP1(dadosBasicosDTO);

		PropostaP1 propostaP1 = new PropostaP1();

		propostaP1.setCpf(dadosBasicosDTO.getCpf());

		propostaP1.setDataNascimento(dadosBasicosDTO.getDataNascimento());

		propostaP1.setNome(dadosBasicosDTO.getNome());

		propostaP1.setSexo(dadosBasicosDTO.getSexoEnum());

		propostaP1.setProposta(proposta);

		return propostaP1;

	}

	private void doValidarDadosP1(DadosBasicosDTO dadosP1)
			throws CalsystemInvalidArgumentException, PropostaException {

		if (dadosP1 == null)
			throw new CalsystemInvalidArgumentException(
					"Dados b�sicos n�o informados!");

		if (dadosP1.getDataNascimento() == null)
			throw new PropostaException("Data de nascimento n�o informada!");

		if (CalsystemUtil.doCalcularIdade(dadosP1.getDataNascimento()) < 18)
			throw new PropostaException(
					"Proposta n�o pode ser registrada para menores de 18 anos!");

		if (dadosP1.getSexo() == null)
			throw new PropostaException("Sexo n�o informado!");

		try {
			CalsystemUtil.doValidarNome(dadosP1.getNome());
		} catch (NomeException e) {
			throw new PropostaException("Nome in�lido!", e);
		}

		try {
			CalsystemUtil.doValidarCpf(dadosP1.getCpf());
		} catch (CPFException e) {
			throw new PropostaException("CPF inv�lido!", e);
		}

	}

}
