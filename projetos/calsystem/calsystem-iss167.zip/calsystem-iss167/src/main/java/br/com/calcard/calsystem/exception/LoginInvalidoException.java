package br.com.calcard.calsystem.exception;

public class LoginInvalidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1663833763783478165L;

	public LoginInvalidoException(String mensagem) {
		super(mensagem);
	}

}
