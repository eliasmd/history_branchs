package br.com.calcard.calsystem.dto;

import java.util.List;

public class AnaliseBiometriaDTO {
		
	private BiometriaDTO biometriaLoja;
	
	private BiometriaDTO biometriaCadastro;
	
	private List<BiometriaDTO> biometriaSimilaresLoja;
	
	private List<BiometriaDTO> biometriaSimilaresCadastro;
	
	private List<BiometriaDTO> biometriaFraudes;
	
	public AnaliseBiometriaDTO() {
		super();
	}

	public AnaliseBiometriaDTO(BiometriaDTO biometriaLoja, 
							   BiometriaDTO biometriaCadastro,
							   List<BiometriaDTO> biometriaSimilaresLoja,
							   List<BiometriaDTO> biometriaSimilaresCadastro,
							   List<BiometriaDTO> biometriaFraudes) {
		
		super();
		this.biometriaLoja 				= biometriaLoja;
		this.biometriaCadastro 			= biometriaCadastro;
		this.biometriaSimilaresLoja 	= biometriaSimilaresLoja;
		this.biometriaSimilaresCadastro = biometriaSimilaresCadastro;
		this.biometriaFraudes			= biometriaFraudes;
	}

	public BiometriaDTO getBiometriaLoja() {
		return biometriaLoja;
	}

	public void setBiometriaLoja(BiometriaDTO biometriaLoja) {
		this.biometriaLoja = biometriaLoja;
	}

	public BiometriaDTO getBiometriaCadastro() {
		return biometriaCadastro;
	}

	public void setBiometriaCadastro(BiometriaDTO biometriaCadastro) {
		this.biometriaCadastro = biometriaCadastro;
	}

	public List<BiometriaDTO> getBiometriaSimilaresLoja() {
		return biometriaSimilaresLoja;
	}

	public void setBiometriaSimilaresLoja(List<BiometriaDTO> biometriaSimilaresLoja) {
		this.biometriaSimilaresLoja = biometriaSimilaresLoja;
	}

	public List<BiometriaDTO> getBiometriaSimilaresCadastro() {
		return biometriaSimilaresCadastro;
	}

	public void setBiometriaSimilaresCadastro(
			List<BiometriaDTO> biometriaSimilaresCadastro) {
		this.biometriaSimilaresCadastro = biometriaSimilaresCadastro;
	}

	public List<BiometriaDTO> getBiometriaFraudes() {
		return biometriaFraudes;
	}

	public void setBiometriaFraudes(List<BiometriaDTO> biometriaFraudes) {
		this.biometriaFraudes = biometriaFraudes;
	}
	
}
