package br.com.calcard.calsystem.exception.proposta;

import br.com.calcard.calframework.exception.CalsystemException;

public class ContatosException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5715181268751808593L;

	public ContatosException(String mensagem) {
		super(mensagem);
	}

	public ContatosException(String message, Throwable cause) {
		super(message, cause);
	}

}
