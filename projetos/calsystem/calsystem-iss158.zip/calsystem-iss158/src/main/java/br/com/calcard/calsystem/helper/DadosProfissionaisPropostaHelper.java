package br.com.calcard.calsystem.helper;

import br.com.calcard.calframework.exception.CnpjException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calsystem.dto.EnderecoDTO;
import br.com.calcard.calsystem.dto.proposta.DadosProfissionaisDTO;
import br.com.calcard.calsystem.entity.proposta.Endereco;
import br.com.calcard.calsystem.entity.proposta.PropostaDadosProfissionais;
import br.com.calcard.calsystem.entity.proposta.Telefone;
import br.com.calcard.calsystem.enums.PropostaEnum.TipoTelefoneEnum;
import br.com.calcard.calsystem.exception.EnderecoException;
import br.com.calcard.calsystem.exception.TelefoneException;
import br.com.calcard.calsystem.exception.proposta.DadosProfissionaisException;

public class DadosProfissionaisPropostaHelper {

	public PropostaDadosProfissionais doCarregarDadosProfissionais(
			DadosProfissionaisDTO dadosProfissionaisDTO)
			throws DadosProfissionaisException {

		PropostaDadosProfissionais dadosProfissionais = new PropostaDadosProfissionais();

		this.doValidarDadosProfissionais(dadosProfissionaisDTO);

		dadosProfissionais.setCnpj(dadosProfissionaisDTO.getCnpj());

		dadosProfissionais.setDataAdmissao(dadosProfissionaisDTO
				.getDataAdmissao());

		dadosProfissionais.setNaturezaOcupacao(dadosProfissionaisDTO
				.getNaturezaOcupacaoEnum());

		dadosProfissionais.setNomeEmpresa(dadosProfissionaisDTO
				.getNomeEmpresa());

		dadosProfissionais.setOrigemOutrasRendas(dadosProfissionaisDTO
				.getOrigemOutrasRendas());

		dadosProfissionais.setOutrasRendas(dadosProfissionaisDTO
				.getOutrasRendas());

		dadosProfissionais.setSalario(dadosProfissionaisDTO.getSalario());

		dadosProfissionais.setProfissao(dadosProfissionaisDTO
				.getProfissaoEnum());

		dadosProfissionais.setEndereco(this
				.doCarregarEnderecoProfissional(dadosProfissionaisDTO
						.getEndereco()));

		if (dadosProfissionaisDTO.getTelefoneComercial() != null) {

			dadosProfissionais.setTelefone(new Telefone(dadosProfissionaisDTO
					.getTelefoneComercial().getDddEnum(), dadosProfissionaisDTO
					.getTelefoneComercial().getNumero(), dadosProfissionaisDTO
					.getTelefoneComercial().getRamal(),
					TipoTelefoneEnum.COMERCIAL));

		}

		return dadosProfissionais;

	}

	private void doValidarDadosProfissionais(
			DadosProfissionaisDTO dadosProfissionaisDTO)
			throws DadosProfissionaisException {

		if (dadosProfissionaisDTO == null)
			throw new DadosProfissionaisException(
					"Dados profissionais n�o informados!");

		if (!CalsystemUtil.isNull(dadosProfissionaisDTO.getCnpj())) {

			try {
				CalsystemUtil.doValidarCNPJ(dadosProfissionaisDTO.getCnpj());
			} catch (CnpjException e) {
				throw new DadosProfissionaisException("CNPJ inv�lido!", e);
			}

		}

		if (dadosProfissionaisDTO.getDataAdmissao() == null)
			throw new DadosProfissionaisException(
					"Data de Admiss�o n�o informada!");

		if (dadosProfissionaisDTO.getNaturezaOcupacaoEnum() == null)
			throw new DadosProfissionaisException(
					"Natureza da ocupa��o n�o informada!");

		if (dadosProfissionaisDTO.getProfissaoEnum() == null)
			throw new DadosProfissionaisException("Profiss�o n�o informada!");

		if (dadosProfissionaisDTO.getSalario() == null)
			throw new DadosProfissionaisException("Sal�rio n�o informado!");

		if (dadosProfissionaisDTO.getSalario() < 0)
			throw new DadosProfissionaisException("Sal�rio inv�lido!");

		// if (Arrays.asList(
		// new String[] { NaturezaOcupacaoEnum.EMPREGADO.name(),
		// NaturezaOcupacaoEnum.FUNCIONARIO_PUBLICO.name() })
		// .contains(
		// this.propostaDTO.getDadosProfissionais()
		// .getNaturezaOcupacaoEnum().name())) {

		if (dadosProfissionaisDTO.getEndereco() != null) {

			try {
				new EnderecoPropostaHelper()
						.doValidarEndereco(dadosProfissionaisDTO.getEndereco());
			} catch (EnderecoException e) {
				throw new DadosProfissionaisException(
						"Endere�o profissional inv�lido!", e);
			}
		}

		if (dadosProfissionaisDTO.getTelefoneComercial() != null) {

			try {
				new TelefonePropostaHelper()
						.doValidarTelefone(dadosProfissionaisDTO
								.getTelefoneComercial());
			} catch (TelefoneException e) {
				throw new DadosProfissionaisException(
						"Telefone comercial inv�lido!", e);
			}
		}

	}

	private Endereco doCarregarEnderecoProfissional(EnderecoDTO enderecoDTO) {

		Endereco endereco = new Endereco();

		endereco.setBairro(enderecoDTO.getBairro());

		endereco.setCep(enderecoDTO.getCep());

		endereco.setCidade(enderecoDTO.getCidade());

		endereco.setComplemento(enderecoDTO.getComplemento());

		endereco.setLogradouro(enderecoDTO.getLogradouro());

		endereco.setNumero(enderecoDTO.getNumero());

		endereco.setUf(enderecoDTO.getUf());

		return endereco;

	}

}
