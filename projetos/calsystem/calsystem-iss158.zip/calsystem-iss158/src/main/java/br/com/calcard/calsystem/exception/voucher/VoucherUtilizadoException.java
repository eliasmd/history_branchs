package br.com.calcard.calsystem.exception.voucher;

public class VoucherUtilizadoException extends VoucherException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3902439782432569857L;

}
