package br.com.calcard.calsystem.exception;

public class ContaNaoEncontradaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2773390277462978868L;

}
