package br.com.calcard.calsystem.helper;

import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calsystem.dto.EnderecoDTO;
import br.com.calcard.calsystem.exception.EnderecoException;

public class EnderecoPropostaHelper {

	public void doValidarEndereco(EnderecoDTO endereco)
			throws EnderecoException {

		if (endereco == null)
			throw new EnderecoException("Endere�o n�o informado!");

		if (CalsystemUtil.isNull(endereco.getBairro()))
			throw new EnderecoException("Bairro n�o informado!");

		if (CalsystemUtil.isNull(endereco.getCep()))
			throw new EnderecoException("Cep n�o informado!");

		if (endereco.getCep().replace(" ", "").length() != 8)
			throw new EnderecoException("Cep inv�lido!");

		if (CalsystemUtil.isNull(endereco.getCidade()))
			throw new EnderecoException("Cidade n�o informado!");

		if (CalsystemUtil.isNull(endereco.getLogradouro()))
			throw new EnderecoException("Logradouro n�o informado!");

		if (endereco.getNumero() == null)
			throw new EnderecoException("N�mero n�o informado!");

		if (endereco.getUf() == null)
			throw new EnderecoException(
					"UF do Endere�o residencial n�o informado!");

	}

}
