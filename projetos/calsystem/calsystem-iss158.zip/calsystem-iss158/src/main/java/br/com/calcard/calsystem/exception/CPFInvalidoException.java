package br.com.calcard.calsystem.exception;

public class CPFInvalidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1144780416976899125L;

}
