package br.com.calcard.calsystem.dto;

import java.util.List;

import br.com.calcard.calintegrador.motorBiometria.dto.DocumentDTO;

public class AnalisePendenciaAlteracaoSenhaDTO {
	
	private AnaliseBiometriaDTO analiseBiometriaDTO;
	
	private List<DocumentDTO> documentosDTO;

	public AnalisePendenciaAlteracaoSenhaDTO(AnaliseBiometriaDTO analiseBiometriaDTO,
											 List<DocumentDTO> documentosDTO) {
		this.analiseBiometriaDTO 	= analiseBiometriaDTO;
		this.documentosDTO 			= documentosDTO;
	}

	public AnaliseBiometriaDTO getAnaliseBiometriaDTO() {
		return analiseBiometriaDTO;
	}

	public void setAnaliseBiometriaDTO(AnaliseBiometriaDTO analiseBiometriaDTO) {
		this.analiseBiometriaDTO = analiseBiometriaDTO;
	}

	public List<DocumentDTO> getDocumentosDTO() {
		return documentosDTO;
	}

	public void setDocumentosDTO(List<DocumentDTO> documentosDTO) {
		this.documentosDTO = documentosDTO;
	}

}
