package br.com.calcard.calsystem.exception.voucher;

public class VoucherDisponivelException extends VoucherException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8433546516335454415L;

}
