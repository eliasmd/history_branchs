package br.com.calcard.calsystem.service;

import java.util.ArrayList;
import java.util.List;

import br.com.calcard.calframework.exception.CalsystemDAOException;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.DocumentDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoAnexoDocumentosDTO;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;

public class IntegracaoMotorBiometriaPropostaHelper {

	private IMotorBiometria motorBiometriaService;

	public IntegracaoMotorBiometriaPropostaHelper(
			IMotorBiometria motorBiometriaService) {
		this.motorBiometriaService = motorBiometriaService;
	}

	public IntegracaoAnexoDocumentosDTO doAnexarDocumentos(
			List<DocumentoDigitalizado> documentosDigitalizados,
			Integer idCreditRequest) throws ServiceException,
			CalsystemDAOException, IntegracaoException,
			IntegracaoMotorBiometriaException,
			CalsystemInvalidArgumentException {

		if (documentosDigitalizados == null
				|| documentosDigitalizados.size() == 0)
			throw new ServiceException(
					"Documentos digitalizados n�o informados!");

		List<DocumentDTO> documentsDTO = new ArrayList<DocumentDTO>();

		for (DocumentoDigitalizado documentoDigitalizado : documentosDigitalizados) {

			documentsDTO.add(new DocumentDTO(documentoDigitalizado.getTipo()
					.getDocumentType(), documentoDigitalizado.getBase64()));

		}

		return this.motorBiometriaService.doAnexarDocumentos(documentsDTO,
				idCreditRequest);

	}

}
