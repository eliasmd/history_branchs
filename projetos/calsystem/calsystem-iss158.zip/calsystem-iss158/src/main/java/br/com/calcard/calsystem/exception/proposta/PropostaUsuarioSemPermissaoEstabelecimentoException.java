package br.com.calcard.calsystem.exception.proposta;

public class PropostaUsuarioSemPermissaoEstabelecimentoException extends
		Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3473948080812988296L;

	public PropostaUsuarioSemPermissaoEstabelecimentoException(String mensagem) {
		super(mensagem);
	}

}
