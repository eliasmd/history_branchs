package br.com.calcard.calsystem.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.exception.CalsystemDAOException;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calsystem.entity.Periferico;
import br.com.calcard.calsystem.entity.TokenLogin;
import br.com.calcard.calsystem.entity.TokenSessao;
import br.com.calcard.calsystem.entity.TokenTransacao;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.enums.Enum.StatusTokenEnum;
import br.com.calcard.calsystem.exception.TokenInvalidoException;
import br.com.calcard.calsystem.exception.token.TokenSessaoInvalidoException;
import br.com.calcard.calsystem.exception.token.TokenSessaoNaoEncontradoException;
import br.com.calcard.calsystem.interfaces.IToken;
import br.com.calcard.calsystem.util.Parametro;

@Service
public class TokenService implements IToken {

	private ICalsystemDAO daoService;

	private CriptografiaService criptografiaService;

	@Autowired
	public TokenService(CriptografiaService criptografiaService,
			ICalsystemDAO daoService) {

		this.criptografiaService = criptografiaService;

		this.daoService = daoService;

	}

	@Override
	public String doGerarToken() throws ServiceException {

		Integer r = new Random().nextInt();

		if (r < 0)
			r *= -1;

		String semente = new SimpleDateFormat("MMddyyHHmmssSSS")
				.format(new Date()) + r;

		return criptografiaService.new HASH().MD5(semente);

	}

	@Override
	public TokenSessao doValidarTokens(String tSessao, String tTransacao)
			throws CalsystemNoDataFoundException, TokenInvalidoException,
			CalsystemInvalidArgumentException {

		TokenSessao tokenSessao = this.doConsultarTokenSessao(tSessao);

		// if (!tokenSessao.getTokenTransacao().getToken().equals(tTransacao))
		// throw new TokenTransacaoInvalidoException(
		// "O Token de Transa��o informado n�o confere com o vig�nte.");

		return tokenSessao;

	}

	@Override
	public TokenTransacao doGerarTokenTransacao(TokenSessao tokenSessao)
			throws ServiceException, TokenSessaoInvalidoException,
			CalsystemDAOException, TokenSessaoNaoEncontradoException {

		if (tokenSessao == null)
			throw new TokenSessaoInvalidoException(
					"Token de Sess�o n�o informado!");

		String tTransacao = this.doGerarToken();

		return new TokenTransacao(tTransacao, tokenSessao.getPeriferico(),
				new Date(), null);

	}

	@Override
	public TokenLogin doGerarTokenLogin(Periferico periferico)
			throws CalsystemInvalidArgumentException, ServiceException {

		if (periferico == null)
			throw new CalsystemInvalidArgumentException(
					"Perif�rico n�o informado!");

		String token = this.doGerarToken();

		TokenLogin tokenLogin = new TokenLogin(token, periferico, new Date(),
				CalsystemUtil.doSomarSegundos(new Date(), 30),
				StatusTokenEnum.ATIVO);

		this.daoService.doCreate(tokenLogin, "Token de login n�o informado!");

		return tokenLogin;

	}

	@Override
	public TokenSessao doGerarTokenSessao(TokenLogin tokenLogin, Usuario usuario)
			throws CalsystemInvalidArgumentException, ServiceException {

		if (tokenLogin == null)
			throw new CalsystemInvalidArgumentException(
					"Token de login n�o informado!");

		else if (usuario == null)
			throw new CalsystemInvalidArgumentException(
					"Usu�rio n�o informado!");

		String tSessao = this.doGerarToken();

		String tTransacao = this.doGerarToken();

		TokenTransacao tokenTransacao = new TokenTransacao(tTransacao,
				tokenLogin.getPeriferico(), new Date(), null);

		TokenSessao tokenSessao = new TokenSessao(tSessao,
				tokenLogin.getPeriferico(), new Date(), null, tokenTransacao,
				usuario, StatusTokenEnum.ATIVO);

		this.daoService.doCreate(tokenSessao, "Token de sess�o n�o informado!");

		return tokenSessao;
	}

	public TokenLogin doConsultarTokenLogin(String tLogin)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		if (tLogin == null)
			throw new CalsystemInvalidArgumentException(
					"Token de login n�o informado!");

		return this.daoService.doGetSingleResult(
				TokenLogin.NQ_SELECT_TOKEN_LOGIN_BY_TOKEN, new Parametro()
						.doAddParametro("token", tLogin).getParametros(),
				TokenLogin.class, true, "Token de Login n�o encontrado!");

	}

	@Override
	public TokenSessao doConsultarTokenSessao(String tSessao)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		if (tSessao == null)
			throw new CalsystemInvalidArgumentException(
					"Token de sess�o n�o informado!");

		return this.daoService.doGetSingleResult(
				TokenSessao.NQ_SELECT_TOKEN_SESSAO_BY_TOKEN, new Parametro()
						.doAddParametro("token", tSessao).getParametros(),
				TokenSessao.class, true, "Token de sess�o n�o encontrado!");

	}

	@Override
	public TokenLogin doValidarTokenLogin(String tLogin)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, TokenInvalidoException {

		if (tLogin == null)
			throw new CalsystemInvalidArgumentException(
					"Token de Login n�o informado!");

		TokenLogin tokenLogin = this.daoService.doGetSingleResult(
				TokenLogin.NQ_SELECT_TOKEN_LOGIN_BY_TOKEN, new Parametro()
						.doAddParametro("token", tLogin).getParametros(),
				TokenLogin.class, true, "Token de login n�o encontrado!");

		if (tokenLogin.getStatus().equals(StatusTokenEnum.UTILIZADO))
			throw new TokenInvalidoException("Token de login utilizado!");

		else if (tokenLogin.getStatus().equals(StatusTokenEnum.EXPIRADO))
			throw new TokenInvalidoException("Token de login expirado!");

		else if (tokenLogin.getDataExpiracao().before(new Date())) {
			tokenLogin.setStatus(StatusTokenEnum.EXPIRADO);

			this.daoService.doUpdate(tokenLogin,
					"Token de login n�o informado!");

			throw new TokenInvalidoException("Token de login expirado!");

		} else {
			tokenLogin.setStatus(StatusTokenEnum.UTILIZADO);

			this.daoService.doUpdate(tokenLogin,
					"Token de login n�o informado!");

			return tokenLogin;
		}

	}

	public TokenSessao doGerarTokenSessao(String tSessao)
			throws CalsystemNoDataFoundException, TokenInvalidoException,
			CalsystemInvalidArgumentException, ServiceException {

		TokenSessao tokenSessao = this.doConsultarTokenSessao(tSessao);

		String tTransacao = this.doGerarToken();

		tokenSessao.setTokenTransacao(new TokenTransacao(tTransacao,
				tokenSessao.getPeriferico(), new Date(), null));

		this.daoService.doUpdate(tokenSessao, "Token de sess�o n�o informado!");

		return tokenSessao;

	}
	
	public void doRenovarTokenSessao(TokenSessao tokenSessao)
			throws TokenSessaoInvalidoException, CalsystemDAOException,
			CalsystemInvalidArgumentException {

		if (tokenSessao == null)
			throw new TokenSessaoInvalidoException(
					"Token de Sess�o n�o informado!");

		tokenSessao.setDataExpiracao(CalsystemUtil.doSomarMinutos(new Date(),
				10));

		this.daoService.doUpdate(tokenSessao, "Token de sess�o n�o informado!");

	}

}
