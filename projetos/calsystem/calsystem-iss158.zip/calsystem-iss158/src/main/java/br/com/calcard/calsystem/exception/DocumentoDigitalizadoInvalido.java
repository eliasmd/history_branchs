package br.com.calcard.calsystem.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class DocumentoDigitalizadoInvalido extends CalsystemException {

	private static final long serialVersionUID = 3361579714762328436L;

	public DocumentoDigitalizadoInvalido(String message) {
		super(message);
	}

}
