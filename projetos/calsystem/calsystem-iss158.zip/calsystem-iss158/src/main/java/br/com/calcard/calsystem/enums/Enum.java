package br.com.calcard.calsystem.enums;

public class Enum {

	public enum TipoTokenEnum {
		LOGIN, SESSAO, TRANSACAO;
	}

	public enum StatusPadraoEnum {
		ATIVO, INATIVO;
	}

	public enum StatusTokenEnum {
		ATIVO, EXPIRADO, UTILIZADO
	}

	public enum StatusEstabelecimentoEnum {
		ATIVO, INATIVO;
	}
	
	public enum StatusFilaDePendenciasEnum {
		PENDENTE, APROVADO, NEGADO;
	}
	
	public static String[] getListaStatusFilaDePendenciasEnum() {
		StatusFilaDePendenciasEnum[] states = StatusFilaDePendenciasEnum.values();
	    String[] listaEnum = new String[states.length];

	    for (int i = 0; i < states.length; i++) {
	    	listaEnum[i] = states[i].name();
	    }
	    
	    return listaEnum;
	}

}
