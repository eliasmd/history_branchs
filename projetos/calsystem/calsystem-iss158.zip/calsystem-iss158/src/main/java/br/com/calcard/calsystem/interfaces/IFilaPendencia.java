package br.com.calcard.calsystem.interfaces;

import java.util.Date;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calsystem.dto.AnalisePendenciaAlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.AnalisePendenciaDTO;
import br.com.calcard.calsystem.dto.PendenciaAlteracaoSenhaDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.AnalisePendenciaAlteracaoSenha;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.Usuario;

public interface IFilaPendencia {

	public List<String> doListarStatusFilaDePendencia();

	public List<AlteracaoSenha> doListarFilaDePendencia(String status,
			String cpf) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public AnalisePendenciaAlteracaoSenha doAnalisarPendencia(AnalisePendenciaDTO analisePendenciaDTO) throws CalsystemInvalidArgumentException, 
																											  CalsystemNoDataFoundException,
																											  ServiceException;

	public List<AnalisePendenciaAlteracaoSenha> doCarregarAnaliseIniciada(List<AlteracaoSenha> listaAlteracaoSenhaDTO) throws CalsystemNoDataFoundException,
																															  CalsystemInvalidArgumentException;

	public AlteracaoSenha doNegarPendencia(Integer idAlteracaoSenha,
			String parecer) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public AlteracaoSenha doListarDocumentosAvaliacao(Integer idAlteracaoSenha)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public ResponseEntity<Object> doAprovarPendencia(Integer idAlteracaoSenha);

	public List<AlteracaoSenha> doListarAlteracoesSenha(String status, 
													    String cpf) throws CalsystemNoDataFoundException,
																		   CalsystemInvalidArgumentException;

	public AlteracaoSenha doConsultarPendenciaAlteracaoSenha(
			Integer idPendencia) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public PendenciaAlteracaoSenhaDTO doComporPendenciaAlteracaoSenhaDTO(AlteracaoSenha pendenciaAlteracaoSenha) throws CalsystemInvalidArgumentException;

	public String doCalcularTME(Date dataRegistro, Date dataInicioAnalise) throws CalsystemInvalidArgumentException;

	public String doCalcularTMA(Date dataInicioAnalise, Date dataFimAnalise);

	public AnalisePendenciaAlteracaoSenhaDTO doIniciarAnalisePendenciaAlteracaoSenha(Integer idPendencia, 
																				     Usuario analista) throws CalsystemNoDataFoundException, 
																								 			  CalsystemInvalidArgumentException, 
																								 			  ServiceException, 
																								 			  IntegracaoException, 
																								 			  IntegracaoMotorBiometriaException;
	
	public AlteracaoSenha doRegistrarPendenciaAlteracaoSenha(Estabelecimento estabelecimento, 
														  	 Usuario operador, 
														  	 Integer idConta,
														  	 String cpfPortador,
														  	 String senha,
														  	 Integer idCreditRequest) throws CalsystemNoDataFoundException, 
														  	 								 CalsystemInvalidArgumentException;
	
	public void doNegarPendenciaAlteracaoSenha(Integer idPendencia,
			String parecer) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException, IntegracaoException, ServiceException, IntegracaoMotorBiometriaException;

}
