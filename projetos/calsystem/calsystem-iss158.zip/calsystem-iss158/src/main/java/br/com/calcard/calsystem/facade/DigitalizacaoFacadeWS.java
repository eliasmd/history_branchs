package br.com.calcard.calsystem.facade;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.ws.CalsystemFacadeWS;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.dto.ProcessoDigitalizacaoDTO;
import br.com.calcard.calsystem.dto.TipoDocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.entity.ProcessoDigitalizacao;
import br.com.calcard.calsystem.entity.RegraDigitalizacao;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;
import br.com.calcard.calsystem.util.Parametro;

@Component
public class DigitalizacaoFacadeWS extends CalsystemFacadeWS {

	private ICalsystemDAO daoService;

	private IDigitalizacao digitalizacaoService;

	@Autowired
	public DigitalizacaoFacadeWS(ICalsystemDAO daoService,
			IDigitalizacao digitalizacaoService) {
		super();
		this.daoService = daoService;
		this.digitalizacaoService = digitalizacaoService;
	}

	public ResponseEntity<Object> doListarProcessosDigitalizacao() {

		try {

			List<ProcessoDigitalizacaoDTO> processoDigitalizacaoDTO = new ArrayList<ProcessoDigitalizacaoDTO>();

			for (ProcessoDigitalizacao processoDigitalizacao : this.daoService
					.doList(ProcessoDigitalizacao.class))

				processoDigitalizacaoDTO.add(new ProcessoDigitalizacaoDTO(
						processoDigitalizacao.getId(), processoDigitalizacao
								.getNome(), processoDigitalizacao
								.getDescricao(), processoDigitalizacao
								.getSigla()));

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"ProcessosDigitalizacao", processoDigitalizacaoDTO)
					.getParametros());

		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doListarTiposDocumentosDigitalizaveis(
			Integer idProcesso) {

		try {

			List<RegraDigitalizacao> documentosDigitalizaveis = this.digitalizacaoService
					.doListarTiposDocumentosDigitalizaveis(idProcesso);

			List<TipoDocumentoDigitalizadoDTO> tiposDocumentosDigitalizaveisDTO = new ArrayList<TipoDocumentoDigitalizadoDTO>();

			for (RegraDigitalizacao documentoDigitalizavel : documentosDigitalizaveis) {

				tiposDocumentosDigitalizaveisDTO
						.add(new TipoDocumentoDigitalizadoDTO(
								documentoDigitalizavel
										.getTipoDocumentoDigitalizavel()
										.getId(), documentoDigitalizavel
										.getTipoDocumentoDigitalizavel()
										.getNome(), documentoDigitalizavel
										.getDigitalizacaoObrigatoria(),
								documentoDigitalizavel
										.getTipoDocumentoDigitalizavel()
										.getSigla()));

			}

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"TiposDocumentos", tiposDocumentosDigitalizaveisDTO)
					.getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doListarMiniaturas(String cpf) {

		try {

			List<DocumentoDigitalizadoDTO> documentos = this.digitalizacaoService
					.doListarMiniaturas(cpf);

			List<DocumentoDigitalizadoDTO> documentosDTO = new ArrayList<DocumentoDigitalizadoDTO>();

			for (DocumentoDigitalizadoDTO documento : documentos)
				documentosDTO.add(new DocumentoDigitalizadoDTO(documento
						.getId(), null, null, documento.getBase64()));

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Miniaturas", documentosDTO).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doAlterarTipoDocumento(
			Integer idTipoDocumento, Integer idDocumento) {

		try {

//			DocumentoDigitalizado documentoDigitalizado = this.digitalizacaoService
//					.doAlterarTipoDocumento(idTipoDocumento, idDocumento);
//
//			DocumentoDigitalizadoDTO documentoDigitalizadoDTO = new DocumentoDigitalizadoDTO(
//					documentoDigitalizado.getId(), null, documentoDigitalizado
//							.getTipo().getId(), null);
//
//			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
//					"DocumentoDigitalizado", documentoDigitalizadoDTO)
//					.getParametros());
			
			return null;

		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}
}
