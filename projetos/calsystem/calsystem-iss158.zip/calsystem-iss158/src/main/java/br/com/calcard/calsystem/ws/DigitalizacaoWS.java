package br.com.calcard.calsystem.ws;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calsystem.dto.DocumentoDTO;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.facade.DigitalizacaoFacadeWS;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;
import br.com.calcard.calsystem.util.Parametro;

@RestController
@RequestMapping("/ws/digitalizacao")
@Scope(value = "request")
public class DigitalizacaoWS extends CalsystemWS {

	private DigitalizacaoFacadeWS digitalizacaoFacadeWS;

	private IDigitalizacao digitalizacaoService;

	@Autowired
	public DigitalizacaoWS(DigitalizacaoFacadeWS digitalizacaoFacadeWS,
			IDigitalizacao digitalizacaoService) {
		super();
		this.digitalizacaoFacadeWS = digitalizacaoFacadeWS;
		this.digitalizacaoService = digitalizacaoService;
	}

	@RequestMapping(value = "/listarProcessos", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarProcessos(
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(tSessao);

		return this.digitalizacaoFacadeWS.doListarProcessosDigitalizacao();

	}

	@RequestMapping(value = "/listarTiposDocumentosDigitalizaveis", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarTiposDocumentosDigitalizaveis(
			@RequestParam(value = "idProcesso", required = true) Integer idProcesso,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(tSessao,
				new Parametro().doAddParametro("idProcesso", idProcesso)
						.getParametros());

		return this.digitalizacaoFacadeWS
				.doListarTiposDocumentosDigitalizaveis(idProcesso);

	}

	@RequestMapping(value = "/listarMiniaturas", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarMiniaturas(
			@RequestParam(value = "cpf", required = true) String cpf,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(tSessao, new Parametro().doAddParametro("cpf", cpf)
				.getParametros());

		return this.digitalizacaoFacadeWS.doListarMiniaturas(cpf);

	}

	@RequestMapping(value = "/documentos/{cpf}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doListarDocumentosDigitalizados(
			@PathVariable("cpf") String cpf,
			@RequestHeader(value = "tSessao") String tSessao) {

		try {

			super.doGravarLog(tSessao,
					new Parametro().doAddParametro("cpf", cpf).getParametros());

			List<DocumentoDigitalizadoDTO> documentos = this.digitalizacaoService
					.doListarDocumentosDigitalizados(cpf);

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Documentos", documentos).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);

		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	@RequestMapping(value = "/documentos/{nomeDocumento}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<Object> doDescartarDocumentos(
			@PathVariable("nomeDocumento") String nomeDocumento,
			@RequestHeader(value = "tSessao") String tSessao) {

		try {

			super.doGravarLog(
					tSessao,
					new Parametro().doAddParametro("nomeDocumento",
							nomeDocumento).getParametros());

			this.digitalizacaoService.doDescartarDocumento(nomeDocumento);

			return super.doRetornarSucessoWS();

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	@RequestMapping(value = "/alterarTipoDocumento", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doAlterarTipoDocumento(
			@RequestHeader(value = "tSessao") String tSessao,
			@RequestParam(value = "idTipoDocumento", required = true) Integer idTipoDocumento,
			@RequestParam(value = "idDocumento", required = true) Integer idDocumento) {
		super.doGravarLog(
				tSessao,
				new Parametro()
						.doAddParametro("idTipoDocumento", idTipoDocumento)
						.doAddParametro("idDocumento", idDocumento)
						.getParametros());

		return this.digitalizacaoFacadeWS.doAlterarTipoDocumento(
				idTipoDocumento, idDocumento);

	}
	
	@RequestMapping(value = "/documentos/{idCreditRequest}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doListarDocumentosAvaliacao(@PathVariable("idCreditRequest") Integer creditRequestId,
															  @RequestHeader(value = "tSessao") String tSessao) {
		
		try{
	
			super.doGravarLog(tSessao,
							  new Parametro().doAddParametro("creditRequestId",creditRequestId).getParametros());
			
			List<DocumentoDTO> listaDocumentosDTO = new ArrayList<DocumentoDTO>();
	
			for (br.com.calcard.calintegrador.motorBiometria.dto.DocumentDTO documentoBiometria : this.digitalizacaoService.doConsultarDocumentosDigitalizados(creditRequestId)) {
				
				DocumentoDTO documento = new DocumentoDTO();
				documento.setImagem(documentoBiometria.getImage());
				documento.setIdTipoDocumento(documentoBiometria.getType());
				
				listaDocumentosDTO.add(documento);
	
			}
			
			return super.doRetornarSucessoWS(new Parametro().doAddParametro("DocumentosDigitalizados", listaDocumentosDTO).getParametros());
	
		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

}
