package br.com.calcard.calsystem.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.ws.CalsystemFacadeWS;
import br.com.calcard.calsystem.entity.ParametroGlobal;
import br.com.calcard.calsystem.entity.TokenSessao;
import br.com.calcard.calsystem.entity.TokenTransacao;
import br.com.calcard.calsystem.exception.token.TokenSessaoInvalidoException;
import br.com.calcard.calsystem.exception.token.TokenTransacaoInvalidoException;
import br.com.calcard.calsystem.interfaces.IParametroGlobal;

@Component
public class HttpInterceptorService extends HandlerInterceptorAdapter {

	private TokenService tokenService;

	private CalsystemFacadeWS calsystemFacadeWS;

	private IParametroGlobal parametroglobalService;

	@Autowired
	public HttpInterceptorService(IParametroGlobal parametroGlobalService,
			TokenService tokenService, CalsystemFacadeWS calsystemFacadeWS) {
		this.parametroglobalService = parametroGlobalService;
		this.tokenService = tokenService;
		this.calsystemFacadeWS = calsystemFacadeWS;
	}
	
	
	@Transactional
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) {

		try {

			// this.cloneInputStream(request.getInputStream());

			if (!isValidarToken()) {

				response.addHeader("tSessao", request.getHeader("tSessao"));

				response.addHeader("tTransacao",
						request.getHeader("tTransacao"));

				return true;

			} else if (!request.getPathInfo()
					.equals("/ws/seguranca/tokenLogin")
					&& !request.getPathInfo().equals("/ws/seguranca/login")) {

				String tSessao = request.getHeader("tSessao");

				if (tSessao == null)
					throw new TokenSessaoInvalidoException(
							"Token de Sess�o n�o informado!");

				String tTransacao = request.getHeader("tTransacao");

				if (tTransacao == null)
					throw new TokenTransacaoInvalidoException(
							"Token de transa��o n�o informado!");

				TokenSessao tokenSessao = tokenService.doValidarTokens(tSessao,
						tTransacao);

				this.tokenService.doRenovarTokenSessao(tokenSessao);

				TokenTransacao tokenTransacao = this.tokenService
						.doGerarTokenTransacao(tokenSessao);

				response.addHeader("tSessao", tSessao);

				response.addHeader("tTransacao", tokenTransacao.getToken());

			}

			return true;

		} catch (CalsystemException e) {
			calsystemFacadeWS.doRetornarErroWS(e);

			return false;

		} catch (Exception e) {
			calsystemFacadeWS.doRetornarErroWS(e);

			return false;
		}

	}

	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) {

		// if (!request.getPathInfo().equals("/ws/seguranca/tokenLogin")
		// && !request.getPathInfo().equals("/ws/seguranca/login")) {
		//
		// String tSessao = request.getHeader("tSessao");
		//
		// try {
		// TokenSessao tokenSessao = this.tokenService
		// .doGerarTokenSessao(tSessao);
		//
		// response.addHeader("tSessao", tokenSessao.getToken());
		// response.addHeader("tTransacao", tokenSessao
		// .getTokenTransacao().getToken());
		//
		// } catch (TokenSessaoInvalidoException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (CalsystemDAOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (TokenSessaoNaoEncontradoException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (ServiceException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// // TokenSessao tokenSessao =
		// // this.tokenService.doConsultarTokenSessao(tSessao);
		// //
		// // response.addHeader(name, value);
		// //
		// // response.addHeader(name, value);
		// }

	}

	private boolean isValidarToken() throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		return this.parametroglobalService.doConsultar(
				ParametroGlobal.PARAMETRO_VALIDA_TOKEN).getValorBooleano();

	}

	private String getBody(HttpServletRequest request) throws IOException {

		String body = null;
		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader bufferedReader = null;

		try {
			InputStream inputStream = request.getInputStream();

			if (inputStream != null) {
				// bufferedReader = new BufferedReader(new
				// InputStreamReader(inputStream));
				// char[] charBuffer = new char[128];
				// int bytesRead = -1;
				// while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
				// stringBuilder.append(charBuffer, 0, bytesRead);
				// }
			} else {
				stringBuilder.append("");
			}
		} catch (IOException ex) {
			throw ex;
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (IOException ex) {
					throw ex;
				}
			}
		}

		body = stringBuilder.toString();
		return body;
	}
}
