package br.com.calcard.calsystem.entity;

public interface EntityPrototype<T> {

	public T doClone();

}
