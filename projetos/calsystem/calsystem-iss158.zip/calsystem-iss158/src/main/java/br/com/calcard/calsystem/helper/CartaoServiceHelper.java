package br.com.calcard.calsystem.helper;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calsystem.dto.AlteracaoSenhaDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.exception.proposta.PropostaDocumentosDigitalizadosException;
import br.com.calcard.calsystem.service.PropostaP2Service;

public class CartaoServiceHelper {
	
	public AlteracaoSenha doCarregarDadosAlteracaoDeSenha(AlteracaoSenhaDTO alteracaoSenhaDTO) throws CalsystemNoDataFoundException, CalsystemInvalidArgumentException, PropostaDocumentosDigitalizadosException{
		
		PropostaP2Service validador = new PropostaP2Service();
		validador.doValidarDocumentosDigitalizados(alteracaoSenhaDTO.getDocumentosDigitalizados());
		
		AlteracaoSenha alteracaoSenha = new AlteracaoSenha();
		//alteracaoSenha.setConta(alteracaoSenhaDTO.getIdConta());
		alteracaoSenha.setSenha(alteracaoSenhaDTO.getSenha());
		//alteracaoSenha.setCpf(alteracaoSenhaDTO.getCpfPortador());
		//alteracaoSenha.setTitular(true);
		alteracaoSenha.setStatus("PENDENTE");
		//alteracaoSenha.setNome(alteracaoSenhaDTO.getNome());
		
		return alteracaoSenha;
	}
	

}
