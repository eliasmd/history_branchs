package br.com.calcard.calsystem.exception.proposta;

public class PropostaP1NaoAprovada extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7677853045627730565L;

	public PropostaP1NaoAprovada(String mensagem) {
		super(mensagem);
	}

}
