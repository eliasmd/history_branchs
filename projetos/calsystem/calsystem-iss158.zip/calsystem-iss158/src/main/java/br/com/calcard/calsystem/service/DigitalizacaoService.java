package br.com.calcard.calsystem.service;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.DocumentDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoAnexoDocumentosDTO;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.entity.ParametroGlobal;
import br.com.calcard.calsystem.entity.ProcessoDigitalizacao;
import br.com.calcard.calsystem.entity.RegraDigitalizacao;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;
import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;
import br.com.calcard.calsystem.enums.Enum.StatusPadraoEnum;
import br.com.calcard.calsystem.exception.DocumentoDigitalizadoInvalido;
import br.com.calcard.calsystem.exception.TipoDocumentoDigitalizadoInvalido;
import br.com.calcard.calsystem.helper.DigitalizacaoHelper;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;
import br.com.calcard.calsystem.interfaces.IParametroGlobal;
import br.com.calcard.calsystem.util.Parametro;

@Service
public class DigitalizacaoService implements IDigitalizacao {

	private String extensaoArquivo;

	private String localArquivo;

	private double proposcaoMiniatura;

	private DigitalizacaoHelper digitalizacaoHelper;

	private ICalsystemDAO daoService;

	private IMotorBiometria motorBiometriaService;

	@Autowired
	public DigitalizacaoService(IParametroGlobal parametroGlobalService,
								ICalsystemDAO daoService,
								IMotorBiometria motorBiometriaService) throws CalsystemNoDataFoundException,
																 			  CalsystemInvalidArgumentException {

		this.extensaoArquivo 			= parametroGlobalService.doConsultar(ParametroGlobal.PARAMETRO_FORMATO_ARQUIVO).getValorTexto();

		this.localArquivo 				= parametroGlobalService.doConsultar(ParametroGlobal.PARAMETRO_CAMINHO_DOCUMENTO_DIGITALIZADO).getValorTexto();

		this.proposcaoMiniatura 		= parametroGlobalService.doConsultar(ParametroGlobal.PARAMETRO_PROPORCAO_THUMB).getValorNumero().doubleValue();

		this.digitalizacaoHelper 		= new DigitalizacaoHelper();

		this.daoService 				= daoService;
		
		this.motorBiometriaService 		= motorBiometriaService;

	}

	@Override
	public String doConverterBase64(String nomeArquivo) throws CalsystemInvalidArgumentException,
															   CalsystemNoDataFoundException, 
															   ServiceException {

		if (nomeArquivo == null)
			throw new CalsystemInvalidArgumentException(
					"Nome do arquivo n�o informado!");

		File arquivo = this.doConsultarArquivoRede(nomeArquivo);

		return this.digitalizacaoHelper.doConverterBase64(arquivo,
				this.extensaoArquivo);

	}

	@Override
	public File doConsultarArquivoRede(String nomeArquivo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		if (CalsystemUtil.isNull(nomeArquivo))
			throw new CalsystemInvalidArgumentException(
					"Nome do arquivo n�o informado!");

		File file = new File(this.localArquivo + nomeArquivo);

		if (!file.exists())
			throw new CalsystemNoDataFoundException(
					new StringBuilder()
							.append("N�o foi encontrado nenhum arquivo na rede com o nome informado!")
							.append(" NOME ARQUIVO: ").append(nomeArquivo)
							.toString());

		return file;

	}

	@Transactional
	@Override
	public List<DocumentoDigitalizadoDTO> doListarMiniaturas(String nomeArquivo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, ServiceException {

		if (nomeArquivo == null)
			throw new CalsystemInvalidArgumentException(
					"Nome do arquivo n�o informado!");

		List<DocumentoDigitalizadoDTO> documentos = new ArrayList<DocumentoDigitalizadoDTO>();

		// carrega arquivos da tabela
		List<DocumentoDigitalizado> documentosDigitalizadosTabela = this.daoService
				.doGetResultList(
						DocumentoDigitalizado.NQ_SELECT_DOCUMENTOS_BY_CPF,
						new Parametro().doAddParametro("cpf", nomeArquivo)
								.getParametros(), DocumentoDigitalizado.class);

		for (int i = 0; i < documentosDigitalizadosTabela.size(); i++) {
			// disponibiliza apenas documentos ativos(que ainda nao foram
			// utilizados em solicitacoes de senha)
			if (documentosDigitalizadosTabela.get(i).getStatus() == StatusPadraoEnum.ATIVO) {
				// converte base64 para imagem
				BufferedImage imagem = digitalizacaoHelper
						.decodeBase64ToImage(documentosDigitalizadosTabela.get(
								i).getBase64());
				// transforma imagem em base64 miniatura
				String miniaturaImageBase64 = this.digitalizacaoHelper
						.doCriarThmImagem(imagem, this.proposcaoMiniatura,
								extensaoArquivo);

				documentos.add(new DocumentoDigitalizadoDTO(
						documentosDigitalizadosTabela.get(i).getId(), null,
						null, miniaturaImageBase64));
			}
		}

		// carrega arquivos da rede
		File[] listaArquivos = this.digitalizacaoHelper.doListarArquivosRede(
				localArquivo, nomeArquivo, extensaoArquivo);

		// CARREGA O PROCESSO DEFAULT (ALTERA��O DE SENHA) PARA O VINCULO COM O
		// DOCUMENTO DIGITALIZADO.
		// NO FUTURA, QUANDO HOUVER OUTROS PROCESSOS QUE TAMBEM DIGITALIZEM
		// DOCUMENTOS, O FRONT PRECISAR� ENVIAR O PROCESSO NA REQUISICAO.

		if (listaArquivos.length > 0) {

			List<ProcessoDigitalizacao> processosDigitalizacao = this.daoService
					.doList(ProcessoDigitalizacao.class, true,
							"Nenhum processo de digitaliza��o cadastrado! Entre em contato com o suporte!");

			ProcessoDigitalizacao processoDigitalizacao = null;

			for (ProcessoDigitalizacao processo : processosDigitalizacao) {
				if (processo.getSigla().equals(
						ProcessoDigitalizacao.SIGLA_ALTERACAO_SENHA))
					processoDigitalizacao = processo;
			}

			if (processoDigitalizacao == null)
				throw new CalsystemNoDataFoundException(
						"Processo de digitaliza��o de altera��o de senha n�o encontrado!");

			for (int i = 0; i < listaArquivos.length; i++) {

				String base64 = this.digitalizacaoHelper.doConverterBase64(
						listaArquivos[i], this.extensaoArquivo);

				DocumentoDigitalizado documentoDigitalizado = new DocumentoDigitalizado(
						null, nomeArquivo, base64, StatusPadraoEnum.ATIVO,
						processoDigitalizacao);

				this.daoService.doCreate(documentoDigitalizado);

				String miniaturaBase64 = this.digitalizacaoHelper.doCriarThm(
						listaArquivos[i], this.proposcaoMiniatura,
						this.extensaoArquivo);

				documentos.add(new DocumentoDigitalizadoDTO(
						documentoDigitalizado.getId(), null, null,
						miniaturaBase64));

				// deleta o arquivo apos carregar para a tabela
				listaArquivos[i].delete();

			}
		}

		if (documentos.size() == 0)
			throw new CalsystemNoDataFoundException(new StringBuilder(
					"N�o foi encontrado nenhum documento digitalizado!")
			// "N�o foi encontrado nenhum arquivo com o nome informado!")
			// .append(" NOME ARQUIVO: ").append(nomeArquivo)
					.toString());

		return documentos;

	}

	@Override
	@Transactional
	public void doDescartarDocumentos(Integer idDocumento)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		DocumentoDigitalizado documento = this.daoService
				.doRead(idDocumento,
						DocumentoDigitalizado.class,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhum documento para o ID informado! ID: ")
								.append(idDocumento).toString(),
						"ID do documento n�o informado!");

		this.daoService.doDelete(documento);

	}

	@Override
	public List<RegraDigitalizacao> doListarTiposDocumentosDigitalizaveis(
			Integer idProcesso) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		ProcessoDigitalizacao processo = this.daoService
				.doRead(idProcesso,
						ProcessoDigitalizacao.class,
						true,
						new StringBuilder(
								"N�o foi encontrado nenhum processo de digitaliza��o com o ID informado! ID: ")
								.append(idProcesso).toString(),
						"ID do processo de digitaliza��o n�o foi informado!");

		return this.daoService
				.doGetResultList(
						RegraDigitalizacao.NQ_SELECT_REGRA_BY_PROCESSO,
						new Parametro().doAddParametro("processo", processo)
								.getParametros(),
						RegraDigitalizacao.class,
						true,
						"Nenhum tipo de documento digitalizavel foi encontrado! Por favor, verifique configura��o do sistema.");

	}

	@Transactional
	@Override
	public DocumentoDigitalizado doAlterarTipoDocumento(
			Integer idTipoDocumento, Integer idDocumento)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException, DocumentoDigitalizadoInvalido,
			TipoDocumentoDigitalizadoInvalido {

		TipoDocumentoDigitalizado tipoDocumentoDigitalizado = this.daoService
				.doRead(idTipoDocumento, TipoDocumentoDigitalizado.class, true,
						"Tipo de documento n�o encontrado!",
						"ID do tipo de documento n�o informado!");

		DocumentoDigitalizado documentoDigitalizado = this.daoService.doRead(
				idDocumento, DocumentoDigitalizado.class, true,
				"Documento n�o encontrado!", "ID do documento n�o informado!");

		List<RegraDigitalizacao> regrasDigitalizacao = this.daoService
				.doGetResultList(
						RegraDigitalizacao.NQ_SELECT_REGRA_BY_PROCESSO,
						new Parametro().doAddParametro(
								"processo",
								documentoDigitalizado
										.getProcessoDigitalizacao())
								.getParametros(),
						RegraDigitalizacao.class,
						true,
						new StringBuilder(
								"Regra de digitaliza��o n�o encontrada para o tipo de documento informado! ID TIPO DOCUMENTO: ")
								.append(documentoDigitalizado.getTipo().getId())
								.toString());

		if (documentoDigitalizado.getStatus().equals(StatusPadraoEnum.ATIVO)) {

			boolean tipoDocumentoPermitido = false;

			for (RegraDigitalizacao regraDigitalizacao : regrasDigitalizacao) {

				if (regraDigitalizacao.getTipoDocumentoDigitalizavel().equals(
						tipoDocumentoDigitalizado))
					tipoDocumentoPermitido = true;

			}

			if (!tipoDocumentoPermitido)
				throw new TipoDocumentoDigitalizadoInvalido(
						new StringBuilder(
								"O tipo de documento informado n�o � permitido para este processo! ID TIPO DE DOCUMENTO: ")
								.append(tipoDocumentoDigitalizado.getId())
								.toString());

			documentoDigitalizado.setTipo(tipoDocumentoDigitalizado);

		} else {
			throw new DocumentoDigitalizadoInvalido(
					"Este documento j� foi utilizado, por este motivo seu tipo n�o pode ser alterado!");
		}

		return this.daoService.doUpdate(documentoDigitalizado);

	}

	@Override
	public List<DocumentoDigitalizadoDTO> doListarDocumentosDigitalizados(
			String cpf) throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, ServiceException {

		if (cpf == null)
			throw new CalsystemInvalidArgumentException("CPF n�o informado!");

		File[] listaArquivos = this.digitalizacaoHelper.doListarArquivosRede(
				localArquivo, cpf, extensaoArquivo);

		List<DocumentoDigitalizadoDTO> documentos = new ArrayList<DocumentoDigitalizadoDTO>();

		if (listaArquivos.length > 0) {

			for (int i = 0; i < listaArquivos.length; i++) {

				String base64 = this.digitalizacaoHelper.doConverterBase64(
						listaArquivos[i], this.extensaoArquivo);

				documentos.add(new DocumentoDigitalizadoDTO(null,
						listaArquivos[i].getName(), null, base64));

			}
		}
		
		if (documentos.size() == 0)
			throw new CalsystemNoDataFoundException(
					new StringBuilder(
							"N�o foi encontrado nenhum documento digitalizado!")
							.toString());

		return documentos;

	}

	@Override
	public void doDescartarDocumento(String nomeDocumento)
			throws CalsystemNoDataFoundException {

		File file = new File(new StringBuilder(localArquivo).append("\\\\")
				.append(nomeDocumento).append(this.extensaoArquivo).toString());

		if (file.exists())
			file.delete();

	}
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public List<DocumentDTO> doConsultarDocumentosDigitalizados(Integer creditRequestId) throws IntegracaoException, 
																								CalsystemInvalidArgumentException, 
																								ServiceException, 
																								IntegracaoMotorBiometriaException {

		IntegracaoAnexoDocumentosDTO integracaoDocumentos =  this.motorBiometriaService.doConsultarDocumentos(creditRequestId);
		 
		return integracaoDocumentos.getIntegracaoDocumentos().getCreditrequest().getDocuments();
		
	}
	
	@Override
	public TipoDocumentoDigitalizado doConsultarTipoDocumentoDigitalizado(Integer id, 
																		  boolean validarRetornoNull, 
																		  String mensagemRetornoNull,
																		  String mensagemIdNull) throws CalsystemNoDataFoundException,
																		  								CalsystemInvalidArgumentException {

		return this.daoService.doRead(id, TipoDocumentoDigitalizado.class,
				validarRetornoNull, mensagemRetornoNull, mensagemIdNull);

	}

}
