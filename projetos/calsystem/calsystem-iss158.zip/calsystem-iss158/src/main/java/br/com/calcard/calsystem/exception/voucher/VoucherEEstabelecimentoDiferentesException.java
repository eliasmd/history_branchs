package br.com.calcard.calsystem.exception.voucher;

public class VoucherEEstabelecimentoDiferentesException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -681170305757239922L;

}
