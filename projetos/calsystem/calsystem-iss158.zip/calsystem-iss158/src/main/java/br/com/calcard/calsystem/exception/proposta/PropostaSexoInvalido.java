package br.com.calcard.calsystem.exception.proposta;

public class PropostaSexoInvalido extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2610166798152777733L;

	public PropostaSexoInvalido(String mensagem) {
		super(mensagem);
	}

}
