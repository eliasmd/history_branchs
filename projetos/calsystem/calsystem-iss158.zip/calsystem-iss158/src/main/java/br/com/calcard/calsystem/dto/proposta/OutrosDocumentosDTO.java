package br.com.calcard.calsystem.dto.proposta;

import br.com.calcard.calsystem.dto.RGDTO;

public class OutrosDocumentosDTO {

	private RGDTO rg;

	public RGDTO getRg() {
		return rg;
	}

	public void setRg(RGDTO rg) {
		this.rg = rg;
	}

}
