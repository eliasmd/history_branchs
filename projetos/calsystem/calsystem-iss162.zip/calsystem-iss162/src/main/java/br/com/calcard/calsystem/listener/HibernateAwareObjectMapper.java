package br.com.calcard.calsystem.listener;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.hibernate4.Hibernate4Module;

public class HibernateAwareObjectMapper extends ObjectMapper {

	private static final long serialVersionUID = -8970567788058125004L;

	public HibernateAwareObjectMapper() {
		registerModule(new Hibernate4Module());
	}
}
