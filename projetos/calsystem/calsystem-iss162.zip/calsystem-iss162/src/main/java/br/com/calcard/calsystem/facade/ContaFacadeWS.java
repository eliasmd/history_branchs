package br.com.calcard.calsystem.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.ws.CalsystemFacadeWS;
import br.com.calcard.calsystem.interfaces.IConta;

@Component
public class ContaFacadeWS extends CalsystemFacadeWS {

	private IConta contaService;

	@Autowired
	public ContaFacadeWS(IConta contaService) {
		this.contaService = contaService;
	}

	public ResponseEntity<Object> doListarContasPorCPF(String cpf) {
/*
		try {

			List<ContaDTO> listaContasDTO = new ArrayList<ContaDTO>();

			for (Conta conta : this.contaService.doListarContasPorCPF(cpf))
				listaContasDTO.add(new ContaDTO(conta.getId(), conta
						.getNomeCliente(), CalsystemUtil.doMascararCPF(conta
						.getCpf()), conta.getStatus()));

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Contas", listaContasDTO).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);

		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}
*/

	return null;
	}
}
