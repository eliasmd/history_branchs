package br.com.calcard.calsystem.exception.proposta;

public class PropostaDadosComplementaresInvalidos extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -86144628940283600L;

	public PropostaDadosComplementaresInvalidos(String mensagem) {
		super(mensagem);
	}

}
