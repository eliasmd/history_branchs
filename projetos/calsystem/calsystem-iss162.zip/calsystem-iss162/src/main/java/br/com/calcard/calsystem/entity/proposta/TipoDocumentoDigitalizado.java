package br.com.calcard.calsystem.entity.proposta;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import br.com.calcard.calframework.entity.CalsystemEntity;

@Entity
@Table(name = "tbl_tipo_documento_digitalizado")
@NamedQueries({@NamedQuery(name = TipoDocumentoDigitalizado.NQ_SELECT_TIPO_DOCUMENTO_BY_DOCUMENT_TYPE, 
						   query = "select t from TipoDocumentoDigitalizado t where t.documentType = :documentType")})
public class TipoDocumentoDigitalizado extends CalsystemEntity {

	private static final long serialVersionUID	 							= 577922577481780544L;
	
	public static final String NQ_SELECT_TIPO_DOCUMENTO_BY_DOCUMENT_TYPE 	= "NQTipoDocumentoByDocumentoType";
	
	public static final String SIGLA_TAD_ALTERACAO_SENHA					= "TSAS";
	
	private static final String COLUNA_NOME 								= "nome";

	private static final String COLUNA_DESCRICAO 							= "descricao";
	
	private static final String COLUNA_SIGLA 								= "sigla";

	private static final String COLUNA_DOCUMENT_TYPE 						= "document_type";

	@Column(name = COLUNA_NOME, length = 50, nullable = false, unique = false)
	private String nome;

	@Column(name = COLUNA_DESCRICAO, length = 200, nullable = false, unique = false)
	private String descricao;

	@Column(name = COLUNA_DOCUMENT_TYPE, nullable = false, unique = false)
	private Integer documentType;
	
	@Column(name = COLUNA_SIGLA, length = 10, nullable = true, unique = false)
	private String sigla;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((descricao == null) ? 0 : descricao.hashCode());
		result = prime * result
				+ ((documentType == null) ? 0 : documentType.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		TipoDocumentoDigitalizado other = (TipoDocumentoDigitalizado) obj;
		if (descricao == null) {
			if (other.descricao != null)
				return false;
		} else if (!descricao.equals(other.descricao))
			return false;
		if (documentType == null) {
			if (other.documentType != null)
				return false;
		} else if (!documentType.equals(other.documentType))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		return true;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Integer getDocumentType() {
		return documentType;
	}

	public void setDocumentType(Integer documentType) {
		this.documentType = documentType;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	
	

}