package br.com.calcard.calsystem.exception;

@Deprecated
public class NomeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6388486353771204060L;

	public NomeException(String mensagem) {
		super(mensagem);
	}

}
