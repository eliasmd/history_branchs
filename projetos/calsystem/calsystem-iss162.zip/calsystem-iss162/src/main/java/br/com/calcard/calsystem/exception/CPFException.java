package br.com.calcard.calsystem.exception;

@Deprecated
public class CPFException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7064288223416249783L;

	public CPFException(String mensagem) {

		super(mensagem);
	}

}
