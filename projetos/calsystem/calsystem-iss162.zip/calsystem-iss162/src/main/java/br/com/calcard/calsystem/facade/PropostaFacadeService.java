package br.com.calcard.calsystem.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.exception.CalsystemDAOException;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calsystem.dto.proposta.PropostaDTO;
import br.com.calcard.calsystem.entity.proposta.Proposta;
import br.com.calcard.calsystem.exception.documento.DigitalizacaoException;
import br.com.calcard.calsystem.exception.proposta.DadosComplementaresException;
import br.com.calcard.calsystem.exception.proposta.DadosProfissionaisException;
import br.com.calcard.calsystem.exception.proposta.DadosResidenciaisException;
import br.com.calcard.calsystem.exception.proposta.OutrosDocumentosException;
import br.com.calcard.calsystem.exception.proposta.PropostaDocumentosDigitalizadosException;
import br.com.calcard.calsystem.exception.proposta.PropostaException;
import br.com.calcard.calsystem.exception.proposta.ReferenciaException;
import br.com.calcard.calsystem.interfaces.IProposta;
import br.com.calcard.calsystem.service.PropostaService;

@Component
public class PropostaFacadeService implements IProposta {

	private PropostaService propostaService;

	@Autowired
	public PropostaFacadeService(PropostaService propostaService) {
		this.propostaService = propostaService;
	}

	@Override
	public Proposta doIniciarCadastroProposta()
			throws CalsystemInvalidArgumentException {

		return this.propostaService.doIniciarCadastroProposta();

	}

	@Override
	public Proposta doCadastrarPropostaP1(PropostaDTO propostaDTO)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException, PropostaException,
			IntegracaoException, ServiceException,
			IntegracaoMotorBiometriaException {

		if (propostaDTO == null)
			throw new CalsystemInvalidArgumentException(
					"Proposta n�o informada!");

		Proposta proposta = this.propostaService.doRegistrarPropostaP1(
				propostaDTO.getIdUsuario(), propostaDTO.getIdEstabelecimento(),
				propostaDTO.getNumeroProposta(), propostaDTO.getDadosBasicos());

		this.propostaService.doEnviarPropostaMotorBiometria(proposta,
				propostaDTO.getFotoBase64());

		this.propostaService.doEnviarPropostaMotorCredito(proposta);

		return proposta;

	}

	@Override
	public Proposta doCadastrarPropostaP2(PropostaDTO propostaDTO)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, PropostaException,
			DadosComplementaresException, OutrosDocumentosException,
			DadosResidenciaisException, DadosProfissionaisException,
			ReferenciaException, DigitalizacaoException,
			PropostaDocumentosDigitalizadosException, ServiceException,
			CalsystemDAOException, IntegracaoException,
			IntegracaoMotorBiometriaException {

		return this.propostaService.doCadastrarPropostaP2(propostaDTO);

	}

}
