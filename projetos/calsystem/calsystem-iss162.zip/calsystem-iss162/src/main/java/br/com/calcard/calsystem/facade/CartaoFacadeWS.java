package br.com.calcard.calsystem.facade;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calframework.ws.CalsystemFacadeWS;
import br.com.calcard.calsystem.dto.CartaoDTO;
import br.com.calcard.calsystem.dto.ContaDTO;
import br.com.calcard.calsystem.interfaces.ICartao;
import br.com.calcard.calsystem.util.Parametro;

@Component
public class CartaoFacadeWS extends CalsystemFacadeWS {

	private ICartao cartaoService;


	@Autowired
	public CartaoFacadeWS(ICartao cartaoService) {

		this.cartaoService = cartaoService;

	}

	public ResponseEntity<Object> doListarCartoesCadastroSenhaEDesbloqueio(
			String cpf, String numeroCartao) {

		try {

			List<CartaoDTO> cartoes = null;/*this.cartaoService
					.doListarCartoesCadastroSenhaEDesbloqueio(cpf, numeroCartao);*/

			List<CartaoDTO> cartoesDTO = new ArrayList<CartaoDTO>();

			for (CartaoDTO cartaoDTO : cartoes) {

				ContaDTO conta = new ContaDTO(cartaoDTO.getConta().getId(),
						cartaoDTO.getConta().getNome(), cartaoDTO.getConta()
								.getCpf(), cartaoDTO.getConta().getStatus());

				CartaoDTO cartao = new CartaoDTO(
						CalsystemUtil.doMascararCartao(cartaoDTO
								.getNumeroCartao()),
						cartaoDTO.getNomePortador(),
						CalsystemUtil.doMascararCPF(cartaoDTO.getCpfPortador()),
						cartaoDTO.isTitular(), cartaoDTO.getStatus(), conta);

				cartoesDTO.add(cartao);

			}

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"Cartoes", cartoesDTO).getParametros());

		} catch (CalsystemInvalidArgumentException e) {
			return super.doRetornarErroWS(e);
		}

	}
}
