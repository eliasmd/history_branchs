package br.com.calcard.calsystem.facade;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.ws.CalsystemFacadeWS;
import br.com.calcard.calsystem.dto.AlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.AnalisePendenciaDTO;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.AnalisePendenciaAlteracaoSenha;
import br.com.calcard.calsystem.helper.FilaDePendenciaHelper;
import br.com.calcard.calsystem.interfaces.IFilaPendencia;
import br.com.calcard.calsystem.util.Parametro;

@Component
public class FilaDePendenciasFacadeWS extends CalsystemFacadeWS {

	private IFilaPendencia filaDePendenciasService;
	private FilaDePendenciaHelper filaDePendenciaHelper;

	@Autowired
	public FilaDePendenciasFacadeWS(
			IFilaPendencia filaDePendenciasService,
			FilaDePendenciaHelper filaDePendenciaHelper) {
		super();
		this.filaDePendenciasService = filaDePendenciasService;
		this.filaDePendenciaHelper = filaDePendenciaHelper;

	}
	
	public ResponseEntity<Object> doListarFilaDePendencias(String status, String cpf) {
			
			try {
	
				List<AlteracaoSenha> listaFilaDePendencia = 
						filaDePendenciasService.doListarFilaDePendencia(status, cpf);
				
				//busca a lista de AnalisePendencia com as an�lises iniciadas
				List<AnalisePendenciaAlteracaoSenha> listaAnalisePendencia = filaDePendenciasService.doCarregarAnaliseIniciada(listaFilaDePendencia);
				
				//FilaDePendenciaHelper filaDePendenciaHelper = new FilaDePendenciaHelper();
				List<AlteracaoSenhaDTO> listaAlteracaoSenhaDTO = filaDePendenciaHelper.doComporFilaDePendenciaDTO(listaFilaDePendencia,listaAnalisePendencia);
				
				return super.doRetornarSucessoWS(new Parametro().doAddParametro(
						"listaFilaDePendencia", listaAlteracaoSenhaDTO)
						.getParametros());
		
			} catch (CalsystemException e) {
				return super.doRetornarErroWS(e);
			} catch (Exception e) {
				return super.doRetornarErroWS(e);
			}
	}
	
	
	public ResponseEntity<Object> doListarDocumentosAvaliacao(Integer idAlteracaoSenha) {
		
		try {

			AlteracaoSenha alteracaoSenha = filaDePendenciasService.doListarDocumentosAvaliacao(idAlteracaoSenha);
			
			List<DocumentoDigitalizadoDTO> documentosDTO = new ArrayList<DocumentoDigitalizadoDTO>();

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"DocumentosDigitalizados", documentosDTO).getParametros());
	
		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}
	}
	
	
	public ResponseEntity<Object> doAnalisarPendencia(AnalisePendenciaDTO analisePendenciaDTO) {
		
		try {

			AnalisePendenciaAlteracaoSenha analisePendencia = filaDePendenciasService.doAnalisarPendencia(analisePendenciaDTO);
			analisePendenciaDTO.setId(analisePendencia.getId());
			
			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"analisePendenciaDTO", analisePendenciaDTO)
					.getParametros());
	
		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}
	}	

}
