package br.com.calcard.calsystem.exception;

public class ExcecaoNaoEncontradaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3663800661673161966L;

}
