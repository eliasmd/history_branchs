package br.com.calcard.calsystem.exception.token;

import br.com.calcard.calframework.exception.CalsystemException;

public class TokenSessaoNaoEncontradoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8341229517189281407L;

	public TokenSessaoNaoEncontradoException(String mensagem) {
		super(mensagem);
	}
}
