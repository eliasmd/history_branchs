package br.com.calcard.calsystem.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import br.com.calcard.calsystem.dto.AlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.AnalisePendenciaDTO;
import br.com.calcard.calsystem.dto.UsuarioDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.AnalisePendenciaAlteracaoSenha;

@Component
public class FilaDePendenciaHelper {

	public List<AlteracaoSenhaDTO> doComporFilaDePendenciaDTO(List<AlteracaoSenha> listaAlteracaoSenha,
															  List<AnalisePendenciaAlteracaoSenha> listaAnalisePendencia) {
		
		List<AlteracaoSenhaDTO> listaAlteracaoSenhaDTO = new ArrayList<AlteracaoSenhaDTO>();
		
		for (int i = 0; i < listaAlteracaoSenha.size(); i++) {
			
			AlteracaoSenhaDTO alteracaoSenhaDTO = new AlteracaoSenhaDTO();
			
			//alteracaoSenhaDTO.setCpfPortador(listaAlteracaoSenha.get(i).getCpf());
			//alteracaoSenhaDTO.setIdConta(listaAlteracaoSenha.get(i).getConta());
			alteracaoSenhaDTO.setStatus(listaAlteracaoSenha.get(i).getStatus());
			alteracaoSenhaDTO.setDataRegistro(listaAlteracaoSenha.get(i).getDataRegistro());
			//alteracaoSenhaDTO.setNome(listaAlteracaoSenha.get(i).getNome());
			alteracaoSenhaDTO.setIdEstabelecimento(listaAlteracaoSenha.get(i).getEstabelecimento().getId());
			alteracaoSenhaDTO.setId(listaAlteracaoSenha.get(i).getId());
			
			
				//busca se j� possui analise para a solicitacao de senha
				for (int j = 0; j < listaAnalisePendencia.size(); j++) {
					try{
						if( listaAnalisePendencia.get(j) != null && listaAlteracaoSenha.get(i) != null &&
							listaAnalisePendencia.get(j).getAlteracaoSenha().getId() == listaAlteracaoSenha.get(i).getId()){
	
							alteracaoSenhaDTO.setAnalisePendencia(new AnalisePendenciaDTO(listaAnalisePendencia.get(j).getId(),
																						  new UsuarioDTO(listaAnalisePendencia.get(j).getAnalista().getId(),
																								  		 listaAnalisePendencia.get(j).getAnalista().getNome(),
																								  		 listaAnalisePendencia.get(j).getAnalista().getPerfil().getNome(),
																								  		 listaAnalisePendencia.get(j).getAnalista().getCpf()),
																						  listaAnalisePendencia.get(j).getParecer(),
																						  listaAnalisePendencia.get(j).getAlteracaoSenha().getId(),
																						  null,//listaAnalisePendencia.get(j).getEtapa_status(),
																						  listaAnalisePendencia.get(j).getDataInicio(),
																						  listaAnalisePendencia.get(j).getDataFim()
																						  ));
							listaAnalisePendencia.remove(j);
							break;
						}
						
					}catch(Exception e){
						 int teste = j;
					}
				}
			
			
			listaAlteracaoSenhaDTO.add(alteracaoSenhaDTO);

		}

		return listaAlteracaoSenhaDTO;

	}

}
