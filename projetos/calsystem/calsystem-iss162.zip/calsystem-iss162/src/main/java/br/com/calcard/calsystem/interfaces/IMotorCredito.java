package br.com.calcard.calsystem.interfaces;

import br.com.calcard.calsystem.entity.proposta.Proposta;

public interface IMotorCredito {

	public void doEnviarPropostaMotorCredito(Proposta proposta);

}
