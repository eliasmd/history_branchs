package br.com.calcard.calsystem.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Service;

import br.com.calcard.calsystem.interfaces.IEntityManager;

@Service
public class CalsystemEntityManagerService implements IEntityManager {

	@PersistenceContext(unitName = "entityManager")
	protected EntityManager em;

	@Override
	public EntityManager doGetEntityManager() {
		return em;
	}

}
