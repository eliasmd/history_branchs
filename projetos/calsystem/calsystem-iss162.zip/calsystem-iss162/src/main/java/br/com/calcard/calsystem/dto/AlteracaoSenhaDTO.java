package br.com.calcard.calsystem.dto;

import java.util.Date;
import java.util.List;

import br.com.calcard.calframework.util.CustomJsonDateDeserializer;
import br.com.calcard.calframework.util.CustomJsonDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class AlteracaoSenhaDTO {
	
	private Integer id;
	
	private Integer fotoNSU;

	private String status;
	
	private String senha;
	
	private String cpfPortador;
	
	private Integer idConta;
	
	private String nome;
	
	private Integer idEstabelecimento;
	
	private AnalisePendenciaDTO analisePendencia;
	
	@JsonDeserialize(using = CustomJsonDateDeserializer.class)
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date dataRegistro;
	
	private List<DocumentoDigitalizadoDTO> documentosDigitalizados;
	
	public AlteracaoSenhaDTO() {
		super();
	}

	public AlteracaoSenhaDTO(Integer fotoNSU, String status, Integer idConta,String cpfPortador, String senha, List<DocumentoDigitalizadoDTO> documentosDigitalizados ) {
		super();
		this.fotoNSU = fotoNSU;
		this.status = status;
		this.senha = senha;
		this.documentosDigitalizados = documentosDigitalizados;
		this.idConta = idConta;
		this.cpfPortador = cpfPortador;
	}


	public Integer getFotoNSU() {
		return fotoNSU;
	}

	public void setFotoNSU(Integer fotoNSU) {
		this.fotoNSU = fotoNSU;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public List<DocumentoDigitalizadoDTO> getDocumentosDigitalizados() {
		return documentosDigitalizados;
	}

	public void setDocumentosDigitalizados(
			List<DocumentoDigitalizadoDTO> documentosDigitalizados) {
		this.documentosDigitalizados = documentosDigitalizados;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCpfPortador() {
		return cpfPortador;
	}

	public void setCpfPortador(String cpfPortador) {
		this.cpfPortador = cpfPortador;
	}

	public Integer getIdConta() {
		return idConta;
	}

	public void setIdConta(Integer idConta) {
		this.idConta = idConta;
	}

	public Date getDataRegistro() {
		return dataRegistro;
	}

	public void setDataRegistro(Date dataRegistro) {
		this.dataRegistro = dataRegistro;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getIdEstabelecimento() {
		return idEstabelecimento;
	}

	public void setIdEstabelecimento(Integer idEstabelecimento) {
		this.idEstabelecimento = idEstabelecimento;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public AnalisePendenciaDTO getAnalisePendencia() {
		return analisePendencia;
	}

	public void setAnalisePendencia(AnalisePendenciaDTO analisePendencia) {
		this.analisePendencia = analisePendencia;
	}
	
	

}
