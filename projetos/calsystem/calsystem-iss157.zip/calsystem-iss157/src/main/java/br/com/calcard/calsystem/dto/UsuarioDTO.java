package br.com.calcard.calsystem.dto;

import java.util.Date;

import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calframework.util.CustomJsonDateSerializer;
import br.com.calcard.calsystem.entity.Usuario;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class UsuarioDTO {

	private Integer id;

	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date dataRegistro;

	private String login;

	private String nome;

	private String codigoPerfil;

	private Integer idPerfil;

	private String cpf;

	public UsuarioDTO(Usuario usuario) {

		this.id = usuario.getId();
		this.nome = usuario.getNome();
		this.codigoPerfil = usuario.getPerfil().getCodigo();
		this.cpf = CalsystemUtil.doMascararCPF(usuario.getCpf());

	}

	public UsuarioDTO() {
		super();
	}

	public UsuarioDTO(Integer id, String nome, String codigoPerfil, String cpf) {
		super();
		this.id = id;
		this.nome = nome;
		this.codigoPerfil = codigoPerfil;
		this.cpf = cpf;
	}

	public UsuarioDTO(Integer id, String login, String nome, Integer idPerfil,
			String cpf, Date dataRegistro) {
		super();
		this.id = id;
		this.login = login;
		this.nome = nome;
		this.idPerfil = idPerfil;
		this.cpf = cpf;
		this.dataRegistro = dataRegistro;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCodigoPerfil() {
		return codigoPerfil;
	}

	public void setCodigoPerfil(String codigoPerfil) {
		this.codigoPerfil = codigoPerfil;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public Integer getIdPerfil() {
		return idPerfil;
	}

	public void setIdPerfil(Integer idPerfil) {
		this.idPerfil = idPerfil;
	}

	public Date getDataRegistro() {
		return dataRegistro;
	}

	public void setDataRegistro(Date dataRegistro) {
		this.dataRegistro = dataRegistro;
	}

}
