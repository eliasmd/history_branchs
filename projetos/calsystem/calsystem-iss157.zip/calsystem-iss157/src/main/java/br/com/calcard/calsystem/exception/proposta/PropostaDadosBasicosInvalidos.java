package br.com.calcard.calsystem.exception.proposta;

public class PropostaDadosBasicosInvalidos extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1295604341537934170L;

	public PropostaDadosBasicosInvalidos(String mensagem) {
		super(mensagem);
	}

}
