package br.com.calcard.calsystem.exception.estabelecimento;

import br.com.calcard.calframework.exception.CalsystemException;

public class EstabelecimentoCnpjInvalidoException extends CalsystemException {

	private static final long serialVersionUID = 1624526651101036395L;

	public EstabelecimentoCnpjInvalidoException(String mensagem) {
		super(mensagem);
	}

}
