package br.com.calcard.calsystem.exception;

public class EntidadePropriedadeInvalida extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3562770726687000131L;

	public EntidadePropriedadeInvalida(String mensagem) {
		super(mensagem);
	}

}
