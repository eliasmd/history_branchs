package br.com.calcard.calsystem.exception.voucher;

public class VoucherException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8736114580058023523L;

}
