package br.com.calcard.calsystem.interfaces;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.enums.StatusSolicitacaoDeCredito;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calsystem.dto.AnaliseBiometriaDTO;

public interface IBiometria {

	public void doAvaliarFoto(String fotoBase64) throws IntegracaoException,
														CalsystemInvalidArgumentException, 
														ServiceException,
														IntegracaoMotorBiometriaException;

	public AnaliseBiometriaDTO doConsutlarAvaliacaoBiometrica(Integer idCreditRequest) throws CalsystemInvalidArgumentException, 
																							  ServiceException, 
																							  IntegracaoException, 
																							  IntegracaoMotorBiometriaException;


	public void doAlterarStatusSolicitacaoDeCredito(Integer idCreditRequest, 
													StatusSolicitacaoDeCredito statusAlterado,
													String comentario) throws IntegracaoException, 
													  							CalsystemInvalidArgumentException, 
													  							ServiceException, 
													  							IntegracaoMotorBiometriaException;
}
