package br.com.calcard.calsystem.exception.estabelecimento;

import br.com.calcard.calframework.exception.CalsystemException;

public class EstabelecimentoCnpjExistenteException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4314668770691882115L;

	public EstabelecimentoCnpjExistenteException(String mensagem) {
		super(mensagem);
	}

}
