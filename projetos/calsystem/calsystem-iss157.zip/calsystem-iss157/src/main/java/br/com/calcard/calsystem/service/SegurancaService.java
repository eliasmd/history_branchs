package br.com.calcard.calsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calsystem.entity.Menu;
import br.com.calcard.calsystem.entity.Perfil;
import br.com.calcard.calsystem.entity.Periferico;
import br.com.calcard.calsystem.entity.TokenLogin;
import br.com.calcard.calsystem.entity.TokenSessao;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.exception.TokenInvalidoException;
import br.com.calcard.calsystem.interfaces.ISeguranca;
import br.com.calcard.calsystem.interfaces.IToken;
import br.com.calcard.calsystem.util.Parametro;

@Service
public class SegurancaService implements ISeguranca {

	private ICalsystemDAO daoService;

	private IToken tokenService;

	@Autowired
	public SegurancaService(ICalsystemDAO daoService, IToken tokenService) {
		this.daoService = daoService;
		this.tokenService = tokenService;
	}

	@Override
	public TokenLogin doGerarTokenLogin(String codigoPeriferico)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, ServiceException {

		if (codigoPeriferico == null)
			throw new CalsystemInvalidArgumentException(
					"C�digo do perif�rico n�o informado!");

		Periferico periferico = this.daoService.doGetSingleResult(
				Periferico.NQ_SELECT_PERIFERICO_BY_CODIGO,
				new Parametro().doAddParametro("codigo",
						codigoPeriferico.substring(0, 6)).getParametros(),
				Periferico.class, true, "Perif�rico n�o encontrado!");

		return this.tokenService.doGerarTokenLogin(periferico);

	}

	@Override
	public TokenSessao doLogin(String tLogin, String login, String senha)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, TokenInvalidoException,
			ServiceException {

		if (tLogin == null)
			throw new CalsystemInvalidArgumentException(
					"Token de login n�o informado!");

		if (login == null)
			throw new CalsystemInvalidArgumentException("Login n�o informado!");

		if (senha == null)
			throw new CalsystemInvalidArgumentException("Senha n�o informada!");

		TokenLogin tokenLogin = this.tokenService.doValidarTokenLogin(tLogin);

		Usuario usuario = this.daoService.doGetSingleResult(
				Usuario.NQ_SELECT_USUARIO_BY_LOGIN_SENHA,
				new Parametro().doAddParametro("login", login)
						.doAddParametro("senha", senha).getParametros(),
				Usuario.class, true, "Usu�rio n�o encontrado");

		usuario.getEstabelecimentos();

		return this.tokenService.doGerarTokenSessao(tokenLogin, usuario);

	}

	@Override
	@Transactional
	public List<Menu> doListarMenus(String tSessao)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		if (tSessao == null)
			throw new CalsystemInvalidArgumentException(
					"Token de sess�o n�o informado!");

		TokenSessao tokenSessao = this.tokenService
				.doConsultarTokenSessao(tSessao);

		if (tokenSessao.getUsuario().getPerfil().getCodigo()
				.equals(Perfil.CODIGO_SUPER_USUARIO))
			return this.daoService.doList(Menu.class);

		else
			return this.daoService.doGetResultList(
					Menu.NQ_SELECT_MENUS_BY_PERFIL,
					new Parametro().doAddParametro("perfil",
							tokenSessao.getUsuario().getPerfil())
							.getParametros(), Menu.class);

	}

}
