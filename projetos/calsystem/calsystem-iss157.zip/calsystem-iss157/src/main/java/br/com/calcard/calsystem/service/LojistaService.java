package br.com.calcard.calsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calsystem.interfaces.ILojista;

@Service
public class LojistaService implements ILojista {

	private ICalsystemDAO daoService;

	@Autowired
	public LojistaService(ICalsystemDAO daoService) {
		this.daoService = daoService;
	}

}
