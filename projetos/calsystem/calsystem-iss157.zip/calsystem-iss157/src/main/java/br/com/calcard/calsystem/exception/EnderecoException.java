package br.com.calcard.calsystem.exception;

public class EnderecoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3614131881473776082L;

	public EnderecoException(String mensagem) {
		super(mensagem);
	}

}
