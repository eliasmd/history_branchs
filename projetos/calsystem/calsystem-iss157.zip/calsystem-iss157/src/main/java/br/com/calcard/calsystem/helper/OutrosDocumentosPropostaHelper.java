package br.com.calcard.calsystem.helper;

import br.com.calcard.calsystem.dto.RGDTO;
import br.com.calcard.calsystem.dto.proposta.OutrosDocumentosDTO;
import br.com.calcard.calsystem.entity.proposta.PropostaOutrosDocumentos;
import br.com.calcard.calsystem.enums.PropostaEnum.TipoDocumentoEnum;
import br.com.calcard.calsystem.exception.proposta.OutrosDocumentosException;
import br.com.calcard.calsystem.exception.proposta.RGException;

public class OutrosDocumentosPropostaHelper {

	public PropostaOutrosDocumentos doCarregarOutrosDocumentos(
			OutrosDocumentosDTO outrosDocumentosDTO)
			throws OutrosDocumentosException {

		PropostaOutrosDocumentos outrosDocumentos = new PropostaOutrosDocumentos();

		this.doValidarOutrosDocumentos(outrosDocumentosDTO);

		outrosDocumentos.setDataEmissao(outrosDocumentosDTO.getRg()
				.getDataEmissao());

		outrosDocumentos.setNumero(outrosDocumentosDTO.getRg().getNumero());

		outrosDocumentos.setOrgaoEmissor(outrosDocumentosDTO.getRg()
				.getOrgaoEmissorEnum());

		outrosDocumentos.setUf(outrosDocumentosDTO.getRg().getUf());

		outrosDocumentos.setTipoDocumento(TipoDocumentoEnum.RG);

		return outrosDocumentos;
	}

	private void doValidarOutrosDocumentos(
			OutrosDocumentosDTO outrosDocumentosDTO)
			throws OutrosDocumentosException {

		if (outrosDocumentosDTO == null)
			throw new OutrosDocumentosException(
					"Outros documentos n�o informados!");

		if (outrosDocumentosDTO.getRg() == null)
			throw new OutrosDocumentosException("RG n�o informado!");

		try {
			this.doValidarRG(outrosDocumentosDTO.getRg());
		} catch (RGException e) {
			throw new OutrosDocumentosException("RG inv�lido", e);
		}

	}

	public void doValidarRG(RGDTO rg) throws RGException {

		if (rg == null)
			throw new RGException("RG n�o informado!");

		else if (rg.getDataEmissao() == null)
			throw new RGException("Data de emiss�o n�o informada!");

		else if (rg.getNumero() == null)
			throw new RGException("N�mero n�o informado!");

		else if (rg.getOrgaoEmissorEnum() == null)
			throw new RGException("Org�o emissor n�o informado!");

		else if (rg.getUf() == null)
			throw new RGException("UF n�o informada!");

	}

}
