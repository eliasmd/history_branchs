package br.com.calcard.calsystem.exception.proposta;

public class PropostaNomeInvalido extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5540191041372948747L;

	public PropostaNomeInvalido() {
		super();
	}

	public PropostaNomeInvalido(String mensagem) {
		super(mensagem);
	}

}
