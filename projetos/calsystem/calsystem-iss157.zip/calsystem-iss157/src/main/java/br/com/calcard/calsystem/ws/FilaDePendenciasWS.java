package br.com.calcard.calsystem.ws;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calsystem.dto.AnalisePendenciaDTO;
import br.com.calcard.calsystem.dto.DocumentoDTO;
import br.com.calcard.calsystem.dto.PendenciaAlteracaoSenhaDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.TokenSessao;
import br.com.calcard.calsystem.facade.FilaDePendenciasFacadeWS;
import br.com.calcard.calsystem.interfaces.IFilaPendencia;
import br.com.calcard.calsystem.interfaces.IToken;
import br.com.calcard.calsystem.util.Parametro;

@RestController
@RequestMapping("/ws/filaDePendencias")
@Scope(value = "request")
public class FilaDePendenciasWS extends CalsystemWS {

	private FilaDePendenciasFacadeWS filaDePendenciasFacadeWS;
	private IFilaPendencia filaPendenciaService;
	private IToken tokenService;

	@Autowired
	public FilaDePendenciasWS(FilaDePendenciasFacadeWS filaDePendenciasFacadeWS,
							  IFilaPendencia filaPendenciaService,
							  IToken tokenService) {
		this.filaDePendenciasFacadeWS = filaDePendenciasFacadeWS;
		this.filaPendenciaService = filaPendenciaService;
		this.tokenService = tokenService;
	}

	@RequestMapping(value = "/status", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doListarStatusFilaDePendencia(@RequestHeader(value = "tSessao") String tSessao) {
			
		super.doGravarLog(tSessao);
	
		List<String> listaStatusFilaDePendencia = this.filaPendenciaService.doListarStatusFilaDePendencia();
			
		return super.doRetornarSucessoWS(new Parametro().doAddParametro("listaStatusFilaDePendencia", listaStatusFilaDePendencia).getParametros());

	}

	@RequestMapping(value = "/listarFilaDePendencia", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarFilaDePendencia(
			@RequestParam(value = "cpf", required = false) String cpf,
			@RequestParam(value = "status", required = true) String status,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(tSessao, new Parametro().doAddParametro("cpf", cpf)
				.doAddParametro("status", status).getParametros());

		return this.filaDePendenciasFacadeWS.doListarFilaDePendencias(status,
				cpf);
	}

	@RequestMapping(value = "/listarDocumentosAvaliacao", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarDocumentosAvaliacao(
			//@RequestParam(value = "id", required = true) Integer idAlteracaoSenha,
			@RequestParam(value = "id", required = true) Integer creditRequestId,
			@RequestHeader(value = "tSessao") String tSessao) {
		
	try{

		super.doGravarLog(
				tSessao,
				new Parametro().doAddParametro("creditRequestId",
						creditRequestId).getParametros());

		/*DocumentoDTO*/
		
		List<DocumentoDTO> listaDocumentosDTO = new ArrayList<DocumentoDTO>();

		for (br.com.calcard.calintegrador.motorBiometria.dto.DocumentDTO documentoBiometria : this.filaPendenciaService.doConsultarDocumentosAvaliacao(creditRequestId)) {
			
			DocumentoDTO documento = new DocumentoDTO();
			documento.setImagem(documentoBiometria.getImage());
			documento.setIdTipoDocumento(documentoBiometria.getType());
			
			listaDocumentosDTO.add(documento);

		}
		
		return super.doRetornarSucessoWS(new Parametro().doAddParametro("DocumentosDigitalizados", listaDocumentosDTO).getParametros());

	} catch (CalsystemException e) {
		return super.doRetornarErroWS(e);
	} catch (Exception e) {
		return super.doRetornarErroWS(e);
	}

	}

	@RequestMapping(value = "/analisarPendencia", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doAnalisarPendencia(
			@RequestBody AnalisePendenciaDTO analisePendenciaDTO,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(
				tSessao,
				new Parametro().doAddParametro("alteracaoSenhaDTO",
						analisePendenciaDTO).getParametros());
		
		return this.filaDePendenciasFacadeWS
				.doAnalisarPendencia(analisePendenciaDTO);

	}
	
	

	@RequestMapping(value = "/negarPendencia", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doNegarPendencia(
			@RequestParam(value = "id", required = true) Integer idAlteracaoSenha,
			@RequestBody Map<String, String> requestBody,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(
				tSessao,
				new Parametro()
						.doAddParametro("idAlteracaoSenha", idAlteracaoSenha)
						.doAddParametro("parecer", requestBody.get("parecer"))
						.getParametros());

		return this.filaDePendenciasFacadeWS.doNegarPendencia(idAlteracaoSenha,
				requestBody.get("parecer"));

	}

	@RequestMapping(value = "/aprovarPendencia", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doAprovarPendencia(
			@RequestParam(value = "id", required = true) Integer idAlteracaoSenha,
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(
				tSessao,
				new Parametro().doAddParametro("idAlteracaoSenha",
						idAlteracaoSenha).getParametros());

		return this.filaPendenciaService.doAprovarPendencia(idAlteracaoSenha);

	}

	/**
	 * Servi�o respons�vel por litar todas as pend�ncias de Altera��o de Senha
	 */
	@Transactional
	@RequestMapping(value = "/alteracaoSenha", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doListarAlteracoesSenha(@RequestHeader(value = "tSessao") String tSessao,
														  @RequestParam(value = "status", required = true) String status,
														  @RequestParam(value = "cpf", required = false) String cpf) {

		try {

			super.doGravarLog(tSessao,
					new Parametro().doAddParametro("status", status)
							.doAddParametro("cpf", cpf).getParametros());
			
			List<PendenciaAlteracaoSenhaDTO> pendencias = new ArrayList<PendenciaAlteracaoSenhaDTO>();

			for (AlteracaoSenha p : this.filaPendenciaService.doListarAlteracoesSenha(status, cpf)) {
				
				PendenciaAlteracaoSenhaDTO pendencia = this.filaPendenciaService.doComporPendenciaAlteracaoSenhaDTO(p);
				
				pendencias.add(pendencia);

			}
			
			return super.doRetornarSucessoWS(new Parametro().doAddParametro("Pendencias",pendencias).getParametros());

		/*} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);*/
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	/**
	 * Servi�o respons�vel por consultar uma determinada pendencia de altera��o
	 * de senha
	 */
	@Transactional
	@RequestMapping(value = "/alteracaoSenha/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doConsultarPendenciaAlteracaoSenha(
			@PathVariable("id") Integer idPendencia,
			@RequestHeader(value = "tSessao") String tSessao) {

		try {

			super.doGravarLog(tSessao,
					new Parametro().doAddParametro("id", idPendencia)
							.getParametros());
			
			AlteracaoSenha p = this.filaPendenciaService.doConsultarPendenciaAlteracaoSenha(idPendencia);
			
			PendenciaAlteracaoSenhaDTO pendenciaDTO = this.filaPendenciaService.doComporPendenciaAlteracaoSenhaDTO(p);
			
			return super.doRetornarSucessoWS(new Parametro().doAddParametro("Pendencia",pendenciaDTO).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}
	
	/**
	 * Servi�o respons�vel por iniciar an�lise de uma pend�ncia de altera��o de senha
	 */
	@RequestMapping(value = "/alteracaoSenha/{id}/iniciarAnalise", method = RequestMethod.PUT, produces = "application/json")
	public ResponseEntity<Object> doIniciarAnalisePendenciaAlteracaoSenha(
			@PathVariable("id") Integer idPendencia,
			@RequestHeader(value = "tSessao") String tSessao) {

		try {
			
			super.doGravarLog(
					tSessao,
					new Parametro().doAddParametro("idPendencia",
							idPendencia).getParametros());
		
		
			TokenSessao tokenSessao = this.tokenService.doConsultarTokenSessao(tSessao);
			
			this.filaPendenciaService.doIniciarAnalisePendenciaAlteracaoSenha(idPendencia, tokenSessao.getUsuario());
			
			return super.doRetornarSucessoWS();
			
		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}	
		
	}

}