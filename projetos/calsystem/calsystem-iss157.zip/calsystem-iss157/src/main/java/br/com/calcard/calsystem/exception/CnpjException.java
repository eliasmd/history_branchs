package br.com.calcard.calsystem.exception;

@Deprecated
public class CnpjException extends Exception {

	private static final long serialVersionUID = -510457086267663262L;

	public CnpjException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CnpjException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
