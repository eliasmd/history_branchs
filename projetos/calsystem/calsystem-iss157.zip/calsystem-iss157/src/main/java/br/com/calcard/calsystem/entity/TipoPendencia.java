package br.com.calcard.calsystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import br.com.calcard.calframework.entity.CalsystemEntity;

@Entity
@NamedQueries({
	@NamedQuery(name = TipoPendencia.NQ_SELECT_TIPO_PENDENCIA_BY_CODIGO, query = "select t from TipoPendencia t where t.codigo = :codigo")})
@Table (name= "tbl_tipo_pendencia")
public class TipoPendencia extends CalsystemEntity {

	private static final long serialVersionUID = -5239271731785564847L;

	public static final String NQ_SELECT_TIPO_PENDENCIA_BY_CODIGO = "NQTipoPendenciaByCodigo";
	
	public static final String CODIGO_TIPO_PENDENCIA_ALTERACAO_SENHA = "ALT_SEN";
	
	private static final String COLUNA_NOME = "nome";

	private static final String COLUNA_DESCICAO = "descricao";

	private static final String COLUNA_CODIGO = "codigo";
	
	@Column(length = 50, name = COLUNA_NOME, nullable = false, unique = true)
	private String nome;
	
	@Column(length = 50, name = COLUNA_CODIGO, nullable = false, unique = true)
	private String codigo;
	
	@Column(length = 200, name = COLUNA_DESCICAO, nullable = false, unique = true)
	private String descricao;
	
	public TipoPendencia() {
		
	}
	
	public TipoPendencia(String nome, String codigo, String descricao) {
		super();
		this.nome = nome;
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
