package br.com.calcard.calsystem.ws;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calintegrador.motorBiometria.enums.StatusSolicitacaoDeCredito;
import br.com.calcard.calsystem.dto.AnaliseBiometriaDTO;
import br.com.calcard.calsystem.interfaces.IBiometria;
import br.com.calcard.calsystem.util.Parametro;

@RestController
@RequestMapping("/ws/biometria")
@Scope(value = "request")
public class BiometriaWS extends CalsystemWS {

	private IBiometria biometriaService;

	@Autowired
	public BiometriaWS(IBiometria biometriaService) {
		this.biometriaService = biometriaService;

	}
	
	/**
	 * Servi�o responsavel por verificar se a foto est� apta para biometria.
	 * @param requestBody
	 * @param tSessao
	 * @return
	 */
	@RequestMapping(value = "/avaliarFoto", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doAvaliarFoto(
			@RequestBody Map<String, String> requestBody,
			@RequestHeader(value = "tSessao") String tSessao) {
		
		try {
			
			super.doGravarLog(tSessao);
		
			this.biometriaService.doAvaliarFoto((String) requestBody.get("fotoBase64"));
			
			return super.doRetornarSucessoWS();
			
		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch(Exception e){
			return super.doRetornarErroWS(e);
		}

	}
	
	@RequestMapping(value = "/alterarStatus", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doAtualizarStatusSolicitacaoDeCredito(
			@RequestBody Map<String, String> requestBody,
			@RequestHeader(value = "tSessao") String tSessao) {
		
		try {
			
			super.doGravarLog(tSessao,
					  new Parametro()
						.doAddParametro("idCreditRequest",requestBody.get("id"))
						.doAddParametro("statusAlterado",requestBody.get("status"))
						.doAddParametro("comentario",requestBody.get("comentario"))
							.getParametros());
		
			this.biometriaService.doAlterarStatusSolicitacaoDeCredito(Integer.valueOf(requestBody.get("id")),//idCreditRequest
																	  StatusSolicitacaoDeCredito.valueOf( requestBody.get("status")),//statusAlterado, 
																	  requestBody.get("comentario"));//comentario
			
			return super.doRetornarSucessoWS();
			
		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch(Exception e){
			return super.doRetornarErroWS(e);
		}

	}
	
	/**
	 * Servi�o respons�vel por consultar no motor de biometria o resultado da avalia��o 
	 * biometrica de uma solicita��o
	 * 
	 * @param idCreditRequest
	 * @param tSessao
	 * @return
	 */
	@RequestMapping(value = "/{idCreditRequest}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doConsultarAvaliacaoBiometrica(@PathVariable("idCreditRequest") Integer idCreditRequest,
											  			         @RequestHeader(value = "tSessao") String tSessao) {
		try {
			
			super.doGravarLog(tSessao,
							  new Parametro()
								.doAddParametro("idCreditRequest",idCreditRequest)
									.getParametros());
			
			AnaliseBiometriaDTO analiseBiometria = this.biometriaService.doConsutlarAvaliacaoBiometrica(idCreditRequest);
			
			return super.doRetornarSucessoWS(new Parametro().doAddParametro("avaliacaoBiometrica", analiseBiometria).getParametros()); 
			
		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}
	
	

}
