package br.com.calcard.calsystem.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class PerifericoCodigoInvalidoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 33908269716526351L;

	public PerifericoCodigoInvalidoException(String mensagem) {
		super(mensagem);
	}

}
