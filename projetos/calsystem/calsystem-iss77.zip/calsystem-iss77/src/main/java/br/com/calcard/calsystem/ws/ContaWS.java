package br.com.calcard.calsystem.ws;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calsystem.facade.ContaFacadeWS;

@RestController
@RequestMapping("/ws/contas")
public class ContaWS extends CalsystemWS {

	private ContaFacadeWS contaFacadeWS;

	@Autowired
	public ContaWS(ContaFacadeWS contaFacadeWS) {
		this.contaFacadeWS = contaFacadeWS;
	}

	@RequestMapping(value = "/listar", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarProcessos(
			@RequestHeader(value = "tSessao") String tSessao,
			@RequestParam(value = "cpf", required = true) String cpf) {

		super.doGravarLog(tSessao, cpf);

		return this.contaFacadeWS.doListarContasPorCPF(cpf);

	}

}
