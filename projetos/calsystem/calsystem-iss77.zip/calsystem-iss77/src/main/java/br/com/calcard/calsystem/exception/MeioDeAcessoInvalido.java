package br.com.calcard.calsystem.exception;

public class MeioDeAcessoInvalido extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2221412309754059026L;

	public MeioDeAcessoInvalido(String mensagem) {
		super(mensagem);
	}

}
