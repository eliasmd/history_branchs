package br.com.calcard.calsystem.service;

import br.com.calcard.calsystem.entity.proposta.Proposta;
import br.com.calcard.calsystem.interfaces.IMotorCredito;

public class IntegracaoMotorCreditoService implements IMotorCredito {

	@Override
	public void doEnviarPropostaMotorCredito(Proposta proposta) {

	}

}
