package br.com.calcard.calsystem.helper;

import java.util.ArrayList;
import java.util.List;

import br.com.calcard.calframework.exception.NomeException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calsystem.dto.proposta.ReferenciaDTO;
import br.com.calcard.calsystem.entity.proposta.PropostaReferencia;
import br.com.calcard.calsystem.entity.proposta.Telefone;
import br.com.calcard.calsystem.enums.PropostaEnum.TipoTelefoneEnum;
import br.com.calcard.calsystem.exception.TelefoneException;
import br.com.calcard.calsystem.exception.proposta.ReferenciaException;

public class ReferenciasPropostaHelper {

	public List<PropostaReferencia> doCarregarReferencias(
			List<ReferenciaDTO> referenciasDTO) throws ReferenciaException {

		List<PropostaReferencia> referencias = new ArrayList<PropostaReferencia>();

		this.doValidarReferencias(referenciasDTO);

		for (ReferenciaDTO referencia : referenciasDTO) {

			PropostaReferencia dadosReferencia = new PropostaReferencia();
			dadosReferencia.setNome(referencia.getNome());
			dadosReferencia.setGrauParentesco(referencia
					.getGrauParentescoEnum());

			dadosReferencia.setTelefone(new Telefone(referencia.getTelefone()
					.getDddEnum(), referencia.getTelefone().getNumero(),
					referencia.getTelefone().getRamal(),
					TipoTelefoneEnum.REFERENCIA));

			referencias.add(dadosReferencia);

		}

		return referencias;

	}

	private void doValidarReferencias(List<ReferenciaDTO> referencias)
			throws ReferenciaException {

		if (referencias == null || referencias.size() < 2)
			throw new ReferenciaException(
					"Quantidade de referencias m�nimas n�o informadas!");

		for (ReferenciaDTO referencia : referencias) {

			if (referencia.getGrauParentescoEnum() == null)
				throw new ReferenciaException(
						"Grau de parentesco n�o informado!");

			try {
				new TelefonePropostaHelper().doValidarTelefone(referencia
						.getTelefone());
			} catch (TelefoneException e) {
				throw new ReferenciaException("Telefone inv�lido!", e);
			}

			try {
				CalsystemUtil.doValidarNome(referencia.getNome());
			} catch (NomeException e) {
				throw new ReferenciaException("Nome inválido!", e);
			}

		}

	}

}
