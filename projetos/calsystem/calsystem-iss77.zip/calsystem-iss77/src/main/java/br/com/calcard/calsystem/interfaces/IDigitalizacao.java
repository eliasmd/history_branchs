package br.com.calcard.calsystem.interfaces;

import java.io.File;
import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.exception.documento.DigitalizacaoException;

public interface IDigitalizacao {

	public File doConsultarArquivoRede(String nomeArquivo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public String doConverterBase64(String nomeArquivo)
			throws DigitalizacaoException, CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public void doDescartarArquivo(String nomeDocumento)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public List<DocumentoDigitalizadoDTO> doGerarMiniaturas(String nomeArquivo,
			String localArquivo, String extensaoArquivo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, ServiceException;

	public void doDescartarDocumentos(String nomeDocumento)
			throws CalsystemNoDataFoundException, CalsystemInvalidArgumentException;

}
