package br.com.calcard.calsystem.entity.proposta;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import br.com.calcard.calframework.entity.CalsystemEntity;

@Entity
@Table(name = "tbl_tipo_documento_digitalizado")
public class TipoDocumentoDigitalizado extends CalsystemEntity {

	private static final long serialVersionUID = 577922577481780544L;

	private static final String COLUNA_NOME = "nome";

	private static final String COLUNA_DESCRICAO = "descricao";

	private static final String COLUNA_DIGITALIZACAO_OBRIGATORIA = "digitalizacao_obrigatoria";

	private static final String COLUNA_DOCUMENT_TYPE = "document_type";

	@Column(name = COLUNA_NOME, length = 50, nullable = false, unique = false)
	private String nome;

	@Column(name = COLUNA_DESCRICAO, length = 200, nullable = false, unique = false)
	private String descricao;

	@Type(type = "yes_no")
	@Column(name = COLUNA_DIGITALIZACAO_OBRIGATORIA, nullable = false, unique = false)
	private Boolean digitalizacaoObrigatoria;

	@Column(name = COLUNA_DOCUMENT_TYPE, nullable = false, unique = false)
	private Integer documentType;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((descricao == null) ? 0 : descricao.hashCode());
		result = prime
				* result
				+ ((digitalizacaoObrigatoria == null) ? 0
						: digitalizacaoObrigatoria.hashCode());
		result = prime * result
				+ ((documentType == null) ? 0 : documentType.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		TipoDocumentoDigitalizado other = (TipoDocumentoDigitalizado) obj;
		if (descricao == null) {
			if (other.descricao != null)
				return false;
		} else if (!descricao.equals(other.descricao))
			return false;
		if (digitalizacaoObrigatoria == null) {
			if (other.digitalizacaoObrigatoria != null)
				return false;
		} else if (!digitalizacaoObrigatoria
				.equals(other.digitalizacaoObrigatoria))
			return false;
		if (documentType == null) {
			if (other.documentType != null)
				return false;
		} else if (!documentType.equals(other.documentType))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		return true;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Boolean getDigitalizacaoObrigatoria() {
		return digitalizacaoObrigatoria;
	}

	public void setDigitalizacaoObrigatoria(Boolean digitalizacaoObrigatoria) {
		this.digitalizacaoObrigatoria = digitalizacaoObrigatoria;
	}

	public Integer getDocumentType() {
		return documentType;
	}

	public void setDocumentType(Integer documentType) {
		this.documentType = documentType;
	}

}