package br.com.calcard.calsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calsystem.entity.Periferico;
import br.com.calcard.calsystem.interfaces.IPeriferico;
import br.com.calcard.calsystem.util.Parametro;

@Service
public class PerifericoService implements IPeriferico {

	private ICalsystemDAO daoService;

	@Autowired
	public PerifericoService(ICalsystemDAO daoService) {
		this.daoService = daoService;
	}

	public Periferico doConsultarPerifericoPorCodigo(String codigo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		if (codigo == null)
			throw new CalsystemInvalidArgumentException(
					"Código do periférico não informado!");

		return this.daoService.doGetSingleResult(
				Periferico.NQ_SELECT_PERIFERICO_BY_CODIGO, new Parametro()
						.doAddParametro("codigo", codigo).getParametros(),
				Periferico.class, true, "Periférico não encontrado!");

	}

}
