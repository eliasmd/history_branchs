package br.com.calcard.calsystem.helper;

import java.util.ArrayList;
import java.util.Arrays;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calsystem.entity.proposta.Proposta;
import br.com.calcard.calsystem.entity.proposta.PropostaIntegracao;

public class IntegracaoPropostaHelper {

	public void doVincularIntegracao(Proposta proposta,
			Integer... idsIntegracao) throws CalsystemInvalidArgumentException {

		if (proposta == null)
			throw new CalsystemInvalidArgumentException(
					"Proposta não informada!");

		if (proposta.getPropostaIntegracao() == null)
			proposta.setPropostaIntegracao(new ArrayList<PropostaIntegracao>());

		for (Integer idIntegracao : Arrays.asList(idsIntegracao))
			proposta.getPropostaIntegracao().add(
					new PropostaIntegracao(proposta, idIntegracao));

	}

}
