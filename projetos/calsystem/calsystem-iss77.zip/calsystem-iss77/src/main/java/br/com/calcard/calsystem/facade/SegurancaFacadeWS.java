package br.com.calcard.calsystem.facade;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.ws.CalsystemFacadeWS;
import br.com.calcard.calsystem.dto.MenuDTO;
import br.com.calcard.calsystem.dto.UsuarioDTO;
import br.com.calcard.calsystem.entity.Menu;
import br.com.calcard.calsystem.entity.TokenLogin;
import br.com.calcard.calsystem.entity.TokenSessao;
import br.com.calcard.calsystem.interfaces.ISeguranca;
import br.com.calcard.calsystem.util.Parametro;

@Component
public class SegurancaFacadeWS extends CalsystemFacadeWS {

	private ISeguranca segurancaService;

	@Autowired
	public SegurancaFacadeWS(ISeguranca segurancaService) {

		this.segurancaService = segurancaService;

	}

	@Transactional
	public ResponseEntity<Object> doGerarTokenLogin(String codigoPeriferico) {

		try {

			TokenLogin tokenLogin = this.segurancaService
					.doGerarTokenLogin(codigoPeriferico);

			HttpHeaders headers = new HttpHeaders();

			headers.add("tLogin", tokenLogin.getToken());

			return super.doRetornarSucessoWS(null, headers);

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	@Transactional
	public ResponseEntity<Object> doLogin(String tLogin, String login,
			String senha) {

		try {

			TokenSessao tokenSessao = this.segurancaService.doLogin(tLogin,
					login, senha);

			HttpHeaders header = new HttpHeaders();

			header.add("tSessao", tokenSessao.getToken());

			header.add("tTransacao", tokenSessao.getTokenTransacao().getToken());

			return super.doRetornarSucessoWS(
					new Parametro().doAddParametro("usuarioDTO",
							new UsuarioDTO(tokenSessao.getUsuario()))
							.getParametros(), header);

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}

	public ResponseEntity<Object> doListarMenus(String tSessao) {

		try {

			List<MenuDTO> menusDTO = new ArrayList<MenuDTO>();

			for (Menu menu : this.segurancaService.doListarMenus(tSessao))
				menusDTO.add(new MenuDTO(menu));

			return super.doRetornarSucessoWS(
					new Parametro().doAddParametro("menus", menusDTO)
							.getParametros(), new HttpHeaders());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}
}
