package br.com.calcard.calsystem.enums;

public enum MotivoNegacaoPropostaEnum {

	SCORE, //
	BIOMETRIA, //
	RESTRITIVO;

}
