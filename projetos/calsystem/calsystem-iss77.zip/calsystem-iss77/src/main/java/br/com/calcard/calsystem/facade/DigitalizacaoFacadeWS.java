package br.com.calcard.calsystem.facade;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calframework.ws.CalsystemFacadeWS;
import br.com.calcard.calsystem.dto.ProcessoDigitalizacaoDTO;
import br.com.calcard.calsystem.entity.ProcessoDigitalizacao;
import br.com.calcard.calsystem.util.Parametro;

@Component
public class DigitalizacaoFacadeWS extends CalsystemFacadeWS {

	private ICalsystemDAO daoService;

	@Autowired
	public DigitalizacaoFacadeWS(ICalsystemDAO daoService) {
		super();
		this.daoService = daoService;
	}

	public ResponseEntity<Object> doListarProcessosDigitalizacao() {

		try {

			List<ProcessoDigitalizacaoDTO> processoDigitalizacaoDTO = new ArrayList<ProcessoDigitalizacaoDTO>();

			for (ProcessoDigitalizacao processoDigitalizacao : this.daoService
					.doList(ProcessoDigitalizacao.class))
				processoDigitalizacaoDTO.add(new ProcessoDigitalizacaoDTO(
						processoDigitalizacao.getId(), processoDigitalizacao
								.getNome(), processoDigitalizacao
								.getDescricao()));

			return super.doRetornarSucessoWS(new Parametro().doAddParametro(
					"ProcessosDigitalizacao", processoDigitalizacaoDTO)
					.getParametros());

		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}
}
