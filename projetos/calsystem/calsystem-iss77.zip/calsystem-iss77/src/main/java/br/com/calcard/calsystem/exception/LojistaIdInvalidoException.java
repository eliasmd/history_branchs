package br.com.calcard.calsystem.exception;

import br.com.calcard.calframework.exception.CalsystemException;

public class LojistaIdInvalidoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4604490315091218124L;

	public LojistaIdInvalidoException(String mensagem) {
		super(mensagem);
	}

}
