package br.com.calcard.calsystem.entity.proposta;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import br.com.calcard.calframework.entity.CalsystemEntity;

@Entity
@Table(name = "tbl_documento_digitalizado")
public class DocumentoDigitalizado extends CalsystemEntity {

	private static final long serialVersionUID = -615801916310051684L;

	private static final String COLUNA_PROPOSTA = "id_proposta";

	private static final String COLUNA_ARQUIVO = "nome_arquivo";

	private static final String COLUNA_TIPO_DOCUMENTO_DIGITALIZADO = "id_tipo_documento_digitalizado";

	private static final String COLUNA_BASE64 = "base64";

	@OneToOne
	@JoinColumn(name = COLUNA_PROPOSTA, nullable = false, unique = false)
	private Proposta proposta;

	@Column(name = COLUNA_ARQUIVO, length = 50, nullable = false, unique = false)
	private String nomeArquivo;

	@OneToOne
	@JoinColumn(name = COLUNA_TIPO_DOCUMENTO_DIGITALIZADO, nullable = false, unique = false)
	private TipoDocumentoDigitalizado tipo;

	@Lob
	@Column(name = COLUNA_BASE64, nullable = false, unique = false)
	private String base64;

	public DocumentoDigitalizado() {

	}

	public DocumentoDigitalizado(Proposta proposta, String nomeArquivo,
			TipoDocumentoDigitalizado tipo, String base64) {
		super();
		this.proposta = proposta;
		this.nomeArquivo = nomeArquivo;
		this.tipo = tipo;
		this.base64 = base64;
	}

	public Proposta getProposta() {
		return proposta;
	}

	public void setProposta(Proposta proposta) {
		this.proposta = proposta;
	}

	public String getNomeArquivo() {
		return nomeArquivo;
	}

	public void setNomeArquivo(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
	}

	public TipoDocumentoDigitalizado getTipo() {
		return tipo;
	}

	public void setTipo(TipoDocumentoDigitalizado tipo) {
		this.tipo = tipo;
	}

	public String getBase64() {
		return base64;
	}

	public void setBase64(String base64) {
		this.base64 = base64;
	}

}
