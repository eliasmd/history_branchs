package br.com.calcard.calsystem.exception.voucher;

public class VoucherStatusException extends VoucherException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5371201742621138373L;

}
