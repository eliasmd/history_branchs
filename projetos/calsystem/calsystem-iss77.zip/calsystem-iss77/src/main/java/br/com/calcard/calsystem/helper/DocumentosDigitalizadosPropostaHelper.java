package br.com.calcard.calsystem.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.entity.proposta.DocumentoDigitalizado;
import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;
import br.com.calcard.calsystem.exception.documento.DigitalizacaoException;
import br.com.calcard.calsystem.exception.proposta.PropostaDocumentosDigitalizadosException;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;

public class DocumentosDigitalizadosPropostaHelper {

	private IDigitalizacao digitalizacaoService;

	public DocumentosDigitalizadosPropostaHelper(
			IDigitalizacao digitalizacaoService) {
		this.digitalizacaoService = digitalizacaoService;
	}

	public List<DocumentoDigitalizado> doCarregarDocumentosDigitalizados(
			Map<Integer, TipoDocumentoDigitalizado> tiposDocumentosExistentes,
			List<DocumentoDigitalizadoDTO> documentosDigitalizadosDTO)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, DigitalizacaoException,
			PropostaDocumentosDigitalizadosException {

		if (tiposDocumentosExistentes == null
				|| tiposDocumentosExistentes.size() == 0)
			throw new CalsystemInvalidArgumentException(
					"Tipos de documentos existentes não informados!");

		if (documentosDigitalizadosDTO == null
				|| documentosDigitalizadosDTO.size() == 0)
			throw new CalsystemInvalidArgumentException(
					"Documentos digitalizados não informados!");

		List<DocumentoDigitalizado> documentosDigitalizados = new ArrayList<DocumentoDigitalizado>();

		for (DocumentoDigitalizadoDTO documentoDigitalizado : documentosDigitalizadosDTO) {

			if (documentoDigitalizado.getIdTipoDocumento() == null)
				throw new CalsystemInvalidArgumentException(
						"Id do tipo do documento não informado!");

			if (CalsystemUtil.isNull(documentoDigitalizado.getNomeArquivo()))
				throw new CalsystemInvalidArgumentException(
						"Nome do arquivo não informado!");

			String base64 = this.digitalizacaoService
					.doConverterBase64(documentoDigitalizado.getNomeArquivo());

			if (!tiposDocumentosExistentes.containsKey(documentoDigitalizado
					.getIdTipoDocumento()))
				throw new PropostaDocumentosDigitalizadosException(
						new StringBuilder(
								"Tipo de documento definido é inválido! ID TIPO DOCUMENTO: ")
								.append(documentoDigitalizado
										.getIdTipoDocumento())
								.append(" NOME ARQUIVO: ")
								.append(documentoDigitalizado.getNomeArquivo())
								.toString());

			documentosDigitalizados.add(new DocumentoDigitalizado(null,
					documentoDigitalizado.getNomeArquivo(),
					tiposDocumentosExistentes.get(documentoDigitalizado
							.getIdTipoDocumento()), base64));

		}

		/*
		 * Verifica se todos os documentos obrigatórios foram informados
		 */
		for (Map.Entry<Integer, TipoDocumentoDigitalizado> entry : tiposDocumentosExistentes
				.entrySet()) {

			if (entry.getValue().getDigitalizacaoObrigatoria()) {

				boolean documentoObrigatorioDigitalizado = false;

				for (DocumentoDigitalizadoDTO documentoDigitalizado : documentosDigitalizadosDTO) {

					if (documentoDigitalizado.getIdTipoDocumento().equals(
							entry.getValue().getId())) {
						documentoObrigatorioDigitalizado = true;
						break;
					}

				}

				if (!documentoObrigatorioDigitalizado)
					throw new PropostaDocumentosDigitalizadosException(
							new StringBuilder(
									"Documento obrigatório não digitalizado!")
									.append(" DOCUMENTO: ")
									.append(entry.getValue().getNome())
									.toString());

			}

		}

		return documentosDigitalizados;

	}

}
