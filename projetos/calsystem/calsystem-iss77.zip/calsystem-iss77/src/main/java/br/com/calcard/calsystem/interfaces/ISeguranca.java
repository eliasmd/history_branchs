package br.com.calcard.calsystem.interfaces;

import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calsystem.entity.Menu;
import br.com.calcard.calsystem.entity.TokenLogin;
import br.com.calcard.calsystem.entity.TokenSessao;
import br.com.calcard.calsystem.exception.TokenInvalidoException;

public interface ISeguranca {

	public TokenSessao doLogin(String tLogin, String login, String senha)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, TokenInvalidoException,
			ServiceException;

	public List<Menu> doListarMenus(String tSessao)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public TokenLogin doGerarTokenLogin(String codigoPeriferico)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, ServiceException;

}
