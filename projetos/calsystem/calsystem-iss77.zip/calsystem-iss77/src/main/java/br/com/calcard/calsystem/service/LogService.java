package br.com.calcard.calsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calsystem.entity.LogTabela;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.interfaces.ILogTabela;

@Service
public class LogService implements ILogTabela {

	private ICalsystemDAO daoService;

	@Autowired
	public LogService(ICalsystemDAO daoService) {
		this.daoService = daoService;
	}

	@Override
	public LogTabela doRegistrarLogTabela(String nomeTabela, String nomeColuna,
			String de, String para, Usuario usuario, CalsystemEntity entity)
			throws CalsystemInvalidArgumentException {

		if (nomeTabela == null || nomeColuna == null || de == null
				|| para == null || usuario == null || entity == null)
			throw new CalsystemInvalidArgumentException(
					"Parâmetros obrigatórios não informados");

		LogTabela log = new LogTabela(nomeTabela, nomeColuna, de, para,
				usuario, entity.getId());

		return this.daoService.doCreate(log);

	}

}
