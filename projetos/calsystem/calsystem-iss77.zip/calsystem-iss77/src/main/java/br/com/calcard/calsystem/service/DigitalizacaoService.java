package br.com.calcard.calsystem.service;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.imageio.ImageIO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.util.CalsystemUtil;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.entity.ParametroGlobal;
import br.com.calcard.calsystem.exception.documento.DigitalizacaoException;
import br.com.calcard.calsystem.helper.DigitalizacaoHelper;
import br.com.calcard.calsystem.interfaces.IDigitalizacao;
import br.com.calcard.calsystem.interfaces.IParametroGlobal;

@Service
public class DigitalizacaoService implements IDigitalizacao {

	private String extensaoArquivo;

	private String localArquivo;

	private double proposcaoMiniatura;

	private DigitalizacaoHelper digitalizacaoHelper;

	@Autowired
	public DigitalizacaoService(IParametroGlobal parametroGlobalService)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		this.extensaoArquivo = parametroGlobalService.doConsultar(
				ParametroGlobal.PARAMETRO_FORMATO_ARQUIVO).getValorTexto();

		this.localArquivo = parametroGlobalService.doConsultar(
				ParametroGlobal.PARAMETRO_CAMINHO_DOCUMENTO_DIGITALIZADO)
				.getValorTexto();

		this.proposcaoMiniatura = parametroGlobalService
				.doConsultar(ParametroGlobal.PARAMETRO_PROPORCAO_THUMB)
				.getValorNumero().doubleValue();

		this.digitalizacaoHelper = new DigitalizacaoHelper();

	}

	@Override
	public String doConverterBase64(String nomeArquivo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, DigitalizacaoException {

		try {

			if (nomeArquivo == null)
				throw new CalsystemInvalidArgumentException(
						"Nome do arquivo não informado!");

			File arquivo = this.doConsultarArquivoRede(nomeArquivo);

			BufferedImage image = ImageIO.read(arquivo);

			String type = this.extensaoArquivo.replace(".", "");
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			ImageIO.write(image, type, out);
			byte[] bytes = out.toByteArray();

			String base64bytes = org.apache.commons.codec.binary.Base64
					.encodeBase64String(bytes);

			return new StringBuilder("data:image/jpeg").append(";base64,")
					.append(base64bytes).toString();

		} catch (IOException e) {
			throw new DigitalizacaoException(
					"Não foi possível converter a miniatura em Base64!", e);
		}

	}

	@Override
	public void doDescartarArquivo(String nomeArquivo)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		for (File arquivo : Arrays.asList(this
				.doConsultarArquivoRede(nomeArquivo)))
			arquivo.delete();

	}

	@Override
	public File doConsultarArquivoRede(String nomeArquivo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		if (CalsystemUtil.isNull(nomeArquivo))
			throw new CalsystemInvalidArgumentException(
					"Nome do arquivo não informado!");

		File file = new File(this.localArquivo + nomeArquivo);

		if (!file.exists())
			throw new CalsystemNoDataFoundException(
					new StringBuilder()
							.append("Não foi encontrado nenhum arquivo na rede com o nome informado!")
							.append(" NOME ARQUIVO: ").append(nomeArquivo)
							.toString());

		return file;

	}

	@Override
	public List<DocumentoDigitalizadoDTO> doGerarMiniaturas(String nomeArquivo,
			String localArquivo, String extensaoArquivo)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException, ServiceException {

		if (nomeArquivo == null)
			throw new CalsystemInvalidArgumentException(
					"Nome do arquivo não informado!");

		File[] listaArquivos = this.digitalizacaoHelper.doListarArquivosRede(
				localArquivo, nomeArquivo, extensaoArquivo);

		List<DocumentoDigitalizadoDTO> documentos = new ArrayList<DocumentoDigitalizadoDTO>();

		for (int i = 0; i < listaArquivos.length; i++) {

			File arquivo = this.doConsultarArquivoRede(listaArquivos[i]
					.getName());

			String miniatura = this.digitalizacaoHelper.doCriarThm(arquivo,
					this.proposcaoMiniatura, this.extensaoArquivo);

			documentos.add(new DocumentoDigitalizadoDTO(listaArquivos[i]
					.getName(), null, miniatura));

		}

		return documentos;

	}

	@Override
	public void doDescartarDocumentos(String nomeDocumento)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		File arquivo = this.doConsultarArquivoRede(nomeDocumento);

		arquivo.delete();

	}
}
