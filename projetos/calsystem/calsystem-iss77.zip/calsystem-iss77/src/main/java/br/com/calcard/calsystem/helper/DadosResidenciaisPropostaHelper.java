package br.com.calcard.calsystem.helper;

import br.com.calcard.calsystem.dto.EnderecoDTO;
import br.com.calcard.calsystem.dto.proposta.DadosResidenciaisDTO;
import br.com.calcard.calsystem.entity.proposta.Endereco;
import br.com.calcard.calsystem.entity.proposta.PropostaDadosResidenciais;
import br.com.calcard.calsystem.entity.proposta.Telefone;
import br.com.calcard.calsystem.enums.PropostaEnum.TipoTelefoneEnum;
import br.com.calcard.calsystem.exception.EnderecoException;
import br.com.calcard.calsystem.exception.TelefoneException;
import br.com.calcard.calsystem.exception.proposta.DadosResidenciaisException;

public class DadosResidenciaisPropostaHelper {

	public PropostaDadosResidenciais doCarregarDadosResidenciais(
			DadosResidenciaisDTO dadosResidenciaisDTO)
			throws DadosResidenciaisException {

		PropostaDadosResidenciais dadosResidenciais = new PropostaDadosResidenciais();

		this.doValidarDadosResidenciais(dadosResidenciaisDTO);

		dadosResidenciais.setAnosResidencia(dadosResidenciaisDTO
				.getAnosResidencia());

		dadosResidenciais.setMesesResidencia(dadosResidenciaisDTO
				.getMesesResidencia());

		dadosResidenciais.setTipoResidencia(dadosResidenciaisDTO
				.getTipoResidenciaEnum());

		dadosResidenciais.setTelefone(new Telefone(dadosResidenciaisDTO
				.getTelefoneResidencial().getDddEnum(), dadosResidenciaisDTO
				.getTelefoneResidencial().getNumero(), dadosResidenciaisDTO
				.getTelefoneResidencial().getRamal(),
				TipoTelefoneEnum.RESIDENCIAL));

		dadosResidenciais.setEndereco(this
				.doCarregarEnderecoResidencial(dadosResidenciaisDTO
						.getEndereco()));

		return dadosResidenciais;

	}

	private void doValidarDadosResidenciais(
			DadosResidenciaisDTO dadosResidenciais)
			throws DadosResidenciaisException {

		if (dadosResidenciais == null)
			throw new DadosResidenciaisException(
					"Dados residenciais n�o informados!");

		if (dadosResidenciais.getAnosResidencia() == null)
			throw new DadosResidenciaisException(
					"Tempo (anos) de Residencia n�o informado!");

		if (dadosResidenciais.getMesesResidencia() == null)
			throw new DadosResidenciaisException(
					"Tempo (meses) de Residencia n�o informado!");

		if (dadosResidenciais.getMesesResidencia() > 11)
			throw new DadosResidenciaisException(
					"Tempo (meses) de Residencia inv�lido! > 11");

		if (dadosResidenciais.getTipoResidenciaEnum() == null)
			throw new DadosResidenciaisException(
					"Tipo de resid�ncia n�o informada!");

		try {
			new TelefonePropostaHelper().doValidarTelefone(dadosResidenciais
					.getTelefoneResidencial());
		} catch (TelefoneException e) {
			throw new DadosResidenciaisException("Telefone inv�lido!", e);
		}

		try {
			new EnderecoPropostaHelper().doValidarEndereco(dadosResidenciais
					.getEndereco());
		} catch (EnderecoException e) {
			throw new DadosResidenciaisException(
					"Endere�o residencial inv�lido!", e);
		}

	}

	private Endereco doCarregarEnderecoResidencial(EnderecoDTO enderecoDTO) {

		Endereco endereco = new Endereco();

		endereco.setBairro(enderecoDTO.getBairro());

		endereco.setCep(enderecoDTO.getCep());

		endereco.setCidade(enderecoDTO.getCidade());

		endereco.setComplemento(enderecoDTO.getComplemento());

		endereco.setLogradouro(enderecoDTO.getLogradouro());

		endereco.setNumero(enderecoDTO.getNumero());

		endereco.setUf(enderecoDTO.getUf());

		return endereco;

	}

}
