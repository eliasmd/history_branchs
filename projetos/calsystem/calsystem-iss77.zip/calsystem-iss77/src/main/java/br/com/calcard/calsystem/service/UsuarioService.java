package br.com.calcard.calsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.Usuario;
import br.com.calcard.calsystem.interfaces.IUsuario;
import br.com.calcard.calsystem.util.Parametro;

@Service
public class UsuarioService implements IUsuario {

	private ICalsystemDAO daoService;

	@Autowired
	public UsuarioService(ICalsystemDAO daoService) {
		this.daoService = daoService;
	}

	@Override
	public List<Usuario> doListarUsuariosPorEstabelecimento(
			Integer idEstabelecimento)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		Estabelecimento estabelecimento = this.daoService.doRead(
				idEstabelecimento, Estabelecimento.class, true,
				"Estabelecimento não encontrado!",
				"ID do estabelecimento não informado!");

		return this.daoService
				.doGetResultList(
						Usuario.NQ_SELECT_USUARIOS_BY_ESTABELECIMENTO,
						new Parametro().doAddParametro("estabelecimento",
								estabelecimento).getParametros(),
						Usuario.class,
						true,
						new StringBuilder()
								.append("Nenhum usu�rio vinculado ao Estabelecimento informado! ID Estabelecimento: ")
								.append(estabelecimento.getId()).toString());

	}

	@Override
	public Usuario doConsultarByLogin(String loginUsuario)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		if (loginUsuario == null)
			throw new CalsystemInvalidArgumentException(
					"Login do usuário não informado!");

		return this.daoService.doGetSingleResult(
				Usuario.NQ_SELECT_USUARIO_BY_LOGIN, new Parametro()
						.doAddParametro("login", loginUsuario).getParametros(),
				Usuario.class, true, "Usuário não encontrado!");

	}

	@Override
	public Usuario doConsultarUsuarioPorId(Integer id)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		return this.daoService.doRead(id, Usuario.class, true,
				"Usuário não encontrado!", "ID do usuário não informado!");

	}

}
