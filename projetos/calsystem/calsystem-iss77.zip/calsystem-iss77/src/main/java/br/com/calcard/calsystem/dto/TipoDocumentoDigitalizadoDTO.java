package br.com.calcard.calsystem.dto;

import br.com.calcard.calsystem.entity.proposta.TipoDocumentoDigitalizado;

public class TipoDocumentoDigitalizadoDTO {

	private Integer id;

	private String nome;

	private Boolean digitalizacaoObrigatoria;

	public static TipoDocumentoDigitalizadoDTO toDTO(
			TipoDocumentoDigitalizado tipoDocumentoDigitalizado) {

		return new TipoDocumentoDigitalizadoDTO(
				tipoDocumentoDigitalizado.getId(),
				tipoDocumentoDigitalizado.getNome(),
				tipoDocumentoDigitalizado.getDigitalizacaoObrigatoria());

	}

	public TipoDocumentoDigitalizadoDTO() {

	}

	public TipoDocumentoDigitalizadoDTO(Integer id, String nome,
			Boolean digitalizacaoObrigatoria) {
		super();
		this.id = id;
		this.nome = nome;
		this.digitalizacaoObrigatoria = digitalizacaoObrigatoria;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Boolean getDigitalizacaoObrigatoria() {
		return digitalizacaoObrigatoria;
	}

	public void setDigitalizacaoObrigatoria(Boolean digitalizacaoObrigatoria) {
		this.digitalizacaoObrigatoria = digitalizacaoObrigatoria;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
