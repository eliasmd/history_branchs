package br.com.calcard.calsystem.job;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import br.com.calcard.calframework.job.CalsystemJob;

public class JobEnvioPropostaMotorFraude extends CalsystemJob {

	// private PropostaServiceFacade propostaServiceFacade;

	@Override
	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException {
		// try {
		//
		// // this.propostaServiceFacade.doEnviarPropostasMotorFraude();
		//
		// } catch (CalsystemDAOException | IntegracaoFraudeException e) {
		//
		// super.logger.error(ExceptionUtils.getFullStackTrace(e));
		//
		// }
	}

}
