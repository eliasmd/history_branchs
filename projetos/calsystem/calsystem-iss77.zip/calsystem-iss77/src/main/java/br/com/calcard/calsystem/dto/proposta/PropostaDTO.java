package br.com.calcard.calsystem.dto.proposta;

import java.util.Date;
import java.util.List;

import br.com.calcard.calframework.util.CustomJsonDateSerializer;
import br.com.calcard.calsystem.dto.DocumentoDigitalizadoDTO;
import br.com.calcard.calsystem.enums.StatusPropostaEnum;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class PropostaDTO {

	private Integer numeroProposta;

	private StatusPropostaEnum status;

	private Integer idEstabelecimento;

	private Integer idUsuario;

	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date dataRegistro;

	private DadosBasicosDTO dadosBasicos;

	private DadosComplementaresDTO dadosComplementares;

	private OutrosDocumentosDTO outrosDocumentos;

	private DadosResidenciaisDTO dadosResidenciais;

	private DadosProfissionaisDTO dadosProfissionais;

	private List<ReferenciaDTO> referencias;

	private List<DocumentoDigitalizadoDTO> documentosDigitalizados;

	private String fotoBase64;

	public PropostaDTO() {

	}

	public Integer getIdEstabelecimento() {
		return idEstabelecimento;
	}

	public void setIdEstabelecimento(Integer idEstabelecimento) {
		this.idEstabelecimento = idEstabelecimento;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public DadosComplementaresDTO getDadosComplementares() {
		return dadosComplementares;
	}

	public void setDadosComplementares(
			DadosComplementaresDTO dadosComplementares) {
		this.dadosComplementares = dadosComplementares;
	}

	public OutrosDocumentosDTO getOutrosDocumentos() {
		return outrosDocumentos;
	}

	public void setOutrosDocumentos(OutrosDocumentosDTO outrosDocumentos) {
		this.outrosDocumentos = outrosDocumentos;
	}

	public DadosResidenciaisDTO getDadosResidenciais() {
		return dadosResidenciais;
	}

	public void setDadosResidenciais(DadosResidenciaisDTO dadosResidenciais) {
		this.dadosResidenciais = dadosResidenciais;
	}

	public DadosProfissionaisDTO getDadosProfissionais() {
		return dadosProfissionais;
	}

	public void setDadosProfissionais(DadosProfissionaisDTO dadosProfissionais) {
		this.dadosProfissionais = dadosProfissionais;
	}

	public List<ReferenciaDTO> getReferencias() {
		return referencias;
	}

	public void setReferencias(List<ReferenciaDTO> referencias) {
		this.referencias = referencias;
	}

	public DadosBasicosDTO getDadosBasicos() {
		return dadosBasicos;
	}

	public void setDadosBasicos(DadosBasicosDTO dadosBasicos) {
		this.dadosBasicos = dadosBasicos;
	}

	public StatusPropostaEnum getStatus() {
		return status;
	}

	public void setStatus(StatusPropostaEnum status) {
		this.status = status;
	}

	public Integer getNumeroProposta() {
		return numeroProposta;
	}

	public void setNumeroProposta(Integer numeroProposta) {
		this.numeroProposta = numeroProposta;
	}

	public Date getDataRegistro() {
		return dataRegistro;
	}

	public void setDataRegistro(Date dataRegistro) {
		this.dataRegistro = dataRegistro;
	}

	public List<DocumentoDigitalizadoDTO> getDocumentosDigitalizados() {
		return documentosDigitalizados;
	}

	public void setDocumentosDigitalizados(
			List<DocumentoDigitalizadoDTO> documentosDigitalizados) {
		this.documentosDigitalizados = documentosDigitalizados;
	}

	public String getFotoBase64() {
		return fotoBase64;
	}

	public void setFotoBase64(String fotoBase64) {
		this.fotoBase64 = fotoBase64;
	}

}
