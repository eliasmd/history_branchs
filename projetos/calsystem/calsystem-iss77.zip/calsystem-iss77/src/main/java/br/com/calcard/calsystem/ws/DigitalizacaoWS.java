package br.com.calcard.calsystem.ws;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calsystem.facade.DigitalizacaoFacadeWS;

@RestController
@RequestMapping("/ws/digitalizacao")
@Scope(value = "request")
public class DigitalizacaoWS extends CalsystemWS {

	private DigitalizacaoFacadeWS digitalizacaoFacadeWS;

	@Autowired
	public DigitalizacaoWS(DigitalizacaoFacadeWS digitalizacaoFacadeWS) {
		super();
		this.digitalizacaoFacadeWS = digitalizacaoFacadeWS;
	}

	@RequestMapping(value = "/listarProcessos", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doListarProcessos(
			@RequestHeader(value = "tSessao") String tSessao) {

		super.doGravarLog(tSessao);

		return this.digitalizacaoFacadeWS.doListarProcessosDigitalizacao();

	}

}
