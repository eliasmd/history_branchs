package br.com.calcard.calsystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calframework.util.CalsystemCPFUtil;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.dto.CreditRequestDTO;
import br.com.calcard.calintegrador.motorBiometria.dto.IntegracaoAvaliacaoFotoDTO;
import br.com.calcard.calintegrador.motorBiometria.enums.StatusSolicitacaoDeCredito;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorBiometria.interfaces.IMotorBiometria;
import br.com.calcard.calsystem.dto.AnaliseBiometriaDTO;
import br.com.calcard.calsystem.dto.BiometriaDTO;
import br.com.calcard.calsystem.interfaces.IBiometria;

@Service
public class BiometriaService implements IBiometria {

	private IMotorBiometria motorBiometriaService;

	@Autowired
	public BiometriaService(IMotorBiometria motorBiometriaService) {

		this.motorBiometriaService = motorBiometriaService;

	}
	
	/*
	 * Verifica se a foto est� adequada para biometria 
	 */		
	@Override
	@Transactional(rollbackFor = Exception.class)
	public void doAvaliarFoto(String fotoBase64) throws IntegracaoException,
														CalsystemInvalidArgumentException, 
														ServiceException,
														IntegracaoMotorBiometriaException {

		this.motorBiometriaService.doAvaliarFoto(fotoBase64);

	}
	
	/**
	 * Consultar avalia��o biometrica comparando o creditRequest com a base de foto do Motor de Biometria
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public AnaliseBiometriaDTO doConsultarAvaliacaoBiometrica(Integer idCreditRequest) throws CalsystemInvalidArgumentException, 
																							  ServiceException, 
																							  IntegracaoException, 
																							  IntegracaoMotorBiometriaException {
	
		IntegracaoAvaliacaoFotoDTO integracaoPooling = this.motorBiometriaService.doConsultarAnaliseComFoto(idCreditRequest);

		return doComporAnaliseBiometriaDTO(integracaoPooling);
		
	}
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public void doAlterarStatusSolicitacaoCredito(Integer idCreditRequest, 
												  StatusSolicitacaoDeCredito novoStatus,
												  String comentario) throws IntegracaoException, 
												  							CalsystemInvalidArgumentException, 
												  							ServiceException, 
												  							IntegracaoMotorBiometriaException {
		
		motorBiometriaService.doAlterarStatusSolicitacaoCredito(idCreditRequest, novoStatus, comentario);
		
	}
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public String doConsultarStatusSolicitacaoCredito(Integer idCreditRequest) throws IntegracaoException, 
																					CalsystemInvalidArgumentException, 
																					ServiceException, 
																					IntegracaoMotorBiometriaException {
		
		return motorBiometriaService.doConsultarStatusSolicitacaoCredito(idCreditRequest).getResponseDTO().getCreditrequest().getStatus();
		
	}
	
	private AnaliseBiometriaDTO doComporAnaliseBiometriaDTO(IntegracaoAvaliacaoFotoDTO integracaoAvaliacaoFotoDTO) {

		BiometriaDTO biometriaLoja = null;
		
		if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO().getCreditrequest().getCol1() != null) {
			
			CreditRequestDTO creditRequestLoja = integracaoAvaliacaoFotoDTO.getResponsePoolingDTO().getCreditrequest().getCol1().getCreditrequest();
			
			biometriaLoja = new BiometriaDTO(creditRequestLoja.getPhoto(), 
											 CalsystemCPFUtil.doDesformatarCPF(creditRequestLoja.getIdentifierCode()),
											 creditRequestLoja.getIdentification(),
											 creditRequestLoja.getSimilarity(),
											 creditRequestLoja.getName(),
											 creditRequestLoja.getInsertDate(),
											 creditRequestLoja.getId());
		}

		BiometriaDTO biometriaCadastro = null;
		
		List<BiometriaDTO> listaBiometriaFraude = new ArrayList<BiometriaDTO>();
		
		if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO().getCreditrequest().getCol2() != null ) {
				
			
			if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO().getCreditrequest().getCol2().getCustomer() != null ){
			
				CreditRequestDTO creditRequestCadastro = integracaoAvaliacaoFotoDTO.getResponsePoolingDTO().getCreditrequest().getCol2().getCustomer();
				
				biometriaCadastro = new BiometriaDTO(creditRequestCadastro.getPhoto(), 
													 CalsystemCPFUtil.doDesformatarCPF(creditRequestCadastro.getIdentifierCode()),
													 creditRequestCadastro.getIdentification(),
													 creditRequestCadastro.getSimilarity(),
													 creditRequestCadastro.getName(),
													 creditRequestCadastro.getInsertDate(),
													 creditRequestCadastro.getId());
			}
						
			if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO().getCreditrequest().getCol2().getFraud() != null ){
				
				for (CreditRequestDTO creditRequestFraude : integracaoAvaliacaoFotoDTO.getResponsePoolingDTO().getCreditrequest().getCol2().getFraud()){
				
					listaBiometriaFraude.add(new BiometriaDTO(creditRequestFraude.getPhoto(), 
															  CalsystemCPFUtil.doDesformatarCPF(creditRequestFraude.getIdentifierCode()), 
															  creditRequestFraude.getIdentification(), 
															  creditRequestFraude.getSimilarity(), 
															  creditRequestFraude.getName(),
															  creditRequestFraude.getInsertDate(),
															  creditRequestFraude.getId()));
					
				}
				
			}
			
		}

		List<BiometriaDTO> listaBiometriaSimilaresLoja = new ArrayList<BiometriaDTO>();
		
		List<BiometriaDTO> listaBiometriaSimilaresCadastro = new ArrayList<BiometriaDTO>();
		
		if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO()
				.getCreditrequest().getCol3() != null) {

			if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO()
					.getCreditrequest().getCol3().getCreditrequest_similars() != null) {
				for (int i = 0; i < integracaoAvaliacaoFotoDTO
						.getResponsePoolingDTO().getCreditrequest().getCol3()
						.getCreditrequest_similars().size(); i++) {
					
					CreditRequestDTO creditRequestSimilaresLoja = integracaoAvaliacaoFotoDTO.getResponsePoolingDTO().getCreditrequest().getCol3().getCreditrequest_similars().get(i);
					
					listaBiometriaSimilaresLoja.add(new BiometriaDTO(creditRequestSimilaresLoja.getPhoto(), 
																	 CalsystemCPFUtil.doDesformatarCPF(creditRequestSimilaresLoja.getIdentifierCode()),
																	 creditRequestSimilaresLoja.getIdentification(),
																	 creditRequestSimilaresLoja.getSimilarity(),
																	 creditRequestSimilaresLoja.getName(),
																	 creditRequestSimilaresLoja.getInsertDate(),
																	 creditRequestSimilaresLoja.getId()));
					
				}
			}

			if (integracaoAvaliacaoFotoDTO.getResponsePoolingDTO()
					.getCreditrequest().getCol3().getCustomer_similars() != null) {
				
				for (int i = 0; i < integracaoAvaliacaoFotoDTO
						.getResponsePoolingDTO().getCreditrequest().getCol3()
						.getCustomer_similars().size(); i++) {
					
					CreditRequestDTO creditRequestSimilaresCadastro = integracaoAvaliacaoFotoDTO.getResponsePoolingDTO().getCreditrequest().getCol3().getCustomer_similars().get(i);
					
					listaBiometriaSimilaresCadastro.add(new BiometriaDTO(creditRequestSimilaresCadastro.getPhoto(),
																  		 CalsystemCPFUtil.doDesformatarCPF(creditRequestSimilaresCadastro.getIdentifierCode()),
																		 creditRequestSimilaresCadastro.getIdentification(),
																		 creditRequestSimilaresCadastro.getSimilarity(),
																		 creditRequestSimilaresCadastro.getName(),
																		 creditRequestSimilaresCadastro.getInsertDate(),
																		 creditRequestSimilaresCadastro.getId()));

				}
			}

		}
		
		return new AnaliseBiometriaDTO(biometriaLoja, 
									   biometriaCadastro, 
									   listaBiometriaSimilaresLoja, 
									   listaBiometriaSimilaresCadastro,
									   listaBiometriaFraude);
		
		
	}

}
