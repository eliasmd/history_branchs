package br.com.calcard.calsystem.exception.token;

import br.com.calcard.calframework.exception.CalsystemException;

public class TokenLoginUtilizadoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -549097501273329925L;

	public TokenLoginUtilizadoException(String mensagem) {
		super(mensagem);
	}

}
