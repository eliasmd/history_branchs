package br.com.calcard.calsystem.interfaces;

import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calintegrador.motorCredito.exception.IntegracaoMotorCreditoException;
import br.com.calcard.calintegrador.processadora.exception.IntegracaoProcessadoraException;
import br.com.calcard.calsystem.dto.CartaoDTO;
import br.com.calcard.calsystem.dto.DocumentoDTO;

public interface ICartao {

	public List<CartaoDTO> doListarCartoesCadastroSenhaEDesbloqueio(String cpf,
			String numeroCartao) throws IntegracaoProcessadoraException, IntegracaoException, CalsystemInvalidArgumentException, CalsystemNoDataFoundException;

	public String doAlterarSenhaPortador(Integer idConta, 
										 String cpfPortador,
										 String senha, 
										 Integer idUsuario, 
										 String foto,
										 Integer idEstabelecimento, 
										 List<DocumentoDTO> documentoDTO) throws CalsystemInvalidArgumentException,
										 										 CalsystemNoDataFoundException, 
										 										 IntegracaoException,
										 										 ServiceException, 
										 										 IntegracaoMotorBiometriaException,
										 										 IntegracaoProcessadoraException, 
										 										 IntegracaoMotorCreditoException;

	
	public void doIniciarAlteracaoSenhaPortador(String cpfPortador) throws CalsystemNoDataFoundException, 
																							CalsystemInvalidArgumentException;
}
