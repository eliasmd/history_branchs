package br.com.calcard.calsystem.helper;

import br.com.calcard.calsystem.dto.RGDTO;
import br.com.calcard.calsystem.exception.proposta.RGException;

public class RGPropostaHelper {

	
}
