package br.com.calcard.calsystem.ws;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.interfaces.ICalsystemLog;
import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calsystem.util.Parametro;

@RestController
@RequestMapping("/ws/excecao")
@Scope(value = "request")
public class ExcecaoWS extends CalsystemWS {

	/*private IExcecao excecaoService;
	*/
	@Autowired
	public ExcecaoWS(ICalsystemLog 	logService) {
		super(logService);
		//this.excecaoService = excecaoService;
	}
	
	/**
	 * Servi�o responsavel por registrar uma excecao generica ocorrida no cliente
	 * @param requestBody
	 * @param tSessao
	 * @return
	 */
	@RequestMapping(value = "/registrarExcecaoGenerica", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> doRegistrarExcecaoGenerica(
			@RequestBody Map<String, String> requestBody,
			@RequestHeader(value = "tSessao") String tSessao) {
		
		try {
			super.logService.setTokenSessao(tSessao);
			super.doGravarLog(
					  new Parametro()
						.doAddParametro("descricao",requestBody.get("descricao"))
							.getParametros());
		
			//this.excecaoService.doRegistrarExcecaoGenerica((String) requestBody.get("descricao"));
			
			return super.doRetornarSucessoWS();
			
		/*} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);*/
		} catch(Exception e){
			return super.doRetornarErroWS(e);
		}

	}
	

	

}
