package br.com.calcard.calsystem.exception.token;

import br.com.calcard.calframework.exception.CalsystemException;

public class TokenLoginNaoEncontradoException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 701982507989438659L;

	public TokenLoginNaoEncontradoException(String mensagem) {
		super(mensagem);
	}

}
