package br.com.calcard.calsystem.exception.proposta;

import br.com.calcard.calframework.exception.CalsystemException;

public class DadosComplementaresException extends CalsystemException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 370960252369670129L;

	public DadosComplementaresException(String mensagem) {
		super(mensagem);
	}

	public DadosComplementaresException(String mensagem, Throwable e) {
		super(mensagem, e);
	}

}
