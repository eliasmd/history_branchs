package br.com.calcard.calsystem.exception.voucher;

public class VoucherEContaDiferentesException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8180594980911243007L;

}
