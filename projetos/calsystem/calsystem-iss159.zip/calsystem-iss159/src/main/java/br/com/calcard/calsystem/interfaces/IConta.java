package br.com.calcard.calsystem.interfaces;

import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.processadora.exception.IntegracaoProcessadoraException;
import br.com.calcard.calsystem.dto.ContaDTO;

public interface IConta {

	public List<ContaDTO> doConsultarContas(String cpf, Integer idConta) throws IntegracaoProcessadoraException, IntegracaoException, CalsystemInvalidArgumentException;
		
}
