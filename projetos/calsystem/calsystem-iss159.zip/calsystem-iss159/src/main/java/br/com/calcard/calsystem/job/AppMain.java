package br.com.calcard.calsystem.job;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppMain {
	public static void main(String args[]) {
		new ClassPathXmlApplicationContext("quartz-context.xml");
	}

}
