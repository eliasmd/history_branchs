package br.com.calcard.calsystem.interfaces;

public interface ILojista {

}
