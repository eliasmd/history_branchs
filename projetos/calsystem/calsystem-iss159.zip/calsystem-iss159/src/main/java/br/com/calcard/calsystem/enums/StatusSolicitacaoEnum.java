package br.com.calcard.calsystem.enums;

public enum StatusSolicitacaoEnum {
	
	TODOS(0, "TODOS", "Todos os status."),
	APROVADA(1, "APROVADO", "Solicita��o aprovada."),
	NEGADA(2, "NEGADO", "Solicita��o negada."),
	PENDENTE(3, "PENDENTE", "Solicita��o na fila para an�lise."),
	EM_ANALISE(4, "EM ANALISE", "Solicita��o sendo analisada.");
	
	private Integer id;
	
	private String codigo;
	
	private String descricao;
	
	private StatusSolicitacaoEnum(Integer id, String codigo, String descricao) {		
		this.id 		= id;
		this.codigo 	= codigo;
		this.descricao 	= descricao;
	}

	public Integer getId() {
		return id;
	}

	public String getDescricao() {
		return descricao;
	}

	public String getCodigo() {
		return codigo;
	}	
	
}
