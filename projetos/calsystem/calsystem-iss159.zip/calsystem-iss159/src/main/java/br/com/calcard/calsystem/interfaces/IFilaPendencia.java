package br.com.calcard.calsystem.interfaces;

import java.util.List;

import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.service.ServiceException;
import br.com.calcard.calintegrador.exception.IntegracaoException;
import br.com.calcard.calintegrador.motorBiometria.exception.IntegracaoMotorBiometriaException;
import br.com.calcard.calsystem.dto.AnalisePendenciaAlteracaoSenhaDTO;
import br.com.calcard.calsystem.dto.AnalisePendenciaDTO;
import br.com.calcard.calsystem.dto.PendenciaAlteracaoSenhaDTO;
import br.com.calcard.calsystem.entity.AlteracaoSenha;
import br.com.calcard.calsystem.entity.AnalisePendenciaAlteracaoSenha;
import br.com.calcard.calsystem.entity.Estabelecimento;
import br.com.calcard.calsystem.entity.MotivoNegacaoPendencia;
import br.com.calcard.calsystem.entity.Usuario;

public interface IFilaPendencia {

	public List<String> doListarStatusFilaDePendencia();

	public List<AlteracaoSenha> doListarFilaDePendencia(String status,
			String cpf) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public AnalisePendenciaAlteracaoSenha doAnalisarPendencia(AnalisePendenciaDTO analisePendenciaDTO) throws CalsystemInvalidArgumentException, 
																											  CalsystemNoDataFoundException,
																											  ServiceException;

	public List<AnalisePendenciaAlteracaoSenha> doCarregarAnaliseIniciada(List<AlteracaoSenha> listaAlteracaoSenhaDTO) throws CalsystemNoDataFoundException,
																															  CalsystemInvalidArgumentException;


	public AlteracaoSenha doListarDocumentosAvaliacao(Integer idAlteracaoSenha)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public void doAprovarPendencia(Integer idAlteracaoSenha) throws CalsystemInvalidArgumentException, 
																	CalsystemNoDataFoundException, 
																	IntegracaoException, 
																	ServiceException, 
																	IntegracaoMotorBiometriaException;

	public List<AlteracaoSenha> doListarAlteracoesSenha(String status, 
													    String cpf) throws CalsystemNoDataFoundException,
																		   CalsystemInvalidArgumentException;

	public AlteracaoSenha doConsultarPendenciaAlteracaoSenha(
			Integer idPendencia) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public PendenciaAlteracaoSenhaDTO doComporPendenciaAlteracaoSenhaDTO(AlteracaoSenha pendenciaAlteracaoSenha) throws CalsystemInvalidArgumentException;

	public AnalisePendenciaAlteracaoSenhaDTO doIniciarAnalisePendenciaAlteracaoSenha(Integer idPendencia, 
																				     Usuario analista) throws CalsystemNoDataFoundException, 
																								 			  CalsystemInvalidArgumentException, 
																								 			  ServiceException, 
																								 			  IntegracaoException, 
																								 			  IntegracaoMotorBiometriaException;
	
	public AlteracaoSenha doRegistrarPendenciaAlteracaoSenha(Estabelecimento estabelecimento, 
														  	 Usuario operador, 
														  	 Integer idConta,
														  	 String cpfPortador,
														  	 String senha,
														  	 Integer idCreditRequest) throws CalsystemNoDataFoundException, 
														  	 								 CalsystemInvalidArgumentException;
	
	public void doNegarPendenciaAlteracaoSenha(Integer idPendencia,
											   String parecer,
											   Integer idMotivo) throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException, IntegracaoException, ServiceException, IntegracaoMotorBiometriaException;
	
	public List<MotivoNegacaoPendencia> doListarMotivosNegacaoAlteracaoSenha() throws CalsystemNoDataFoundException, 
																					  CalsystemInvalidArgumentException;
	
	
	public List<AlteracaoSenha> doListarFilaDePendencia(String status, 
														String cpf,
														boolean validarRetornoNull, 
														String mensagemRetornoNull) throws CalsystemNoDataFoundException,
																						   CalsystemInvalidArgumentException;

}
