package br.com.calcard.calsystem.ws;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.calcard.calframework.exception.CalsystemException;
import br.com.calcard.calframework.interfaces.ICalsystemLog;
import br.com.calcard.calframework.ws.CalsystemWS;
import br.com.calcard.calsystem.dto.AlteracaoSenhaRequestDTO;
import br.com.calcard.calsystem.dto.CartaoDTO;
import br.com.calcard.calsystem.interfaces.ICartao;
import br.com.calcard.calsystem.util.Parametro;

@RestController
@RequestMapping("/ws/cartoes")
@Scope(value="request")
public class CartaoWS extends CalsystemWS {

	private ICartao cartaoService;

	@Autowired
	public CartaoWS(ICartao 		cartaoService,
			  ICalsystemLog 			logService) {
		
super(logService);

		this.cartaoService = cartaoService;
	}

	@RequestMapping(value = "", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doListar(@RequestHeader(value = "tSessao") String tSessao,
										   @RequestParam(value = "cpf", required = false) String cpf,
										   @RequestParam(value = "numeroCartao", required = false) String numeroCartao) {
		
		try {
			
			super.logService.setTokenSessao(tSessao);
			
			super.doGravarLog(new Parametro().doAddParametro("cpf", cpf)
									.doAddParametro("numeroCartao", numeroCartao).getParametros());
	
			List<CartaoDTO> cartoesDTO = this.cartaoService.doListarCartoesCadastroSenhaEDesbloqueio(cpf, numeroCartao);
			
			 return super.doRetornarSucessoWS(new Parametro().doAddParametro("cartoes", cartoesDTO).getParametros());
			 	
		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
			
		} catch (Exception e) {
			return super.doRetornarErroWS(e);
		}

	}
	
	@RequestMapping(value = "/senha/iniciarAlteracao", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> doIniciarAlteracaoSenha(
			@RequestParam(value = "cpfPortador", required = true) String cpfPortador,
			@RequestHeader(value = "tSessao") String tSessao) {
		try {
			super.logService.setTokenSessao(tSessao);
			super.doGravarLog(
					new Parametro().doAddParametro("cpfPortador", cpfPortador)
								   .getParametros());

			this.cartaoService.doIniciarAlteracaoSenhaPortador(cpfPortador);

			return super.doRetornarSucessoWS();

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		}
	}

	@RequestMapping(value = "/senha", method = RequestMethod.PUT, produces = "application/json")
	public ResponseEntity<Object> doAlterarSenha(
			@RequestParam(value = "idConta", required = true) Integer idConta,
			@RequestParam(value = "cpfPortador", required = true) String cpfPortador,
			@RequestBody AlteracaoSenhaRequestDTO body,
			@RequestHeader(value = "tSessao") String tSessao) {
		try {
			
			super.logService.setTokenSessao(tSessao);
			
			super.doGravarLog(new Parametro().doAddParametro("idConta", idConta)
							.doAddParametro("cpfPortador", cpfPortador)
							.doAddParametro("AlteracaoSenhaRequestDTO", body)
							.getParametros());

			String respostaMotorCredito = this.cartaoService.doAlterarSenhaPortador(idConta, 
																				    cpfPortador,
																				    body.getSenha(), 
																				    body.getIdUsuario(), 
																				    body.getFoto(),
																				    body.getIdEstabelecimento(), 
																				    body.getDocumentos());

			return super.doRetornarSucessoWS(new Parametro().doAddParametro("resposta", respostaMotorCredito).getParametros());

		} catch (CalsystemException e) {
			return super.doRetornarErroWS(e);
		}
	}

}
