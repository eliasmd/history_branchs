package br.com.calcard.calframework.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;
import br.com.calcard.calframework.interfaces.ICalsystemDAO;

@Service
public class CalsystemDAOService implements ICalsystemDAO {

	@PersistenceContext(unitName = "entityManager")
	protected EntityManager em;

	public CalsystemDAOService() {

	}

	public <T extends CalsystemEntity> T doCreate(T entity)
			throws CalsystemInvalidArgumentException {

		return this.doCreate(entity, null);

	}

	public <T extends CalsystemEntity> T doCreate(T entity,
			String mensagemArgumentoNull)
			throws CalsystemInvalidArgumentException {

		final String MENSAGEM_DEFAULT = "Entidade não informada!";

		if (entity == null)
			throw new CalsystemInvalidArgumentException(new StringBuilder(
					mensagemArgumentoNull == null ? MENSAGEM_DEFAULT
							: mensagemArgumentoNull).toString());

		Date data = new Date();

		((CalsystemEntity) entity).setDataAtualizacao(data);
		((CalsystemEntity) entity).setDataRegistro(data);

		this.em.persist(entity);

		return entity;

	}

	public <T extends CalsystemEntity> T doRead(Integer id, Class<T> clazz)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		return this.doRead(id, clazz, false, null);

	}

	public <T extends CalsystemEntity> T doRead(Integer id, Class<T> clazz,
			boolean validarRetornoNull, String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		return this.doRead(id, clazz, validarRetornoNull, mensagemRetornoNull,
				null);

	}

	public <T extends CalsystemEntity> T doRead(Integer id, Class<T> clazz,
			boolean validarRetornoNull, String mensagemRetornoNull,
			String mensagemIdNull) throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		final String MENSAGEM_DEFAUL_ID = "ID da entidade não informado!";

		final String MENSAGEM_DEFAUL_RETORNO = "Nenhum registro encontrado!";

		if (clazz == null)
			throw new CalsystemInvalidArgumentException(new StringBuilder(
					"Parâmetros inválidos!").append(" CLASSE: ").append(clazz)
					.append(" ID: ").append(id).toString());

		if (id == null)
			throw new CalsystemInvalidArgumentException(
					mensagemIdNull == null ? MENSAGEM_DEFAUL_ID
							: mensagemIdNull);

		T entity = this.em.find(clazz, id);

		if (validarRetornoNull && entity == null)
			throw new CalsystemNoDataFoundException(new StringBuilder(
					mensagemRetornoNull == null ? MENSAGEM_DEFAUL_RETORNO
							: mensagemRetornoNull).append(" CLASSE: ")
					.append(clazz).append(" ID: ").append(id).toString());

		return entity;
	}

	@Override
	public <T extends CalsystemEntity> T doUpdate(T entity)
			throws CalsystemInvalidArgumentException {

		return this.doUpdate(entity, null);

	}

	@Override
	public <T extends CalsystemEntity> T doUpdate(T entity,
			String mensagemArgumentoNull)
			throws CalsystemInvalidArgumentException {

		final String MENSAGEM_DEFAULT = "Entidade não informada!";

		if (entity == null)
			throw new CalsystemInvalidArgumentException(new StringBuilder(
					mensagemArgumentoNull == null ? MENSAGEM_DEFAULT
							: mensagemArgumentoNull).toString());

		((CalsystemEntity) entity).setDataAtualizacao(new Date());

		return this.em.merge(entity);

	}

	@Override
	public void doDelete(Object entity)
			throws CalsystemInvalidArgumentException {

		this.doDelete(entity, null);

	}

	@Override
	public void doDelete(Object entity, String mensagemArgumentoNull)
			throws CalsystemInvalidArgumentException {

		final String MENSAGEM_DEFAULT = "Entidade não informada!";

		if (entity == null)
			throw new CalsystemInvalidArgumentException(new StringBuilder(
					mensagemArgumentoNull == null ? MENSAGEM_DEFAULT
							: mensagemArgumentoNull).toString());

		entity = this.em.merge(entity);

		this.em.remove(entity);

	}

	@Override
	public <T extends CalsystemEntity> List<T> doList(Class<T> entity)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		return this.doList(entity, false, null);

	}

	@Override
	public <T extends CalsystemEntity> List<T> doList(Class<T> entity,
			boolean validarRetornoNull, String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		final String MENSAGEM_DEFAULT = "Nenhum registro encontrado!";

		if (entity == null)
			throw new CalsystemInvalidArgumentException(new StringBuilder(
					"Classe não informada para pesquisa!").toString());

		CriteriaQuery<T> cq = this.em.getCriteriaBuilder().createQuery(entity);

		cq.select(cq.from(entity));

		List<T> listaRetorno = this.em.createQuery(cq).getResultList();

		if (validarRetornoNull
				&& (listaRetorno == null || listaRetorno.size() == 0))
			throw new CalsystemNoDataFoundException(
					mensagemRetornoNull == null ? MENSAGEM_DEFAULT
							: mensagemRetornoNull);

		return listaRetorno;

	}

	@Override
	public <T extends CalsystemEntity> Map<Integer, T> doListAsMap(
			Class<T> entity) throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		return this.doListAsMap(entity, false, null);

	}

	@Override
	public <T extends CalsystemEntity> Map<Integer, T> doListAsMap(
			Class<T> entity, boolean validarRetornoNull,
			String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		List<T> resultadoList = this.doList(entity, validarRetornoNull,
				mensagemRetornoNull);

		Map<Integer, T> resultadoMap = new HashMap<Integer, T>();

		for (T resultado : resultadoList)
			resultadoMap.put(resultado.getId(), resultado);

		return resultadoMap;
	}

	@Override
	public <T extends CalsystemEntity> T doGetSingleResult(String namedQuery,
			Map<String, Object> parametros, Class<T> clazz)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		return this.doGetSingleResult(namedQuery, parametros, clazz, false,
				null);

	}

	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public <T extends CalsystemEntity> T doGetSingleResult(String namedQuery,
			Map<String, Object> parametros, Class<T> clazz,
			boolean validarRetornoNull, String mensagemRetornoNull)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException {

		final String MENSAGEM_DEFAULT = new StringBuilder(
				"Nenhum registro encontrado!").append(" QUERY: ")
				.append(namedQuery).toString();

		try {

			if (clazz == null)
				throw new CalsystemInvalidArgumentException(
						"Classe não informada!");

			Query q = this.em.createNamedQuery(namedQuery, clazz);

			if (parametros != null) {
				Iterator it = parametros.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry parametro = (Map.Entry) it.next();
					q.setParameter((String) parametro.getKey(),
							parametro.getValue());
				}
			}

			return (T) q.getSingleResult();

		} catch (NoResultException e) {

			if (validarRetornoNull)
				throw new CalsystemNoDataFoundException(
						mensagemRetornoNull == null ? MENSAGEM_DEFAULT
								: mensagemRetornoNull);

			return null;

		}
	}

	@Override
	public <T extends CalsystemEntity> List<T> doGetResultList(
			String namedQuery, Map parametros, Class<T> clazz)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		return this.doGetResultList(namedQuery, parametros, clazz, false, null);
	}

	@Override
	public <T extends CalsystemEntity> List<T> doGetResultList(
			String namedQuery, Map parametros, Class<T> clazz,
			boolean validarRetornoNull, String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		final String MENSAGEM_DEFAULT = new StringBuilder(
				"Nenhum registro encontrado!").append(" QUERY: ")
				.append(namedQuery).toString();

		if (clazz == null)
			throw new CalsystemInvalidArgumentException("Classe não informada!");

		Query q = this.em.createNamedQuery(namedQuery, clazz);

		if (parametros != null) {
			Iterator it = parametros.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry parametro = (Map.Entry) it.next();
				q.setParameter((String) parametro.getKey(),
						parametro.getValue());
			}
		}

		List<T> resultado = q.getResultList();

		if (validarRetornoNull && (resultado == null || resultado.size() == 0))
			throw new CalsystemNoDataFoundException(
					mensagemRetornoNull == null ? MENSAGEM_DEFAULT
							: mensagemRetornoNull);

		return resultado;

	}

	@Override
	public <T extends CalsystemEntity> Criteria doGetCriteria(Class<T> clazz) {

		return ((Session) em.getDelegate()).createCriteria(clazz);

	}

	@Override
	public <T extends CalsystemEntity> List<T> doList(Criteria criteria)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		return this.doList(criteria, false, null);
	}

	@Override
	@SuppressWarnings("unchecked")
	public <T extends CalsystemEntity> List<T> doList(Criteria criteria,
			boolean validarRetornoNull, String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException {

		final String MENSAGEM_DEFAULT = "Nenhum registro encontrado!";

		if (criteria == null)
			throw new CalsystemInvalidArgumentException(
					"Criteria não informada!");

		List<T> resultado = criteria.list();

		if (validarRetornoNull && (resultado == null || resultado.size() == 0))
			throw new CalsystemNoDataFoundException(
					mensagemRetornoNull == null ? MENSAGEM_DEFAULT
							: mensagemRetornoNull);

		return resultado;

	}
}
