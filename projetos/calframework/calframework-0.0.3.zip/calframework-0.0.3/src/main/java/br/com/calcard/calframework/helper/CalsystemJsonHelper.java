package br.com.calcard.calframework.helper;

import java.io.IOException;

import br.com.calcard.calframework.service.ServiceException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class CalsystemJsonHelper {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object doConverterDeJson(String json, Class clazz)
			throws ServiceException {

		try {

			ObjectMapper conversorJson = new ObjectMapper();

			return conversorJson.readValue(json, clazz);

		} catch (IOException e) {
			throw new ServiceException(
					new StringBuilder()
							.append("Não foi possível realizar a conversão do JSON enviado! JSON: ")
							.append(json).append(" CLASSE: ")
							.append(clazz.getName()).toString(), e);
		}

	}

	public static String doConverterParaJson(Object obj)
			throws ServiceException {

		try {

			ObjectMapper conversorJson = new ObjectMapper();

			return conversorJson.writeValueAsString(obj);

		} catch (IOException e) {
			throw new ServiceException(
					new StringBuilder()
							.append("Não foi possível realizar a conversão para JSON do objeto enviado! OBJETO: ")
							.append(obj).toString(), e);
		}

	}

}
