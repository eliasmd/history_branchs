package br.com.calcard.calframework.service;

import br.com.calcard.calframework.exception.CalsystemException;

public class ServiceException extends CalsystemException {

	private static final long serialVersionUID = -6612358651262155294L;

	public ServiceException(String mensagem, Throwable cause) {
		super(mensagem, cause);
	}

	public ServiceException(String mensagem) {
		super(mensagem);
	}

	public ServiceException(Throwable cause) {
		super(cause);
	}

}
