package br.com.calcard.calframework.exception;

public class CalsystemException extends Exception {

	private static final long serialVersionUID = -562564224714948111L;

	public CalsystemException(String message) {
		super(message);
	}

	public CalsystemException(String message, Throwable cause) {
		super(message, cause);
	}

	public CalsystemException(Throwable cause) {
		super(cause);
	}

}
