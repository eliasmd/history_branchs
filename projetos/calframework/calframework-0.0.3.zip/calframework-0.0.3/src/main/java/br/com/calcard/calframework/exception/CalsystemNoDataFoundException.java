package br.com.calcard.calframework.exception;

public class CalsystemNoDataFoundException extends CalsystemDAOException {

	private static final long serialVersionUID = -8074147047068791302L;

	public CalsystemNoDataFoundException(String mensagem) {
		super(mensagem);
	}

}
