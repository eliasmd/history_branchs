package br.com.calcard.calframework.interfaces;

import javax.persistence.EntityManager;

public interface ICalsystemEntityManager {

	public EntityManager doGetEntityManager();

}
