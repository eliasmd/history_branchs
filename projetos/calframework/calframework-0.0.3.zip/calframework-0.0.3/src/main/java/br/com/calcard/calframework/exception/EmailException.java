package br.com.calcard.calframework.exception;

public class EmailException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6418948466836849218L;

	public EmailException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
