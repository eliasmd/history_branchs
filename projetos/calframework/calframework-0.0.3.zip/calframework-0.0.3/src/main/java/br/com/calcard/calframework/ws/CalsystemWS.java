package br.com.calcard.calframework.ws;

import java.util.Date;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import br.com.calcard.calframework.exception.CalsystemException;

import com.google.gson.Gson;

public abstract class CalsystemWS {

	static final Logger logger = LogManager.getLogger(CalsystemWS.class
			.getName());

	public CalsystemWS() {

	}

	@RequestMapping(value = "/teste", method = RequestMethod.GET, produces = "text/plain")
	public String teste() {
		return "Servi�o no ar: " + new Date();
	}

	public void doConverterNull(Map<String, String> requestBody) {

		for (Map.Entry<String, String> parametro : requestBody.entrySet()) {

			if (parametro.getValue().equals(""))
				parametro.setValue(null);

		}

	}

	public void doGravarLog(String tSessao) {

		StringBuilder log = new StringBuilder();
		Gson gson = new Gson();

		log.append("Sess�o: ").append(tSessao).append(" ");

		log.append("Servi�o: ")
				.append(Thread.currentThread().getStackTrace()[2]
						.getClassName())
				.append(".")
				.append(Thread.currentThread().getStackTrace()[2]
						.getMethodName()).append(" ");

		logger.info(log);

	}

	public void doGravarLog(String tSessao, Map<String, Object> parametros) {

		StringBuilder log = new StringBuilder();

		Gson gson = new Gson();

		log.append("Sessão: ").append(tSessao).append(" ");

		log.append("Serviço: ")
				.append(Thread.currentThread().getStackTrace()[2]
						.getClassName())
				.append(".")
				.append(Thread.currentThread().getStackTrace()[2]
						.getMethodName()).append(" ");

		log.append("Parâmetros: ");

		log.append(gson.toJson(parametros));

		logger.info(log);

	}

	public String doConverterNull(String parametro) {

		if (parametro.equals(""))
			return null;
		else
			return parametro;

	}

	public ResponseEntity<Object> doRetornarSucessoWS() {

		return doRetornarSucessoWS(null);

	}

	public ResponseEntity<Object> doRetornarSucessoWS(Map<String, Object> body) {

		HttpHeaders header = new HttpHeaders();

		header.add("codExec", "000000");

		header.add("msnExec", "Sucesso");

		return new ResponseEntity<Object>(body, header, HttpStatus.OK);
	}

	public ResponseEntity<Object> doRetornarErroWS(CalsystemException e) {

		e.printStackTrace();

		HttpHeaders header = new HttpHeaders();

		header.add("codExec", "999999");

		header.add("msnExec", e.getMessage());

		return new ResponseEntity<Object>(header, HttpStatus.OK);

	}

	public ResponseEntity<Object> doRetornarErroWS(Exception e) {

		e.printStackTrace();

		HttpHeaders header = new HttpHeaders();

		header.add("codExec", "999999");

		header.add("msnExec", e.getMessage());

		return new ResponseEntity<Object>(header, HttpStatus.OK);

	}

}
