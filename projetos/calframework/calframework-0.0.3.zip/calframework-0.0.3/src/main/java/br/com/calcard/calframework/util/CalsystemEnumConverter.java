package br.com.calcard.calframework.util;

public class CalsystemEnumConverter<T extends Enum<T>> {

	Class<T> type;

	public CalsystemEnumConverter(Class<T> type) {
		this.type = type;
	}

	public Enum<T> convert(String codigo) {

		for (Enum<T> candidate : type.getEnumConstants()) {
			if (candidate.name().equalsIgnoreCase(codigo)) {
				return candidate;
			}
		}

		throw new IllegalArgumentException("Código do Enum inválido!");
	}

}
