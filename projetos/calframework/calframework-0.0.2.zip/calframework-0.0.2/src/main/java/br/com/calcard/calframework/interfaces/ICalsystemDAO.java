package br.com.calcard.calframework.interfaces;

import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;

import br.com.calcard.calframework.entity.CalsystemEntity;
import br.com.calcard.calframework.exception.CalsystemInvalidArgumentException;
import br.com.calcard.calframework.exception.CalsystemNoDataFoundException;

public interface ICalsystemDAO {

	public <T extends CalsystemEntity> T doCreate(T entity)
			throws CalsystemInvalidArgumentException;

	public <T extends CalsystemEntity> T doCreate(T entity,
			String mensagemArgumentoNull)
			throws CalsystemInvalidArgumentException;

	public <T extends CalsystemEntity> T doRead(Integer id, Class<T> clazz)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public <T extends CalsystemEntity> T doRead(Integer id, Class<T> clazz,
			boolean validarRetornoNull, String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public <T extends CalsystemEntity> T doRead(Integer id, Class<T> clazz,
			boolean validarRetornoNull, String mensagemRetornoNull,
			String mensagemIdNull) throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public <T extends CalsystemEntity> T doUpdate(T entity)
			throws CalsystemInvalidArgumentException;

	public <T extends CalsystemEntity> T doUpdate(T entity,
			String mensagemArgumentoNull)
			throws CalsystemInvalidArgumentException;

	public void doDelete(Object entity)
			throws CalsystemInvalidArgumentException;

	public void doDelete(Object entity, String mensagemArgumentoNull)
			throws CalsystemInvalidArgumentException;

	public <T extends CalsystemEntity> List<T> doList(Class<T> entity,
			boolean validarRetornoNull, String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public <T extends CalsystemEntity> Map<Integer, T> doListAsMap(
			Class<T> entity) throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public <T extends CalsystemEntity> Map<Integer, T> doListAsMap(
			Class<T> entity, boolean validarRetornoNull,
			String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public <T extends CalsystemEntity> T doGetSingleResult(String namedQuery,
			Map<String, Object> parametros, Class<T> clazz,
			boolean validarRetornoNull, String mensagemRetornoNull)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public <T extends CalsystemEntity> T doGetSingleResult(String namedQuery,
			Map<String, Object> parametros, Class<T> clazz)
			throws CalsystemNoDataFoundException,
			CalsystemInvalidArgumentException;

	public <T extends CalsystemEntity> List<T> doGetResultList(
			String namedQuery, Map parametros, Class<T> clazz,
			boolean validarRetornoNull, String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public <T extends CalsystemEntity> List<T> doGetResultList(
			String namedQuery, Map parametros, Class<T> clazz)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public <T extends CalsystemEntity> List<T> doList(Class<T> entity)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public <T extends CalsystemEntity> List<T> doList(Criteria criteria)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public <T extends CalsystemEntity> List<T> doList(Criteria criteria,
			boolean validarRetornoNull, String mensagemRetornoNull)
			throws CalsystemInvalidArgumentException,
			CalsystemNoDataFoundException;

	public <T extends CalsystemEntity> Criteria doGetCriteria(Class<T> clazz);

}
