package br.com.calcard.calframework.service;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.springframework.scheduling.quartz.QuartzJobBean;

@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public abstract class CalsystemJobTaskSerialService extends QuartzJobBean {

	protected abstract void executeInternal(JobExecutionContext context)
			throws JobExecutionException;

}