package br.com.calcard.calframework.job;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.scheduling.quartz.QuartzJobBean;

public abstract class CalsystemJob extends QuartzJobBean {

	protected Logger logger = LogManager.getLogger();

}
