package br.com.calcard.calframework.exception;

public class CnpjException extends Exception {

	private static final long serialVersionUID = -510457086267663262L;

	public CnpjException(String message, Throwable cause) {
		super(message, cause);
	}

	public CnpjException(String message) {
		super(message);
	}

}
