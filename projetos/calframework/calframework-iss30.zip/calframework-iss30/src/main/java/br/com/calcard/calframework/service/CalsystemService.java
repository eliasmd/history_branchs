package br.com.calcard.calframework.service;

import br.com.calcard.calframework.interfaces.ICalsystemLog;

public abstract class CalsystemService {

	protected ICalsystemLog logService;
	
	public CalsystemService(ICalsystemLog logService) {
		this.logService = logService;
	}
	
}
