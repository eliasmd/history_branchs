package br.com.calcard.calframework.interfaces;

import java.util.Map;

public interface ICalsystemLog {
	
	public void setTokenSessao(String tSessao);
	
	public String getTokenSessao();

	public void doGravarLogErro(Exception e);

	public void doGravarLog(String mensagem, Map<String, Object> parametros, String metodo);
	
	//public void doGravarLogService();
	
	//public void doGravarLogService(String mensagem);
	
	//public void doGravarLogService(Map<String, Object> parametros);
	
	public void doGravarLogService(String mensagem, Map<String, Object> parametros);
	
	
	
}
