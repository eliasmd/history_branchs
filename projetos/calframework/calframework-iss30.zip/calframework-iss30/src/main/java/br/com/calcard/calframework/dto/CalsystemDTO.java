package br.com.calcard.calframework.dto;

import br.com.calcard.calframework.helper.CalsystemJsonHelper;
import br.com.calcard.calframework.service.ServiceException;

public abstract class CalsystemDTO {

	public String toJson() throws ServiceException {

		return CalsystemJsonHelper.doConverterParaJson(this);

	}

}
