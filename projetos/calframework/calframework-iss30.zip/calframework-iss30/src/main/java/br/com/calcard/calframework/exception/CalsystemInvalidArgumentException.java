package br.com.calcard.calframework.exception;

public class CalsystemInvalidArgumentException extends CalsystemException {

	private static final long serialVersionUID = -1035918832062725899L;

	public CalsystemInvalidArgumentException(String mensagem) {
		super(mensagem);
	}

	public CalsystemInvalidArgumentException(String mensagem, Throwable cause) {
		super(mensagem, cause);
	}

}
