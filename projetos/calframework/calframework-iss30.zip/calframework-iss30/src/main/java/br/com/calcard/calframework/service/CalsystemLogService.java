package br.com.calcard.calframework.service;

import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;

import br.com.calcard.calframework.interfaces.ICalsystemLog;

import com.google.gson.Gson;

@Service
@Scope(value="request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class CalsystemLogService implements ICalsystemLog {

	private String tokenSessao;
		
	@Override
	public void doGravarLog(String mensagem,  Map<String, Object> parametros, String metodo) {
		
		StringBuilder log = new StringBuilder();
		Gson gson = new Gson();
		
		if (this.tokenSessao != null)
			log.append(";Sessão: ").append(this.tokenSessao);
		else
			log.append(";Sessão: ").append("N/A");
		
		log.append(";Método: ").append(metodo);
		
		if (mensagem != null)
			log.append(";Mensagem: ").append(mensagem);
		else 
			log.append(";Mensagem: ").append("N/A");
		
		if (parametros != null)
			log.append(";Parâmetros: ").append(gson.toJson(parametros));
		else
			log.append(";Parâmetros: ").append("N/A");
		
		LogManager.getLogger("app").info(log);		
		
	}

	@Override
	public void doGravarLogErro(Exception e) {
		
		StringBuilder log = new StringBuilder();
		
		if (this.tokenSessao != null)
			log.append(";Sessão: ").append(this.tokenSessao);
		else
			log.append(";Sessão: ").append("N/A");
		
		log.append(";").append(ExceptionUtils.getFullStackTrace(e));
		
		LogManager.getLogger("erro").error(log);	
		
	}
	
	@Override
	public void doGravarLogService(String mensagem,
								   Map<String, Object> parametros) {
		
		StringBuilder log = new StringBuilder();
		Gson gson = new Gson();
		
		if (this.tokenSessao != null)
			log.append(";Sessão: ").append(this.tokenSessao);
		else
			log.append(";Sessão: ").append("N/A");
		
		log.append(";Método: ").append(new StringBuilder(Thread.currentThread().getStackTrace()[11].getClassName())
											.append(".").append(Thread.currentThread().getStackTrace()[11].getMethodName()).toString());
		
		if (mensagem != null)
			log.append(";Mensagem: ").append(mensagem);
		else 
			log.append(";Mensagem: ").append("N/A");
		
		if (parametros != null)
			log.append(";Parâmetros: ").append(gson.toJson(parametros));
		else
			log.append(";Parâmetros: ").append("N/A");
		
		LogManager.getLogger("app").info(log);	
		
		
	}
	
//	@Override
//	public void doGravarLogService() {
//		
//		StringBuilder log = new StringBuilder();
//		
//		if (this.tokenSessao != null)
//			log.append(";Sessão: ").append(this.tokenSessao);
//		else
//			log.append(";Sessão: ").append("N/A");
//		
//		log.append(";Método: ").append(new StringBuilder(Thread.currentThread().getStackTrace()[11].getClassName())
//											.append(".").append(Thread.currentThread().getStackTrace()[11].getMethodName()).toString());
//		
//		log.append(";Mensagem: ").append("N/A");
//		
//		log.append(";Parâmetros: ").append("N/A");
//		
//		LogManager.getLogger("app").info(log);	
//		
//	}
	
//	@Override
//	public void doGravarLogService(String mensagem) {
//		
//		StringBuilder log = new StringBuilder();
//		
//		if (this.tokenSessao != null)
//			log.append(";Sessão: ").append(this.tokenSessao);
//		else
//			log.append(";Sessão: ").append("N/A");
//		
//		log.append(";Método: ").append(new StringBuilder(Thread.currentThread().getStackTrace()[11].getClassName())
//											.append(".").append(Thread.currentThread().getStackTrace()[11].getMethodName()).toString());
//		
//		if (mensagem != null)
//			log.append(";Mensagem: ").append(mensagem);
//		else 
//			log.append(";Mensagem: ").append("N/A");
//		
//		log.append(";Parâmetros: ").append("N/A");
//		
//		LogManager.getLogger("app").info(log);	
//		
//	}

//	@Override
//	public void doGravarLogService(Map<String, Object> parametros) {
//		
//		StringBuilder log = new StringBuilder();
//		Gson gson = new Gson();
//		
//		if (this.tokenSessao != null)
//			log.append(";Sessão: ").append(this.tokenSessao);
//		else
//			log.append(";Sessão: ").append("N/A");
//		
//		log.append(";Método: ").append(new StringBuilder(Thread.currentThread().getStackTrace()[11].getClassName())
//											.append(".").append(Thread.currentThread().getStackTrace()[11].getMethodName()).toString());
//		
//		log.append(";Mensagem: ").append("N/A");
//		
//		if (parametros != null)
//			log.append(";Parâmetros: ").append(gson.toJson(parametros));
//		else
//			log.append(";Parâmetros: ").append("N/A");
//		
//		LogManager.getLogger("app").info(log);	
//		
//	}
	
	public String getTokenSessao() {
		return tokenSessao;
	}

	public void setTokenSessao(String tokenSessao) {
		this.tokenSessao = tokenSessao;
	}


}
