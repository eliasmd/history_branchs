package br.com.calcard.calframework.exception;

public class CalsystemDAOException extends CalsystemException {

	private static final long serialVersionUID = 977030101683491298L;

	public CalsystemDAOException(String mensagem) {
		super(mensagem);
	}

	public CalsystemDAOException(String mensagem, Throwable causa) {
		super(mensagem, causa);
	}

}
